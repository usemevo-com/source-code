/// <reference types="vite/client" />

declare module 'mixpanel-browser'
