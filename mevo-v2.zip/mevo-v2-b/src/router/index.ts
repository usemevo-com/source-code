import { createRouter, createWebHistory } from 'vue-router'
import { storeToRefs } from 'pinia'
import { useAuthStore } from '@/stores'
import { PreloginRoutes } from '@/modules/prelogin/routes'
import { HomeRoutes } from '@/modules/home/routes'
import { CommonRoutes } from '@/modules/common/routes'
import { SettingsRoutes } from '@/modules/settings/routes'
import { BotRoutes } from '@/modules/bot/routes'
import { WidgetRoutes } from '@/modules/widget/routes'
import { OrganizationRoutes } from '@/modules/organization/routes'
import Root from '@/modules/common/pages/RootView.vue'
import { InboxRoutes } from '@/modules/v2/inbox/routes'
import { BuilderRoutes } from '@/modules/v2/builder/routes'
import { NextRoutes } from '@/modules/v3/routes'
import { VisualBuilderRoutes } from '@/modules/v3/visual-builder/routes'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    ...CommonRoutes,
    ...OrganizationRoutes,
    {
      path: '/o/:oid',
      component: Root,
      children: [...HomeRoutes, ...SettingsRoutes, ...BotRoutes, ...InboxRoutes, ...BuilderRoutes, ...NextRoutes, ...VisualBuilderRoutes]
    },
    ...PreloginRoutes,
    ...WidgetRoutes
  ]
})

router.beforeEach((to, from, next) => {
  // check every route transition process
  const authStore = useAuthStore()
  const isTargetLoading = to.path === '/loading'
  const isTargetPrelogin = typeof to.meta.prelogin !== 'undefined' && to.meta.prelogin
  const isTargetWidgetView = typeof to.meta.widget !== 'undefined' && to.meta.widget
  const isTargetBotView = to.name === 'common-bot-view'
  const { isLoggedIn } = storeToRefs(authStore)

  if (to.query.invitationCode) {
    localStorage.setItem('mevo:invitation_code', to.query.invitationCode as string)
  }

  if (to.query.plan) {
    localStorage.setItem('mevo:buy_decided', (to.query.frequency as string) || 'monthly')
  }

  // if target route is loading, just let it go
  if (isTargetLoading) {
    next()
    return
  }

  // if target route is not prelogin, persist last visited route on local storage
  if (
    !isTargetPrelogin &&
    !isTargetWidgetView &&
    to.path !== '/' &&
    to.path !== '/redirect' &&
    !isTargetBotView
  ) {
    if (Object.keys(to.query).length) {
      localStorage.setItem('mevo:last_visited_route', `${to.path}?${new URLSearchParams(to.query)}`)
    } else {
      localStorage.setItem('mevo:last_visited_route', to.path as string)
    }
  }

  // if target is neither loading nor prelogin route
  // AND
  // if user loggedin
  if (isLoggedIn.value) {
    // and if user try to go prelogin page even he is already logged in
    // it means he try to do something wrong
    // so we need to redirect him loading
    // loading will take care of it
    if (isTargetPrelogin && !to.meta.access_with_auth) {
      next('/loading')
      return
    }

    // if target is not prelogin
    // just let it go
    next()
    return
  } else {
    // and if user try to go prelogin page when he is not logged in yet
    // we just let it go
    if (isTargetPrelogin || isTargetWidgetView || isTargetBotView) {
      next()
      return
    }

    // if user try to access restricted views before logged in we need to redirect him to loading
    // loading will be take care of it
    next('/loading')
    return
  }
})

export default router
