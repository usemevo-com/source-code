import { getBot } from "@/modules/bot/services/BotService";
import type { IBot } from "@/modules/bot/types/IBot";
import { useAuthStore } from "@/stores";
import { storeToRefs } from "pinia";
import useSWRV from "swrv";
import { computed, type Ref } from "vue";
import { useRouteGlobals } from "./useRouteGlobals";

export function useBot() {
  const { bid } = useRouteGlobals();
  const authStore = useAuthStore();
  const { isLoggedIn } = storeToRefs(authStore);
  const {
    data: bot,
    mutate: refreshBot,
    isValidating,
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () =>
      isLoggedIn.value &&
      bid.value &&
      bid.value !== "0" &&
      `/bots/${bid.value}`,
    () => getBot({ id: bid.value }),
    {
      revalidateOnFocus: false,
    }
  );

  return {
    bot: computed(() => bot.value?.payload) as Ref<IBot>,
    refreshBot,
    isValidating,
  };
}
