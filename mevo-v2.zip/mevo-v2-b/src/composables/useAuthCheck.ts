import { useRouter } from "vue-router";
import { verify } from "@/modules/prelogin/services/UserService";
import { useAuthStore } from "@/stores";
import { useOrganizations } from "@/composables/useOrganizations";

export async function useAuthCheck() {
  const $router = useRouter();
  const { setLoggedIn, setUser } = useAuthStore();
  const { organizations } = useOrganizations();
  const lastVisitedRoute = localStorage.getItem("mevo:last_visited_route");
  const response = await verify();

  setTimeout(() => {
    if (response.isOk()) {
      setLoggedIn(true);
      setUser(response.value.payload);

      if (lastVisitedRoute) {
        $router.push(lastVisitedRoute as string);
      } else {
        $router.push(`/o/${organizations.value[0]._id}/home`);
      }
    } else {
      setLoggedIn(false);
      setUser({ name: "", email: "", _id: "", picture: "" });
      $router.push("/login");
    }
  }, 747);
}
