import { useAuthStore } from '@/stores'
import { useRouteGlobals } from './useRouteGlobals'
import { useOrganizations } from './useOrganizations'
import type { IOrganization } from '@/modules/organization/types/IOrganization'
import { computed, type Ref } from 'vue'

export function usePermission() {
  const { user } = useAuthStore()
  const { oid } = useRouteGlobals()
  const { organizations } = useOrganizations()

  const organization: Ref<IOrganization> = computed(
    () => organizations.value && organizations.value.find((o: IOrganization) => o._id === oid.value)
  )
  const isAdmin: Ref<boolean> = computed(() => {
    if (organization.value && organization.value.admins) {
      const match = organization.value.admins.find((a) => a._id === user._id)
      if (match) return true
    }
    return false
  })

  return {
    isAdmin,
  }
}
