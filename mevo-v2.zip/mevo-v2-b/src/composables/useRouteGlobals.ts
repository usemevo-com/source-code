import { computed, type Ref } from 'vue'
import { useRoute } from 'vue-router'

export function useRouteGlobals() {
  const $route = useRoute()

  return {
    oid: computed(() => {
      return typeof $route.params.oid === 'undefined' ? '0' : $route.params.oid.toString()
    }) as Ref<string>,
    bid: computed(() => {
      return typeof $route.params.bid === 'undefined' ? '0' : $route.params.bid.toString()
    }),
    bot_id: computed(() => {
      return typeof $route.params.bot_id === 'undefined' ? '0' : $route.params.bot_id.toString()
    }),
    sid: computed(() => {
      return typeof $route.params.sid === 'undefined' ? '0' : $route.params.sid.toString()
    })
  }
}
