import { computed, type Ref } from "vue";
import useSWRV from "swrv";
import { getResponses } from "@/modules/bot/services/BotService";
import { useRouteGlobals } from "./useRouteGlobals";
import { useAuthStore } from "@/stores";
import { storeToRefs } from "pinia";

export function useResponses(page: Ref<number>) {
  const { bid } = useRouteGlobals();
  const authStore = useAuthStore();
  const { isLoggedIn } = storeToRefs(authStore);
  const {
    data: responses,
    mutate: refreshResponses,
    isValidating,
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () =>
      isLoggedIn.value &&
      bid.value &&
      bid.value !== "0" &&
      `/user-responses?bot=${bid.value}&p=${page.value}`,
    () => getResponses({ id: bid.value, page: page.value })
  );

  return {
    responses: computed(() => responses.value?.payload),
    refreshResponses,
    isValidating,
  };
}
