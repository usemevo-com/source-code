import { computed } from 'vue'
import { useRoute } from 'vue-router'
import useSWRV from 'swrv'
import { getLinks } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'
import type { LinkStatus } from '@/types/LinkStatus'

export function useLinks(status: LinkStatus) {
  const authStore = useAuthStore()
  const $route = useRoute()
  const { isLoggedIn } = storeToRefs(authStore)
  const { bid } = useRouteGlobals()
  const page = computed(() => parseInt($route.query.page as string) || 1)

  const {
    data: links,
    mutate: refreshLinks,
    isValidating
  } = useSWRV(
    // @ts-ignore
    () =>
      isLoggedIn.value &&
      bid.value !== '0' &&
      `/bots/links/${bid.value}?page=${page.value}&status=${status}`,
    () => getLinks({ id: bid.value, page: page.value, status })
  )

  return {
    links: computed(() => links.value?.payload),
    refreshLinks,
    isValidating
  }
}
