import { computed } from 'vue'
import useSWRV from 'swrv'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'
import { getRecentInteractions } from '@/modules/organization/services/OrganizationService'

export function useRecentInteractions() {
  const authStore = useAuthStore()
  const { isLoggedIn } = storeToRefs(authStore)
  const { oid } = useRouteGlobals()

  const {
    data: interactions,
    mutate: refreshInteractions,
    isValidating
  } = useSWRV(
    // @ts-ignore
    () =>
      isLoggedIn.value && oid.value !== '0' && `/organizations/recent-interactions/${oid.value}`,
    () => getRecentInteractions(oid.value)
  )

  return {
    interactions: computed(() => interactions.value?.payload),
    refreshInteractions,
    isValidating
  }
}
