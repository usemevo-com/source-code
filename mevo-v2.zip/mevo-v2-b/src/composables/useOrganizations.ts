import { computed } from "vue";
import useSWRV from "swrv";
import { getOrganizations } from "@/modules/organization/services/OrganizationService";
import { useAuthStore } from "@/stores";
import { storeToRefs } from "pinia";

export function useOrganizations() {
  const authStore = useAuthStore();
  const { isLoggedIn } = storeToRefs(authStore);
  const {
    data: organizations,
    mutate: refreshOrganizations,
    isValidating,
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () => isLoggedIn.value && `/organizations/v3`,
    () => getOrganizations()
  );

  return {
    organizations: computed(() => organizations.value?.payload),
    refreshOrganizations,
    isValidating,
  };
}
