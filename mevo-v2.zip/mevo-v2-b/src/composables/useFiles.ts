import { computed } from 'vue'
import { useRoute } from 'vue-router'
import useSWRV from 'swrv'
import { getFiles } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'

export function useFiles() {
  const authStore = useAuthStore()
  const $route = useRoute()
  const { isLoggedIn } = storeToRefs(authStore)
  const { bid } = useRouteGlobals()
  const page = computed(() => parseInt($route.query.page as string) || 1)

  const {
    data: files,
    mutate: refreshFiles,
    isValidating
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () => isLoggedIn.value && bid.value !== '0' && `/bots/files/${bid.value}?page=${page.value}`,
    () => getFiles({ id: bid.value, page: page.value })
  )

  return {
    files: computed(() => files.value?.payload),
    refreshFiles,
    isValidating
  }
}
