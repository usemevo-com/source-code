import { computed } from "vue";
import { useSubscription } from "./useSubscription";
import {
  BasicPlan,
  PlanType,
  Plans,
  ProPlan,
} from "@/modules/organization/types/IPlan";
import AppConfig from "@/utils/helpers/app-config";

export function useUsage() {
  const { activeOrganization } = useSubscription();

  const organizationResponseLimit = computed(() => {
    if (activeOrganization.value) {
      return activeOrganization.value.plan
        ? Plans[activeOrganization.value.plan].limits.response
        : -1;
    } else {
      return 0;
    }
  });

  const organizationTokenLimit = computed(() => {
    if (activeOrganization.value) {
      return activeOrganization.value.plan
        ? Plans[activeOrganization.value.plan].limits.token
        : -1;
    } else {
      return 0;
    }
  });

  const organizationResponseUsage = computed(() => {
    if (activeOrganization.value) {
      return activeOrganization.value.activePeriod
        ? activeOrganization.value.activePeriod.usage
        : 0;
    } else {
      return 0;
    }
  });

  const organizationCustomDomainUsage = computed(() => {
    if (activeOrganization.value) {
      return activeOrganization.value.customDomainUsage
        ? activeOrganization.value.customDomainUsage
        : 0;
    } else {
      return 0;
    }
  });

  const organizationLimitExceed = computed(() => {
    return organizationResponseUsage.value - organizationResponseLimit.value;
  });

  const organizationPeriodEnd = computed(() => {
    if (activeOrganization.value) {
      return activeOrganization.value.activePeriod
        ? AppConfig.$filters.formatDate(
            activeOrganization.value.activePeriod.end
          )
        : 0;
    } else {
      return 0;
    }
  });

  const activePeriod = computed(() => {
    return (
      activeOrganization.value?.activePeriod || { subscriptionType: "monthly" }
    );
  });

  return {
    activePeriod,
    organizationTokenLimit,
    organizationTokenUsage: activeOrganization.value
      ? activeOrganization.value.monthlyTokenUsage
      : 0,
    organizationResponseLimit,
    organizationResponseUsage,
    organizationPeriodEnd,
    organizationLimitExceed,
    organizationCustomDomainUsage,
  };
}
