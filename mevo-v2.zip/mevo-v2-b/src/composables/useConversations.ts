import { computed, type Ref } from "vue";
import useSWRV from "swrv";
import { storeToRefs } from "pinia";
import { get_inbox_v3 } from "@/modules/bot/services/BotService";
import { useAuthStore } from "@/stores";
import type { InboxFilter } from "@/modules/v3/data/inbox.state";

export function useConversations(bot_id: Ref<string>, page: Ref<number>, filter: Ref<InboxFilter>) {
  const authStore = useAuthStore();
  const { isLoggedIn } = storeToRefs(authStore);
  
  const {
    data: conversations,
    mutate: refreshConversations,
    isValidating,
  } = useSWRV(
    // @ts-ignore
    () =>
      isLoggedIn.value &&
      bot_id.value &&
      bot_id.value !== "0" &&
      `/bots/v3/${bot_id.value}/inbox?p=${page.value}&f=${filter.value}`,
    () => get_inbox_v3(bot_id.value, page.value, filter.value)
  );

  return {
    conversations: computed(() => conversations.value),
    refreshConversations,
    isConversationsLoading: isValidating,
  };
}
