import { computed } from 'vue'
import { useRoute } from 'vue-router'
import useSWRV from 'swrv'
import { getSubmissions } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'

export function useSubmissions() {
  const authStore = useAuthStore()
  const $route = useRoute()
  const { isLoggedIn } = storeToRefs(authStore)
  const { bid } = useRouteGlobals()
  const page = computed(() => parseInt($route.query.page as string) || 1)

  const {
    data: submissions,
    mutate: refreshSubmissions,
    isValidating
  } = useSWRV(
    // @ts-ignore
    () => isLoggedIn.value && bid.value !== '0' && `/bots/${bid.value}/submissions?p=${page.value}`,
    () => getSubmissions(bid.value, page.value)
  )

  return {
    submissions: computed(() => submissions.value?.payload),
    refreshSubmissions,
    isValidating
  }
}
