// externals
import { useRouter } from 'vue-router'
// import * as Countly from "countly-sdk-web";
import mixpanel from 'mixpanel-browser'
import { useI18n } from 'vue-i18n'

// internals
import {
  planChange,
  purchaseAddOn,
  removeAddOn
} from '@/modules/organization/services/OrganizationService'
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import {
  PlanType,
  type IPlan,
  BasicPlan,
  Plans,
  SubscriptionType,
  AddOn
} from '@/modules/organization/types/IPlan'
import { NotificationType, useCommonStore } from '@/stores'
import { useOrganizations } from './useOrganizations'
import { computed, type Ref } from 'vue'
import type { IOrganization } from '@/modules/organization/types/IOrganization'

export function useSubscription() {
  const $router = useRouter()
  const { oid } = useRouteGlobals()
  const { setNotification } = useCommonStore()
  const { refreshOrganizations, organizations } = useOrganizations()
  const { t } = useI18n()

  const activeOrganization: Ref<IOrganization> = computed(
    () => organizations.value && organizations.value.find((o: IOrganization) => o._id === oid.value)
  )

  const upgradePlan = async function (plan: PlanType, subscriptionType: SubscriptionType, affiliate_referrer: string = '') {
    const planChangeResponse = await planChange(oid.value, plan, subscriptionType, affiliate_referrer)

    if (planChangeResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "plan_change",
        "count": 1,
        "segmentation": {
          "newPlan": plan,
          "oid": oid.value,
          "subscriptionType": subscriptionType,
          "success": true
        }
      }]);
      const result = planChangeResponse.value.payload.status
      if (result === 'subscription-continued') {
        setNotification(t('plan.REACTIVATED'), NotificationType.SUCCESS)
      } else if (result === 'plan-updated') {
        setNotification(t('plan.UPDATED'), NotificationType.SUCCESS)
      } else if (result === 'subscription-cancelled') {
        setNotification(t('plan.CANCELLED'), NotificationType.SUCCESS)
      } else if (result === 'already-cancelled') {
        setNotification(t('plan.ALREADY_CANCELLED'), NotificationType.INFO)
      } else if (result === 'payment-could-not-be-completed') {
        setNotification(t('plan.PAYMENT_FAILED'), NotificationType.ERROR)
      } else {
        $router.push(
          `/redirect?url=${planChangeResponse.value.payload.session.url.replace(
            '#',
            '%23'
          )}&oid=${oid.value}`
        )
      }
      refreshOrganizations()
    } else {
      window.Countly.q.push(['add_event',{
        "key": "plan_change",
        "count": 1,
        "segmentation": {
          "newPlan": plan,
          "oid": oid.value,
          "subscriptionType": subscriptionType,
          "success": false
        }
      }]);
    }
  }

  const buyAddOn = async function (addOn: AddOn) {
    const buyAddOnResponse = await purchaseAddOn(addOn, oid.value)
    if (buyAddOnResponse.isOk()) {
      if (buyAddOnResponse.value.payload.status === 'addon-purchased') {
        setNotification(t('plan.ADDON_BOUGHT'), NotificationType.SUCCESS)
      } else if (buyAddOnResponse.value.payload.status === 'already-purchased') {
        setNotification(t('plan.ADDON_ALREADY_BOUGHT'), NotificationType.INFO)
      }
      refreshOrganizations()
    } else {
      setNotification(t('plan.ADDON_FAILED'), NotificationType.ERROR)
    }
  }

  const cancelAddOn = async function (addOn: AddOn) {
    const cancelAddOnResponse = await removeAddOn(addOn, oid.value)
    if (cancelAddOnResponse.isOk()) {
      if (cancelAddOnResponse.value.payload.status === 'addon-canceled') {
        setNotification(t('plan.ADDON_BOUGHT'), NotificationType.SUCCESS)
      } else if (cancelAddOnResponse.value.payload.status === 'already-canceled') {
        setNotification(t('plan.ADDON_ALREADY_BOUGHT'), NotificationType.INFO)
      }
      refreshOrganizations()
    } else {
      setNotification(t('plan.ADDON_FAILED'), NotificationType.ERROR)
    }
  }

  const activePlan: Ref<IPlan> = computed(() => {
    if (activeOrganization.value && activeOrganization.value.plan) {
      return Plans[activeOrganization.value.plan]
    }
    return BasicPlan
  })

  return {
    cancelAddOn,
    buyAddOn,
    upgradePlan,
    activePlan,
    activeOrganization,
    refreshOrganizations
  }
}
