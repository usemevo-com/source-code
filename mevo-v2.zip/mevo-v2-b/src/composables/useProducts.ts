import { computed } from 'vue'
import { useRoute } from 'vue-router'
import useSWRV from 'swrv'
import { getProducts } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'

export function useProducts() {
  const authStore = useAuthStore()
  const $route = useRoute()
  const { isLoggedIn } = storeToRefs(authStore)
  const { bid } = useRouteGlobals()
  const page = computed(() => parseInt($route.query.page as string) || 1)

  const {
    data: products,
    mutate: refreshProducts,
    isValidating
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () => isLoggedIn.value && bid.value !== '0' && `/bots/products/${bid.value}?page=${page.value}`,
    () => getProducts(bid.value, page.value)
  )

  return {
    products: computed(() => products.value?.payload),
    refreshProducts,
    isValidating
  }
}
