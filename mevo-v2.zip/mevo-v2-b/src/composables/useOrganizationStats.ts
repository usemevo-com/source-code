import { computed } from 'vue'
import useSWRV from 'swrv'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'
import { getOrganizationStats } from '@/modules/organization/services/OrganizationService'

export function useOrganizationStats() {
  const authStore = useAuthStore()
  const { isLoggedIn } = storeToRefs(authStore)
  const { oid } = useRouteGlobals()

  function calculateDiff(prev: number, curr: number) {
    const diff = curr - prev
    const percentageDiff = (diff / prev) * 100
    if (isNaN(percentageDiff) || !isFinite(percentageDiff)) return 0
    return percentageDiff !== 0 ? percentageDiff.toFixed(1) : 0
  }

  const {
    data: stats,
    mutate: refreshStats,
    isValidating
  } = useSWRV(
    // @ts-ignore
    () => isLoggedIn.value && oid.value !== '0' && `/organizations/stats/${oid.value}`,
    () => getOrganizationStats(oid.value)
  )

  return {
    stats: computed(() => stats.value?.payload),
    refreshStats,
    isValidating,
    calculateDiff
  }
}
