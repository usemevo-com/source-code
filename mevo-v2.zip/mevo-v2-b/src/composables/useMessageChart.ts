import { computed } from 'vue'
import useSWRV from 'swrv'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'
import { getMessageChartData } from '@/modules/organization/services/OrganizationService'

export function useMessageChart() {
  const authStore = useAuthStore()
  const { isLoggedIn } = storeToRefs(authStore)
  const { oid } = useRouteGlobals()

  const {
    data: chartData,
    mutate: refreshChartData,
    isValidating
  } = useSWRV(
    // @ts-ignore
    () => isLoggedIn.value && oid.value !== '0' && `/organizations/message-chart-data/${oid.value}`,
    () => getMessageChartData(oid.value)
  )

  return {
    chartData: computed(() => chartData.value?.payload),
    refreshChartData,
    isValidating
  }
}
