import { computed } from 'vue'
import { useRoute } from 'vue-router'
import useSWRV from 'swrv'
import { getTexts } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'

export function useTexts() {
  const authStore = useAuthStore()
  const $route = useRoute()
  const { isLoggedIn } = storeToRefs(authStore)
  const { bid } = useRouteGlobals()
  const page = computed(() => parseInt($route.query.page as string) || 1)

  const {
    data: texts,
    mutate: refreshTexts,
    isValidating
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () => isLoggedIn.value && bid.value !== '0' && `/bots/texts/${bid.value}?page=${page.value}`,
    () => getTexts({ bot: bid.value, page: page.value })
  )

  return {
    texts: computed(() => texts.value?.payload),
    refreshTexts,
    isValidating
  }
}
