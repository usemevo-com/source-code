import { computed } from 'vue'
import useSWRV from 'swrv'
import { getBots } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import { storeToRefs } from 'pinia'

export function useBots() {
  const authStore = useAuthStore()
  const { isLoggedIn } = storeToRefs(authStore)
  const { oid } = useRouteGlobals()
  const {
    data: bots,
    mutate: refreshBots,
    isValidating,
  } = useSWRV(
    // TODO: Fix this ts-ignore
    // @ts-ignore
    () => isLoggedIn.value && oid.value !== '0' && `/bots?organization=${oid.value}`,
    () => getBots({ oid: oid.value })
  )

  return {
    bots: computed(() => bots.value?.payload),
    refreshBots,
    isValidating,
  }
}
