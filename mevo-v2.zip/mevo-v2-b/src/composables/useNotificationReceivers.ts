import { computed, type Ref } from 'vue'
import useSWRV from 'swrv'
import { storeToRefs } from 'pinia'
import { getNotificationReceivers } from '@/modules/bot/services/BotService'
import { useRouteGlobals } from './useRouteGlobals'
import { useAuthStore } from '@/stores'
import type { NotificationType } from '@/modules/bot/dtos/AddNotificationReceiverRequest'
import { useRoute } from 'vue-router'

export function useNotificationReceivers(type: NotificationType) {
  const authStore = useAuthStore()
  const { isLoggedIn } = storeToRefs(authStore)
  const { bid } = useRouteGlobals()
  const $route = useRoute()
  const page = computed(() => parseInt($route.query.page as string) || 1)

  const {
    data: notificationReceivers,
    mutate: refreshNotificationReceivers,
    isValidating
  } = useSWRV(
    // @ts-ignore
    () =>
      isLoggedIn.value &&
      bid.value !== '0' &&
      `/bots/notification-receivers/${bid.value}?type=${type}&page=${page.value}`,
    () => getNotificationReceivers(bid.value, type, page.value)
  )

  return {
    notificationReceivers: computed(() => notificationReceivers.value?.payload),
    refreshNotificationReceivers,
    isValidating
  }
}
