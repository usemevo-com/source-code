<template>
  <!-- global notification component -->
  <!-- <MNotification
    :type="notificationType"
    :message="notificationMessage"
    :show="notificationMessage.length > 0"
    @close="setNotification('')"
  /> -->
  <Toaster />
  <T />
  <RouterView />
</template>

<script setup lang="ts">
import mixpanel from 'mixpanel-browser'
import { onMounted, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { useI18n } from 'vue-i18n'
import { RouterView, useRoute, useRouter } from 'vue-router'

import { Toaster } from '@/components/ui/sonner'
import { Toaster as T } from './components/ui/toast'
import { NotificationType, useCommonStore } from './stores'
import { useOrganizations } from './composables/useOrganizations'
import { useSubscription } from './composables/useSubscription'
import { useRouteGlobals } from './composables/useRouteGlobals'
import type { IOrganization } from './modules/organization/types/IOrganization'
import { genericOptions } from './constants'

const $route = useRoute()
const $router = useRouter()
const commonStore = useCommonStore()
const { t } = useI18n()
const setNotification = commonStore.setNotification
const setGlobalNotification = commonStore.setGlobalNotification
const { notificationType, notificationMessage } = storeToRefs(commonStore)
const { organizations } = useOrganizations()
const { activeOrganization } = useSubscription()
const { oid } = useRouteGlobals()

// array of route NAMES which does not require oid in param
const routesThatNotRequiredOID: string[] = [
  'common-bot-view',
  'gpt-view',
  'widget-view',
  'organization-create',
  'redirect',
  'payment-success',
  'payment-failed',
  'experimental',
  'onboarding',
  'get-started',
  'choose-pages',
  'set-up-account',
  'set-branding',
  'finalize-setup'
]

watch(organizations, (newOrganizations) => {
  const atLeastOneOrganizationExist = newOrganizations.length
  const noOrganizationIdOnUrl = !$route.params.oid
  const thisIsNotAnExceptionalRoute = routesThatNotRequiredOID.indexOf($route.name as string) === -1

  if (thisIsNotAnExceptionalRoute && organizations.value && organizations.value.length) {
    // fallback for invalid organization id
    let oidValid = false

    organizations.value.forEach((organization: IOrganization) => {
      if (organization._id === oid.value) {
        oidValid = true
      }
    })

    if (!oidValid) {
      $router.replace(`/o/${organizations.value[0]._id}/home`)
      return
    }
  }

  // this is App component
  // the root of all other components in this project
  // so we can rely this for navigation
  // check organizations length, if at least one organization exist in this account
  // and user is not in oid not-required view
  // redirect user to home with first organization id
  if (atLeastOneOrganizationExist && noOrganizationIdOnUrl && thisIsNotAnExceptionalRoute) {
    $router.replace(`/o/${organizations.value[0]._id}/home`)
    return
  }

  if (!atLeastOneOrganizationExist) {
    $router.replace(`/organization-create`)
    return
  }
})

watch(activeOrganization, (newOrganization) => {
  if (newOrganization) {
    // when organization switched, check if it has failed payment
    // if it has, show notification
    if (newOrganization.failedPaymentTry && newOrganization.failedPaymentTry > 0) {
      setGlobalNotification(t('organizations.PAYMENT_FAILED'), NotificationType.ERROR)
    } else {
      setGlobalNotification('', NotificationType.ERROR)
    }
  }
})

onMounted(() => {
  if (window.location.host === genericOptions.prodDomain) {
    mixpanel.init(genericOptions.mixpanelProdToken, {
      track_pageview: true,
      persistence: 'localStorage'
    })
  } else {
    mixpanel.init(genericOptions.mixpanelLocalToken, {
      debug: false,
      track_pageview: true,
      persistence: 'localStorage'
    })
  }

  // // @ts-ignore
  // window.createLemonSqueezy()
})
</script>
