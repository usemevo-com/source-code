import { defineRule } from "vee-validate";

defineRule("required", (value: string) => {
  if (!value || !value.length) {
    return "This field is required.";
  }
  return true;
});

defineRule("required_answer", (value: string) => {
  if (!value || !value.length) {
    return "Please type an answer";
  }
  return true;
});

defineRule("email", (value: string) => {
  // Field is empty, should pass
  if (!value || !value.length) {
    return true;
  }
  // Check if email
  if (
    !/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/.test(
      value
    )
  ) {
    return "This field must be a valid email.";
  }
  return true;
});

defineRule("email_answer", (value: string) => {
  // Field is empty, should pass
  if (!value || !value.length) {
    return true;
  }
  // Check if email
  if (
    !/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/.test(
      value
    )
  ) {
    return "Please type a valid email address";
  }
  return true;
});

defineRule("minMax", (value: string, [min, max]: [number, number]) => {
  // The field is empty so it should pass
  if (!value || !value.length) {
    return true;
  }
  const length = value.length;

  if (length < min) {
    return `This field must be greater than ${min} characters.`;
  }
  if (length > max) {
    return `This field must be less than ${max} characters.`;
  }
  return true;
});

defineRule("one_uppercase", (value: string) => {
  if (!/^([a-z0-9A-Z]*[A-Z]+[a-z0-9A-Z]*)/.test(value)) {
    return "Must contain at least one uppercase letter.";
  }

  return true;
});

defineRule("one_number", (value: string) => {
  if (!/(?=.*[0-9])/.test(value)) {
    return "Must contain at least one number.";
  }

  return true;
});

defineRule("one_special", (value: string) => {
  if (!/(?=.*\W+)/.test(value)) {
    return "Must contain at least one special character.";
  }

  return true;
});

defineRule("confirmed", (value: string, [target]: [string]) => {
  if (value === target) {
    return true;
  }

  return "Passwords must match";
});

defineRule("url_answer", (value: string) => {
  if (
    !/[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/.test(
      value
    )
  ) {
    return "Please type a valid url";
  }

  return true;
});

defineRule("date_answer", (value: string) => {
  if (!/^\d\d\.\d\d\.\d\d\d\d$/.test(value)) {
    return "Please type a valid date like DD.MM.YYYY";
  }

  return true;
});

defineRule("digits_answer", (value: string) => {
  if (Number.isInteger(parseInt(value))) {
    return true;
  }

  return "Please type a valid number";
});

// define a rule for gsm number
defineRule("phone_answer", (value: string) => {
  if (!/^\+?[0-9]{6,15}$/.test(value.trim().replaceAll(" ", ""))) {
    return "Please type a valid phone number";
  }

  return true;
});

// define a rule for valid social network username
defineRule("username_answer", (value: string) => {
  if (!/^[a-zA-Z0-9._]+$/.test(value)) {
    return "Please type a valid username";
  }

  return true;
});
