import { createI18n } from 'vue-i18n'

import tr from './keys_tr'
import en from './keys_en'

const messages = {
  en,
  tr,
}

export default createI18n({
  legacy: false,
  locale: 'en',
  fallbackLocale: 'en',
  messages,
})
