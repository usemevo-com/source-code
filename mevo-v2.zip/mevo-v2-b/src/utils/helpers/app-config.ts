import moment from 'moment'

export default {
  $filters: {
    timeAgo(date: Date) {
      return moment(date).fromNow()
    },
    formatDate(date: Date) {
      return moment(date).format('MMMM DD, HH:mm')
    },
    formatDateLong(date: Date) {
      return moment(date).format('MMMM DD, YYYY - HH:mm')
    }
  }
}
