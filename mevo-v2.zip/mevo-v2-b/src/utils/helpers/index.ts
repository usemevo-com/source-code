import type { Ref } from "vue";

export const createDebounce = function (timeout: Ref<any>) {
  return function (fnc: Function, delayMs?: number) {
    clearTimeout(timeout.value);
    timeout.value = setTimeout(() => {
      fnc();
    }, delayMs || 100);
  };
};

export enum BuilderTabKey {
  KNOWLEDGE = "knowledge",
  SETTINGS = "settings",
  INTEGRATIONS = "integrations",
  PAGE_CUSTOMIZATION = "pageCustomization",
  POPUP_CUSTOMIZATION = "popupCustomization",
  LOCALIZATION = "localization",
  SEO_SETTINGS = "seoSettings",
  LEAD_CAPTURE = "leadCapture",
  NOTIFICATIONS = "notifications",
  PREVIEW = "preview",
  FLOW = "flow",
  LEAD_GEN = "leadGen",
}

export const builderTabs = [
  {
    label: "Knowledge",
    key: BuilderTabKey.KNOWLEDGE,
    current: true,
    hide: false,
    ruleBased: false,
    aiBased: true,
  },
  {
    label: "Flow",
    key: BuilderTabKey.FLOW,
    current: true,
    hide: false,
    ruleBased: true,
    aiBased: false,
  },
  {
    label: "Settings",
    key: BuilderTabKey.SETTINGS,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
  {
    label: "Notifications",
    key: BuilderTabKey.INTEGRATIONS,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
  {
    label: "Lead Capture",
    key: BuilderTabKey.LEAD_GEN,
    current: false,
    hide: false,
    ruleBased: false,
    aiBased: true,
  },
  {
    label: "Page Design",
    key: BuilderTabKey.PAGE_CUSTOMIZATION,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
  {
    label: "Popup Design",
    key: BuilderTabKey.POPUP_CUSTOMIZATION,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
  {
    label: "Localization",
    key: BuilderTabKey.LOCALIZATION,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
  {
    label: "SEO",
    key: BuilderTabKey.SEO_SETTINGS,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
  {
    label: "Preview",
    key: BuilderTabKey.PREVIEW,
    current: false,
    hide: false,
    ruleBased: true,
    aiBased: true,
  },
];

export enum TextSource {
  INPUT = "input",
  FILE = "file",
}
