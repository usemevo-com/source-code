import type { InboxConversation } from "@/modules/v3/data/inbox.state";

function hashCode(str: string) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0; // 32bit integer
  }
  return Math.abs(hash);
}

function getDeterministicItem(array: any, seed: number) {
  return array[seed % array.length];
}

function capFirst(name: string): string {
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function generateName(id: string): string {
  const colors = ["Red", "Blue", "Green", "Yellow", "Purple", "Orange", "Pink", "Brown", "Black", "White"];
  const flowers = ["Rose", "Tulip", "Daisy", "Lily", "Sunflower", "Orchid", "Lavender", "Peony", "Violet", "Daffodil"];

  const seed = hashCode(id);

  const color = getDeterministicItem(colors, seed);
  const flower = getDeterministicItem(flowers, seed >> 4);

  return capFirst(color) + ' ' + capFirst(flower);
}

export const getConversationTitle = function (conversation: InboxConversation): string {
  if (conversation.lead && conversation.lead.length && conversation.lead[0].email !== "N/A") {
    return conversation.lead[0].email;
  } else {
    return generateName(conversation._id);
  }
}