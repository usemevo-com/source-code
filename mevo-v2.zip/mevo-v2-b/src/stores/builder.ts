import { defineStore } from 'pinia'

type builderState = {
  [key: string]: any
}

export const useBuilderStore = defineStore('builder', {
  state: () => {
    return {
      trainingContent:
        "You are an AI assistant who answers questions.  \n\nDo not mention the training files while answering questions; say 'dataset' instead of uploaded files. Say, 'I did not find any information about your question in my dataset.'  instead of  'I did not find any information about your questions in uploaded files.' If a user asks something you can not find in the files, say, 'If you leave your email address, our team can contact you and answer this question as soon as possible.",
      themeColor: 'blue',
      title: 'Do you need help?',
      description: 'Type your question and get an answer from our AI support agent.',
      callToAction: 'Ask a question',
      brandLogoUrl: 'https://placehold.co/150x150',
      leadCaptureMode: 'none',
      notificationType: 'email',
      notificationReceiverName: '',
      notificationReceiverEmail: '',
      notificationReceiverUrl: '',
      createdBotId: '',
      chatbotType: 'from_website',
      bgColor: '#ef4444',
      questions: [] as { question: string, answer: string }[],
      urls: [] as string[],
      singlePage: false,
      urlToScan: '',
      selectedUrls: [] as string[],
    } as builderState
  },
  actions: {
    setBuilderState(key: string, value: any) {
      this[key] = value
    },
    resetBuilderState() {
      this.trainingContent =
        "You are an AI assistant who answers questions.  \n\nDo not mention the training files while answering questions; say 'dataset' instead of uploaded files. Say, 'I did not find any information about your question in my dataset.'  instead of  'I did not find any information about your questions in uploaded files.' If a user asks something you can not find in the files, say, 'If you leave your email address, our team can contact you and answer this question as soon as possible."
      this.themeColor = 'blue'
      this.title = 'Do you need help?'
      this.description = 'Type your question and get an answer from our AI support agent.'
      this.callToAction = 'Ask a question'
      this.brandLogoUrl = 'https://placehold.co/150x150'
      this.leadCaptureMode = 'none'
      this.notificationType = 'email'
      this.notificationReceiverName = ''
      this.notificationReceiverEmail = ''
      this.notificationReceiverUrl = ''
      this.chatbotType = 'from_scratch'
      this.bgColor = '#ef4444'
    }
  },
  persist: true
})
