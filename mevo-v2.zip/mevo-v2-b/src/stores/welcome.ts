import { defineStore } from "pinia";

type onboardingState = {
  steps: { [key: string]: { priority: number; hasDone: boolean } };
};

export const useWelcomeStore = defineStore("welcome", {
  state: () => {
    return {
      steps: {
        "go-builder": { priority: 1, hasDone: false },
        "add-first-step": { priority: 2, hasDone: false },
        "edit-first-step": { priority: 3, hasDone: false },
        "close-popup-1": { priority: 4, hasDone: false },
        "close-popup-2": { priority: 4, hasDone: false },
        "close-popup-3": { priority: 4, hasDone: false },
        "close-onboarding-popup": { priority: 4, hasDone: false },
      },
    } as onboardingState;
  },
  actions: {
    setStepDone(key: string) {
      this.steps[key].hasDone = true;
    },
  },
  persist: true,
});
