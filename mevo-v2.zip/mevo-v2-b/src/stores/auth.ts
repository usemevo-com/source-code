import { defineStore } from "pinia";
// import * as Countly from "countly-sdk-web";
import mixpanel from "mixpanel-browser";

import type { IUser } from "@/modules/prelogin/types/IUser";

type authState = {
  isLoggedIn: boolean;
  user: IUser;
};

export const useAuthStore = defineStore("auth", {
  state: () => {
    return {
      isLoggedIn: false,
      user: {},
    } as authState;
  },
  actions: {
    setLoggedIn(isLoggedIn: boolean) {
      this.isLoggedIn = isLoggedIn;
    },
    setUser(user: IUser) {
      if (user) {
        mixpanel.identify(user.email);
        mixpanel.people.set({
          $name: user.name,
          $email: user.email,
        });
      }
      this.user = user;
    },
  },
});
