import { defineStore } from 'pinia'
import mixpanel from 'mixpanel-browser'
import { toast } from 'vue-sonner'
import { computed, reactive } from 'vue'

export const enum NotificationType {
  ERROR = 'error',
  SUCCESS = 'success',
  INFO = 'info',
  WARNING = 'warning'
}

type commonState = {
  notificationType: NotificationType
  notificationMessage: string
  globalNotificationType: NotificationType
  globalNotificationMessage: string
  isUpgradeModalOpen: boolean
  isCreateModalOpen: boolean
}

export const useCommonStore = defineStore('common', () => {
  const state: commonState = reactive({
    notificationType: NotificationType.INFO,
    notificationMessage: '',
    globalNotificationType: NotificationType.ERROR,
    globalNotificationMessage: '',
    isUpgradeModalOpen: false,
    isCreateModalOpen: false
  })

  function setIsCreateModalOpen(isOpen: boolean) {
    state.isCreateModalOpen = isOpen
  }

  function setUpgradeModal(isOpen: boolean) {
    state.isUpgradeModalOpen = isOpen

    if (isOpen) {
      window.Countly.q.push(['add_event',{
        "key": "show_upgrade_modal",
        "count": 1
      }]);
    }
  }

  function setNotification(message: string, type: NotificationType = NotificationType.ERROR) {
    if (type === NotificationType.ERROR) {
      toast.error(message)
    } else if (type === NotificationType.SUCCESS) {
      toast.success(message)
    } else if (type === NotificationType.INFO) {
      toast.info(message)
    } else if (type === NotificationType.WARNING) {
      toast.warning(message)
    } else {
      toast(message)
    }
  }

  function setGlobalNotification(
    message: string,
    type: NotificationType = NotificationType.ERROR,
    timeout = 0
  ) {
    state.globalNotificationMessage = message
    state.globalNotificationType = type
    if (timeout === 0) return
    setTimeout(() => {
      state.globalNotificationMessage = ''
    }, timeout * 1000)
  }

  return {
    notificationType: NotificationType.INFO,
    notificationMessage: '',
    globalNotificationType: NotificationType.ERROR,
    globalNotificationMessage: '',
    isUpgradeModalOpen: computed(() => state.isUpgradeModalOpen),
    isCreateModalOpen: false,
    setIsCreateModalOpen,
    setUpgradeModal,
    setNotification,
    setGlobalNotification
  }
})
