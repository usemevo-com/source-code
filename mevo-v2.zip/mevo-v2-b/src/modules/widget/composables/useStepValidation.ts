import { ScriptStepType } from "@/modules/bot/types/IScriptStep";

export function useStepValidation() {
  const TypeRuleMap: { [key: string]: string } = {};

  TypeRuleMap[ScriptStepType.QUESTION_TEXT] = "required_answer";
  TypeRuleMap[ScriptStepType.EMAIL] = "required_answer|email_answer";
  TypeRuleMap[ScriptStepType.PHONE_NUMBER] = "required_answer|phone_answer";
  TypeRuleMap[ScriptStepType.NUMBER] = "required_answer|digits_answer";
  TypeRuleMap[ScriptStepType.URL] = "required_answer|url_answer";
  TypeRuleMap[ScriptStepType.DATE] = "required_answer|date_answer";
  TypeRuleMap[ScriptStepType.USERNAME] = "required_answer|username_answer";

  return {
    TypeRuleMap,
  };
}
