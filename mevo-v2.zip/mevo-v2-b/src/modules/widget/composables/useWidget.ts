import { type IScriptStep, ScriptStepType } from '@/modules/bot/types/IScriptStep'
import { nextTick } from 'vue'

export function useWidget() {
  const scrollToBottom = function (selector: string) {
    nextTick(() => {
      const container = document.querySelector(selector)
      container?.scrollTo({
        top: container?.scrollHeight,
        left: 0,
        behavior: 'smooth',
      })
    })
  }

  const scrollToRight = function (selector: string) {
    nextTick(() => {
      const container = document.querySelector(selector)
      container?.scrollTo({
        top: 0,
        left: container?.scrollWidth,
        behavior: 'smooth',
      })
    })
  }

  const scrollToLeft = function (selector: string) {
    nextTick(() => {
      const container = document.querySelector(selector)
      container?.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      })
    })
  }

  const userResponseObjectFactory = function (message: string, id: number): IScriptStep {
    return {
      data: {
        message,
        options: [''],
      },
      response: true,
      description: '',
      type: ScriptStepType.RESPONSE,
      isSkippable: false,
      isManualInputAllowed: false,
      id: `${id}`,
      hasOption: false,
    }
  }

  return {
    scrollToBottom,
    scrollToLeft,
    scrollToRight,
    userResponseObjectFactory,
  }
}
