<template>
  <div
    v-if="bot.data._id"
    class="flex w-full relative widget-vh overflow-hidden h-screen"
    :style="{ backgroundColor: bot.data.design.backgroundColor }"
    :class="[
      bot.data.design.backgroundType === 'image' &&
        `bg-[url('https://cdn.usemevo.com/bg/${bot.data.design.background}')] bg-[length:300px_300px] bg-repeat`,
      'justify-center items-center ',
    ]"
  >
    <widget-left-side
      :no-mevo-mark="!isBrandingVisible"
      :theme="bot.data.design.theme"
      v-if="bot.data.design.layout === BotLayout.CHAT_RIGHT"
      :image="bot.data.design.background"
      :use-image="bot.data.design.backgroundType === 'image'"
      :color="bot.data.design.backgroundColor"
    />
    <div
      v-if="!isCompleted && !isErrorOccurred"
      class="w-full sm:w-2/3 bg-white shadow-lg flex flex-col widget-vh"
    >
      <div
        class="py-4 px-5 border-b border-gray-100 flex justify-between items-center text-black"
      >
        <div class="flex flex-col w-full">
          <div class="flex justify-between w-full" v-if="!isBotDataLoading">
            <div class="flex flex-col">
              <div class="font-semibold">{{ bot.data.name }}</div>
              <div class="flex flex-col">
                <div class="font-light text-xs">
                  {{ bot.data.byText }}
                  <a
                    target="_blank"
                    :href="
                      bot.data.organization && bot.data.organization.domain
                        ? 'https://' + bot.data.organization.domain
                        : 'javascript:void(0)'
                    "
                    ><span class="font-bold text-gray-500">{{
                      bot.data.organization && bot.data.organization.name
                    }}</span></a
                  >
                </div>
              </div>
            </div>
            <div class="flex items-center">
              <div
                @click="postMessage('chatbox-closed')"
                v-if="!isBotDataLoading && !isCloseIconHidden"
                v-tooltip="{
                  text: 'Close popup',
                  theme: { placement: 'left', trigger: 'hover' },
                }"
                class="rounded-full bg-gray-100 hover:bg-gray-200 p-2 cursor-pointer sm:hidden ml-4 h-fit"
              >
                <x-mark-icon class="w-4 h-4 text-gray-700" />
              </div>
            </div>
          </div>
          <div class="animate-pulse" v-else>
            <div class="h-4 w-72 bg-gray-300 rounded"></div>
            <div class="mt-2 h-4 w-36 bg-gray-300 rounded"></div>
          </div>
        </div>
      </div>
      <TransitionGroup
        name="widget-message-list"
        tag="div"
        v-if="scene.steps.length && !isBotDataLoading"
        class="grow w-full p-4 overflow-y-scroll relative"
        id="message-container"
      >
        <m-script-step
          :key="index"
          v-for="(step, index) in scene.steps"
          :theme="bot.data.design.bubbleColor"
          :step="step"
          :primary="step && typeof step.response === 'undefined'"
          :active-step="activeStep"
          :step-index="index"
          @next="onNext"
          @skip="onSkip"
        />
        <m-loading v-if="isLoading" />
        <div
          v-if="
            !isInteractedOnce &&
            !started &&
            bot.data.gptSettings.showPredefinedQuestions
          "
          class="absolute bottom-4 right-2 ml-2 flex flex-col space-y-2 items-end w-fit"
        >
          <!-- text-gray-500 border-gray-500 hover:bg-gray-500 -->
          <!-- text-blue-500 border-blue-500 hover:bg-blue-500 -->
          <!-- text-yellow-500 border-yellow-500 hover:bg-yellow-500 -->
          <!-- text-pink-500 border-pink-500 hover:bg-pink-500 -->
          <!-- text-purple-500 border-purple-500 hover:bg-purple-500 -->
          <!-- text-green-500 border-green-500 hover:bg-green-500 -->
          <!-- text-indigo-500 border-indigo-500 hover:bg-indigo-500 -->
          <!-- text-red-500 border-red-500 hover:bg-red-500 -->
          <div
            :key="index"
            v-for="(option, index) in bot.data.gptSettings.feed[1].data.slice(
              0,
              3
            )"
            @click="() => onPredefinedOptionSelected(option.q)"
            :class="[
              `text-${bot.data.design.bubbleColor}-500 border-${bot.data.design.bubbleColor}-500 hover:bg-${bot.data.design.bubbleColor}-500 hover:bg-${bot.data.design.bubbleColor}-500`,
            ]"
            class="text-sm border px-4 py-2 rounded-2xl hover:text-white cursor-pointer"
          >
            {{ option.q }}
          </div>
        </div>
      </TransitionGroup>
      <div v-else class="grow w-full p-4 animate-pulse space-y-2">
        <div class="ml-1 h-12 w-48 bg-gray-300 rounded-2xl"></div>
        <div class="ml-1 h-12 w-64 bg-gray-300 rounded-2xl"></div>
        <div class="ml-1 h-12 w-64 bg-gray-300 rounded-2xl"></div>
      </div>
      <widget-input
        :disabled="isSubmitDisabled"
        :input-placeholder="bot.data.inputText"
        mode="GPT"
        :type="ScriptStepType.QUESTION_TEXT"
        @submit="onTextSubmit"
      />
      <div
        v-if="isBrandingVisible"
        class="flex flex-col py-2 px-4 items-center sm:hidden border-t border-gray-100"
      >
        <div class="text-xs">
          made with
          <a target="_blank" href="https://usemevo.com"
            ><span class="font-black text-primary">mevo</span></a
          >
        </div>
      </div>
    </div>
    <widget-completed
      :no-mevo-mark="
        bot.data.organization && bot.data.organization.plan !== PlanType.BASIC
      "
      :class="['h-screen']"
      v-else-if="isCompleted"
      @restart="onRestartConversation"
    />
    <widget-error-occurred
      :class="['h-screen']"
      v-else-if="isErrorOccurred"
      @restart="onRestartConversation"
      :message="errorMessage"
    />
    <widget-left-side
      :no-mevo-mark="!isBrandingVisible"
      v-if="bot.data.design.layout === BotLayout.CHAT_LEFT"
      :image="bot.data.design.background"
      :use-image="bot.data.design.backgroundType === 'image'"
      :color="bot.data.design.backgroundColor"
    />
  </div>
  <div v-else class="h-screen w-full flex justify-center items-center bg-white">
    <div class="flex flex-col items-center justify-center">
      <i
        class="animate-spin text-indigo-300 fa-sharp fa-light fa-spinner-third text-3xl"
      ></i>
    </div>
  </div>
</template>

<script lang="ts" setup>
// external dependencies
import { computed, onMounted, reactive, ref, watch, type Ref } from "vue";
import { useRoute } from "vue-router";
import { XMarkIcon } from "@heroicons/vue/24/outline";
import mixpanel from "mixpanel-browser";
// internal dependencies
import {
  ScriptStepType,
  type IScriptStep,
} from "@/modules/bot/types/IScriptStep";
import {
  BotEventType,
  BotLayout,
  BotPosition,
  BotTheme,
  BotType,
  type IBot,
} from "@/modules/bot/types/IBot";
import {
  getBotSafePublic,
  interact,
  interactV2,
  retrieve,
  sendBotEvent,
} from "@/modules/bot/services/BotService";
import { useWidget } from "../composables/useWidget";
// components
import MScriptStep from "@/components/basic/MScriptStep.vue";
import MLoading from "@/components/basic/MLoading.vue";
import MBrand from "@/components/v2/elements/MBrand.vue";
import WidgetCompleted from "../containers/WidgetCompleted.vue";
import WidgetInput from "../containers/WidgetInput.vue";
import WidgetLeftSide from "../containers/WidgetLeftSide.vue";
import WidgetErrorOccurred from "../containers/WidgetErrorOccurred.vue";
import { PlanType } from "@/modules/organization/types/IPlan";
import { useCommonStore } from "@/stores";
import { useI18n } from "vue-i18n";
import { v4 as uuidv4 } from "uuid";

const $route = useRoute();
const isCloseIconHidden = computed(() => {
  return $route.query.hideCloseIcon === "true";
});
const { scrollToBottom, userResponseObjectFactory } = useWidget();
const { t } = useI18n();
// fetched bot object
const bot: { data: IBot } = reactive({
  data: {
    name: "",
    script: {
      steps: [],
    },
    design: {
      theme: BotTheme.BLUE,
      position: BotPosition.MIDDLE,
      layout: BotLayout.CHAT_RIGHT,
      background: "NO_BACKGROUND",
    },
    type: BotType.GPT,
    gptSettings: {
      firstMessage: "",
      fallbackMessage: "",
      represented: "",
      feed: [],
    },
    organization: {
      name: "Organization",
    },
    hideBranding: false,
  },
});
const messageGenerationMap: { [key: number]: boolean } = reactive({});
const session: Ref<string> = ref("");
// array which hold user responses as string array
// we'll use this array for persist user responses
// at the end of conversation
const response: { data: { value: string; id: string }[] } = reactive({
  data: [],
});
// array which represent bot flow
// all script steps and user responses pushed in this array
const scene: { steps: IScriptStep[] } = reactive({
  steps: [],
});
// index for active step
// only count script steps, not user responses
const activeStep: Ref<number> = ref(0);
// filtered versions of scene
// which only returns script steps, not user responses
const botStepsOnly: Ref<IScriptStep[]> = computed(() =>
  scene.steps.filter(
    (step: IScriptStep) => step && typeof step.response === "undefined"
  )
);
// kind of cache for bot data
// we'll rely this when user want to restart conversaiton
let fetchedBotData: IBot = bot.data;
// some logical flags
const isErrorOccurred: Ref<boolean> = ref(false);
const errorMessage = ref("");
const isLoading: Ref<boolean> = ref(false);
const isBotDataLoading: Ref<boolean> = ref(true);
const isCompleted: Ref<boolean> = ref(false);
const isBotResetBlocked: Ref<boolean> = ref(false);
const started = ref(false);
const isInteractedOnce = ref(false);
const isSubmitDisabled = ref(false);

const isBrandingVisible = computed(() => {
  return !bot.data.hideBranding;
});

const isChatbotPageBrandingVisible = computed(() => {
  return false;
});

const onPredefinedOptionSelected = function (option: string) {
  onTextSubmit(option);
  isInteractedOnce.value = true;
};

// conversation restart event handler
const onRestartConversation = async function (
  refetch: boolean = false
): Promise<void> {
  if (refetch) {
    await fetchBotAndSetAssignments($route.params.id as string);
  } else {
    // reset state to initial
    bot.data = fetchedBotData;
    response.data = [];
    scene.steps = [];
    activeStep.value = 0;
    isErrorOccurred.value = false;
    isLoading.value = false;
    isCompleted.value = false;
    // start flow
    scene.steps.push(bot.data.script.steps[activeStep.value]);
    isLoading.value = true;
  }
};

const onReset = function () {
  if (isBotResetBlocked.value) {
    return;
  }

  isBotResetBlocked.value = true;
  // reset state to initial
  bot.data = fetchedBotData;
  response.data = [];
  scene.steps = [];
  activeStep.value = 0;
  isErrorOccurred.value = false;
  isLoading.value = false;
  isCompleted.value = false;
  // start flow
  scene.steps.push(bot.data.script.steps[activeStep.value]);
  setTimeout(() => {
    if (
      bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
    ) {
      isLoading.value = true;
    }
  }, 1000);
  setTimeout(() => {
    onNext();
    isBotResetBlocked.value = false;
  }, 1500);
};

// script step next event handler
// only work for non-text-required steps
const onNext = function (reply: string = "") {
  // does this step has reply?
  // we're checking this because it may a message which does not require any reply
};

// script step skip event handler
const onSkip = function () {
  response.data.push({
    value: "SKIPPED",
    id: bot.data.script.steps[activeStep.value].id || "",
  });
  scrollToBottom("#message-container");
  isLoading.value = true;
  activeStep.value++;
  calculateNextStep();
};

const postMessage = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

// script step text event handler
// only work for steps which manual input required
const onTextSubmit = async function (message: string) {
  if (message.trim() === "") {
    return;
  }

  if (!started.value) {
    await trackBotEvent(BotEventType.START);
    started.value = true;
  }

  // set loading before next script step appear
  isLoading.value = true;
  // push user response object into scene
  scene.steps.push(userResponseObjectFactory(message, scene.steps.length));

  // scroll to bottom
  scrollToBottom("#message-container");

  if (bot.data.gptSettings.useAssistantAPI) {
    isSubmitDisabled.value = true;
    const aiSubmission = await interactV2(fetchedBotData._id || "id", {
      message,
      sid: session.value,
    });
    messageGenerationMap[scene.steps.length - 1] = false;
    if (aiSubmission.isOk()) {
      setTimeout(() => {
        const retrieveInterval = setInterval(async () => {
          const retrieveResponse = await retrieve(
            session.value,
            fetchedBotData._id || ""
          );

          if (retrieveResponse.isOk()) {
            if (retrieveResponse.value.payload.status) {
              clearInterval(retrieveInterval);
              isSubmitDisabled.value = false;
              isLoading.value = false;

              if (!messageGenerationMap[scene.steps.length - 1]) {
                messageGenerationMap[scene.steps.length - 1] = true;

                scene.steps.push({
                  type: ScriptStepType.MESSAGE,
                  data: {
                    message: retrieveResponse.value.payload.message,
                    options: [],
                  },
                });
              }
            }
          }
        }, 1500);
      }, 1000);
    } else {
      isLoading.value = false;
      isSubmitDisabled.value = false;
      scene.steps.push({
        type: ScriptStepType.MESSAGE,
        data: {
          message:
            "Something went wrong while trying to communicate with server",
          options: [],
        },
      });
    }
  } else {
    // push text into responses array
    const aiResponse = await interact(fetchedBotData._id || "id", {
      message,
      sid: session.value,
    });

    if (aiResponse.isOk()) {
      scene.steps.push({
        type: ScriptStepType.MESSAGE,
        data: {
          message: aiResponse.value.payload.message,
          options: [],
        },
      });
      isLoading.value = false;
    } else {
      isLoading.value = false;
      scene.steps.push({
        type: ScriptStepType.MESSAGE,
        data: {
          message:
            "Something went wrong while trying to communicate with server",
          options: [],
        },
      });
    }
  }

  // scroll to bottom
  scrollToBottom("#message-container");
};

// calculate next step of bot flow
// make assignments or end flow
const calculateNextStep = function (): void {
  // remove loading indicator after a half second
  setTimeout(() => {
    isLoading.value = false;
  }, 500);
  // create 250ms gap between loading dissolve and new message appear transition
  setTimeout(async () => {
    // check is this end of bot flow?
    if (bot.data.script.steps.length > activeStep.value) {
      // if not
      // push next step into scene
      scene.steps.push(bot.data.script.steps[activeStep.value]);
      // scroll scene to bottom
      scrollToBottom("#message-container");

      // focus to text input if this step require manual input
      setTimeout(() => {
        if (bot.data.script.steps[activeStep.value].isManualInputAllowed) {
          document.getElementById("widget-text-input")?.focus();
        }
      }, 500);

      // if this step is a message? show loading indicator
      // because we know, if the type is message
      // m-script-step component will emit "replied" event after 500ms
      // so we need to show loading indicator till it'll emit that
      if (
        bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
      ) {
        isLoading.value = true;
      }
    } else {
      // const result = await createUserResponse({
      //   bot: bot.data._id || "fallback_id",
      //   values: response.data,
      // });
      // if (result.isOk()) {
      //   isCompleted.value = true;
      // } else {
      //   isErrorOccurred.value = true;
      //   errorMessage.value = t(result.error.message);
      // }
    }
  }, 750);
};

const fetchBotAndSetAssignments = async function (id: string): Promise<void> {
  const botDetailResponse = await getBotSafePublic({ id });
  isBotDataLoading.value = false;
  if (botDetailResponse.isOk()) {
    mixpanel.track("view_bot", {
      id: botDetailResponse.value.payload._id,
      bot: botDetailResponse.value.payload._id,
      organization: botDetailResponse.value.payload.organization._id,
    });
    if (!botDetailResponse.value.payload.isActive) {
      isErrorOccurred.value = true;
      return;
    }
    // store bot data for cache
    fetchedBotData = botDetailResponse.value.payload;
    // assign to bot state
    bot.data = botDetailResponse.value.payload;
    // push first step into scene
    scene.steps.push({
      type: ScriptStepType.MESSAGE,
      data: {
        message: bot.data.gptSettings.firstMessage,
        options: [],
      },
    });

    if (bot.data.design.pageCustomCSS) {
      const style = document.createElement("style");
      style.innerHTML =
        "@media (min-width: 640px) {" + bot.data.design.pageCustomCSS + "}";
      document.head.appendChild(style);
    }

    if (typeof bot.data.design.openerColor === "undefined") {
      bot.data.design.openerColor = "indigo";
    }

    if (typeof bot.data.design.bubbleColor === "undefined") {
      bot.data.design.bubbleColor = "indigo";
    }

    if (typeof bot.data.design.openerIcon === "undefined") {
      bot.data.design.openerIcon = "message-smile";
    }
  } else {
    isErrorOccurred.value = true;
    errorMessage.value = t("widget.BOT_NOT_FOUND");
  }
};

const trackBotEvent = async function (type: BotEventType) {
  await sendBotEvent({
    bot: bot.data._id + "",
    type,
  });
};

watch(isCompleted, async (_isCompleted) => {
  if (_isCompleted) {
    await trackBotEvent(BotEventType.COMPLETED);
  }
});

onMounted(async () => {
  setTimeout(async () => {
    await fetchBotAndSetAssignments($route.params.id as string);
  }, 1000);

  if (localStorage.getItem("mevo:sid")) {
    session.value = localStorage.getItem("mevo:sid") as string;
  } else {
    session.value = uuidv4();
    localStorage.setItem("mevo:sid", session.value);
  }
});
</script>

<style>
#message-container {
  scrollbar-gutter: stable both-edges;
}
</style>
