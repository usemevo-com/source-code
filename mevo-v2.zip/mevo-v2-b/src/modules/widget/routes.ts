import Widget from "./pages/Widget.vue";
import WidgetGPT from "./pages/WidgetGPT.vue";
import Bot from "./pages/Bot.vue";

export const WidgetRoutes = [
  {
    name: "widget-view",
    path: "/widget/:id",
    component: Widget,
    meta: { widget: true },
  },
  {
    name: "gpt-view",
    path: "/gpt/:id",
    component: WidgetGPT,
    meta: { widget: true },
  },
  {
    name: "common-bot-view",
    path: "/b/:bid",
    component: Bot,
  },
];
