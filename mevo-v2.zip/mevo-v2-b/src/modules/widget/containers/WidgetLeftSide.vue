<template>
  <!-- bg-[url('/imgs/bg-blue.jpeg')] -->
  <!-- bg-[url('/imgs/bg-yellow.jpeg')] -->
  <!-- bg-[url('/imgs/bg-pink.jpeg')] -->
  <!-- bg-[url('/imgs/bg-purple.jpeg')] -->
  <!-- bg-[url('/imgs/bg-green.jpeg')] -->
  <!-- bg-gradient-to-r from-primary via-blue-400 to-blue-300 -->
  <!-- bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-300 -->
  <!-- bg-gradient-to-r from-pink-500 via-pink-400 to-pink-300 -->
  <!-- bg-gradient-to-r from-purple-500 via-purple-400 to-purple-300 -->
  <!-- bg-gradient-to-r from-green-500 via-green-400 to-green-300 -->
  <!-- bg-gradient-to-r from-slate-500 via-slate-400 to-slate-300 -->
  <!-- bg-blue-200 bg-yellow-200 bg-pink-200 bg-purple-200 bg-green-200 bg-slate-200-->
  <!-- :class="`bg-gradient-to-r from-${theme}-400 via-${theme}-600 to-${theme}-800`" -->
  <div
    class="flex flex-col items-center justify-end h-screen w-1/3 hidden sm:flex py-8"
    :class="[
      useImage &&
        `bg-[url('https://cdn.usemevo.com/bg/${image}')] bg-repeat bg-[length:300px_300px]`,
    ]"
    :style="{ backgroundColor: color }"
  >
    <div
      v-if="!noMevoMark"
      class="flex flex-col py-2 px-4 items-center rounded shadow bg-primary text-white hidden sm:block"
    >
      <a target="_blank" href="https://usemevo.com">
        <div class="text-sm font-medium">
          made with
          <span class="font-black">mevo</span>
        </div>
      </a>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { PlanType } from "@/modules/organization/types/IPlan";
const props = defineProps([
  "image",
  "useImage",
  "color",
  "theme",
  "noMevoMark",
]);
</script>
