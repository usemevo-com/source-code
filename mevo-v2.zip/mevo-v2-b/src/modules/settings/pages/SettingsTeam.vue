<template>
  <m-settings-section
    :title="$t('settings.TEAM_SETTINGS')"
    :description="$t('settings.TEAM_SETTINGS_DESCRIPTION')"
  >
    <template #header-right>
      <Button class="h-fit" @click="onUserInvite" type="primary"
        >{{ $t('settings.INVITE_USER') }}
      </Button>
    </template>
    <table class="min-w-full divide-y divide-gray-300">
      <thead>
        <tr>
          <th
            scope="col"
            class="hidden sm:block py-3.5 px-4 text-left text-sm font-semibold text-gray-900"
          >
            {{ $t('common.NAME') }}
          </th>
          <th
            scope="col"
            class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6"
          >
            {{ $t('common.EMAIL') }}
          </th>
          <th
            scope="col"
            class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6"
          >
            {{ $t('common.ROLE') }}
          </th>
          <th></th>
        </tr>
      </thead>
      <tbody class="bg-white">
        <tr
          v-for="(user, uIndex) in team.data"
          :key="uIndex"
          :class="uIndex % 2 === 0 ? undefined : 'bg-gray-50'"
        >
          <td class="hidden sm:flex whitespace-nowrap py-4 px-4 text-sm text-gray-900 items-center">
            <img v-if="user.picture" class="w-6 h-6 rounded-full" :src="user.picture" />
            <img
              v-else
              class="w-6 h-6 rounded-full"
              :src="`https://gravatar.com/avatar/${md5(user.email)}`"
            />
            <div class="ml-2">{{ user.name }}</div>
          </td>
          <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6">
            {{ user.email }}
          </td>
          <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6">
            {{ user.role }}
          </td>
          <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6 flex-shrink-0">
            <button
              @click="removeAccess(user)"
              type="button"
              :class="uIndex % 2 !== 0 && '!bg-gray-50'"
              class="rounded-md bg-white font-medium text-red-600 hover:text-red-500 focus:outline-none"
            >
              {{ $t('settings.REMOVE_ACCESS') }}
            </button>
          </td>
        </tr>
        <tr
          v-if="activeOrganization"
          v-for="(user, uIndex) in activeOrganization.listeners"
          :key="uIndex"
          :class="uIndex % 2 === 0 ? undefined : 'bg-gray-50'"
        >
          <td class="hidden sm:flex whitespace-nowrap py-4 px-4 text-sm text-gray-900 items-center">
            <img v-if="user.picture" class="w-6 h-6 rounded-full" :src="user.picture" />
            <div class="ml-2">-</div>
          </td>
          <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6">
            {{ user.email }}
          </td>
          <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6">
            {{ $t('settings.NOTIFICATION_LISTENER') }}
          </td>
          <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6 flex-shrink-0">
            <button
              @click="removeAccess(user, true)"
              type="button"
              :class="uIndex % 2 !== 0 && '!bg-gray-50'"
              class="rounded-md bg-white font-medium text-red-600 hover:text-red-500 focus:outline-none"
            >
              {{ $t('settings.REMOVE_ACCESS') }}
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </m-settings-section>

  <invite-member-modal
    :open="isInviteModalOpen"
    @close="($event) => (isInviteModalOpen = false)"
    @cancel="() => (isInviteModalOpen = false)"
  />
  <remove-member-modal
    :user="userWillBeRemoved"
    :open="isRemoveAccessModalOpen"
    @close="($event) => (isRemoveAccessModalOpen = false)"
    @cancel="() => (isInviteModalOpen = false)"
  />
</template>

<script lang="ts" setup>
// externals
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import md5 from 'md5'

// internals
import { useOrganizations } from '@/composables/useOrganizations'
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import type { IUser } from '@/modules/prelogin/types/IUser'
import type { IOrganization } from '@/modules/organization/types/IOrganization'

// components
import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import InviteMemberModal from '@/modules/settings/containers/InviteMemberModal.vue'
import RemoveMemberModal from '@/modules/settings/containers/RemoveMemberModal.vue'
import MButton from '@/components/v2/elements/MButton.vue'
import { PlanType } from '@/modules/organization/types/IPlan'
import { useCommonStore } from '@/stores'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

// hooks
const { t } = useI18n()
const { organizations } = useOrganizations()
const { setUpgradeModal } = useCommonStore()
const { oid } = useRouteGlobals()

// states
const team: {
  data: { picture: string; name: string; email: string; role: string }[]
} = reactive({
  data: []
})
const isInviteModalOpen = ref(false)
const isRemoveAccessModalOpen = ref(false)
const userWillBeRemoved = ref({
  name: '',
  email: '',
  role: '',
  picture: ''
})
const activeOrganization = computed(
  () => organizations.value && organizations.value.find((o: IOrganization) => o._id === oid.value)
)

// methods
watch(activeOrganization, function (org) {
  if (org) {
    const admins = org.admins.map((a: { name: string; email: string; _id: string }) => ({
      ...a,
      role: 'Admin'
    }))
    const users = org.users.map((u: { name: string; email: string; _id: string }) => ({
      ...u,
      role: 'User'
    }))
    team.data = [...admins, ...users]
  }
})

onMounted(() => {
  if (activeOrganization.value) {
    const admins = activeOrganization.value.admins.map(
      (a: { name: string; email: string; _id: string }) => ({
        ...a,
        role: t('common.ADMIN')
      })
    )
    const users = activeOrganization.value.users.map(
      (u: { name: string; email: string; _id: string }) => ({
        ...u,
        role: t('common.USER')
      })
    )
    team.data = [...admins, ...users]
  }
})

const onUserInvite = () => {
  if (activeOrganization.value.plan === PlanType.BASIC) {
    setUpgradeModal(true)
  } else {
    isInviteModalOpen.value = true
  }
}

const removeAccess = (user: IUser, isListener: boolean = false) => {
  userWillBeRemoved.value = { ...user }
  isRemoveAccessModalOpen.value = true
  if (isListener) {
    userWillBeRemoved.value.role = 'notification-listener'
  }
}
</script>
