<template>
  <m-settings-section
    :title="$t('settings.UPGRADE_WITH_KEY')"
    :description="$t('settings.UPGRADE_WITH_KEY_DESCRIPTION')"
    pro
  >
    <dl>
      <div v-for="(key, index) in keys" class="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
        <dt class="text-sm font-medium text-gray-500 flex items-start flex-col">
          <div class="flex items-center">
            {{ $t('settings.PRODUCT_KEY') + ' ' + (index + 1) }}
          </div>
        </dt>
        <dd class="flex text-sm text-gray-900 sm:col-span-2">
          <span class="flex-grow">
            <Input
              rules="required|minMax:8,255"
              v-model="keys[index]"
              name="org-name"
              type="text"
              class="w-full sm:w-64"
              :placeholder="$t('settings.PRODUCT_KEY_PLACEHOLDER')"
            />
          </span>
          <Button v-if="index !== 0" @clicked="removeKey(index)" type="danger" class="ml-4">
            <i class="fa fa-sharp fa-trash mr-2"></i>
            Remove
          </Button>
        </dd>
      </div>
    </dl>
    <template #footer-section>
      <dt class="text-sm font-medium text-gray-500"></dt>
      <dd class="flex justify-end text-sm text-gray-900 sm:col-span-2 mt-8">
        <Button class="mr-4" @clicked="addAnotherKey()" type="white">
          <i class="fa fa-sharp fa-plus mr-2"></i>
          Add another key
        </Button>
        <Button type="primary" @click="onSubmit">{{ $t('settings.UPGRADE') }}</Button>
      </dd>
    </template>
  </m-settings-section>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from 'vue'
import mixpanel from 'mixpanel-browser'

import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import MTextInput from '@/components/basic/MTextInput.vue'
import MButton from '@/components/v2/elements/MButton.vue'
import { upgradeWithKey } from '@/modules/organization/services/OrganizationService'
import { useOrganizations } from '@/composables/useOrganizations'
import { useSubscription } from '@/composables/useSubscription'
import { NotificationType, useCommonStore } from '@/stores'
import { useI18n } from 'vue-i18n'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const { refreshOrganizations } = useOrganizations()
const { setNotification } = useCommonStore()
const { activeOrganization } = useSubscription()
const { t } = useI18n()

const keys = reactive<string[]>([''])

const addAnotherKey = () => {
  if (keys.length >= 3) return
  keys.push('')
}

const removeKey = (index: number) => {
  if (keys.length === 1) return
  keys.splice(index)
}

const onSubmit = async () => {
  try {
    const upgradeResponse = await upgradeWithKey({
      keys,
      organization: activeOrganization.value._id || ''
    })

    if (upgradeResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "use_product_key",
        "count": 1,
        "segmentation": {
          oid: activeOrganization.value._id,
          success: true,
        }
      }]);
      setNotification(t(upgradeResponse.value.payload.message), NotificationType.SUCCESS)
      refreshOrganizations()
    } else {
      window.Countly.q.push(['add_event',{
        "key": "use_product_key",
        "count": 1,
        "segmentation": {
          oid: activeOrganization.value._id,
          success: false,
        }
      }]);
      setNotification(t(upgradeResponse.error.message), NotificationType.ERROR)
    }
  } catch (error) {
    setNotification(t('common.SOMETHING_WENT_WRONG'), NotificationType.ERROR)
  }
}

onMounted(() => {
  refreshOrganizations()
})
</script>
