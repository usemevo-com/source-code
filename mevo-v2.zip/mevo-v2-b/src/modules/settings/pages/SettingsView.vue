<template>
  <div class="flex flex-col relative p-8 w-full">
    <!-- HEADER -->
    <m-page-header
      :title="$t('settings.TITLE')"
      :subtitle="activeOrganization && activeOrganization.name"
    />

    <!-- SETTINGS NAV TAB -->
    <Tabs v-model="activeTab" default-value="account" class="my-8">
      <TabsList class="w-fit flex justify-start space-x-2">
        <router-link v-for="tab in tabs" :key="tab.name" :to="tab.href">
          <TabsTrigger :value="tab.key">{{ tab.name }}</TabsTrigger>
        </router-link>
      </TabsList>
    </Tabs>

    <!-- ROUTER CONTENT -->
    <router-view />
  </div>
</template>

<script lang="ts" setup>
// externals
import { computed, onMounted, reactive, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'

// internals
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { useOrganizations } from '@/composables/useOrganizations'
import { usePermission } from '@/composables/usePermission'
import type { IOrganization } from '@/modules/organization/types/IOrganization'

// components
import MPageHeader from '@/components/v2/elements/MPageHeader.vue'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'

// hooks
const { organizations } = useOrganizations()
const { t } = useI18n()
const { oid } = useRouteGlobals()
const { isAdmin } = usePermission()
const $route = useRoute()

// states
const activeOrganization = computed(
  () => organizations.value && organizations.value.find((o: IOrganization) => o._id === oid.value)
)
const tabs = reactive([
  {
    key: 'account-settings',
    name: t('settings.ACCOUNT'),
    href: `/o/${oid.value}/settings/account`,
    current: computed(() => $route.name === 'account-settings'),
    hide: false
  }
])

const adminTabs = [
  {
    key: 'organization-settings',
    name: t('settings.ORGANIZATION'),
    href: `/o/${oid.value}/settings/organization`,
    current: computed(() => $route.name === 'organization-settings'),
    hide: computed(() => !isAdmin.value)
  },
  {
    key: 'team-settings',
    name: t('settings.TEAM'),
    href: `/o/${oid.value}/settings/team`,
    current: computed(() => $route.name === 'team-settings'),
    hide: computed(() => !isAdmin.value)
  },
  {
    key: 'subscription-settings',
    name: t('settings.SUBSCRIPTION'),
    href: `/o/${oid.value}/settings/subscription`,
    hide: computed(() => !isAdmin.value),
    current: computed(() => $route.name === 'subscription-settings')
  },
  {
    key: 'integration-settings',
    name: t('settings.INTEGRATION'),
    href: `/o/${oid.value}/settings/integration`,
    hide: computed(() => !isAdmin.value),
    current: computed(() => $route.name === 'integration-settings')
  },
  {
    key: 'notification-settings',
    name: t('settings.NOTIFICATION'),
    href: `/o/${oid.value}/settings/notification`,
    hide: computed(() => !isAdmin.value),
    current: computed(() => $route.name === 'notification-settings')
  },
  {
    key: 'upgrade-with-key',
    name: t('settings.UPGRADE_WITH_KEY'),
    href: `/o/${oid.value}/settings/upgrade-with-key`,
    hide: computed(() => !isAdmin.value),
    current: computed(() => $route.name === 'upgrade-with-key')
  }
]

// computed
const activeTab = computed(() => $route.name)

watch(isAdmin, () => {
  // if isAdmin true, add adminTabs to tabs
  if (isAdmin.value) {
    // @ts-ignore
    tabs.push(...adminTabs)
  }
})

onMounted(() => {
  // if isAdmin true, add adminTabs to tabs
  if (isAdmin.value) {
    // @ts-ignore
    tabs.push(...adminTabs)
  }
})
</script>
