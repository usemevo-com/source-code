<template>
  <m-settings-section
    :title="$t('settings.INTEGRATION_SETTINGS')"
    :description="$t('settings.INTEGRATION_SETTINGS_DESCRIPTION')"
    pro
  >
    <dl>
      <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
        <dt class="text-sm font-medium text-gray-500 flex items-start flex-col">
          <div class="flex items-center">
            {{ $t('settings.WEB_HOOK_URL') }}
            <m-badge
              v-if="activePlan === Plans[PlanType.BASIC]"
              type="success"
              text="PRO"
              class="w-fit ml-2 h-fit"
            />
          </div>
          <div class="text-xs text-indigo-500 mt-1">
            Need help about webhooks?
            <a
              class="underline"
              href="https://www.notion.so/mevo-knowledge-base/How-can-you-receive-notifications-using-Mevo-s-webhook-feature-with-Zapier-17e20cb00fff4828a7560aa796a3e2dc?pvs=4"
              target="_blank"
              >Check our tutorial!</a
            >
          </div>
        </dt>
        <dd class="mt-1 flex text-sm text-gray-900 sm:col-span-2 sm:mt-0">
          <span class="flex-grow">
            <Input
              :disabled="activePlan === Plans[PlanType.BASIC]"
              rules="required|minMax:8,255"
              v-model="webhookURL"
              name="org-name"
              type="text"
              class="w-full sm:w-64"
              :placeholder="$t('settings.WEB_HOOK_URL_PLACEHOLDER')"
            />
          </span>
        </dd>
      </div>
    </dl>
    <template #footer-section>
      <dt class="text-sm font-medium text-gray-500"></dt>
      <dd class="mt-1 flex justify-end text-sm text-gray-900 sm:col-span-2 sm:mt-0">
        <Button :disabled="activePlan === Plans[PlanType.BASIC]" type="primary" @click="onSubmit">{{
          $t('common.SAVE_CHANGES')
        }}</Button>
      </dd>
    </template>
  </m-settings-section>
</template>

<script lang="ts" setup>
import { onMounted, ref, watch } from 'vue'
import mixpanel from 'mixpanel-browser'

import { useSubscription } from '@/composables/useSubscription'
import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import MTextInput from '@/components/basic/MTextInput.vue'
import MButton from '@/components/v2/elements/MButton.vue'
import MBadge from '@/components/v2/elements/MBadge.vue'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { NotificationType, useCommonStore } from '@/stores'
import { useI18n } from 'vue-i18n'
import { setWebhookURL } from '@/modules/organization/services/OrganizationService'
import { Plans, PlanType } from '@/modules/organization/types/IPlan'
import { useOrganizations } from '@/composables/useOrganizations'

const { refreshOrganizations } = useOrganizations()
const { activeOrganization, activePlan } = useSubscription()
const { setNotification } = useCommonStore()
const { t } = useI18n()

const webhookURL = ref('')

watch(activeOrganization, (newVal) => {
  webhookURL.value = activeOrganization.value.webhookURL || ''
})

const onSubmit = async () => {
  if (
    webhookURL.value === '' ||
    /[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/.test(
      webhookURL.value
    )
  ) {
    if (activeOrganization.value._id) {
      const webhookResponse = await setWebhookURL(activeOrganization.value._id, webhookURL.value)

      if (webhookResponse.isOk()) {
        window.Countly.q.push(['add_event',{
          "key": "set_webhook",
          "count": 1,
          segmentation: {
            organization: activeOrganization.value._id,
            success: true,
            webhook: webhookURL.value
          }
        }]);

        setNotification(t('settings.WEB_HOOK_URL_UPDATED'), NotificationType.SUCCESS)
      } else {
        setNotification(t('settings.WEB_HOOK_URL_UPDATE_FAILED'))

        window.Countly.q.push(['add_event',{
          "key": "set_webhook",
          "count": 1,
          segmentation: {
            organization: activeOrganization.value._id,
            success: false,
            webhook: webhookURL.value
          }
        }]);
      }
    }
  } else {
    setNotification(t('settings.INVALID_WEB_HOOK_URL'))
  }
}

onMounted(() => {
  refreshOrganizations()
})
</script>
