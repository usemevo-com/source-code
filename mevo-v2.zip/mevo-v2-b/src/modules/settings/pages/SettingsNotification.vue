<template>
  <m-settings-section
    :title="$t('settings.NOTIFICATION_SETTINGS')"
    :description="$t('settings.NOTIFICATION_SETTINGS_DESCRIPTION')"
  >
    <div class="flex w-full justify-between items-center pb-8">
      <div>
        <div class="text-sm font-medium text-gray-700">
          {{ $t('settings.ENABLE_EMAIL_NOTIFICATIONS_ADMINS') }}
        </div>
        <div class="text-gray-400 text-sm">
          <span>{{ $t('settings.ENABLE_EMAIL_NOTIFICATIONS_ADMINS_DESCRIPTION') }}</span>
        </div>
      </div>
      <div>
        <m-checkbox v-model="emailNotificationPreference" />
      </div>
    </div>
    <template #footer-section>
      <dt class="text-sm font-medium text-gray-500"></dt>
      <dd class="mt-1 flex justify-end text-sm text-gray-900 sm:col-span-2 sm:mt-0">
        <Button type="primary" @click="onSubmit">{{ $t('common.SAVE_CHANGES') }}</Button>
      </dd>
    </template>
  </m-settings-section>
</template>

<script lang="ts" setup>
import { onMounted, ref, watch } from 'vue'
import mixpanel from 'mixpanel-browser'
import { useI18n } from 'vue-i18n'

import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import MTextInput from '@/components/basic/MTextInput.vue'
import MCheckbox from '@/components/v2/elements/MCheckbox.vue'
import MButton from '@/components/v2/elements/MButton.vue'
import MBadge from '@/components/v2/elements/MBadge.vue'

import { useSubscription } from '@/composables/useSubscription'
import { NotificationType, useCommonStore } from '@/stores'
import { updateOrganization } from '@/modules/organization/services/OrganizationService'
import { Plans, PlanType } from '@/modules/organization/types/IPlan'
import { useOrganizations } from '@/composables/useOrganizations'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const { refreshOrganizations } = useOrganizations()
const { activeOrganization, activePlan } = useSubscription()
const { setNotification } = useCommonStore()
const { t } = useI18n()

const emailNotificationPreference = ref<boolean>(true)

const onSubmit = async () => {
  const updateOrganizationResponse = await updateOrganization(activeOrganization.value._id, {
    sendEmailNotificationsToAdmins: emailNotificationPreference.value,
    name: activeOrganization.value.name
  })

  if (updateOrganizationResponse) {
    setNotification('Notification preference updated successfully', NotificationType.SUCCESS)
  } else {
    setNotification(t('common.SOMETHING_WENT_WRONG'), NotificationType.ERROR)
  }
}

onMounted(() => {
  refreshOrganizations()
})

watch(activeOrganization, () => {
  if (
    activeOrganization.value &&
    typeof activeOrganization.value.sendEmailNotificationsToAdmins !== 'undefined'
  ) {
    emailNotificationPreference.value = activeOrganization.value.sendEmailNotificationsToAdmins
  } else {
    emailNotificationPreference.value = true
  }
})
</script>
