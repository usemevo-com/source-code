<template>
  <!-- UPGRADE TO PRO SECTION IF PLAN IS BASIC -->
  <m-settings-section
    v-if="activePlan.name === PlanType.BASIC"
    :title="$t('settings.UPGRADE_TO_PRO')"
    :description="`${$t(
      'settings.UPGRADE_TO_PRO_DESCRIPTION_1'
    )} ${ProPrice} ${$t('settings.UPGRADE_TO_PRO_DESCRIPTION_2')}`"
    :is-horizontal="true"
    :has-footer="false"
  >
    <m-button class="h-fit w-36" @clicked="setUpgradeModal(true)" type="primary">{{
      $t('settings.UPGRADE_NOW')
    }}</m-button>
  </m-settings-section>

  <!-- COME BACK TO PRO SECTION IF USER CANCELLED SUBSCRIPTION -->
  <m-settings-section
    v-if="
      activeOrganization &&
      [PlanType.PRO, PlanType.PRO_NEW, PlanType.LITE_NEW, PlanType.MAX_NEW].includes(
        activePlan.name
      ) &&
      activeOrganization.subscriptionCancelled
    "
    :title="$t('settings.COME_BACK_TO_PRO')"
    :description="`${$t('settings.COME_BACK_TO_PRO_DESCRIPTION_1')} ${
      activeOrganization && subscriptionEndDate
    }.`"
    :is-horizontal="true"
    :has-footer="false"
  >
    <Button class="h-fit w-28" @click="reactivatePlan" type="primary">{{
      $t('settings.REACTIVATE')
    }}</Button>
  </m-settings-section>

  <!-- SETTINGS CONTENT AREA -->
  <m-settings-section
    :class="[
      activeOrganization &&
      (activeOrganization.plan === PlanType.BASIC || activeOrganization.subscriptionCancelled)
        ? 'mt-8'
        : ''
    ]"
    :title="$t('settings.SUBSCRIPTION_SETTINGS')"
    :description="$t('settings.SUBSCRIPTION_SETTINGS_DESCRIPTION')"
  >
    <div class="flex justify-between">
      <dl class="w-1/2">
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.ACTIVE_PLAN') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.ACTIVE_PLAN_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span v-if="activeOrganization" class="capitalize">{{
              activeOrganization &&
              activeOrganization.plan &&
              activeOrganization.plan === PlanType.LTD
                ? $t('plan.APP_SUMO_LTD')
                : activeOrganization.plan
            }}</span>
          </dd>
        </div>
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.PRICE') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.PRICE_DESC') }}
            </div>
          </dt>
          <dd
            v-if="activePeriod?.subscriptionType === 'yearly'"
            class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0"
          >
            <span class="flex-grow">{{
              (activePlan.price * 10).toLocaleString('en-US', {
                style: 'currency',
                currency: 'USD'
              })
            }}</span>
          </dd>
          <dd v-else class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{
              activePlan.price.toLocaleString('en-US', {
                style: 'currency',
                currency: 'USD'
              })
            }}</span>
          </dd>
        </div>
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.BOT_LIMIT_USAGE') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.BOT_LIMIT_USAGE_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{ bots && bots.length }} / {{ activePlan.limits.bot }}</span>
          </dd>
        </div>
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.USER_LIMIT_USAGE') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.USER_LIMIT_USAGE_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{ team.data.length }} / {{ activePlan.limits.user }}</span>
          </dd>
        </div>
      </dl>
      <dl class="w-1/2">
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.RESET_DATE') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.RESET_DATE_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">
              {{
                activeOrganization
                  ? AppConfig.$filters.formatDateLong(activeOrganization.activePeriod.end)
                  : ''
              }}
            </span>
          </dd>
        </div>

        <div v-if="activeOrganization && activePlan.limits.rb_allowed" class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.RESPONSE_LIMIT_USAGE') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.RESPONSE_LIMIT_USAGE_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{ usageValue }} / {{ organizationResponseLimit }}</span>
          </dd>
        </div>
        <!-- <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.SUPPORT_LEVEL') }}
          </dt>
          <dd  class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{
              activePlan.limits.support === 1
                ? $t('plan.PREMIUM_SUPPORT')
                : $t('plan.COMMUNITY_SUPPORT')
            }}</span>
          </dd>
        </div> -->
        <div v-if="activeOrganization && activePlan.limits.custom_domain_allowed" class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.CUSTOM_DOMAIN') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.CUSTOM_DOMAIN_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow"
              >{{ organizationCustomDomainUsage }} / {{ activePlan.limits.customDomain }}</span
            >
          </dd>
        </div>
        <div
          v-if="activeOrganization && !activeOrganization.useLegacyPricing"
          class="py-4 sm:grid sm:grid-cols-3 sm:gap-4"
        >
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.MESSAGES_LIMIT') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.MESSAGES_LIMIT_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">
              {{ activeOrganization && activeOrganization.activePeriod.message_usage }} /
              {{ activePlan.limits.message }}
            </span>
          </dd>
        </div>
        <div
          v-if="activeOrganization && activeOrganization.useLegacyPricing"
          class="py-4 sm:grid sm:grid-cols-3 sm:gap-4"
        >
          <dt class="text-sm font-medium text-gray-500">
            Monthly token limit
            <div class="text-xs text-gray-400 text-light mt-1">
              Tokens are used by AI chatbots to generate responses.
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">
              {{ activeOrganization && activeOrganization.monthlyTokenUsage }} /
              {{ activePlan.limits.token }}
            </span>
          </dd>
        </div>
        <div
          class="py-4 sm:grid sm:grid-cols-3 sm:gap-4"
        >
          <dt class="text-sm font-medium text-gray-500">
            Monthly email sending limit
            <div class="text-xs text-gray-400 text-light mt-1">
              How many emails can be sent to your customers from inbox.
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">
              {{ activeOrganization && activeOrganization.activePeriod.email_usage ? activeOrganization.activePeriod.email_usage : 0 }} /
              {{ activePlan.limits.email_limit }}
            </span>
          </dd>
        </div>
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('settings.TRAINING_CHAR_USAGE') }}
            <div class="text-xs text-gray-400 text-light mt-1">
              {{ $t('settings.TRAINING_CHAR_USAGE_DESC') }}
            </div>
          </dt>
          <dd class="mt-1 flex items-center text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow"
              >{{ activeOrganization && activeOrganization.trainingCharacterUsage }} /
              {{ activePlan.limits.charLimit.toLocaleString() }}</span
            >
          </dd>
        </div>
      </dl>
    </div>
  </m-settings-section>

  <!-- BILLING MANAGEMENT AREA IF PLAN IS PRO -->
  <m-settings-section
    v-if="
      [PlanType.PRO, PlanType.PRO_NEW, PlanType.LITE_NEW, PlanType.MAX_NEW].includes(
        activePlan.name
      ) &&
      activeOrganization &&
      !activeOrganization.subscriptionCancelled
    "
    :title="$t('settings.BILLING_MANAGEMENT')"
    :description="`${$t('settings.BILLING_MANAGEMENT_DESCRIPTION')}`"
    :is-horizontal="true"
    :has-footer="false"
    class="mt-8"
  >
    <div class="w-full flex justify-between">
      <Button
        :disabled="isBillingPortalLoading"
        class="mr-2"
        @click="navigateToBillingPortal"
        type="white"
      >
        <i v-if="isBillingPortalLoading" class="fa fa-spinner-third animate-spin mr-2 text-xs"></i>
        {{ $t('settings.GO_BILLING_MANAGEMENT') }}
      </Button>
      <Button @click="isSubscriptionCancelModalOpen = true" type="white">
        {{ $t('settings.CANCEL_SUBSCRIPTION') }}
      </Button>
    </div>
  </m-settings-section>

  <subscription-cancel-modal
    :open="isSubscriptionCancelModalOpen"
    @close="isSubscriptionCancelModalOpen = false"
  />
</template>

<script lang="ts" setup>
// externals
import { computed, reactive, watch, ref } from 'vue'
import { useRouter } from 'vue-router'
import mixpanel from 'mixpanel-browser'

// internals
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { useOrganizations } from '@/composables/useOrganizations'
import { PlanType, ProPlan, SubscriptionType } from '@/modules/organization/types/IPlan'
import { useBots } from '@/composables/useBots'
import type { IOrganization } from '@/modules/organization/types/IOrganization'
import AppConfig from '@/utils/helpers/app-config'

// services
import { getBillingManagementUrl } from '@/modules/organization/services/OrganizationService'

// components
import MButton from '@/components/v2/elements/MButton.vue'
import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import SubscriptionCancelModal from '../containers/SubscriptionCancelModal.vue'
import { useSubscription } from '@/composables/useSubscription'
import { useUsage } from '@/composables/useUsage'
import { useCommonStore } from '@/stores'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

// hooks
const $router = useRouter()
const { organizations } = useOrganizations()
const { bots } = useBots()
const { oid } = useRouteGlobals()
const { upgradePlan, activePlan } = useSubscription()
const { setUpgradeModal } = useCommonStore()
const {
  organizationResponseLimit,
  organizationResponseUsage,
  organizationCustomDomainUsage,
  organizationLimitExceed,
  activePeriod
} = useUsage()

const usageValue = computed(() => {
  if (organizationLimitExceed.value > 0) {
    return organizationResponseLimit.value
  }
  return organizationResponseUsage.value
})

const reactivatePlan = async function () {
  await upgradePlan(activeOrganization.value.plan, SubscriptionType.MONTHLY)
}

// states
const team: { data: { name: string; email: string; role: string }[] } = reactive({
  data: []
})
const isSubscriptionCancelModalOpen = ref(false)
const isBillingPortalLoading = ref(false)

const activeOrganization = computed(
  () => organizations.value && organizations.value.find((o: IOrganization) => o._id === oid.value)
)
const subscriptionEndDate = computed(() =>
  AppConfig.$filters.formatDate(activeOrganization.value.subscriptionEndAt)
)
const ProPrice = ProPlan.price.toLocaleString('en-US', {
  style: 'currency',
  currency: 'USD'
})

// methods
watch(activeOrganization, function (org) {
  if (org) {
    const admins = org.admins.map((a: { name: string; email: string; _id: string }) => ({
      ...a,
      role: 'Admin'
    }))
    const users = org.users.map((u: { name: string; email: string; _id: string }) => ({
      ...u,
      role: 'User'
    }))
    team.data = [...admins, ...users]
  }
})

const navigateToBillingPortal = async function () {
  isBillingPortalLoading.value = true
  const billingManagementUrlResponse = await getBillingManagementUrl(oid.value)
  isBillingPortalLoading.value = false
  if (billingManagementUrlResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "go_stripe_billing_portal",
      "count": 1,
      segmentation: {
        organization: oid.value,
        success: true
      }
    }]);
    $router.push(`/redirect?url=${billingManagementUrlResponse.value.payload.url}&oid=${oid.value}`)
  } else {
    window.Countly.q.push(['add_event',{
      "key": "go_stripe_billing_portal",
      "count": 1,
      segmentation: {
        organization: oid.value,
        success: false
      }
    }]);
  }
}
</script>
