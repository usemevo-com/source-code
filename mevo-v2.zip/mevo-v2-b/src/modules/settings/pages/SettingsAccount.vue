<template>
  <div class="space-y-6">
    <!-- Existing Account Information Section -->
    <m-settings-section
      :title="$t('settings.ACCOUNT_SETTINGS')"
      :description="$t('settings.ACCOUNT_SETTINGS_DESCRIPTION')"
    >
      <dl>
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('common.NAME') }}
          </dt>
          <dd class="mt-1 flex text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{ user.name }}</span>
          </dd>
        </div>
        <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:pt-5">
          <dt class="text-sm font-medium text-gray-500">
            {{ $t('common.EMAIL') }}
          </dt>
          <dd class="mt-1 flex text-sm text-gray-900 sm:col-span-2 sm:mt-0">
            <span class="flex-grow">{{ user.email }}</span>
          </dd>
        </div>
      </dl>
    </m-settings-section>

    <!-- GDPR Data Deletion Section -->
    <m-settings-section
      :title="$t('settings.DANGER_ZONE')"
      :description="$t('settings.DATA_DELETION_DESCRIPTION')"
    >
      <div class="bg-red-50 border border-red-200 rounded-lg p-6">
        <div class="flex items-start">
          <exclamation-triangle-icon class="h-6 w-6 text-red-600 mt-1 mr-4 flex-shrink-0" />
          <div class="flex-1">
            <h3 class="text-lg font-medium text-red-900 mb-2">
              {{ $t('settings.DATA_DELETION_TITLE') }}
            </h3>
            <p class="text-red-800 mb-4">
              {{ $t('settings.DATA_DELETION_WARNING') }}
            </p>
            
            <div class="bg-white border border-red-200 rounded-md p-4 mb-4">
              <h4 class="text-sm font-medium text-gray-900 mb-2">
                {{ $t('settings.DATA_DELETION') }}:
              </h4>
              <ul class="text-sm text-gray-600 space-y-1">
                <li class="flex items-center">
                  <check-icon class="h-4 w-4 text-red-500 mr-2" />
                  {{ $t('common.ACCOUNT') }} ({{ user.email }})
                </li>
                <li class="flex items-center">
                  <check-icon class="h-4 w-4 text-red-500 mr-2" />
                  {{ $t('common.ORGANIZATIONS') }}
                </li>
                <li class="flex items-center">
                  <check-icon class="h-4 w-4 text-red-500 mr-2" />
                  {{ $t('common.BOTS') }}
                </li>
                <li class="flex items-center">
                  <check-icon class="h-4 w-4 text-red-500 mr-2" />
                  {{ $t('common.MESSAGES') }}
                </li>
                <li class="flex items-center">
                  <check-icon class="h-4 w-4 text-red-500 mr-2" />
                  {{ $t('common.LEADS') }}
                </li>
                <li class="flex items-center">
                  <check-icon class="h-4 w-4 text-red-500 mr-2" />
                  {{ $t('common.TRAINING_DATA') }} ({{ $t('common.LINKS') }}, {{ $t('common.FILES') }}, {{ $t('common.TEXTS') }}, {{ $t('common.QUESTIONS') }})
                </li>
              </ul>
            </div>

            <button
              @click="showDeleteModal = true"
              class="inline-flex items-center px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors"
            >
              <trash-icon class="h-4 w-4 mr-2" />
              {{ $t('settings.DELETE_ACCOUNT_BUTTON') }}
            </button>
          </div>
        </div>
      </div>
    </m-settings-section>

    <!-- Delete Account Modal -->
    <delete-account-modal
      :open="showDeleteModal"
      @close="showDeleteModal = false"
    />
  </div>
</template>

<script lang="ts" setup>
// externals
import { computed, ref } from 'vue'
import { ExclamationTriangleIcon, CheckIcon, TrashIcon } from "@heroicons/vue/24/outline"

// internals
import { useAuthStore } from '@/stores'

// components
import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import DeleteAccountModal from '@/modules/settings/containers/DeleteAccountModal.vue'

// hooks
const { user } = useAuthStore()

// reactive data
const showDeleteModal = ref(false)

// computed (keeping the original pp computed for potential future use)
const pp = computed(() => `https://gravatar.com/avatar/${btoa(user.email)}`)
</script>
