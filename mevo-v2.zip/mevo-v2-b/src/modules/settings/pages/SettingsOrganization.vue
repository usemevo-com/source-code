<template>
  <!-- PRIMARY SECTION -->
  <m-settings-section
    :title="$t('settings.ORGANIZATION_SETTINGS')"
    :description="$t('settings.ORGANIZATION_SETTINGS_DESCRIPTION')"
  >
    <dl>
      <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
        <dt class="text-sm font-medium text-gray-500">
          {{ $t('common.NAME') }}
        </dt>
        <dd class="mt-1 flex text-sm text-gray-900 sm:col-span-2 sm:mt-0">
          <span class="flex-grow">
            <Input
              rules="required|minMax:8,255"
              v-model="organization.data.name"
              name="org-name"
              type="text"
              class="w-full sm:w-64"
              :placeholder="$t('fields.ORGANIZATON_NAME')"
            />
          </span>
        </dd>
      </div>
      <div class="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:pt-5">
        <dt class="text-sm font-medium text-gray-500">
          {{ $t('organizations.DOMAIN') }}
        </dt>
        <dd class="mt-1 flex text-sm text-gray-900 sm:col-span-2 sm:mt-0">
          <Input
            rules="required|minMax:8,255"
            v-model="organization.data.domain"
            name="org-name"
            type="text"
            class="w-full sm:w-64"
            :placeholder="$t('organizations.DOMAIN')"
          />
        </dd>
      </div>
    </dl>
    <template #footer-section>
      <dt class="text-sm font-medium text-gray-500"></dt>
      <dd class="mt-1 flex justify-end text-sm text-gray-900 sm:col-span-2 sm:mt-0">
        <Button type="primary" @click="onSubmit">{{ $t('common.SAVE_CHANGES') }}</Button>
      </dd>
    </template>
  </m-settings-section>

  <m-settings-section
    v-if="hasRightToCustomAPIKey"
    class="mt-8"
    :title="$t('settings.OPEN_AI_SETTINGS')"
    :description="
      activeOrganization.apiKeySet
        ? $t('organizations.YOU_LINKED_KEY')
        : $t('organizations.YOU_DIDNT_LINK_KEY')
    "
    :has-footer="false"
    is-horizontal
  >
    <div class="flex justify-end">
      <div>
        <Input
          v-model="openAIKey"
          name="api-key"
          type="password"
          class="w-full sm:w-64"
          :placeholder="$t('organizations.OPEN_AI_KEY_PLACEHOLDER')"
        />
      </div>
      <Button @click="setAPIKey" class="w-fit ml-4" type="white">
        {{
          activeOrganization.apiKeySet
            ? $t('organizations.UPDATE_KEY')
            : $t('organizations.LINK_KEY')
        }}
      </Button>
      <Button
        v-if="activeOrganization.apiKeySet"
        @click="deleteAPIKey"
        class="w-fit ml-4"
        type="danger"
      >
        {{ $t('organizations.REMOVE_KEY') }}
      </Button>
    </div>
  </m-settings-section>

  <!-- DANGER ZONE -->
  <m-settings-section
    class="my-8"
    :title="$t('settings.DANGER_ZONE')"
    :description="$t('settings.DANGER_ZONE_DESCRIPTION')"
    :has-footer="false"
    is-horizontal
  >
    <Button type="danger" @click="() => (isOrganizationRemoveModal = true)">{{
      $t('settings.REMOVE_ORGANIZATION')
    }}</Button>
  </m-settings-section>

  <!-- MODAL -->
  <remove-organization-modal
    :name="organization.data.name"
    :open="isOrganizationRemoveModal"
    @close="isOrganizationRemoveModal = false"
    @cancel="isOrganizationRemoveModal = false"
  />
</template>

<script lang="ts" setup>
// externals
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import mixpanel from 'mixpanel-browser'

// internals
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { useOrganizations } from '@/composables/useOrganizations'
import { NotificationType, useCommonStore } from '@/stores'

// services
import {
  updateAPIKey,
  removeAPIKey,
  updateOrganization
} from '@/modules/organization/services/OrganizationService'
import type { IOrganization } from '@/modules/organization/types/IOrganization'

// components
import MButton from '@/components/v2/elements/MButton.vue'
import MSettingsSection from '@/components/v2/elements/MSettingsSection.vue'
import MTextInput from '@/components/basic/MTextInput.vue'
import RemoveOrganizationModal from '@/modules/settings/containers/RemoveOrganizationModal.vue'
import { useSubscription } from '@/composables/useSubscription'
import { PlanType } from '@/modules/organization/types/IPlan'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

// hooks
const { t } = useI18n()
const { setNotification } = useCommonStore()
const { organizations } = useOrganizations()
const { oid } = useRouteGlobals()
const { activePlan, refreshOrganizations } = useSubscription()

// states
const organization = reactive({
  data: {
    name: '',
    domain: ''
  }
})
const isOrganizationRemoveModal = ref(false)
const openAIKey = ref('')
const activeOrganization = computed(
  () => organizations.value && organizations.value.find((o: IOrganization) => o._id === oid.value)
)
const hasRightToCustomAPIKey = computed(() => {
  return activePlan.value.limits.customApiKey === 1
})

// methods
watch(activeOrganization, function (org) {
  if (org) {
    organization.data.name = org.name
    organization.data.domain = org.domain
  }
})

onMounted(() => {
  if (activeOrganization.value) {
    organization.data.name = activeOrganization.value.name
    organization.data.domain = activeOrganization.value.domain
  }
})

const onSubmit = async () => {
  const updateResponse = await updateOrganization(activeOrganization.value._id, organization.data)

  if (updateResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "update_organization",
      "count": 1,
      segmentation: {
        organization: activeOrganization.value._id,
        success: true,
        data: organization.data
      }
    }]);

    setNotification(t('settings.ORGANIZATION_UPDATED_SUCCESSFULLY'), NotificationType.SUCCESS)
  } else {
    window.Countly.q.push(['add_event',{
      "key": "update_organization",
      "count": 1,
      segmentation: {
        organization: activeOrganization.value._id,
        success: false,
        data: organization.data
      }
    }]);
    setNotification(t(updateResponse.error.message), NotificationType.ERROR)
  }
}

const deleteAPIKey = async () => {
  const apiKeyRemoveResponse = await removeAPIKey(activeOrganization.value._id)

  if (apiKeyRemoveResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "remove_open_ai_api_key",
      "count": 1,
      segmentation: {
        organization: activeOrganization.value._id,
        success: true
      }
    }]);
    openAIKey.value = ''
    setNotification(t('settings.API_KEY_REMOVED'), NotificationType.SUCCESS)
    refreshOrganizations()
  } else {
    window.Countly.q.push(['add_event',{
      "key": "remove_open_ai_api_key",
      "count": 1,
      segmentation: {
        organization: activeOrganization.value._id,
        success: false
      }
    }]);
    setNotification(t(apiKeyRemoveResponse.error.message), NotificationType.ERROR)
  }
}

const setAPIKey = async () => {
  const apiKeyUpdateResponse = await updateAPIKey(activeOrganization.value._id, openAIKey.value)

  if (apiKeyUpdateResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "set_open_ai_api_key",
      "count": 1,
      segmentation: {
        organization: activeOrganization.value._id,
        success: true
      }
    }]);
    
    setNotification(t('settings.API_KEY_UPDATED'), NotificationType.SUCCESS)
    refreshOrganizations()
  } else {
    window.Countly.q.push(['add_event',{
      "key": "set_open_ai_api_key",
      "count": 1,
      segmentation: {
        organization: activeOrganization.value._id,
        success: false
      }
    }]);

    setNotification(t(apiKeyUpdateResponse.error.message), NotificationType.ERROR)
  }
}
</script>
