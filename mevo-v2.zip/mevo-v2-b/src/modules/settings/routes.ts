import Settings from "./pages/SettingsView.vue";
import SettingsAccount from "./pages/SettingsAccount.vue";
import SettingsOrganization from "./pages/SettingsOrganization.vue";
import SettingsTeam from "./pages/SettingsTeam.vue";
import SettingsSubscription from "./pages/SettingsSubscription.vue";
import SettingsIntegration from "./pages/SettingsIntegration.vue";
import SettingsUpgradeWithKey from "./pages/SettingsUpgradeWithKey.vue";
import SettingsNotification from "./pages/SettingsNotification.vue";

export const SettingsRoutes = [
  {
    path: "settings",
    component: Settings,
    children: [
      {
        name: "account-settings",
        path: "account",
        component: SettingsAccount,
      },
      {
        name: "organization-settings",
        path: "organization",
        component: SettingsOrganization,
      },
      {
        name: "team-settings",
        path: "team",
        component: SettingsTeam,
      },
      {
        name: "subscription-settings",
        path: "subscription",
        component: SettingsSubscription,
      },
      {
        name: "integration-settings",
        path: "integration",
        component: SettingsIntegration,
      },
      {
        name: "notification-settings",
        path: "notification",
        component: SettingsNotification,
      },
      {
        name: "upgrade-with-key",
        path: "upgrade-with-key",
        component: SettingsUpgradeWithKey,
      },
    ],
  },
];
