<template>
  <m-modal
    @cancel="$emits('close')"
    @close="$emits('close')"
    @confirm="onSubmit"
    :confirm-text="$t('common.REMOVE')"
    :cancel-text="$t('common.CANCEL')"
    :open="open"
    :title="$t('modals.REMOVE_ORGANIZATION')"
    :description="$t('modals.REMOVE_ORGANIZATION_DESCRIPTION')"
    :danger="true"
  >
  </m-modal>
</template>

<script lang="ts" setup>
// externals
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import mixpanel from "mixpanel-browser";

// internals
import { useRouteGlobals } from "@/composables/useRouteGlobals";
import { NotificationType, useCommonStore } from "@/stores";

// services
import { removeOrganization } from "@/modules/organization/services/OrganizationService";

// components
import MModal from "@/components/v2/elements/MModal.vue";

// hooks
const $router = useRouter();
const { t } = useI18n();
const { setNotification } = useCommonStore();
const { oid } = useRouteGlobals();

// props
const $emits = defineEmits(["close"]);
const props = defineProps({
  open: {
    type: Boolean,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
});

// methods
const onSubmit = async () => {
  const removingResponse = await removeOrganization(oid.value, {
    name: props.name,
  });

  if (removingResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "remove_organization",
      "count": 1,
      segmentation: {
        organization: oid.value,
        success: true,
      }
    }]);

    setNotification(t("modals.ORGANIZATION_REMOVED"), NotificationType.SUCCESS);
    localStorage.removeItem("mevo:last_visited_route");
    $router.push("/loading");
  } else {
    window.Countly.q.push(['add_event',{
      "key": "remove_organization",
      "count": 1,
      segmentation: {
        organization: oid.value,
        success: false,
      }
    }]);

    setNotification(t(removingResponse.error.message), NotificationType.ERROR);
  }

  $emits("close");
};
</script>
