<template>
  <m-modal
    @cancel="$emits('close')"
    @close="$emits('close')"
    @confirm="onSubmit"
    :confirm-text="$t('settings.REMOVE_ACCESS')"
    :cancel-text="$t('common.CANCEL')"
    :open="open"
    :title="$t('settings.REMOVE_ACCESS')"
    :description="$t('modals.REMOVE_ACCESS_DESCRIPTION')"
    :danger="true"
  >
  </m-modal>
</template>

<script lang="ts" setup>
// externals
import { useI18n } from "vue-i18n";
import mixpanel from "mixpanel-browser";

// internals
import { useRouteGlobals } from "@/composables/useRouteGlobals";
import { NotificationType, useCommonStore } from "@/stores";
import { useOrganizations } from "@/composables/useOrganizations";

// services
import {
  removeAdmin,
  removeUser,
  removeListener,
} from "@/modules/organization/services/OrganizationService";

// components
import MModal from "@/components/v2/elements/MModal.vue";

// hooks
const { t } = useI18n();
const { setNotification } = useCommonStore();
const { refreshOrganizations } = useOrganizations();
const { oid } = useRouteGlobals();

// props
const $emits = defineEmits(["close"]);
const props = defineProps({
  open: {
    type: Boolean,
    required: true,
  },
  user: {
    type: Object,
    required: true,
    default: () => ({
      role: "User",
      email: "",
    }),
  },
});

// methods
const onSubmit = async () => {
  if (props.user.role === "Admin") {
    const removeResponse = await removeAdmin(oid.value, props.user.email);
    if (removeResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "remove_access",
        "count": 1,
        segmentation: {
          organization: oid.value,
          removed_admin: props.user.email,
          success: true,
          role: "admin",
        }
      }]);

      setNotification(t("modals.ADMIN_REMOVED"), NotificationType.SUCCESS);
    } else {
      window.Countly.q.push(['add_event',{
        "key": "remove_access",
        "count": 1,
        segmentation: {
          organization: oid.value,
          removed_admin: props.user.email,
          success: false,
          role: "admin",
        }
      }]);
      setNotification(t(removeResponse.error.message));
    }
  } else if (props.user.role === "notification-listener") {
    const removeResponse = await removeListener(oid.value, props.user.email);

    if (removeResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "remove_access",
        "count": 1,
        segmentation: {
          organization: oid.value,
          removed_listener: props.user.email,
          success: true,
          role: "notification-listener",
        }
      }]);

      setNotification(t("modals.LISTENER_REMOVED"), NotificationType.SUCCESS);
    } else {
      window.Countly.q.push(['add_event',{
        "key": "remove_access",
        "count": 1,
        segmentation: {
          organization: oid.value,
          removed_listener: props.user.email,
          success: false,
          role: "notification-listener",
        }
      }]);

      setNotification(t(removeResponse.error.message));
    }
  } else {
    const removeResponse = await removeUser(oid.value, props.user.email);

    if (removeResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "remove_access",
        "count": 1,
        segmentation: {
          organization: oid.value,
          removed_user: props.user.email,
          success: true,
          role: "user",
        }
      }]);
      
      setNotification(t("modals.USER_REMOVED"), NotificationType.SUCCESS);
    } else {
      window.Countly.q.push(['add_event',{
        "key": "remove_access",
        "count": 1,
        segmentation: {
          organization: oid.value,
          removed_user: props.user.email,
          success: false,
          role: "user",
        }
      }]);
      setNotification(t(removeResponse.error.message));
    }
  }
  refreshOrganizations();
  $emits("close");
};
</script>
