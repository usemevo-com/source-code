<template>
  <m-modal
    @cancel="$emits('close')"
    @close="$emits('close')"
    @confirm="onSubmit"
    :confirm-text="$t('modals.CANCEL_MY_SUBSCRIPTION')"
    :cancel-text="$t('modals.I_WANT_TO_KEEP_IT')"
    :open="open"
    :title="$t('settings.CANCEL_SUBSCRIPTION')"
    :description="$t('modals.CANCEL_SUBSCRIPTION_DESCRIPTION')"
    :danger="true"
  >
  </m-modal>
</template>

<script lang="ts" setup>
// externals
import { useI18n } from 'vue-i18n'
import mixpanel from 'mixpanel-browser'

// internals
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { NotificationType, useCommonStore } from '@/stores'
import { useOrganizations } from '@/composables/useOrganizations'
import { PlanType } from '@/modules/organization/types/IPlan'

// services
import { planChange } from '@/modules/organization/services/OrganizationService'

// components
import MModal from '@/components/v2/elements/MModal.vue'

// hooks
const { t } = useI18n()
const { setNotification } = useCommonStore()
const { refreshOrganizations } = useOrganizations()
const { oid } = useRouteGlobals()
const $emits = defineEmits(['close'])
defineProps({
  open: {
    type: Boolean,
    required: true
  }
})

// methods
const onSubmit = async () => {
  const planChangeResponse = await planChange(oid.value, PlanType.BASIC)

  if (planChangeResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "cancel_subscription",
      "count": 1,
      segmentation: {
        organization: oid.value,
        success: true
      }
    }]);

    setNotification(t('modals.SUBSCRIPTION_CANCELLED'), NotificationType.SUCCESS)
  } else {
    window.Countly.q.push(['add_event',{
      "key": "cancel_subscription",
      "count": 1,
      segmentation: {
        organization: oid.value,
        success: false
      }
    }]);

    setNotification(t('modals.SUBSCRIPTION_CANCEL_FAILED'), NotificationType.ERROR)
  }
  refreshOrganizations()
  $emits('close')
}
</script>
