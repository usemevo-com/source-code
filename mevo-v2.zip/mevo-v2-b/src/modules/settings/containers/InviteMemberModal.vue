<template>
  <m-modal
    @cancel="$emits('close')"
    @close="$emits('close')"
    @confirm="onSubmit"
    :confirm-text="$t('modals.SEND_INVITATION')"
    :cancel-text="$t('common.CANCEL')"
    :open="open"
    :title="$t('modals.INVITE_MEMBER')"
    :description="$t('modals.INVITE_MEMBER_DESCRIPTION')"
  >
    <div class="flex flex-col space-y-4 my-4">
      <Input
        name="email"
        rules="required|email"
        type="email"
        v-model="email"
        placeholder="john@doe.com"
      />

      <Select v-model="role">
        <SelectTrigger>
          <SelectValue placeholder="Select a role" />
        </SelectTrigger>
        <SelectContent>
          <SelectGroup>
            <SelectItem
              :key="index"
              v-for="(roleOption, index) in roleOptions"
              :value="roleOption.value"
              >{{ roleOption.label }}</SelectItem
            >
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  </m-modal>
</template>

<script lang="ts" setup>
// externals
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
import mixpanel from 'mixpanel-browser'

// internals
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { NotificationType, useCommonStore } from '@/stores'
import { useOrganizations } from '@/composables/useOrganizations'

// services
import {
  inviteUser,
  inviteAdmin,
  addListener
} from '@/modules/organization/services/OrganizationService'

// components
import MTextInput from '@/components/basic/MTextInput.vue'
import MSelect from '@/components/basic/MSelect.vue'
import MModal from '@/components/v2/elements/MModal.vue'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectValue
} from '@/components/ui/select'

// hooks
const { t } = useI18n()
const { setNotification } = useCommonStore()
const { refreshOrganizations } = useOrganizations()
const { oid } = useRouteGlobals()

// props
defineProps({
  open: {
    type: Boolean,
    required: true
  }
})
const $emits = defineEmits(['close'])

// states
const roleOptions = [
  { value: 'user', label: t('common.USER') },
  { value: 'admin', label: t('common.ADMIN') },
  { value: 'notification-listener', label: t('common.NOTIFICATION_LISTENER') }
]
const email = ref('')
const role = ref('user')

const onSubmit = async () => {
  if (role.value === 'user') {
    const invitationResponse = await inviteUser(oid.value, email.value)

    if (invitationResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "user_invitation",
        "count": 1,
        segmentation: {
          organization: oid.value,
          invited_user: email.value,
          success: true,
          role: 'user'
        }
      }]);

      email.value = ''
      role.value = 'user'
      setNotification(t('modals.INVITATION_SENT'), NotificationType.SUCCESS)
    } else {
      window.Countly.q.push(['add_event',{
        "key": "user_invitation",
        "count": 1,
        segmentation: {
          organization: oid.value,
          invited_user: email.value,
          success: false,
          role: 'user'
        }
      }]);
      setNotification(t(invitationResponse.error.message), NotificationType.ERROR)
    }
  } else if (role.value === 'notification-listener') {
    const addListenerResponse = await addListener(oid.value, email.value)

    if (addListenerResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "user_invitation",
        "count": 1,
        segmentation: {
          organization: oid.value,
          invited_user: email.value,
          success: true,
          role: 'notification-listener'
        }
      }]);

      email.value = ''
      role.value = 'user'
      setNotification(t('modals.INVITATION_SENT'), NotificationType.SUCCESS)
    } else {
      window.Countly.q.push(['add_event',{
        "key": "user_invitation",
        "count": 1,
        segmentation: {
          organization: oid.value,
          invited_user: email.value,
          success: false,
          role: 'notification-listener'
        }
      }]);
      setNotification(t(addListenerResponse.error.message), NotificationType.ERROR)
    }
  } else {
    const invitationResponse = await inviteAdmin(oid.value, email.value)

    if (invitationResponse.isOk()) {
      window.Countly.q.push(['add_event',{
        "key": "user_invitation",
        "count": 1,
        segmentation: {
          organization: oid.value,
          invited_user: email.value,
          success: true,
          role: 'admin'
        }
      }]);

      email.value = ''
      role.value = 'user'
      setNotification(t('modals.INVITATION_SENT'), NotificationType.SUCCESS)
    } else {
      window.Countly.q.push(['add_event',{
        "key": "user_invitation",
        "count": 1,
        segmentation: {
          organization: oid.value,
          invited_user: email.value,
          success: false,
          role: 'admin'
        }
      }]);

      setNotification(t(invitationResponse.error.message), NotificationType.ERROR)
    }
  }
  refreshOrganizations()
  $emits('close')
}
</script>
