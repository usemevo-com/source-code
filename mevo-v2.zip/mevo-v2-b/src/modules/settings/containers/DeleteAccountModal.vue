<template>
  <m-modal
    @cancel="$emits('close')"
    @close="$emits('close')"
    @confirm="onSubmit"
    :confirm-text="$t('modals.I_UNDERSTAND_DELETE_EVERYTHING')"
    :cancel-text="$t('common.CANCEL')"
    :open="open"
    :title="$t('modals.DELETE_ACCOUNT_MODAL_TITLE')"
    :description="$t('modals.DELETE_ACCOUNT_MODAL_DESCRIPTION')"
    :danger="true"
    :disabled="!isConfirmed"
  >
    <div class="space-y-4">
      <!-- Warning Box -->
      <div class="bg-red-50 border border-red-200 rounded-md p-4 mt-4">
        <div class="flex">
          <exclamation-triangle-icon class="h-5 w-5 text-red-400" />
          <div class="ml-3">
            <h3 class="text-sm font-medium text-red-800">
              {{ $t('modals.DELETE_ACCOUNT_FINAL_WARNING') }}
            </h3>
          </div>
        </div>
      </div>

      <!-- Deletion List -->
      <div class="bg-gray-50 border border-gray-200 rounded-md p-4">
        <h4 class="text-sm font-medium text-gray-900 mb-3">
          {{ $t('settings.DATA_DELETION_DESCRIPTION') }}
        </h4>
        <ul class="text-sm text-gray-600 space-y-1">
          <li class="flex items-center">
            <check-icon class="h-4 w-4 text-red-500 mr-2" />
            {{ $t('common.ACCOUNT') }}
          </li>
          <li class="flex items-center">
            <check-icon class="h-4 w-4 text-red-500 mr-2" />
            {{ $t('common.ORGANIZATIONS') }}
          </li>
          <li class="flex items-center">
            <check-icon class="h-4 w-4 text-red-500 mr-2" />
            {{ $t('common.BOTS') }}
          </li>
          <li class="flex items-center">
            <check-icon class="h-4 w-4 text-red-500 mr-2" />
            {{ $t('common.MESSAGES') }}
          </li>
          <li class="flex items-center">
            <check-icon class="h-4 w-4 text-red-500 mr-2" />
            {{ $t('common.TRAINING_DATA') }}
          </li>
        </ul>
      </div>

      <!-- Email Confirmation -->
      <div>
        <label for="email-confirmation" class="block text-sm font-medium text-gray-700 mb-2">
          {{ $t('modals.DELETE_ACCOUNT_CONFIRMATION_TEXT', { email: user.email }) }}
        </label>
        <input
          id="email-confirmation"
          v-model="emailConfirmation"
          type="email"
          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500"
          :placeholder="user.email"
        />
      </div>

      <!-- Final Checkbox -->
      <div class="flex items-start">
        <input
          id="final-confirmation"
          v-model="finalConfirmation"
          type="checkbox"
          class="mt-1 h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
        />
        <label for="final-confirmation" class="ml-2 text-sm text-gray-900">
          {{ $t('settings.DATA_DELETION_WARNING') }}
        </label>
      </div>
    </div>
  </m-modal>
</template>

<script lang="ts" setup>
// externals
import { computed, ref } from 'vue'
import { useRouter } from "vue-router"
import { useI18n } from "vue-i18n"
import { ExclamationTriangleIcon, CheckIcon } from "@heroicons/vue/24/outline"

// internals
import { useAuthStore } from "@/stores"
import { NotificationType, useCommonStore } from "@/stores"

// services
import { deleteAccount, logout } from "@/modules/prelogin/services/UserService"

// components
import MModal from "@/components/v2/elements/MModal.vue"

// Type declaration for Countly
declare global {
  interface Window {
    Countly?: any;
  }
}

// hooks
const $router = useRouter()
const { t } = useI18n()
const { setNotification } = useCommonStore()
const { user } = useAuthStore()

// props
const $emits = defineEmits(["close"])
const props = defineProps({
  open: {
    type: Boolean,
    required: true,
  },
})

// reactive data
const emailConfirmation = ref('')
const finalConfirmation = ref(false)

// computed
const isConfirmed = computed(() => {
  return emailConfirmation.value === user.email && finalConfirmation.value
})

// methods
const onSubmit = async () => {
  if (!isConfirmed.value) {
    setNotification(t("settings.EMAIL_CONFIRMATION_REQUIRED"), NotificationType.ERROR)
    return
  }

  try {
    const deletionResponse = await deleteAccount({
      email: emailConfirmation.value
    })

    if (deletionResponse.isOk()) {
      // Track event
      if (window.Countly) {
        window.Countly.q.push(['add_event',{
          "key": "delete_account",
          "count": 1,
          segmentation: {
            success: true,
          }
        }])
      }

      setNotification(t("settings.ACCOUNT_DELETION_SUCCESS"), NotificationType.SUCCESS)
      
      // Clear all local storage
      await logout()
      
      // Redirect to goodbye page or home
      $router.push("/login")
    } else {
      // Check if it's a paid plan error by message content
      const errorMessage = deletionResponse.error.message || ''
      if (errorMessage.includes('paid subscriptions') || errorMessage.includes('hi@usemevo.com')) {
        setNotification(t("settings.PAID_PLAN_DELETION_MESSAGE"), NotificationType.INFO)
      } else {
        setNotification(t(deletionResponse.error.message), NotificationType.ERROR)
      }

      // Track failed event
      if (window.Countly) {
        window.Countly.q.push(['add_event',{
          "key": "delete_account",
          "count": 1,
          segmentation: {
            success: false,
            error: deletionResponse.error.message,
            isPaidPlanError: errorMessage.includes('paid subscriptions')
          }
        }])
      }
    }
  } catch (error) {
    setNotification(t("common.SOMETHING_WENT_WRONG"), NotificationType.ERROR)
  }

  $emits("close")
}
</script> 