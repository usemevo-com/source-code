<template>
  <div class="flex w-[calc(100vw_-_50px)]">
    <!-- SIDEBAR WITH ANIMATION WRAPPER -->
    <div class="sidebar-transition" :class="{ 'sidebar-hidden': !inboxState.isLeftOpen }">
      <Sidebar
        @filterChange="onFilterChange"
        :conversationsState="inboxState.conversationsState"
        :sidebarState="inboxState.sidebarState"
        :is-open="inboxState.isLeftOpen"
        v-show="inboxState.isLeftOpen"
      />
    </div>
    <!-- SIDEBAR WITH ANIMATION WRAPPER -->

    <ConversationList
      :active-conversation="inboxState.conversationState.selectedConversationId"
      @conversationChange="onConversationChange"
      :active-filter="inboxState.sidebarState.activeFilter"
      :data="inboxState.conversationsState"
      :show-left="inboxState.isLeftOpen"
      :is-conversations-loading="isConversationsLoading"
      :on-toggle-left="toggleLeft"
      :on-refresh="onRefresh"
    />

    <ConversationArea
      :data="inboxState.conversationState"
      :on-toggle-right="toggleRight"
      :is-right-open="inboxState.isRightOpen"
    />

    <!-- COPILOT WITH ANIMATION WRAPPER -->
    <div class="ml-2 copilot-transition" :class="{ 'copilot-hidden': !inboxState.isRightOpen }">
      <CopilotPanel
        :is-open="inboxState.isRightOpen"
        v-show="inboxState.isRightOpen"
      />
    </div>
    <!-- COPILOT WITH ANIMATION WRAPPER -->
  </div>
</template>

<style>
.sidebar-transition {
  width: 200px;
  min-width: 0;
  max-width: 200px;
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  display: flex;
}
.sidebar-transition.sidebar-hidden {
  width: 0;
  max-width: 0;
}
.copilot-transition {
  width: 380px;
  min-width: 0;
  max-width: 380px;
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  display: flex;
}
.copilot-transition.copilot-hidden {
  width: 0;
  max-width: 0;
}
</style>

<script setup lang="ts">
import { onMounted, ref, watch, type Ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { InboxFilter, inboxState, type InboxConversation } from './data/inbox.state'
import Sidebar from '@/components/v3/Sidebar.vue'
import ConversationList from '@/components/v3/ConversationList.vue'
import ConversationArea from '@/components/v3/ConversationArea.vue'
import CopilotPanel from '@/components/v3/CopilotPanel.vue'
import { get_inbox_v3, get_messages_by_session } from '../bot/services/BotService'
import { useConversations } from '@/composables/useConversations'
import { useRouteGlobals } from '@/composables/useRouteGlobals'

const route = useRoute()
const router = useRouter()
const { bot_id } = useRouteGlobals()
const { conversations, refreshConversations, isConversationsLoading } = useConversations(bot_id, ref(1), ref(inboxState.sidebarState.activeFilter));

function toggleLeft() {
  inboxState.isLeftOpen = !inboxState.isLeftOpen
}
function toggleRight() {
  inboxState.isRightOpen = !inboxState.isRightOpen
}

function onFilterChange(filter: InboxFilter) {
  inboxState.sidebarState.activeFilter = filter
}

function onConversationChange(conversation: InboxConversation) {
  inboxState.conversationState.selectedConversationId = conversation._id
}

function onRefresh() {
  refreshConversations()
}

watch(
  () => inboxState.conversationState.selectedConversationId,
  (new_conversation_id) => {
    router.push({
      name: 'v3-inbox',
      params: {
        bot_id: route.params.bot_id,
        filter: route.params.filter,
        conversation_id: new_conversation_id,
      },
    })
  }
)

watch(
  () => inboxState.sidebarState.activeFilter,
  (new_filter) => {
    router.push({
      name: 'v3-inbox',
      params: {
        bot_id: route.params.bot_id,
        conversation_id: route.params.conversation_id,
        filter: new_filter,
      },
    })
  }
)

// TODO: SWR
watch(() => route.params.conversation_id, async (conversation_id) => {
  const bot_id = route.params.bot_id as string
  const inboxResponse = await get_inbox_v3(bot_id, 1, InboxFilter.AI_ALL)

  if (inboxResponse.isOk()) {
    const conversations = inboxResponse.value.payload[0].data;
    inboxState.conversationsState.conversations[InboxFilter.AI_ALL] = conversations
  }

  const messagesResponse = await get_messages_by_session(bot_id, conversation_id as string);

  if (messagesResponse.isOk()) {
    inboxState.conversationState.conversation.messages = messagesResponse.value.payload;
  }
})

watch(() => conversations.value, async (new_conversations: Ref<{ payload: [{ data: InboxConversation[] }] }>) => {
  inboxState.conversationsState.conversations[inboxState.sidebarState.activeFilter] = new_conversations.value.payload[0].data
})

onMounted(async () => {
  const bot_id = route.params.bot_id as string
  const conversation_id = route.params.conversation_id as string
  const filter = route.params.filter as InboxFilter

  if (filter) {
    inboxState.sidebarState.activeFilter = filter
  } else {
    router.push({
      name: 'v3-inbox',
      params: {
        bot_id: route.params.bot_id,
        filter: InboxFilter.AI_ALL,
        conversation_id: conversation_id,
      },
    })
  }

  inboxState.isRightOpen = false

  const inboxResponse = await get_inbox_v3(bot_id, 1, InboxFilter.AI_ALL)

  if (inboxResponse.isOk()) {
    const conversations = inboxResponse.value.payload[0].data;
    inboxState.conversationsState.conversations[InboxFilter.AI_ALL] = conversations
  }

  if (conversation_id) {
    inboxState.conversationState.selectedConversationId = conversation_id
  } else {
    if (inboxState.conversationsState.conversations[filter].length) {
      onConversationChange(inboxState.conversationsState.conversations[filter][0])
    }
  }

  const messagesResponse = await get_messages_by_session(bot_id, conversation_id);

  if (messagesResponse.isOk()) {
    inboxState.conversationState.conversation.messages = messagesResponse.value.payload;
  }
})
</script>