import NextRoot from "./Root.vue";
import NextInbox from "./Inbox.vue";
import NextBuilder from "./visual-builder/pages/Builder.vue";

export const NextRoutes = [
  {
    name: 'v3-root',
    path: 'v3',
    component: NextRoot,
    children: [
      {
        name: 'v3-inbox',
        path: 'inbox/:bot_id/:filter?/:conversation_id?',
        component: NextInbox
      },
      {
        name: 'v3-ai-settings',
        path: ':bot_id/ai-settings',
        component: NextBuilder
      }
    ]
  },
]