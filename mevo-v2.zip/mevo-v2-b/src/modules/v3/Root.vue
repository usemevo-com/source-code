<template>
  <div class="bg-slate-200">
    <router-view></router-view>
  </div>
</template>