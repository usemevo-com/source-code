import Home from "./pages/HomeView.vue";
import Upgrade from "./pages/UpgradeView.vue";

export const HomeRoutes = [
  {
    name: "home",
    path: "home",
    component: Home,
  },
  {
    name: "upgrade",
    path: "upgrade",
    component: Upgrade,
  },
];
