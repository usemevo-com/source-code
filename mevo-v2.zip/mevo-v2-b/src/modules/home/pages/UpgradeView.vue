<template>
<div class="w-full flex flex-col items-center justify-between min-h-screen">
    <div class="max-w-7xl w-full pt-8 flex sm:flex-row flex-col justify-between gap-4 items-center">
        <div class="mx-4 sm:mx-0 hidden sm:block">
            <div class="sm:text-3xl text-2xl font-bold">
                Unlock the full potential
            </div>
            <div class="text-lg text-muted-foreground">
                Choose the plan that fits your needs and have best experience.
            </div>  
        </div>
        <div class="flex flex-col sm:items-end items-center">
          <div class="text-sm text-muted-foreground">Join 2000+ users who loves Mevo</div>
          <img src="/imgs/users-loved-us.png" alt="Mevo" class="h-16" />
        </div>
    </div>
    
    <div class="max-w-7xl w-full">
      <div class="px-6 pt-16 w-full">
        <table class="w-full text-left max-sm:hidden">
          <caption class="sr-only">
            Pricing plan comparison
          </caption>
          <colgroup>
            <col class="w-2/5" />
            <col class="w-1/5" />
            <col class="w-1/5" />
            <col class="w-1/5" />
          </colgroup>
          <thead>
            <tr>
              <td class="flex flex-col space-y-2">
                <div>
                  <div class="text-sm text-muted-foreground">
                    Get 2 months free with yearly billing
                  </div>
                </div>
                <div class="flex items-center space-x-2 h-full">
                  <Label for="billing-period">Monthly</Label>
                  <Switch id="billing-period" v-model:checked="isYearlyBilling" />
                  <Label for="billing-period">Yearly</Label>
                </div>
              </td>
              <th v-for="tier in tiers" :key="tier.name" scope="col" class="p-0">
                <!-- <div v-if="tier.code === 'NEW_PRO'" class="bg-amber-100 text-amber-500 w-fit rounded px-2 py-1 mb-2 text-xs flex items-center space-x-1">
                  <Crown class="w-4 h-4" /> 
                  <span>BEST VALUE</span>
                </div> -->
                <div class="font-semibold text-indigo-600 flex space-x-2">
                  <div>{{ tier.name }}</div>
                </div>
                <span class="text-3xl">
                    <div :class="[isYearlyBilling ? 'opacity-100' : 'opacity-0']" class="text-lg line-through text-gray-500">
                      {{ tier.priceWithoutDiscount }}
                    </div>
                    {{ isYearlyBilling ? tier.priceYearly : tier.priceMonthly }}
                    <span class="font-light text-xs text-muted-foreground">
                      per month
                    </span>
                  </span>
                <div class="mt-2 text-sm font-normal text-gray-500">{{ tier.description }} <span class="sr-only">plan</span></div>
              </th>
            </tr>
            <tr>
              <th class="p-0" />
              <td @click="() => onContinue(plans[t_index].code.name)" v-for="(tier, t_index) in tiers" :key="tier.name" class="px-0 pt-3 pb-0">
                <Button :variant="tier.code === 'NEW_PRO' ? 'default' : 'secondary'" :disabled="isPaymentButtonDisabled" :aria-label="`Get started with the ${tier.name} plan`">Continue with {{ tier.name }}</Button>
              </td>
            </tr>
          </thead>
          <tbody v-for="section in sections" :key="section.name" class="group">
            <tr>
              <th scope="colgroup" colspan="5" class="px-0 pt-10 pb-0 group-first-of-type:pt-5">
                <div class="-mx-4 rounded-lg bg-gray-50 px-4 py-3 text-sm/6 font-semibold text-gray-950">{{ section.name }}</div>
              </th>
            </tr>
            <tr v-for="feature in section.features" :key="feature.name" class="border-b border-gray-100 last:border-none">
              <th scope="row" class="px-0 py-4 text-sm/6 font-normal text-gray-600">{{ feature.name }}</th>
              <td v-for="tier in tiers" :key="tier.name" class="p-4 max-sm:text-center">
                <template v-if="typeof feature.tiers[tier.name] === 'string'">
                  <span class="sr-only">{{ tier.name }} includes:</span>
                  <span class="text-sm/6 text-gray-950">{{ feature.tiers[tier.name] }}</span>
                </template>
                <template v-else>
                  <CheckIcon v-if="feature.tiers[tier.name] === true" class="inline-block size-4 fill-mevo" aria-hidden="true" />
                  <MinusIcon v-else class="inline-block size-4 fill-gray-400" aria-hidden="true" />
                  <span class="sr-only">{{ feature.tiers[tier.name] === true ? `Included in ${tier.name}` : `Not included in ${tier.name}` }}</span>
                </template>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="max-w-7xl w-full px-4 flex flex-col sm:hidden space-y-8">
      <div class="flex flex-col space-y-4 justify-between items-center">
        <div>
          <div class="text-sm text-muted-foreground">
            Get 2 months free with yearly billing
          </div>
        </div>
        <div class="flex items-center space-x-2 h-full">
          <Label for="billing-period">Monthly</Label>
          <Switch id="billing-period" v-model:checked="isYearlyBilling" />
          <Label for="billing-period">Yearly</Label>
        </div>
      </div>
      <div v-for="(plan, index) in tiers" :key="index" class="border border-gray-200 rounded-lg p-4 flex flex-col space-y-6">
        <div class="flex justify-between items-start">
          <div>
            <div class="text-lg font-bold">{{ plan.name }}</div>
            <div class="mt-1 text-sm text-muted-foreground">{{ plan.description }}</div>
          </div>
          <div>
            <div class="text-lg font-bold">{{ isYearlyBilling ? plan.priceYearly : plan.priceMonthly }}<span class="text-xs font-light text-muted-foreground">/mo</span></div>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div v-for="feature in plans[index].features" :key="feature.name" class="flex items-center space-x-2">
            <div class="text-sm text-muted-foreground flex items-center space-x-2">
              <CheckIcon class="w-4 h-4 text-mevo shrink-0" />
              <span>{{ feature.name }}</span>
            </div>
          </div>
        </div>
        <Button @click="() => onContinue(plan.code)" :disabled="isPaymentButtonDisabled" :aria-label="`Get started with the ${plan.name} plan`" class="w-full">Continue with {{ plan.name }}</Button>
      </div>
    </div>

    <div @click="onContinueWithLimitedFeatures" class="max-w-7xl w-full flex justify-center sm:justify-end text-right py-16 text-muted-foreground hover:underline cursor-pointer">
      <div>Continue with limited features</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Crown, Asterisk, BookOpenText, Brain, Mail, MessageCircle, Palette, Rocket, Users, Webhook } from 'lucide-vue-next'
import { onMounted, ref } from 'vue'
import { AddOn, SubscriptionType } from '@/modules/organization/types/IPlan'
import { useSubscription } from '@/composables/useSubscription'
import { Plans, PlanType } from '@/modules/organization/types/IPlan'
import { CheckIcon, MinusIcon } from '@heroicons/vue/16/solid'
import { useRouter } from 'vue-router'
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'


const tiers = [ 
{
    name: 'Lite',
    description: 'For individuals and hobbyists.',
    priceMonthly: '$14.99',
    priceYearly: '$12.5',
    priceWithoutDiscount: '$14.99',
    code: Plans.NEW_LITE.name,
  },
  {
    name: 'Pro',
    description: 'Best for startups.',
    priceMonthly: '$29.99',
    priceYearly: '$25',
    priceWithoutDiscount: '$359.99',
    code: Plans.NEW_PRO.name,
  },
  {
    name: 'Max',
    description: 'For marketers and agencies.',
    priceMonthly: '$499.99',
    priceYearly: '$417',
    priceWithoutDiscount: '$5999.99',
    code: Plans.NEW_MAX.name,
  },
]

const sections = [
  {
    name: 'Limits',
    features: [
      { name: 'Chatbots', tiers: { Lite: '3', Pro: '10', Max: '100' } },
      { name: 'User seats', tiers: { Lite: '3', Pro: '10', Max: '100' } },
      { name: 'Monthly message credits', tiers: { Lite: '1000', Pro: '5000', Max: '50000' } },
      { name: 'Monthly email credits', tiers: { Lite: '100', Pro: '500', Max: '5000' } },
      { name: 'Training characters', tiers: { Lite: '1M', Pro: '5M', Max: '50M' } },
      { name: 'User profiles', tiers: { Lite: '500', Pro: '2500', Max: '50000' } },
    ],
  },
  {
    name: 'Features',
    features: [
      { name: 'Customization options', tiers: { Lite: true, Pro: true, Max: true } },
      { name: 'Smarter and faster models', tiers: { Lite: true, Pro: true, Max: true } },
      { name: 'Webhooks', tiers: { Lite: true, Pro: true, Max: true } },
      { name: 'Custom user attributes', tiers: { Lite: false, Pro: true, Max: true } },
      { name: 'Chatbot-specific notifications', tiers: { Lite: false, Pro: true, Max: true } },
      // { name: 'Auto update training website content', tiers: { Lite: false, Pro: true, Max: true } },
      // { name: 'Analytics and reports', tiers: { Lite: false, Pro: true, Max: true } },
      // { name: 'AI conversation summaries', tiers: { Lite: false, Pro: true, Max: true } },
      { name: 'Remove mevo branding', tiers: { Lite: false, Pro: false, Max: true } },
      // { name: 'White labeling', tiers: { Lite: false, Pro: false, Max: true } },
      // { name: 'User access management', tiers: { Lite: false, Pro: false, Max: true } },
    ],
  },
  // {
  //   name: 'Support',
  //   features: [
  //     { name: '24/7 online support', tiers: { Starter: true, Growth: true, Scale: true } },
  //     { name: 'Quarterly workshops', tiers: { Starter: false, Growth: true, Scale: true } },
  //     { name: 'Priority phone support', tiers: { Starter: false, Growth: false, Scale: true } },
  //     { name: '1:1 onboarding tour', tiers: { Starter: false, Growth: false, Scale: true } },
  //   ],
  // },
]

export interface UpgradeModalProps {
  open: boolean
}

const plans = [
  {
    vendor_ref: 'e805b720-4e39-4898-b846-cc17ed31531b',
    promoted: false,
    name: 'Mevo Lite',
    code: Plans.NEW_LITE,
    description: 'For individuals and hobbyists.',
    price: '$19.99',
    features: [
      {
        name: '3 chatbots',
        description: 'AI chatbots with our state-of-the-art flow builder.',
        icon: Brain,
      },
      {
        name: '1500 monthly message credits',
        description:
          'User and bot messages, and reset every month.',
        icon: MessageCircle,
      },
      {
        name: '3 user seats',
        description: 'Users who can access the chatbots and the data.',
        icon: Users,
      },
    //   {
    //     name: 'Conversation summaries',
    //     description: 'See conversations in a summarized way.'
    //   },
    //   {
    //     name: 'Translate conversations',
    //     description: 'See conversations in different languages.'
    //   },
    //   {
    //     name: 'Access management',
    //     description: 'Choose who can access the chatbots and the data.'
    //   },
      {
        name: '100 monthly email credits',
        description: 'Reply users when AI chatbot is not able to answer.',
        icon: Mail,
      },
      {
        name: '10M training characters',
        description: 'Total characters you can train your AI chatbot with.',
        icon: BookOpenText,
      },
      // {
      //   name: '1000 user profiles',
      //   description: 'Capture leads from your chatbot conversations',
      //   icon: SquareUser,
      // },
      {
        name: 'Webhooks',
        description: 'Integrate your chatbots with other services.',
        icon: Webhook,
      },
      {
        name: 'Customization options',
        description: 'Set a color theme, brand image and more.',
        icon: Palette,
      },
      {
        name: 'Smarter and faster models',
        description:
          'Choose latest models with different credit ratios.',
        icon: Rocket,
      }
    ]
  },
  {
    vendor_ref: '3990af35-5eec-4f59-9c6b-ccbe2f374cdd',
    promoted: true,
    name: 'Mevo Pro',
    code: Plans.NEW_PRO,
    description: 'For startups.',
    price: '$29.99',
    features: [
      {
        name: '10 chatbots',
        description: 'AI chatbots with our state-of-the-art flow builder.',
        icon: Brain,
      },
      {
        name: '5000 monthly message credits',
        description:
          'User and bot messages, and reset every month.',
        icon: MessageCircle,
      },
      {
        name: '10 user seats',
        description: 'Users who can access the chatbots and the data.',
        icon: Users,
      },
      {
        name: '500 monthly email credits',
        description: 'Reply users when AI chatbot is not able to answer.',
        icon: Mail,
      },
      {
        name: '25M training characters',
        description: 'Total characters you can train your AI chatbot with.',
        icon: BookOpenText,
      },
      // {
      //   name: '5000 user profiles',
      //   description: 'Capture leads from your chatbot conversations',
      //   icon: SquareUser,
      // },
      {
        name: 'Webhooks',
        description: 'Integrate your chatbots with other services.',
        icon: Webhook,
      },
      {
        name: 'Customization options',
        description: 'Set a color theme, brand image and more.',
        icon: Palette,
      },
      {
        name: 'Smarter and faster models',
        description:
          'Choose latest models with different credit ratios.',
        icon: Rocket,
      },
      {
        name: 'Custom attributes',
        description: 'Set custom attributes for users from conversations.',
        icon: Asterisk,
      },
    ]
  },
  {
    vendor_ref: '17cd2dc4-8614-4988-ac45-c8e0a98c8c2c',
    promoted: false,
    name: 'Mevo Max',
    code: Plans.NEW_MAX,
    description: 'For those who needs more.',
    price: '$199.99',
    features: [
      {
        name: '25 chatbots',
        description: 'AI chatbots with our state-of-the-art flow builder.',
        icon: Brain,
      },
      {
        name: '30000 monthly message credits',
        description:
          'User and bot messages, and reset every month.',
        icon: MessageCircle,
      },
      {
        name: '25 user seats',
        description: 'Users who can access the chatbots and the data.',
        icon: Users,
      },
      {
        name: '1000 monthly email credits',
        description: 'Reply users when AI chatbot is not able to answer.',
        icon: Mail,
      },
      {
        name: '100M training characters',
        description: 'Total characters you can train your AI chatbot with.',
        icon: BookOpenText,
      },
      // {
      //   name: '25000 user profiles',
      //   description: 'Capture leads from your chatbot conversations',
      //   icon: SquareUser,
      // },
      {
        name: 'Webhooks',
        description: 'Integrate your chatbots with other services.',
        icon: Webhook,
      },
      {
        name: 'Customization options',
        description: 'Set a color theme, brand image and more.',
        icon: Palette,
      },
      {
        name: 'Smarter and faster models',
        description:
          'Choose latest models with different credit ratios.',
        icon: Rocket,
      },
      {
        name: 'Custom attributes',
        description: 'Set custom attributes for users from conversations.',
        icon: Asterisk,
      },
    ]
  }
]

const planMap = {
  [PlanType.BASIC]: 0,
  [PlanType.LITE_NEW]: 1,
  [PlanType.PRO_NEW]: 2,
  [PlanType.MAX_NEW]: 3
}

const supportPlans = [
  {
    name: 'Minor feature development',
    description:
      'Development of a minor feature in 2 weeks. This includes a single feature development, testing and deployment.',
    price: '$199.99'
  }
]

const $router = useRouter()
const { oid } = useRouteGlobals()
const selected = ref(0)
const isPaymentButtonDisabled = ref(false)
const isYearlyBilling = ref(true)

const props = withDefaults(defineProps<UpgradeModalProps>(), {
  open: false
})

const $emits = defineEmits(['close'])
const { cancelAddOn, buyAddOn, upgradePlan, activePlan, activeOrganization, refreshOrganizations } =
  useSubscription()

const onContinue = async (planCode: PlanType) => {
  isPaymentButtonDisabled.value = true
  // mixpanel.track('go_payment', {
  //   frequency: selected.value.frequency
  // })
  await upgradePlan(planCode, isYearlyBilling.value ? SubscriptionType.ANNUALLY : SubscriptionType.MONTHLY);
  refreshOrganizations()
  isPaymentButtonDisabled.value = false
}

const onContinueWithLimitedFeatures = () => {
  $router.push(`/o/${oid.value}/home?onboarding_start=true`)
}

const addItem = async (addOn: AddOn) => {
  isPaymentButtonDisabled.value = true
  await buyAddOn(addOn)
  isPaymentButtonDisabled.value = false
}

const cancelItem = async (addOn: AddOn) => {
  isPaymentButtonDisabled.value = true
  await cancelAddOn(addOn)
  isPaymentButtonDisabled.value = false
}

onMounted(() => {
  const frequency = localStorage.getItem('mevo:buy_decided')

  if (frequency) {
    if (frequency === SubscriptionType.MONTHLY) {
      selected.value = plans[0]
    } else {
      selected.value = plans[1]
    }
  }
})
</script>