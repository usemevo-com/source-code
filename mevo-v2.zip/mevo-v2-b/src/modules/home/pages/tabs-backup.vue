<TabsContent value="overview" class="space-y-4">
  <div class="text-2xl font-bold tracking-tight">Overview</div>
  <DashboardStatCards />

  <div class="grid gap-4 md:grid-cols-2">
    <Card class="col-span-1 h-fit">
      <CardHeader>
        <CardTitle>Recent interactions</CardTitle>
        <CardDescription
          >Here are the most recent interactions with your chatbots</CardDescription
        >
      </CardHeader>

      <CardContent>
        <ScrollArea class="h-[340px]">
          <div :key="index" v-for="(interaction, index) in interactions" class="mb-8">
            <div class="flex items-center">
              <div
                class="h-9 w-9 bg-secondary rounded-full flex items-center justify-center"
              >
                <i class="fa-regular fa-messages text-muted-foreground"></i>
              </div>

              <div class="ml-4 space-y-1">
                <p class="text-sm font-medium leading-none">
                  A conversation from
                  <span v-if="interaction?.location?.city"
                    >{{ interaction.location.city }},
                    {{ interaction.location.country }}</span
                  >
                  <span v-else>Unknown Location</span>
                </p>
                <p class="text-xs text-muted-foreground">
                  {{ interaction.messagesCount }} messages<span
                    v-if="interaction.lead.length"
                    >, lead captured</span
                  >, {{ moment(interaction.lastInteractionDate).fromNow() }}
                </p>
              </div>

              <div class="ml-auto font-medium">
                <Button
                  @click="goBotDetail(interaction._id, interaction.bot)"
                  size="sm"
                  variant="secondary"
                  >See detail</Button
                >
              </div>
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
    <Card class="col-span-1 h-fit">
      <CardHeader>
        <CardTitle>Stats</CardTitle>
        <CardDescription
          >How many messages have been on your AI chatbots in the last six months?
        </CardDescription>
      </CardHeader>
      <CardContent class="p-8 pt-0 pb-16">
        <BarChart
          class="h-[300px]"
          :data="formattedChartData"
          :categories="['messages']"
          :index="'date'"
          :rounded-corners="4"
        />
      </CardContent>
    </Card>
  </div>
</TabsContent>
