<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { v4 as uuidv4 } from 'uuid'
import { useRoute, useRouter } from 'vue-router'
import { toast } from 'vue-sonner'
import moment from 'moment'
import { useBots } from '@/composables/useBots'
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip'
import { Button } from '@/components/ui/button'
import BotItem from '@/modules/bot/containers/BotItem.vue'
import { BotType } from '@/types/BotType'
import { create_chatbot } from '@/modules/bot/services/BotService'
import { getResponseUsage } from '@/modules/organization/services/OrganizationService'
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { useSubscription } from '@/composables/useSubscription'
import { useAuthStore, useCommonStore } from '@/stores'
import { ScriptStepType, type IScriptStep } from '@/modules/bot/types/IScriptStep'
import { PlanType } from '@/modules/organization/types/IPlan'
import { PlusIcon, Info, CircleAlert, RouteIcon, FlaskConical, Database, Gift, Mail, MailCheck } from 'lucide-vue-next'
import Alert from '@/components/ui/alert/Alert.vue'

const $router = useRouter()
const $route = useRoute()
const { bots, refreshBots, isValidating: isBotsLoading } = useBots()
const { oid } = useRouteGlobals()
const { user } = useAuthStore()
const { setUpgradeModal } = useCommonStore()
const { activeOrganization, activePlan } = useSubscription()

const isOnboardingStart = computed(() => $route.query.onboarding_start)
const isAISubmitting = ref(false)
const isRBSubmitting = ref(false)
const responseCount = ref(0)
const selectedTags = ref([])

const v3_bots = computed(() => {
  return bots.value ? bots.value.filter((bot: any) => typeof bot.flow !== 'undefined') : []
})

const v2_bots = computed(() => {
  return bots.value ? bots.value.filter((bot: any) => typeof bot.flow === 'undefined') : []
})

const showUpgrade = () => {
  setUpgradeModal(true)
}

const isSubmitting = computed(() => {
  return isAISubmitting.value || isRBSubmitting.value
})

const filteredBots = computed(() => {
  if (selectedTags.value.length === 0) {
    return bots.value
  }
  return bots.value.filter((bot: { tags: string[] }) =>
    selectedTags.value.some(tag => bot.tags.includes(tag))
  )
})

const nonLtdPlans = [
  PlanType.BASIC,
  PlanType.PRO,
  PlanType.PRO_NEW,
  PlanType.LITE_NEW
  // PlanType.MAX_NEW
]

const pay_incentives = {
  [PlanType.BASIC]: {
    title: 'Unlock Pro features',
    description:
      'Get access to all pro features like Assistants API, webhooks, and increased limits for only $19,99/month.',
    cta: 'Upgrade now'
  },
  [PlanType.PRO]: {
    title: 'Upgrade for more',
    description: 'Increase your limits and get more benefits by choosing a higher plan.',
    cta: 'See plans'
  },
  [PlanType.PRO_NEW]: {
    title: 'Upgrade for more',
    description: 'Increase your limits and get more benefits by choosing a higher plan.',
    cta: 'See plans'
  },
  [PlanType.LITE_NEW]: {
    title: 'Things getting serious?',
    description:
      'Increase your limits and get more benefits by choosing a higher plan from $59.99/month.',
    cta: 'See plans'
  },
  [PlanType.MAX_NEW]: {
    title: 'Do you need more?',
    description:
      'Buy more message credits, remove mevo branding or get custom feature implementation services.',
    cta: 'See add ons'
  },
  others: {
    title: 'Do you need more credits?',
    description: 'You have life time access to Mevo, but you can buy more credits to use it more.',
    cta: 'See add ons'
  }
}

const is_ltd = computed(() => {
  if (activeOrganization.value && activeOrganization.value.plan) {
    return !nonLtdPlans.includes(activeOrganization.value.plan)
  }
  return false
})

// const formattedChartData = computed(() => {
//   if (chartData.value) {
//     var diff = chartData.value[chartData.value.length - 1].month - 6
//     var months = []

//     for (let i = diff; i <= diff + 6; i++) {
//       let index
//       if (i < 0) index = 13 + i
//       else if (i === 0) continue
//       else index = i

//       var isExist = chartData.value.find((item) => item.month === index)

//       if (isExist) {
//         months.push(isExist)
//       } else {
//         months.push({
//           count: 0,
//           month: index,
//           year:
//             i < 0
//               ? chartData.value[chartData.value.length - 1].year - 1
//               : chartData.value[chartData.value.length - 1].year
//         })
//       }
//     }

//     return chartData.value
//       .map((data) => ({
//         date: moment(data.month, 'MM').format('MMM') + ' ' + data.year,
//         messages: data.count
//       }))
//       .reverse()
//   } else return []
// })

// const templates = [
//   {
//     name: 'AI Assistant for SaaS Landing Page',
//     type: BotType.GPT,
//     description: 'This AI assistant will help you to capture leads from your landing page.',
//     isTemplate: true
//   },
//   {
//     name: 'Data Removal Request',
//     type: BotType.SCRIPTED,
//     description: 'Rule based bot to handle data removal requests.',
//     isTemplate: true
//   },
//   {
//     name: 'NPS Survey',
//     type: BotType.SCRIPTED,
//     description: 'Rule based bot to handle NPS survey.',
//     isTemplate: true
//   },
//   {
//     name: 'Demo call booking',
//     type: BotType.SCRIPTED,
//     description: 'Rule based bot to handle demo call booking.',
//     isTemplate: true
//   }
// ]

// const goBotDetail = function (sid: string, bid: string) {
//   $router.push({
//     name: 'bot-inbox',
//     params: {
//       bid: bid,
//       sid: sid
//     }
//   })
// }

const onCreateChatbot = async function (type: BotType = BotType.SCRIPTED) {
  if (type === BotType.GPT) isAISubmitting.value = true
  else isRBSubmitting.value = true

  if (type === BotType.GPT) {
    $router.push({
      name: 'get-started'
    })
    return
  }

  const config = {}
  const payload: {
    name: string
    organization: string
    createdBy: string
    config: {
      model?: string
    }
    type: BotType
    script?: {
      steps: IScriptStep[]
    }
  } = {
    name: 'Rulebased Chatbot',
    organization: oid.value,
    createdBy: user._id || '',
    config,
    type
  }

  if (type === BotType.SCRIPTED) {
    payload.script = {
      steps: [
        {
          id: uuidv4(),
          data: {
            message: 'Hi',
            options: [],
            jumps: [],
          },
          type: ScriptStepType.MESSAGE
        },
        {
          id: uuidv4(),
          data: {
            message:
              'You can edit this flow by adding/removing more steps. Type something and press enter for the next step.',
            options: [],
            jumps: []
          },
          type: ScriptStepType.QUESTION_TEXT,
          isManualInputAllowed: true
        },
        {
          id: uuidv4(),
          data: {
            message: 'Thanks',
            options: [],
            jumps: []
          },
          type: ScriptStepType.MESSAGE
        }
      ]
    }
  }

  const create_chatbot_response = await create_chatbot(payload)

  if (create_chatbot_response.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "create_chatbot",
      "count": 1,
      "segmentation": {
        "success": true,
        "type": 'rule-based'
      }
    }]);

    $router.push({
      name: 'bot-submissions',
      params: {
        oid: oid.value,
        bid: create_chatbot_response.value.payload._id
      }
    })
  } else {
    if (create_chatbot_response.error.message === 'bots.INVALID_API_KEY') {
      toast.error(
        'Your OpenAI key is invalid, please update your organization level OpenAI key or remove it.'
      )
    } else if (
      create_chatbot_response.error.message === 'organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS'
    ) {
      toast.error(
        'You have reached your plan limit for chatbots, choose a higher plan to create more.'
      )
      setUpgradeModal(true)
    } else {
      toast.error('Error occurred while creating chatbot')
    }

    window.Countly.q.push(['add_event',{
      "key": "create_chatbot",
      "count": 1,
      "segmentation": {
        "success": false,
        "failReason": create_chatbot_response.error.message,
        "type": 'rule-based'
      }
    }]);
  }

  isRBSubmitting.value = false
}

const onRemove = () => {
  refreshBots()
}

watch(oid, () => {
  localStorage.setItem('mevo:oid', oid.value)
})

const onStartOnboarding = () => {
  $router.push(`/o/${oid.value}/ai/${bots.value[0]._id}/visual-builder`)
}

onMounted(async () => {
  localStorage.setItem('mevo:oid', oid.value)


  const response_usage = await getResponseUsage(oid.value)

  if (response_usage.isOk()) {
    responseCount.value = response_usage.value.payload
  }

  if ($route.query.upgrade) {
    setUpgradeModal(true)
  }

  if ($route.query.onboarding_start) {
    window.Countly.q.push(['add_event',{
      "key": "start_onboarding",
      "count": 1,
    }]);
  }
})

function onArcadeIframeMessage(e) {
  if (e.origin !== 'https://demo.arcade.software' || !e.isTrusted) return;

  const arcadeIframe = document.querySelector(`iframe[src*=${e.data.id}]`);
  if (!arcadeIframe || !arcadeIframe.contentWindow) return;

  if (e.data.event === 'arcade-init') {
    arcadeIframe.contentWindow.postMessage({event: 'register-popout-handler'}, '*');
  }
  
  if (e.data.event === 'arcade-popout-open') {
    arcadeIframe.style['height'] = '100%';
    arcadeIframe.style['z-index'] = '9999999';
  }

  if (e.data.event === 'arcade-popout-close') {
    arcadeIframe.style['height'] = '0';
    arcadeIframe.style['z-index'] = 'auto';
  }
}

window.addEventListener('message', onArcadeIframeMessage);

function onFirstArcadeTrigger() {
  const arcadeIframe = document.querySelector(`iframe[src*=nZx21gkqgdOeYnSv9Kji]`);
  if (arcadeIframe && arcadeIframe.contentWindow) {
    arcadeIframe.contentWindow.postMessage({event: 'request-popout-open'}, '*');
  }
}

function onSecondArcadeTrigger() {
  const arcadeIframe = document.querySelector(`iframe[src*=iyokwYulLm9q3GIMBnQt]`);
  if (arcadeIframe && arcadeIframe.contentWindow) {
    arcadeIframe.contentWindow.postMessage({event: 'request-popout-open'}, '*');
  }
}

function onThirdArcadeTrigger() { 
  const arcadeIframe = document.querySelector(`iframe[src*=rDx95ABbWzV4E9XkEKtU]`); 
  if (arcadeIframe && arcadeIframe.contentWindow) { 
    arcadeIframe.contentWindow.postMessage({event: 'request-popout-open'}, '*'); 
  }
}
</script>

<template>
  <!-- <div class="w-full flex flex-col items-center justify-center h-screen" v-if="isOnboardingStart">
    <div>onboarding content</div>
  </div> -->
  <div class="col-span-12 w-full flex flex-col">
    <div class="w-full py-2 border-b">
      <div class="text-sm font-medium mb-2 pl-8">Stories from Mevo team</div>
      <div class="flex items-center justify-start space-x-4 px-8 pr-72">
        <div class="flex flex-col space-y-1 items-center w-[52px]">
          <div class="p-0.5 bg-gray-200 rounded-full">
            <div class="border-2 border-white h-12 w-12 rounded-full bg-mevo flex items-center justify-center">
              <img src="https://cdn.bsky.app/img/avatar/plain/did:plc:gjjrkvpvpbizweisbaq6jvzh/bafkreigtucyvayfmg2giv6s5zuegvjduyl2eunyglrc3iqwln3w7jhx264@jpeg" class="h-full w-full rounded-full" />
            </div>
          </div>
          <div class="text-xs font-light antialiased">Furkan</div>
        </div>
        <div class="flex flex-col space-y-1 items-center w-[52px]">
          <div class="p-0.5 bg-gradient-to-r from-mevo via-blue-500 to-purple-500 rounded-full">
            <div class="border-2 border-white h-12 w-12 rounded-full bg-mevo flex items-center justify-center">
              <img src="https://ca.slack-edge.com/T03LWBM03-U026B6UNHHV-4d75ea13e7eb-192" class="h-full w-full rounded-full" />
            </div>
          </div>
          <div class="text-xs font-light antialiased">Pınar</div>
        </div>
        <div class="flex flex-col space-y-1 items-center w-[52px]">
          <div class="p-0.5 bg-gradient-to-r from-mevo via-blue-500 to-purple-500 rounded-full">
            <div class="border-2 border-white h-12 w-12 rounded-full bg-mevo flex items-center justify-center">
              <img src="https://media.licdn.com/dms/image/v2/D4D03AQF9GiViVjCkVA/profile-displayphoto-shrink_800_800/profile-displayphoto-shrink_800_800/0/1680642330834?e=1758153600&v=beta&t=mjKTyOQkSHdepvdjpZT0XTFVDCEFXPeZJq--aWv1Rlk" class="h-full w-full rounded-full" />
            </div>
          </div>
          <div class="text-xs font-light antialiased">Görkem</div>
        </div>
        <div class="flex flex-col space-y-1 items-center w-[52px]">
          <div class="p-0.5 bg-gradient-to-r from-mevo via-blue-500 to-purple-500 rounded-full">
            <div class="border-2 border-white h-12 w-12 rounded-full bg-mevo flex items-center justify-center">
              <img src="https://pbs.twimg.com/profile_images/1950721576308989952/X9fhClC0_400x400.jpg" class="h-full w-full rounded-full" />
            </div>
          </div>
          <div class="text-xs font-light antialiased">Feature</div>
        </div>
        <div class="flex flex-col space-y-1 items-center w-[52px]">
          <div class="p-0.5 bg-gradient-to-r from-mevo via-blue-500 to-purple-500 rounded-full">
            <div class="border-2 border-white h-12 w-12 rounded-full bg-mevo flex items-center justify-center">
              <img src="https://pbs.twimg.com/profile_images/1950721576308989952/X9fhClC0_400x400.jpg" class="h-full w-full rounded-full" />
            </div>
          </div>
          <div class="text-xs font-light antialiased truncate">Black Friday</div>
        </div>
      </div>
    </div>
    <div>
      <div class="flex-1 space-y-8 p-8 mr-72">
        <!-- header -->
        <div class="flex items-center justify-between">
          <!-- left header -->
          <div>
            <div class="text-4xl font-medium tracking-tight antialiased">Welcome, {{ user.name.split(' ')[0] }} 👋</div>
          </div>
          <!-- left header -->

          <!-- right header -->
          <div class="flex items-center space-x-4">
            <!-- usage section -->
            <div class="text-sm flex space-x-6 mr-4" v-if="activeOrganization && activePlan">
              <TooltipProvider>
                <div v-if="activePlan.limits.rb_allowed === 1">
                  <div class="font-medium">
                    Submission credits
                    <Tooltip>
                      <TooltipTrigger>
                        <Info class="w-4 h-4 text-mevo" />
                      </TooltipTrigger>
                      <TooltipContent class="w-[300px]">
                        <div>
                          This is how many submissions you can collect by using your rule-based
                          chatbots in a month. Next limit reset at
                          {{
                            moment(activeOrganization.activePeriod.end).format('DD.MM.YYYY HH:mm')
                          }}.
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <div>
                    {{ activeOrganization.activePeriod.submission_usage }} /
                    {{ activePlan.limits.response.toLocaleString() }}
                  </div>
                </div>
                <div v-if="activeOrganization && !activeOrganization.useLegacyPricing">
                  <div class="font-medium flex items-center space-x-2">
                    
                    <span>Message credits</span>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info class="w-4 h-4 text-mevo" />
                      </TooltipTrigger>
                      <TooltipContent class="w-[300px]">
                        <div>
                          This is how many message you can spend in the conversationts between your AI
                          chatbots and your visitors. Next limit reset at
                          {{
                            moment(activeOrganization.activePeriod.end).format('DD.MM.YYYY HH:mm')
                          }}.
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <div>
                    {{ activeOrganization.activePeriod.message_usage }} /
                    {{ activePlan.limits.message.toLocaleString() }}
                  </div>
                </div>
                <div v-if="activeOrganization && activeOrganization.useLegacyPricing">
                  <div class="font-medium">
                    Monthly tokens
                    <Tooltip>
                      <TooltipTrigger>
                        <Info class="w-4 h-4 text-mevo" />
                      </TooltipTrigger>
                      <TooltipContent class="w-[300px]">
                        <div>
                          This is how many tokens you can spend in the conversationts between your AI
                          chatbots and your visitors. Next limit reset at
                          {{
                            moment(activeOrganization.activePeriod.end).format('DD.MM.YYYY HH:mm')
                          }}.
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <div>
                    {{ activeOrganization.monthlyTokenUsage.toLocaleString() }} /
                    {{ activePlan.limits.token.toLocaleString() }}
                  </div>
                </div>
                <div>
                  <div class="font-medium flex items-center space-x-2">
                    <span>Training characters</span>

                    <Tooltip>
                      <TooltipTrigger>
                        <Info class="w-4 h-4 text-mevo" />
                      </TooltipTrigger>
                      <TooltipContent class="w-[300px]">
                        <div>
                          This is how many characters you spent by adding training content to all
                          chatbots in this organizationts. This limit won't be reset, you should
                          remove some existing training content for free up some space.
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <div>
                    {{ activeOrganization?.trainingCharacterUsage?.toLocaleString() }} /
                    {{ activePlan.limits.charLimit.toLocaleString() }}
                  </div>
                </div>
                <div>
                  <div class="font-medium">Need more?</div>
                  <div @click="showUpgrade" class="font-light text-primary underline cursor-pointer">
                    Upgrade now
                  </div>
                </div>
              </TooltipProvider>
            </div>
            <!-- usage section -->

            <!-- main action button -->
            <Button
              @click="() => onCreateChatbot(BotType.GPT)"
              v-if="v3_bots && v3_bots.length && activePlan && activePlan.limits.rb_allowed === 0"
            >
            <PlusIcon class="w-4 h-4 mr-2" />
            Create a chatbot
            </Button>
            <!-- main action button -->
          </div>
        </div>
        <!-- header -->


        <div>
          <!-- training character limit alert -->
          <Alert class="flex space-x-4 w-full justify-between mb-8 bg-red-500 text-white" v-if="activeOrganization && activeOrganization.trainingCharacterExceeded">
            <div class="flex items-center space-x-4">
              <CircleAlert class="w-6 h-6 text-white" />
              <div>
                <AlertTitle>
                  Insufficient training characters
                </AlertTitle>
                <AlertDescription>
                  Your training character limit exceeded with the latest training. You should remove some existing training content for free up some space or upgrade your plan.
                </AlertDescription>
              </div>
            </div>
            <Button variant="link" class="text-white" @click="showUpgrade">Upgrade now</Button>
          </Alert>
          <!-- training character limit alert -->

          <div class="mb-8">
            <div class="text-2xl font-medium tracking-tight antialiased">Your chatbots</div>
            <p class="text-lg text-muted-foreground antialiased">
              Here are all chatbots you have access to.
            </p>
          </div>
          <div
            class="grid grid-cols-2 2xl:grid-cols-3 gap-4"
            v-if="isBotsLoading && (!v3_bots || !v3_bots.length)"
          >
            <Skeleton class="col-span-1 h-[108px]" />
            <Skeleton class="col-span-1 h-[108px]" />
          </div>
          <div v-else-if="v3_bots && v3_bots.length" class="grid grid-cols-2 2xl:grid-cols-3 gap-4 relative">
            <img src="https://claritystatic.azureedge.net/images/clemGettingStarted-cropped-oneLoop.gif?random=1" class="absolute -top-14 left-[36%]" style="width: 120px;" />
            <BotItem
              :bot="bot"
              class="sm:col-span-1 col-span-3"
              v-for="(bot, index) in v3_bots"
              :key="index"
              @onRemove="onRemove"
            ></BotItem>
            <div v-if="v3_bots.length === 0" class="col-span-2 flex items-center justify-center h-64 flex flex-col space-y-2">
              <div class="text-gray-500">No chatbots found with selected tags</div>
              <div @click="selectedTags = []" class="cursor-pointer underline text-sm text-blue-500">Clear tags filter</div>
            </div>
          </div>
          <div
            v-else
            class="w-full flex items-center justify-between h-64 rounded-lg border border-foreground-muted bg-no-repeat"
            style="
              background-position:
                bottom left,
                top right;
            "
          >
            <div class="m-8">
              <div class="font-bold text-2xl">Get started</div>
              <div class="text-gray-500 w-3/4 mt-2 text-lg">
                Add training content, map out your conversation flow, style your bot, and start automating.
              </div>
              <Button
                :disabled="isAISubmitting"
                @click="() => onCreateChatbot(BotType.GPT)"
                class="mt-4"
              >
                <i class="fa fa-spinner-third animate-spin mr-2 text-xs" v-if="isAISubmitting"></i>
                <span>Create your first chatbot</span>
              </Button>
              <!-- <Button
                v-if="activePlan && activePlan.limits.rb_allowed === 1"
                :disabled="isRBSubmitting"
                @click="() => onCreateChatbot(BotType.SCRIPTED)"
                variant="link"
              >
                <i class="fa fa-spinner-third animate-spin mr-2 text-xs" v-if="isRBSubmitting"></i>
                Create a rule-based chatbot
              </Button> -->
            </div>
            <!-- <img
              class="h-64 rounded-r-lg"
              src="https://images.unsplash.com/photo-1511759066510-46958c3fffa0"
            /> -->
          </div>
          <div v-if="false" class="mt-4">
            <div class="text-2xl font-medium tracking-tight">Guides and tutorials to help you</div>
            <div
              :class="[!is_ltd && 'sm:grid-cols-4', is_ltd && 'sm:grid-cols-3']"
              class="grid grid-cols-1 gap-4 mt-4"
            >
              <div
                v-if="activeOrganization && !is_ltd"
                style="background-position: bottom left"
                class="flex flex-col justify-between animate-border inline-block rounded-lg bg-black text-white bg-[url('/imgs/mask-3.png')] bg-no-repeat"
              >
                <div
                  class="flex-1 justify-between grid-cols-1 rounded-lg border border-foreground-muted px-8 flex py-12 flex-col items-start space-y-4 w-full"
                >
                  <div class="font-medium text-lg">
                    {{ pay_incentives[activeOrganization.plan].title }}
                  </div>
                  <div class="font-light text-sm">
                    {{ pay_incentives[activeOrganization.plan].description }}
                  </div>

                  <a
                    @click="showUpgrade"
                    class="flex items-center space-x-2 mt-2"
                    href="javascript:void(0)"
                  >
                    <span class="text-sm font-medium hover:underline">
                      {{ pay_incentives[activeOrganization.plan].cta }}
                    </span>
                    <i class="fa fa-arrow-right ml-2 animate-pulse" />
                  </a>
                </div>
              </div>

              <div
                v-if="is_ltd"
                class="grid-cols-1 justify-between rounded-lg border border-foreground-muted px-8 flex py-12 flex-col items-start bg-right-top bg-no-repeat space-y-4"
              >
                <div class="font-medium text-lg">How to train your AI chatbot?</div>
                <div class="font-light text-sm">
                  Learn what is the best way to train your AI chatbot to get the best results from it.
                </div>
                <a
                  class="flex items-center space-x-2 mt-2"
                  target="_blank"
                  href="https://mevo-knowledge-base.notion.site/How-to-train-your-agent-19891582696746b798b4e2770152a3b8"
                >
                  <span class="text-sm font-medium hover:underline"> Learn more </span>
                  <i class="fa fa-arrow-right ml-2" />
                </a>
              </div>
              <div
                v-if="!is_ltd"
                class="grid-cols-1 justify-between rounded-lg border border-foreground-muted px-8 flex py-12 flex-col items-start bg-right-top bg-no-repeat space-y-4"
              >
                <div class="font-medium text-lg">How to use product keys?</div>
                <div class="font-light text-sm">
                  Learn how you can activate your product keys and start using your benefits.
                </div>
                <a
                  class="flex items-center space-x-2 mt-2"
                  target="_blank"
                  href="https://mevo-knowledge-base.notion.site/I-bought-product-keys-how-can-I-use-them-3eea94e4af2f4616949ae981b98fc601"
                >
                  <span class="text-sm font-medium hover:underline"> Learn more </span>
                  <i class="fa fa-arrow-right ml-2" />
                </a>
              </div>
              <div
                class="grid-cols-1 rounded-lg border border-foreground-muted px-8 flex py-12 flex-col items-start bg-right-top bg-no-repeat space-y-4"
              >
                <div class="font-medium text-lg">Invite your teammates</div>
                <div class="font-light text-sm mt-4">
                  Learn how you can invite your teammate to collaborate on your workflow.
                </div>
                <a
                  class="flex items-center space-x-2 mt-2"
                  target="_blank"
                  href="https://mevo-knowledge-base.notion.site/How-you-can-invite-your-teammate-d627ac648c2c4436b41824a0fd157b33?pvs=74"
                >
                  <span class="text-sm font-medium hover:underline"> Learn more </span>
                  <i class="fa fa-arrow-right ml-2" />
                </a>
              </div>
              <div
                class="grid-cols-1 justify-between rounded-lg border border-foreground-muted px-8 flex py-12 flex-col items-start bg-right-top bg-no-repeat space-y-4"
              >
                <div class="font-medium text-lg">How integrations works?</div>
                <div class="font-light text-sm mt-4">
                  Learn how you can get email notifications and use webhooks to get data.
                </div>
                <a
                  class="flex items-center space-x-2 mt-2"
                  target="_blank"
                  href="https://mevo-knowledge-base.notion.site/How-can-you-receive-notifications-using-Mevo-s-webhook-feature-with-Zapier-17e20cb00fff4828a7560aa796a3e2dc?pvs=74"
                >
                  <span class="text-sm font-medium"> Learn more </span>
                  <i class="fa fa-arrow-right ml-2" />
                </a>
              </div>
            </div>
          </div>
          <div class="mt-8">
            <div class="text-2xl font-medium tracking-tight antialiased">Learn How to Use</div>
            <p class="text-lg text-muted-foreground antialiased">
              Become a Mevo pro in no time with these step-by-step interactive tutorials.
            </p>
            <div class="grid grid-cols-1 sm:grid-cols-2 2xl:grid-cols-3 gap-4 mt-8">
              <div
                class="col-span-1 rounded-lg border border-foreground-muted p-8 flex flex-col items-start bg-left-bottom bg-no-repeat space-y-8 relative"
              >
                <div class="w-10 h-10 rounded-full bg-mevo flex items-center justify-center">
                  <RouteIcon class="w-5 h-5 text-white" />
                </div>
                <div class="font-semibold text-xl flex flex-col space-y-2">
                  <div class="flex flex-col items-start space-y-1">
                    <!-- <Badge class="w-fit rounded">Must Watch</Badge> -->
                    <div>Learn Flow Fundamentals</div>
                  </div>
                  <div class="font-normal text-sm">
                    Let’s create a chatbot flow together, using essential features like Questions, Webhooks, and User Inputs.
                  </div>
                </div>
                
                <div class="flex items-center space-x-2 justify-between w-full">
                  <Button
                    size="sm"
                    variant="secondary"
                    @click="onFirstArcadeTrigger"
                    class="cursor-pointer flex items-center space-x-2"
                  >
                    <span class="text-sm font-medium"> Watch tutorial</span>
                    <i class="fa fa-arrow-right ml-2" />
                  </Button>
                  <div class="text-sm text-muted-foreground">3 mins</div>
                </div>

                <iframe
                  src="https://demo.arcade.software/nZx21gkqgdOeYnSv9Kji?embed&embed_custom"
                  title="Learn Flow Fundamentals"
                  frameborder="0"
                  loading="lazy"
                  webkitallowfullscreen
                  mozallowfullscreen
                  allowfullscreen
                  allow="clipboard-write"
                  style="position: fixed; top: 0; left: 0; width: 100%; height: 0; color-scheme: light;"
                ></iframe>
              </div>
              <div
                class="col-span-1 rounded-lg border border-foreground-muted p-8 flex flex-col items-start bg-left-bottom bg-no-repeat space-y-8"
              >
                <div class="w-10 h-10 rounded-full bg-mevo flex items-center justify-center">
                  <FlaskConical class="w-5 h-5 text-white" />
                </div>
                <div class="font-semibold text-xl flex flex-col space-y-2">
                  <div class="flex flex-col items-start space-y-1">
                    <!-- <Badge variant="white" class="w-fit rounded">Recommended</Badge> -->
                    <div>Learn How to Test Your Chatbot</div>
                  </div>
                  <div class="font-normal text-sm">
                    In this tutorial we'll preview the chatbot journey with the testing feature and chatbot logs.
                  </div>
                </div>
                
                <div class="flex items-center space-x-2 justify-between w-full">
                  <Button
                    size="sm"
                    variant="secondary"
                    @click="onSecondArcadeTrigger"
                    class="cursor-pointer flex items-center space-x-2"
                  >
                    <span class="text-sm font-medium"> Watch tutorial</span>
                    <i class="fa fa-arrow-right ml-2" />
                  </Button>
                  <div class="text-sm text-muted-foreground">2 mins</div>
                </div>

                <iframe
                  src="https://demo.arcade.software/iyokwYulLm9q3GIMBnQt?embed&embed_custom&show_copy_link=true"
                  title="Simulate and Test a Chatbot Flow for Scheduling a Demo"
                  frameborder="0"
                  loading="lazy"
                  webkitallowfullscreen
                  mozallowfullscreen
                  allowfullscreen
                  allow="clipboard-write"
                  style="position: fixed; top: 0; left: 0; width: 100%; height: 0; color-scheme: light;"
                ></iframe>
              </div>
              <div
                class="col-span-1 rounded-lg border border-foreground-muted p-8 flex flex-col items-start bg-left-bottom bg-no-repeat space-y-8"
              >
                <div class="w-10 h-10 rounded-full bg-mevo flex items-center justify-center">
                  <Database class="w-5 h-5 text-white" />
                </div>
                <div class="font-semibold text-xl flex flex-col space-y-2">
                  <div class="flex flex-col items-start space-y-1">
                    <!-- <Badge variant="white" class="w-fit rounded">Recommended</Badge> -->
                    <div>Learn How to Collect Information</div>
                  </div>
                  <div class="font-normal text-sm">
                    In this tutorial we'll collect specific data from visitors and save it as a custom attribute to their profile.
                  </div>
                </div>
                
                <div class="flex items-center space-x-2 justify-between w-full">
                  <Button
                    size="sm"
                    variant="secondary"
                    @click="onThirdArcadeTrigger"
                    class="cursor-pointer flex items-center space-x-2"
                  >
                    <span class="text-sm font-medium"> Watch tutorial</span>
                    <i class="fa fa-arrow-right ml-2" />
                  </Button>
                  <div class="text-sm text-muted-foreground">2 mins</div>
                </div>

                <iframe
                  src="https://demo.arcade.software/rDx95ABbWzV4E9XkEKtU?embed&embed_custom&show_copy_link=true"
                  title="Create a Chatbot Flow That Schedules Meetings via Calendly"
                  frameborder="0"
                  loading="lazy"
                  webkitallowfullscreen
                  mozallowfullscreen
                  allowfullscreen
                  allow="clipboard-write"
                  style="position: fixed; top: 0; left: 0; width: 100%; height: 0; color-scheme: light;"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="hidden sm:block fixed top-0 right-0 w-72 h-min-screen h-full border-l border-foreground-muted bg-white">
        <ScrollArea class="h-full py-4">
          <div class="text-lg font-bold flex space-x-2 items-center text-mevo border-b pb-4 px-4">
            <Gift class="w-4 h-4 mr-1" />
            <div>What's new?</div>
          </div>
          <div class="flex-col flex px-4">
            <div class="space-y-2 border-b py-4">
              <div class="font-medium">Email Verified Leads</div>
              <div class="text-sm text-muted-foreground">
                Email-type questions can now automatically send an OTP verification code to the user’s email address.
                This ensures the email is valid before continuing the conversation, helping you collect higher-quality leads and prevent fake submissions.
              </div>
              <div class="flex justify-between items-center">
                <div class="text-xs text-muted-foreground">
                  Aug 10, 2025
                </div>
              </div>
            </div>
            <div class="space-y-2 border-b py-4">
              <div class="font-medium">Smarter Jumps</div>
              <div class="text-sm text-muted-foreground">
                Set rules based on user attributes or responses, and only jump to a specific step if those conditions are met.
                This means more personalized paths, smarter automations, and dynamic flows.
              </div>
              <div class="flex justify-between items-center">
                <div class="text-xs text-muted-foreground">
                  Aug 9, 2025
                </div>
              </div>
            </div>
            <div class="space-y-2 border-b py-4">
              <div class="font-medium">Introducing Profiles</div>
              <div class="text-sm text-muted-foreground">
                We've added a new menu item to chatbot manage view, Profiles. It's a new way to view all user profiles and their data in a one place. It has query filters and you can view previous conversations with each profile.
              </div>
              <div class="flex justify-between items-center">
                <div class="text-xs text-muted-foreground">
                  Aug 8, 2025
                </div>
                <!-- <Button variant="link" size="sm" class="text-sm text-muted-foreground">Read more</Button> -->
              </div>
            </div>
            <div class="space-y-2 border-b py-4">
              <div class="font-medium">Custom Attributes in Webhooks</div>
              <div class="text-sm text-muted-foreground">
                You can now send custom attributes to your webhooks, so you can use them in your integrations.
              </div>
              <div class="flex justify-between items-center">
                <div class="text-xs text-muted-foreground">
                  Aug 5, 2025
                </div>
                <!-- <Button variant="link" size="sm" class="text-sm text-muted-foreground">Read more</Button> -->
              </div>
            </div>
            <div class="space-y-2 border-b py-4">
              <div class="font-medium">Test Your Chatbot</div>
              <div class="text-sm text-muted-foreground">
                Now you can test your chatbot with the new testing feature and see how it responds to different inputs. Click the "Test your bot" button in the flow view to enable test section and chatbot logs.
              </div>
              <div class="flex justify-between items-center">
                <div class="text-xs text-muted-foreground">
                  Aug 3, 2025
                </div>
                <!-- <Button variant="link" size="sm" class="text-sm text-muted-foreground">Read more</Button> -->
              </div>
            </div>
            <div class="space-y-2 border-b py-4">
              <div class="font-medium">Introducing Flows</div>
              <div class="text-sm text-muted-foreground">
                We're introducing Flows, the new way to create smart chatbots, now you have flexibility of AI and determinism of scripted chatbots in one place.
              </div>
              <div class="flex justify-between items-center">
                <div class="text-xs text-muted-foreground">
                  Aug 1, 2025
                </div>
                <!-- <Button variant="link" size="sm" class="text-sm text-muted-foreground">Read more</Button> -->
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  </div>
</template>
