<template>
  <!-- <div class="flex flex-col items-end justify-center">
    <div class="flex text-sm items-center">
      <div
        v-tooltip="{
          text: 'The number of responses collected in the current billing period with scripted chatbots.',
          theme: {
            placement: 'left',
          },
        }"
        class="mr-1"
      >
        <question-mark-circle-icon class="h-4 w-4" />
      </div>
      <div class="font-medium mr-2">Response usage:</div>
      <div>{{ usageValue }} / {{ organizationResponseLimit }}</div>
    </div>
    <div class="flex text-sm items-center">
      <div
        v-tooltip="{
          text: activeOrganization.apiKeySet
            ? 'There is no token limit since you are using your own API key.'
            : 'The number of tokens used in the current billing period with ai-chatbots.',
          theme: {
            placement: 'left',
          },
        }"
        class="mr-1"
      >
        <question-mark-circle-icon class="h-4 w-4" />
      </div>
      <div class="font-medium mr-2">Token usage:</div>
      <div>
        <div v-if="!activeOrganization.apiKeySet">
          {{ organizationTokenUsage }} /
          {{ organizationTokenLimit }}
        </div>
        <div v-else>Unlimited</div>
      </div>
    </div>
  </div> -->
  <div v-if="bots" class="flex flex-col">
    <div class="font-bold">
      {{
        activeOrganization.plan
          ? setFirstLetterCapital(activeOrganization.plan) + " Plan"
          : "..."
      }}
    </div>
    <div class="mt-2">
      <div class="flex justify-between">
        <div class="font-medium text-sm">Monthly tokens</div>
        <div v-if="!activeOrganization.apiKeySet">
          <span class="font-semibold text-sm">{{
            organizationTokenUsage
          }}</span>
          of
          <span class="font-semibold text-sm">{{
            organizationTokenLimit
          }}</span>
        </div>
        <div v-else>
          <span class="font-semibold text-sm">Unlimited</span>
        </div>
      </div>
      <div class="w-full bg-indigo-200 h-2 rounded-sm mt-1">
        <div
          class="bg-indigo-500 h-2 rounded-sm"
          :style="{
            width:
              calculatePercentage(
                organizationTokenUsage,
                organizationTokenLimit
              ) + '%',
          }"
        ></div>
      </div>
    </div>
    <div class="mt-2">
      <div class="flex justify-between">
        <div class="font-medium text-sm">Monthly responses</div>
        <div>
          <span class="font-semibold text-sm">{{
            organizationResponseUsage
          }}</span>
          of
          <span class="font-semibold text-sm">{{
            organizationResponseLimit
          }}</span>
        </div>
      </div>
      <div class="w-full bg-indigo-200 h-2 rounded-sm mt-1">
        <div
          class="bg-indigo-500 h-2 rounded-sm"
          :style="{
            width:
              calculatePercentage(
                organizationResponseUsage,
                organizationResponseLimit
              ) + '%',
          }"
        ></div>
      </div>
    </div>
    <m-button
      @clicked="setUpgradeModal(true)"
      v-if="activePlan.name == PlanType.BASIC"
      class="w-full mt-8"
    >
      Upgrade now
      <font-awesome-icon icon="fa-solid fa-bolt" class="text-amber-300 ml-2" />
    </m-button>
  </div>
  <m-modal
    :open="isLimitModalOpen"
    :confirm-text="$t('plan.UPGRADE_NOW')"
    :cancel-text="$t('common.CANCEL')"
    :title="$t('organizations.RESPONSE_LIMIT_REACHED')"
    :description="$t('organizations.RESPONSE_LIMIT_REACHED_DESCRIPTION')"
    @close="isLimitModalOpen = false"
    @confirm="upgradePlan"
  />
</template>

<script setup lang="ts">
import { computed, ref, type Ref } from "vue";
import { useUsage } from "@/composables/useUsage";
import { useCommonStore } from "@/stores";
import { useSubscription } from "@/composables/useSubscription";
import { useOrganizations } from "@/composables/useOrganizations";
import MModal from "@/components/v2/elements/MModal.vue";
import { QuestionMarkCircleIcon } from "@heroicons/vue/20/solid";
import { PlanType, Plans } from "@/modules/organization/types/IPlan";
import type { IOrganization } from "@/modules/organization/types/IOrganization";
import { useRouteGlobals } from "@/composables/useRouteGlobals";
import { useBots } from "@/composables/useBots";
import MButton from "@/components/v2/elements/MButton.vue";

const { setUpgradeModal } = useCommonStore();
const { upgradePlan, activePlan } = useSubscription();
const { bots } = useBots();
const { oid } = useRouteGlobals();
const {
  organizationResponseLimit,
  organizationResponseUsage,
  organizationLimitExceed,
  organizationTokenUsage,
  organizationTokenLimit,
} = useUsage();
const { organizations } = useOrganizations();

const activeOrganization: Ref<IOrganization> = computed(
  () =>
    organizations.value &&
    organizations.value.find((o: IOrganization) => o._id === oid.value)
);

const isLimitModalOpen = ref(false);

const isLimitReached = computed(() => {
  return organizationResponseUsage.value >= organizationResponseLimit.value;
});

const usageValue = computed(() => {
  if (organizationLimitExceed.value > 0) {
    return organizationResponseLimit.value;
  }
  return organizationResponseUsage.value;
});

const width = computed(() => {
  return (usageValue.value / organizationResponseLimit.value) * 200;
});

const setFirstLetterCapital = (str: string) => {
  return str.charAt(0).toUpperCase() + str.slice(1);
};

const calculatePercentage = (value: number, limit: number) => {
  return (value / limit) * 100;
};
</script>
