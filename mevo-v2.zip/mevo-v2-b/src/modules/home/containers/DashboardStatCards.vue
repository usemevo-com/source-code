<template>
  <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
    <!-- QUESTIONS ANSWERED -->
    <Card>
      <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle class="text-sm font-medium"> Questions answered </CardTitle>
        <i class="h-4 w-4 text-muted-foreground fa-regular fa-message-check"></i>
      </CardHeader>
      <CardContent>
        <div class="text-2xl font-bold">{{ stats?.current?.answeredQuestions }}</div>
        <p class="text-xs text-muted-foreground">
          <i
            :class="[
              (statsPercentages.answeredQuestions as number) > 0 && 'fa-arrow-up text-green-500',
              (statsPercentages.answeredQuestions as number) < 0 && 'fa-arrow-down text-red-500',
              (statsPercentages.answeredQuestions as number) === 0 &&
                'fa-minus text-muted-foreground'
            ]"
            class="fa-regular mr-1"
          ></i>
          <span
            :class="[
              (statsPercentages.answeredQuestions as number) > 0 && 'text-green-500',
              (statsPercentages.answeredQuestions as number) < 0 && 'text-red-500'
            ]"
            >{{ statsPercentages.answeredQuestions }}%</span
          >
          from last month
        </p>
      </CardContent>
    </Card>
    <!-- QUESTIONS ANSWERED -->

    <!-- LEADS CAPTURED -->
    <Card>
      <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle class="text-sm font-medium"> Leads captured </CardTitle>
        <i class="fa-regular fa-user-plus h-4 w-4 text-muted-foreground"></i>
      </CardHeader>
      <CardContent>
        <div class="text-2xl font-bold">{{ stats?.current?.capturedLeads }}</div>
        <p class="text-xs text-muted-foreground">
          <i
            :class="[
              (statsPercentages.capturedLeads as number) > 0 && 'fa-arrow-up text-green-500',
              (statsPercentages.capturedLeads as number) < 0 && 'fa-arrow-down text-red-500',
              (statsPercentages.capturedLeads as number) === 0 && 'fa-minus text-muted-foreground'
            ]"
            class="fa-regular mr-1"
          ></i>
          <span
            :class="[
              (statsPercentages.capturedLeads as number) > 0 && 'text-green-500',
              (statsPercentages.capturedLeads as number) < 0 && 'text-red-500'
            ]"
          >
            {{ statsPercentages.capturedLeads }}%
          </span>
          from last month
        </p>
      </CardContent>
    </Card>
    <!-- LEADS CAPTURED -->

    <!-- CONVERSATION STARTED -->
    <Card>
      <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle class="text-sm font-medium">Conversation started</CardTitle>
        <i class="fa-regular fa-comment-alt h-4 w-4 text-muted-foreground"></i>
      </CardHeader>
      <CardContent>
        <div class="text-2xl font-bold">{{ stats?.current?.startedConversations }}</div>
        <p class="text-xs text-muted-foreground">
          <i
            :class="[
              (statsPercentages.startedConversations as number) > 0 && 'fa-arrow-up text-green-500',
              (statsPercentages.startedConversations as number) < 0 && 'fa-arrow-down text-red-500',
              (statsPercentages.startedConversations as number) === 0 &&
                'fa-minus text-muted-foreground'
            ]"
            class="fa-regular"
          ></i>
          {{ statsPercentages.startedConversations }}% from last month
        </p>
      </CardContent>
    </Card>
    <!-- CONVERSATION STARTED -->

    <!-- BOTS VIEWED -->
    <Card>
      <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle class="text-sm font-medium"> Your bots viewed </CardTitle>
        <i class="fa-regular fa-eye h-4 w-4 text-muted-foreground"></i>
      </CardHeader>
      <CardContent>
        <div class="text-2xl font-bold">{{ stats?.current?.totalViewCount }}</div>
        <p class="text-xs text-muted-foreground">times from the beginning</p>
      </CardContent>
    </Card>
    <!-- BOTS VIEWED -->
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card'
import { useOrganizationStats } from '@/composables/useOrganizationStats'

const { stats, calculateDiff } = useOrganizationStats()

const statsPercentages = computed(() => {
  return {
    answeredQuestions: calculateDiff(
      stats.value?.previous?.answeredQuestions,
      stats.value?.current?.answeredQuestions
    ),
    capturedLeads: calculateDiff(
      stats.value?.previous?.capturedLeads,
      stats.value?.current?.capturedLeads
    ),
    startedConversations: calculateDiff(
      stats.value?.previous?.startedConversations,
      stats.value?.current?.startedConversations
    )
  }
})
</script>
