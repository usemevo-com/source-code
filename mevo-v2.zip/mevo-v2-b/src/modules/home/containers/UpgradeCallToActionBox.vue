<template>
  <m-box
    hover-effect
    class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer bg-indigo-500"
    @clicked="$emit('clicked')"
  >
    <div class="flex justify-between">
      <m-badge type="success" class="h-fit w-fit !py-2 items-center">
        <i class="fa-sharp fa-light fa-unlock text-lg w-5"></i>
      </m-badge>
      <i class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"></i>
    </div>

    <div class="mt-4 font-bold sm:w-64 truncate text-white">
      Unlock more with Pro
    </div>
    <div class="text-gray-100 font-medium text-sm">
      More tokens, more responses, no mevo branding, webhooks and more.
    </div>
  </m-box>
</template>

<script setup lang="ts">
import MBox from "@/components/v2/elements/MBox.vue";
import MBadge from "@/components/v2/elements/MBadge.vue";

defineEmits(["clicked"]);
</script>
