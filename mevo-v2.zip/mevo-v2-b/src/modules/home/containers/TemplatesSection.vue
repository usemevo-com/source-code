<template>
  <m-page-header
    class="mt-8"
    title="Need some inspiration?"
    subtitle="Choose one of our example use cases to get started"
  />
  <div class="grid grid-cols-12 gap-4 mt-8">
    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer hidden sm:block"
      @clicked="$emit('selected', 'data_removal')"
    >
      <div class="flex justify-between">
        <m-badge class="h-fit w-fit !py-2 items-center" type="fuchsia">
          <i class="fa-sharp fa-light fa-lock text-lg w-5"></i>
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>
      <div class="font-bold sm:w-64 truncate mt-4">Data Removal Request</div>
      <div class="text-gray-400 font-medium text-sm">
        Create a data removal request for your mobile app or website.
      </div>
    </m-box>
    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer"
      @clicked="$emit('selected', 'saas')"
    >
      <div class="flex justify-between">
        <m-badge type="success" class="h-fit w-fit !py-2 items-center">
          <i class="fa-sharp fa-light fa-microchip-ai text-lg w-5"></i>
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>
      <div class="mt-4 font-bold sm:w-64 truncate">
        Assistant for SaaS landing
      </div>
      <div class="text-gray-400 font-medium text-sm">
        A chatbot that helps you to convert your visitors to leads.
      </div>
    </m-box>
    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer hidden sm:block"
      @clicked="$emit('selected', 'nps')"
    >
      <div class="flex justify-between">
        <m-badge class="h-fit w-fit !py-2 items-center" type="fuchsia">
          <i class="fa-sharp fa-light fa-message-captions text-lg w-5"></i>
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>
      <div class="font-bold sm:w-64 truncate mt-4">NPS</div>
      <div class="text-gray-400 font-medium text-sm">
        A chatbot that asks Net Promoter Score (NPS) to your customers.
      </div>
    </m-box>
    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer hidden sm:block"
      @clicked="$emit('selected', 'demo')"
    >
      <div class="flex justify-between">
        <m-badge class="h-fit w-fit !py-2 items-center" type="fuchsia">
          <i class="fa-sharp fa-light fa-message-captions text-lg w-5"></i>
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>

      <div class="font-bold sm:w-64 truncate mt-4">Demo call scheduler</div>
      <div class="text-gray-400 font-medium text-sm">
        A chatbot that schedules a demo call with your customers.
      </div>
    </m-box>
  </div>
</template>

<script setup lang="ts">
import MBox from "@/components/v2/elements/MBox.vue";
import MPageHeader from "@/components/v2/elements/MPageHeader.vue";
import MBadge from "@/components/v2/elements/MBadge.vue";

defineEmits(["selected"]);
</script>
