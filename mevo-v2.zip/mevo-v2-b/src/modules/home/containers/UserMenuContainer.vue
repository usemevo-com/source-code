<template>
  <Menu v-if="user" as="div" class="relative inline-block text-left">
    <MenuButton>
      <span class="inline-block relative">
        <img class="h-10 w-10 rounded-full" :src="userAvatar" alt="" />
      </span>
    </MenuButton>
    <transition
      enter-active-class="transition duration-100 ease-out"
      enter-from-class="transform scale-95 opacity-0"
      enter-to-class="transform scale-100 opacity-100"
      leave-active-class="transition duration-75 ease-in"
      leave-from-class="transform scale-100 opacity-100"
      leave-to-class="transform scale-95 opacity-0"
    >
      <MenuItems
        class="absolute left-12 bottom-12 mt-2 w-64 origin-top-right divide-y divide-gray-100 rounded-lg bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
      >
        <div class="px-1 py-1">
          <MenuItem class="px-4 pt-3 pb-2 text-sm">
            <div class="flex">
              <div>
                <span class="inline-block relative">
                  <img class="h-10 w-10 rounded-full" :src="userAvatar" alt="" />
                </span>
              </div>
              <div class="ml-4">
                <div class="font-medium text-sm w-40 truncate">{{ user.name }}</div>
                <div :title="user.email" class="text-gray-500 text-xs w-40 truncate">{{ user.email }}</div>
              </div>
            </div>
          </MenuItem>
        </div>
        <div class="px-1 py-1">
          <MenuItem v-slot="{ active }" class="px-4 text-sm">
            <a
              :class="[
                active ? 'bg-blue-500 text-white' : 'text-gray-900',
                'group flex w-full items-center rounded-md px-2 py-1 text-sm',
              ]"
              href="javascript:void(0)"
              @click="$emit('logout')"
            >
              {{ $t('user_menu.SIGN_OUT') }}
            </a>
          </MenuItem>
        </div>
      </MenuItems>
    </transition>
  </Menu>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import md5 from 'md5'
import { Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/vue'
import type { IUser } from '@/modules/prelogin/types/IUser'

const emits = defineEmits(['logout', 'copy-invite-link', 'copy-organization-link'])
const props = defineProps<{ user: IUser }>()
const userAvatar = computed(() => {
  return `https://gravatar.com/avatar/${md5(props.user.email)}`
})
</script>
