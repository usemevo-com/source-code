<template>
  <m-modal
    without-cancel
    :show-close="false"
    :confirm-text="'Get started'"
    @confirm="() => $emits('close')"
    @close="() => $emits('close')"
    :open="isOpen"
  >
    <div class="flex flex-col bg-white">
      <div class="flex items-center justify-center space-x-2">
        <img
          class="h-4"
          src="https://cdn.usemevo.com/assets/images/appsumo.svg"
        />
        <span class="text-2xl">🤝</span>
        <m-brand />
      </div>
      <div>
        <p class="space-y-2 py-12">
          <div>Dear Sumo-ling,</div>
          <div>Thank you very much for your interest and support to Mevo.</div>
          <div>Your support is very valuable to us and will never be forgotten. We hope our product makes your life easier and you will continue to use it for many years. </div>
          <div>If you have any feedback or need assistance, please feel free to contact us.</div>
          <div>Mevo Team</div>
        </p>
      </div>
    </div>
  </m-modal>
</template>

<script lang="ts" setup>
import MModal from "@/components/v2/elements/MModal.vue";
import MBrand from "@/components/v2/elements/MBrand.vue";

export interface AppSumoWelcomeModal {
  isOpen: boolean;
}

withDefaults(defineProps<AppSumoWelcomeModal>(), {
  isOpen: false,
});

const $emits = defineEmits(["confirm", "close"]);
</script>
