<template>
  <m-modal
    without-cancel
    :show-close="false"
    :confirm-text="'Get started'"
    @confirm="onClose"
    @close="onClose"
    :open="isOpen"
  >
    <div class="flex flex-col bg-white">
      <!-- <video autoplay muted class="mt-4">
        <source
          src="https://cdn.usemevo.com/videos%2Fmevo-classic-bot.mp4"
          type="video/mp4"
          width="100%"
        />
      </video> -->
      <!-- <div class="mt-4 flex items-center justify-between sm:flex-row flex-col">
        <div class="sm:w-3/4 text-sm text-black">
          <div class="text-lg font-bold text-black">Tutorials</div>
          <div class="w-full text-sm text-gray-700">
            We have a youtube channel which contains lot of useful videos and
            tutorials if you need.
          </div>
        </div>
        <m-button class="w-full sm:w-[110px] h-fit mt-4 sm:mt-0" type="primary">
          Visit channel
        </m-button>
      </div>

      <div class="mt-4 flex items-center justify-between sm:flex-row flex-col">
        <div class="sm:w-3/4 text-sm text-black">
          <div class="text-lg font-bold text-black">Mevo Pro</div>
          <div class="w-full text-sm text-gray-700">
            We have a paid plan called Mevo Pro which includes unlimited
            responses, AI features and more.
          </div>
        </div>
        <m-button class="w-full sm:w-[110px] h-fit mt-4 sm:mt-0" type="primary">
          Get info
        </m-button>
      </div>

      <div class="mt-4 flex items-center justify-between sm:flex-row flex-col">
        <div class="sm:w-3/4 text-sm text-black">
          <div class="text-lg font-bold text-black">Have a question?</div>
          <div class="w-full text-sm text-gray-700">
            You can always contact us via this bot. We will be happy to help
            you.
          </div>
        </div>
        <m-button class="w-full sm:w-[110px] h-fit mt-4 sm:mt-0" type="primary">
          Contact us
        </m-button>
      </div> -->
    </div>
  </m-modal>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import MModal from "@/components/v2/elements/MModal.vue";
import { useOnboardingStore } from "@/stores/onboarding";

const { setStepDone } = useOnboardingStore();

const onClose = () => {
  setStepDone("close-onboarding-popup");
};
const isOpen = ref(true);
</script>
