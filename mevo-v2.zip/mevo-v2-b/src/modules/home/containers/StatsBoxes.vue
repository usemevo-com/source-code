<template>
  <div v-if="!loading && mode === BotType.SCRIPTED" class="grid grid-cols-2 gap-5 sm:grid-cols-5">
    <Card :key="item.name" v-for="(item, idx) in stats">
      <CardContent
        class="p-5 rounded-md relative bg-white"
        :class="[idx === 4 && 'sm:col-span-1 col-span-2']"
      >
        <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900">
          {{ item.stat }}
        </dd>
        <dt class="truncate text-sm font-medium text-gray-500">
          {{ item.name }}
        </dt>
      </CardContent>
    </Card>
  </div>
  <div v-else-if="!loading && mode === BotType.GPT">
    <dl class="grid grid-cols-2 gap-5 sm:grid-cols-4">
      <div
        v-for="(item, idx) in statsGpt"
        :key="item.name"
        :class="[idx === 4 && 'sm:col-span-1 col-span-2']"
        class="overflow-hidden shadow p-5 rounded-md relative bg-white flex-col justify-between flex"
      >
        <dd
          :class="[item.name === 'Model' ? 'text-2xl' : 'text-3xl']"
          class="w-24 sm:w-fit truncate mt-1 font-semibold tracking-tight text-gray-900"
        >
          {{ item.stat }}
        </dd>
        <dt class="w-24 sm:w-fit truncate text-sm font-medium text-gray-500">
          {{ item.name }}
        </dt>
      </div>
    </dl>
  </div>
  <div v-else>
    <dl class="grid grid-cols-2 gap-5 sm:grid-cols-5 animate-pulse">
      <div
        v-for="item in 5"
        :key="item"
        class="overflow-hidden shadow p-5 rounded-md relative bg-white"
      >
        <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900">
          <div class="mt-4 h-4 w-12 bg-gray-300 rounded"></div>
        </dd>
        <dt class="truncate text-sm font-medium text-gray-500 mt-2">
          <div class="h-4 w-32 bg-gray-300 rounded"></div>
        </dt>
      </div>
    </dl>
  </div>
</template>

<script lang="ts" setup>
import { Card, CardContent } from '@/components/ui/card'
import { BotType } from '@/modules/bot/types/IBot'
import { ScriptStepType } from '@/modules/bot/types/IScriptStep'
import { computed } from 'vue'
const props = defineProps({
  bot: {
    type: Object,
    default: () => ({
      viewCount: 0
    })
  },
  sessions: {
    type: Array,
    default: () => []
  },
  mode: {
    type: String,
    default: 'scripted'
  },
  responseCount: {
    type: Number,
    default: 0
  },
  loading: {
    type: Boolean,
    default: true
  },
  avgMsg: {
    type: Number,
    required: false,
    default: 0
  },
  totalSession: {
    type: Number,
    required: false,
    default: 0
  },
  responseCount: {
    type: Number,
    required: false,
    default: 0
  }
})
const stats = computed(() => [
  {
    name: 'Question includes',
    stat: stepCount.value
  },
  { name: 'Total responses', stat: props.bot.completedCount || 0 },
  { name: 'Total views', stat: props.bot.viewCount || 0 },
  {
    name: 'Avg. start rate',
    stat: startRate.value + '%' || '0 %'
  },
  {
    name: 'Avg. complete rate',
    stat: completeRate.value + '%' || '0 %'
  }
])

const statsGpt = computed(() => [
  { name: 'Total sessions', stat: props.totalSession || 0 },
  { name: 'Total views', stat: props.bot.viewCount || 0 },
  {
    name: 'Avg. message per session',
    stat: props.avgMsg.toFixed(2) || 0
  },
  {
    name: 'Model',
    stat: props.bot.gptSettings.model
  }
])

const avgMessagePerSession = computed(() => {
  const totalMessages = props.sessions.reduce((acc, cur) => {
    return acc + cur.messages.length
  }, 0)
  const val = totalMessages / props.sessions.length

  if (isNaN(val)) {
    return 0
  }
  return val.toFixed(2)
})

const stepCount = computed(() => {
  return (
    (props.bot &&
      props.bot.script &&
      props.bot.script.steps.filter((s) => s.type !== ScriptStepType.MESSAGE).length) ||
    0
  )
})

const startRate = computed(() => {
  const val = (props.bot.startCount / props.bot.viewCount) * 100

  if (isNaN(val)) {
    return 0
  }
  return val.toFixed(2)
})

const completeRate = computed(() => {
  const val = (props.bot.completedCount / props.bot.startCount) * 100

  if (isNaN(val)) {
    return 0
  }
  return val.toFixed(2)
})
</script>
