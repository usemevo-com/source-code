<template>
  <m-page-header
    class="mt-8"
    title="Need help?"
    subtitle="Choose a way to suits you best"
  />
  <div class="grid grid-cols-12 gap-4 my-8">
    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer"
      @clicked="() => $emit('selected', 'custom-domains')"
    >
      <div class="flex justify-between">
        <m-badge class="h-fit w-fit !py-2 items-center" type="info">
          <i class="fa-sharp fa-light fa-globe text-lg w-5"></i>
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>
      <div class="mt-4 font-bold sm:w-64 truncate">
        Tutorial: Custom Domains
      </div>
      <div class="text-gray-400 font-medium text-sm">
        Read instructions and learn how to complete custom domain setup.
      </div>
    </m-box>

    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer"
      @clicked="() => $emit('selected', 'integrations')"
    >
      <div class="flex justify-between">
        <m-badge class="h-fit w-fit !py-2 items-center" type="info">
          <i class="fa-sharp fa-light fa-webhook w-5 text-lg"></i>
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>
      <div class="font-bold sm:w-64 truncate mt-4">
        Tutorial: Hooks and Integrations
      </div>
      <div class="text-gray-400 font-medium text-sm">
        Learn how to integrate your chatbot with Zapier and other services.
      </div>
    </m-box>
    <m-box
      hover-effect
      class="p-4 2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12 cursor-pointer"
      @clicked="() => $emit('selected', 'community')"
    >
      <div class="flex justify-between">
        <m-badge class="h-fit w-fit !py-2 items-center" type="info">
          <font-awesome-icon
            icon="fa-sharp fa-brands fa-discord"
            class="w-5 text-lg"
          />
        </m-badge>
        <i
          class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
        ></i>
      </div>
      <div class="font-bold sm:w-64 truncate mt-4">Ask to community</div>
      <div class="text-gray-400 font-medium text-sm">
        Join our Discord community to ask your questions.
      </div>
    </m-box>
    <a
      class="2xl:col-span-3 xl:col-span-3 md:col-span-6 col-span-12"
      href="mailto:hi@usemevo.com"
    >
      <m-box hover-effect class="p-4 w-full cursor-pointer">
        <div class="flex justify-between">
          <m-badge class="h-fit w-fit !py-2 items-center" type="info">
            <i class="fa-sharp fa-light fa-envelope w-5 text-lg"></i>
          </m-badge>
          <i
            class="fa-sharp fa-light fa-arrow-up-right text-gray-300 text-lg"
          ></i>
        </div>
        <div class="font-bold sm:w-64 truncate mt-4">
          Need a specific answer?
        </div>
        <div class="text-gray-400 font-medium text-sm">
          Send an email. We'll get back to you in 12 hours at the latest.
        </div>
      </m-box>
    </a>
  </div>
</template>

<script setup lang="ts">
import MBox from "@/components/v2/elements/MBox.vue";
import MPageHeader from "@/components/v2/elements/MPageHeader.vue";
import MBadge from "@/components/v2/elements/MBadge.vue";

defineEmits(["selected"]);
</script>
