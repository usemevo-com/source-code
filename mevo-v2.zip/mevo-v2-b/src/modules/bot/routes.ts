import Detail from './pages/Detail.vue'
import DetailGPT from './pages/DetailGPT.vue'
import RuleBasedBuilder from './pages/Builder.vue'
import AIBuilder from './pages/BotBuilder.vue'
import History from './pages/ChatHistory.vue'
import Integration from './pages/Integration.vue'

export const BotRoutes = [
  {
    name: 'rule-based-detail',
    path: 'b/:bid',
    component: Detail
  },
  {
    name: 'bot-detail-gpt',
    path: 'gpt/:bid',
    component: DetailGPT
  },
  {
    name: 'bot-builder',
    path: 'builder',
    component: RuleBasedBuilder
  },
  {
    name: 'bot-builder-v2',
    path: 'build',
    component: AIBuilder
  },
  {
    name: 'bot-editor-v2',
    path: 'edit/:bid',
    component: AIBuilder
  },
  {
    name: 'integration',
    path: 'integrate/:bid',
    component: Integration
  },
  {
    name: 'bot-editor',
    path: 'editor/:bid',
    component: RuleBasedBuilder
  },
  {
    name: 'session-detail',
    path: 'session/:bid/:sid',
    component: History
  }
]
