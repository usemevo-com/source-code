import NotFound from "./pages/NotFoundView.vue";
import Loading from "./pages/LoadingView.vue";
import Redirect from "./pages/RedirectView.vue";
import PaymentSuccess from "./pages/PaymentSuccessView.vue";
import PaymentFailed from "./pages/PaymentFailedView.vue";

export const CommonRoutes = [
  {
    path: "/:*anything",
    component: NotFound,
  },
  {
    path: "/",
    component: Loading,
  },
  {
    path: "/loading",
    component: Loading,
  },
  {
    name: "redirect",
    path: "/redirect",
    component: Redirect,
  },
  {
    name: "payment-success",
    path: "/payment-success",
    component: PaymentSuccess,
  },
  {
    name: "payment-failed",
    path: "/payment-failed",
    component: PaymentFailed,
  },
];
