import ForgotPassword from './pages/ForgotPasswordView.vue'
import Register from './pages/RegisterView.vue'
import Login from './pages/LoginView.vue'
import ResetPassword from './pages/ResetPasswordView.vue'
import GetStarted from './pages/GetStarted.vue'
import SetBranding from './pages/SetBranding.vue'
import SetUpAccount from './pages/SetUpAccount.vue'
import FinalizeSetup from './pages/FinalizeSetup.vue'
import Onboarding from './pages/Onboarding.vue'
import ChoosePages from './pages/ChoosePages.vue'
import Preview from './pages/Preview.vue'
import Clarity from './pages/Clarity.vue'

export const PreloginRoutes = [
  {
    path: '/preview/:site',
    component: Preview,
    meta: {
      prelogin: true,
    },
  },
  {
    path: '/clarity/:site',
    component: Clarity,
    meta: {
      prelogin: true,
    },
  },
  {
    path: '/login',
    component: Login,
    meta: {
      prelogin: true,
    },
  },
  {
    path: '/register',
    component: Register,
    meta: {
      prelogin: true,
    },
  },
  {
    path: '/forgot-password',
    component: ForgotPassword,
    meta: {
      prelogin: true,
    },
  },
  {
    path: '/reset-password',
    component: ResetPassword,
    meta: {
      prelogin: true,
    },
  },
  {
    name: 'get-started',
    path: '/get-started',
    component: GetStarted,
    meta: {
      prelogin: true,
      access_with_auth: true,
    },
  },
  {
    name: 'choose-pages',
    path: '/choose-pages',
    component: ChoosePages,
    meta: {
      prelogin: true,
      access_with_auth: true,
    },
  },
  {
    name: 'set-branding',
    path: '/set-branding',
    component: SetBranding,
    meta: {
      prelogin: true,
      access_with_auth: true,
    },
  },
  {
    name: 'set-up-account',
    path: '/set-up-account',
    component: SetUpAccount,
    meta: {
      prelogin: true,
      access_with_auth: true,
    },
  },
  {
    name: 'finalize-setup',
    path: '/finalize-setup',
    component: FinalizeSetup,
    meta: {
      prelogin: true,
      access_with_auth: true,
    },
  },
  // {
  //   name: 'onboarding',
  //   path: '/onboarding',
  //   component: Onboarding,
  //   meta: {
  //     prelogin: true,
  //     access_with_auth: true,
  //   },
  // },
]
