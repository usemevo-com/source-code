import { HTTPMethods, send, sendHTTPRequest } from '@/utils/http/request'
import type { CreateOrganizationRequest } from '../dtos/CreateOrganizationRequest'
import type { UpdateOrganizationRequest } from '../dtos/UpdateOrganizationRequest'
import type { RemoveOrganizationRequest } from '../dtos/RemoveOrganizationRequest'
import { AddOn, SubscriptionType } from '../types/IPlan'

export async function getOrganizations() {
  return await sendHTTPRequest(HTTPMethods.GET, '/organizations/v3')
}

export async function getMessageChartData(oid: string) {
  return await sendHTTPRequest(HTTPMethods.GET, `/organizations/message-chart-data/${oid}`)
}

export async function getRecentInteractions(oid: string) {
  return await sendHTTPRequest(HTTPMethods.GET, `/organizations/recent-interactions/${oid}`)
}

export async function getOrganizationStats(oid: string) {
  return await sendHTTPRequest(HTTPMethods.GET, `/organizations/stats/${oid}`)
}

export async function createOrganization(payload: CreateOrganizationRequest) {
  return await send(HTTPMethods.POST, `/organizations/v3`, payload)
}

export async function upgradeWithKey(payload: { organization: string; keys: string[] }) {
  return await send(
    HTTPMethods.POST,
    `/organizations/${payload.organization}/upgrade-tier`,
    payload
  )
}

export async function updateOrganization(id: string, payload: UpdateOrganizationRequest) {
  return await send(HTTPMethods.PATCH, `/organizations/${id}`, payload)
}

export async function removeOrganization(id: string, payload: RemoveOrganizationRequest) {
  return await send(HTTPMethods.DELETE, `/organizations/${id}`, payload)
}

export async function inviteUser(id: string, email: string) {
  return await send(HTTPMethods.POST, `/organizations/${id}/add-user`, {
    email
  })
}

export async function addListener(id: string, email: string) {
  return await send(HTTPMethods.POST, `/users/${id}/add-listener`, {
    email
  })
}

export async function removeListener(id: string, email: string) {
  return await send(HTTPMethods.POST, `/users/${id}/remove-listener`, {
    email
  })
}

export async function inviteAdmin(id: string, email: string) {
  return await send(HTTPMethods.POST, `/organizations/${id}/add-admin`, {
    email
  })
}

export async function removeUser(id: string, email: string) {
  return await send(HTTPMethods.POST, `/organizations/${id}/remove-user`, {
    email
  })
}

export async function removeAdmin(id: string, email: string) {
  return await send(HTTPMethods.POST, `/organizations/${id}/remove-admin`, {
    email
  })
}

export async function updateAPIKey(id: string, apiKey: string) {
  return await send(HTTPMethods.POST, `/organizations/${id}/add-secret`, {
    key: 'open_ai_key',
    value: apiKey
  })
}

export async function removeAPIKey(id: string) {
  return await send(HTTPMethods.POST, `/organizations/${id}/remove-secret`, {
    key: 'open_ai_key'
  })
}

export async function acceptInvitation(code: string) {
  return await send(HTTPMethods.POST, `/invitations/accept`, { code })
}

export async function getResponseUsage(organization: string) {
  return await send(HTTPMethods.GET, `/user-responses/count/${organization}`)
}

export async function getHiddenCount(organization: string) {
  return await send(HTTPMethods.GET, `/user-responses/hidden-count/${organization}`)
}

export async function planChange(
  organization: string,
  plan: string,
  subscriptionType: SubscriptionType = SubscriptionType.MONTHLY,
  affiliate_referrer: string
) {
  let payload: { plan: string; subscriptionType: SubscriptionType; affiliate_referrer?: string } = {
    plan,
    subscriptionType,
  };

  if (affiliate_referrer) {
    payload.affiliate_referrer = affiliate_referrer;
  }

  return await send(HTTPMethods.POST, `/subscriptions/plan/change/${organization}`, payload)
}

export async function purchaseAddOn(addOn: AddOn, organization: string) {
  return await send(HTTPMethods.POST, `/subscriptions/buy-add-on/${organization}`, {
    addOn
  })
}

export async function removeAddOn(addOn: AddOn, organization: string) {
  return await send(HTTPMethods.POST, `/subscriptions/cancel-add-on/${organization}`, {
    addOn
  })
}

export async function getBillingManagementUrl(organization: string) {
  return await send(HTTPMethods.POST, `/subscriptions/billing-management-url/${organization}`)
}

export async function setWebhookURL(organization: string, webhookURL: string) {
  return await send(HTTPMethods.POST, `/organizations/set-webhook/${organization}`, {
    webhookURL
  })
}
