export interface RemoveOrganizationRequest {
  name: string
}
