export interface UpdateOrganizationRequest {
  name?: string;
  domain?: string;
  sendEmailNotificationToAdmin?: boolean;
}
