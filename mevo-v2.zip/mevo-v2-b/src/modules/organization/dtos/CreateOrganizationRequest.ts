export interface CreateOrganizationRequest {
  name: string
  domain?: string
  size?: string
  migration?: boolean
  bot?: string
}
