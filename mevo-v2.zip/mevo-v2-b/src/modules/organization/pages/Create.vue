<template>
  <div
    class="max-w-5xl h-screen flex flex-col space-y-8 justify-center items-center relative mx-auto"
  >
  <div v-if="!atLeastOneOrganizationExist" class="bg-mevo-light text-mevo p-4 rounded-lg w-full space-y-2 max-w-md mx-4 sm:mx-0 text-sm">
    <div class="font-semibold">You have no Mevo v3 compatible workspaces</div>
    <div>If you think you already have a workspace but can't see it, you may have legacy organizations, you should login to <a href="https://app.usemevo.com/login" class="text-mevo underline">app.usemevo.com</a> to see and manage them.</div>
  </div>
    <m-form
      @submit="onSubmit"
      class="bg-white p-8 border-b shadow rounded-lg w-full space-y-4 max-w-md mx-4 sm:mx-0"
    >
      <m-headline
        title="Create a new workspace"
        description="Workspaces allow you to organize your data."
      />
      <m-text-input
        :placeholder="$t('organizations.PH_NAME')"
        name="organization-name"
        rules="required"
        label="Workspace name"
        v-model="organization.data.name"
      />
      <m-text-input
        :placeholder="$t('organizations.PH_DOMAIN')"
        name="organization-domain"
        label="Workspace domain"
        v-model="organization.data.domain"
      />
      <div
        class="flex !mt-8 justify-end"
        :class="[!atLeastOneOrganizationExist && '!justify-end']"
      >
        <m-button type="primary" @clicked="">{{
          $t("organizations.SUBMIT_BUTTON")
        }}</m-button>
      </div>
    </m-form>
    <m-button
      class="absolute top-10 left-4 sm:left-0"
      @clicked="goBack"
      v-if="atLeastOneOrganizationExist"
      type="white"
    >
      <arrow-left-icon class="h-4 w-4 text-black mr-2" />
      {{ $t("organizations.BACK_BUTTON") }}
    </m-button>
  </div>
</template>

<script lang="ts" setup>
import { computed, reactive } from "vue";
import { useRouter } from "vue-router";
import { Form as MForm } from "vee-validate";
import { ArrowLeftIcon } from "@heroicons/vue/24/outline";
import mixpanel from "mixpanel-browser";

import MTextInput from "@/components/basic/MTextInput.vue";
import MHeadline from "@/components/basic/MHeadline.vue";
import MButton from "@/components/v2/elements/MButton.vue";
import { useOrganizations } from "@/composables/useOrganizations";
import { createOrganization } from "../services/OrganizationService";
import { useCommonStore } from "@/stores";
import { useI18n } from "vue-i18n";

const $router = useRouter();
const { t } = useI18n();
const { setNotification } = useCommonStore();
const { organizations, refreshOrganizations } = useOrganizations();
const atLeastOneOrganizationExist = computed(
  () => organizations.value && organizations.value.length
);
const organization = reactive({
  data: {
    name: "",
    domain: "",
  },
});

const goBack = function () {
  $router.replace(`/o/${organizations.value[0]._id}/home`);
};

const onSubmit = async function () {
  const createOrganizationResponse = await createOrganization(
    organization.data
  );

  if (createOrganizationResponse.isOk()) {
    window.Countly.q.push(['add_event',{
      "key": "create_organization",
      "count": 1,
      segmentation: {
        name: organization.data.name,
        success: true,
      }
    }]);
    refreshOrganizations();
    $router.replace(`/o/${createOrganizationResponse.value.payload._id}/home`);
  } else {
    window.Countly.q.push(['add_event',{
      "key": "create_organization",
      "count": 1,
      segmentation: {
        name: organization.data.name,
        success: false,
      }
    }]);
    setNotification(t("organizations.CREATE_ERROR"));
  }
};
</script>
