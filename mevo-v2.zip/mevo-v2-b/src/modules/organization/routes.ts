import Create from './pages/Create.vue'

export const OrganizationRoutes = [
  {
    name: 'organization-create',
    path: '/organization-create',
    component: Create,
  },
]
