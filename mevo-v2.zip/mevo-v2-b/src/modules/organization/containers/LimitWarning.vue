<template>
  <div
    v-if="hiddenCount > 0"
    class="bg-white rounded-md p-4 flex justify-between items-center shadow"
  >
    <div class="flex items-center" v-if="type === 'home'">
      <exclamation-triangle-icon class="w-8 h-8 text-yellow-500 mr-4" />
      <div>
        <div class="font-bold">{{ $t("plan.LIMIT_REACHED") }}</div>
        <div class="text-gray-700 text-sm">
          {{ $t("plan.LIMIT_REACHED_DESCRIPTION_1") }}
          <span class="font-semibold">{{ hiddenCount }}</span>
          {{ $t("plan.LIMIT_REACHED_DESCRIPTION_2") }}
          <span v-if="!isAdmin">{{
            $t("plan.LIMIT_REACHED_DESCRIPTION_3")
          }}</span>
        </div>
      </div>
    </div>
    <div class="flex items-center" v-if="type === 'detail'">
      <exclamation-triangle-icon class="w-8 h-8 text-yellow-500 mr-4" />
      <div>
        <div class="font-bold">{{ $t("plan.LIMIT_REACHED") }}</div>
        <div class="text-gray-700 text-sm max-w-2xl">
          {{ $t("plan.LIMIT_REACHED_DESCRIPTION_1") }}
          <span class="font-semibold">{{ hiddenCount }}</span>
          {{ $t("plan.DETAIL_LIMIT_REACHED_DESCRIPTION_2") }}
          <span v-if="!isAdmin">{{
            $t("plan.LIMIT_REACHED_DESCRIPTION_3")
          }}</span>
        </div>
      </div>
    </div>
    <div>
      <m-button v-if="isAdmin" @clicked="() => setUpgradeModal(true)">{{
        $t("plan.UPGRADE_NOW")
      }}</m-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import { ExclamationTriangleIcon } from "@heroicons/vue/20/solid";
import { usePermission } from "@/composables/usePermission";
import { getHiddenCount, planChange } from "../services/OrganizationService";
import { getHiddenResponseCount } from "@/modules/bot/services/BotService";
import { NotificationType, useCommonStore } from "@/stores";
import { useRouteGlobals } from "@/composables/useRouteGlobals";
import { useOrganizations } from "@/composables/useOrganizations";
import { PlanType } from "../types/IPlan";
import { onMounted, ref, watch } from "vue";
import MButton from "@/components/basic/MButton.vue";

const props = defineProps(["type"]);
const { t } = useI18n();
const { oid, bid } = useRouteGlobals();
const { refreshOrganizations } = useOrganizations();
const { setNotification, setUpgradeModal } = useCommonStore();
const $router = useRouter();
const { isAdmin } = usePermission();
const hiddenCount = ref(0);

onMounted(async () => {
  if (props.type === "home") {
    const hiddenCountResponse = await getHiddenCount(oid.value);

    if (hiddenCountResponse.isOk()) {
      hiddenCount.value = hiddenCountResponse.value.payload;
    }
  } else {
    const hiddenCountResponse = await getHiddenResponseCount(bid.value);

    if (hiddenCountResponse.isOk()) {
      hiddenCount.value = hiddenCountResponse.value.payload;
    }
  }
});

watch(oid, async () => {
  if (props.type === "home") {
    const hiddenCountResponse = await getHiddenCount(oid.value);

    if (hiddenCountResponse.isOk()) {
      hiddenCount.value = hiddenCountResponse.value.payload;
    }
  }
});

watch(bid, async () => {
  if (props.type === "detail") {
    const hiddenCountResponse = await getHiddenResponseCount(bid.value);

    if (hiddenCountResponse.isOk()) {
      hiddenCount.value = hiddenCountResponse.value.payload;
    }
  }
});

const upgradePlan = async function () {
  const planChangeResponse = await planChange(oid.value, PlanType.PRO);

  if (planChangeResponse.isOk()) {
    if (planChangeResponse.value.payload.status !== "subscription-continued") {
      $router.push(
        `/redirect?url=${planChangeResponse.value.payload.session.url.replace(
          "#",
          "%23"
        )}`
      );
    } else {
      setNotification(
        t("plan.UPGRADED_SUCCESSFULLY"),
        NotificationType.SUCCESS
      );
    }
    refreshOrganizations();
  }
};
</script>
