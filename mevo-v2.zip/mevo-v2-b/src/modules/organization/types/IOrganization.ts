import type { IUser } from '@/modules/prelogin/types/IUser'
import type { PlanType } from './IPlan'

export enum SubscriptionType {
  MONTHLY = 'monthly',
  YEARLY = 'yearly'
}
export interface ActivePeriod {
  _id?: string
  plan: PlanType
  end: Date
  usage: number
  subscriptionType: SubscriptionType
  message_usage: number
  submission_usage: number
}

export interface IOrganization {
  _id?: string
  name: string
  domain?: string
  admins?: IUser[]
  users?: IUser[]
  listeners?: IUser[]
  plan?: PlanType
  activePeriod: ActivePeriod
  failedPaymentTry?: number
  webhookURL?: string
  apiKeySet?: boolean
  monthlyTokenUsage: number
  customDomainUsage?: number
  trainingCharacterUsage?: number
  subscriptionCancelled: boolean
  brandRemoval: boolean
  extraCharacters: boolean
  useLegacyPricing: boolean
  trainingCharacterExceeded: boolean
}
