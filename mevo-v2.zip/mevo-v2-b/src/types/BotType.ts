export enum BotType {
  GPT = 'gpt',
  SCRIPTED = 'scripted'
}
