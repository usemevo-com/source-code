export interface Session {
  _id: string
  unread: boolean
  lead: {
    email: string
    name: string
    company: string
  }
  ip: string
  firstMessage: string
  lastMessage: string
  lastCreatedAt: string
  count: number
  geo: {
    city: string
    country: string
    timezone: string
  }
  device: {
    browser: string
    os: string
  }
}
