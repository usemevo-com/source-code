export enum LinkStatus {
  ONHOLD = 'onhold',
  TRAINING = 'training',
  TRAINED = 'trained',
  NOT_ONHOLD = 'not_onhold',
  ALL = 'all'
}
