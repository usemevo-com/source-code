import { NotificationType } from './modules/bot/dtos/AddNotificationReceiverRequest'
import {
  BotBackgroundType,
  BotLayout,
  BotPosition,
  Models,
  PreviewMode,
  ShowForm
} from './modules/bot/types/IBot'

// OPTIONS
export const layoutOptions = [
  {
    id: 1,
    title: 'builder.LAYOUT_LEFT',
    value: 'chat-left',
    description: ''
  },
  {
    id: 2,
    title: 'builder.LAYOUT_MIDDLE',
    value: 'chat-middle',
    description: ''
  },
  {
    id: 3,
    title: 'builder.LAYOUT_RIGHT',
    value: 'chat-right',
    description: ''
  }
]
export const showAfterSecondsOptions = [
  {
    id: 1,
    label: 'Do not toggle automatically',
    value: 0,
    description: ''
  },
  {
    id: 2,
    label: 'After a second',
    value: 1,
    description: ''
  },
  {
    id: 3,
    label: 'After three seconds',
    value: 3,
    description: ''
  },
  {
    id: 4,
    label: 'After five seconds',
    value: 5,
    description: ''
  },
  {
    id: 5,
    label: 'After ten seconds',
    value: 10,
    description: ''
  }
]
export const previewOptionsForSelect = [
  {
    label: 'Page',
    value: PreviewMode.PAGE,
    description: 'Use your chatbot as standalone shareable webpage'
  },
  {
    label: 'Popup',
    value: PreviewMode.POPUP,
    description: 'Use your chatbot as openable popup on your website'
  },
  {
    label: 'Iframe',
    value: PreviewMode.IFRAME,
    description: 'Use your chatbot as iframe on your website like native widget'
  }
]
export const openerPositionOptionsForSelect = [
  {
    label: 'Bottom Right',
    value: BotPosition.BOTTOM_RIGHT
  },
  {
    label: 'Bottom Left',
    value: BotPosition.BOTTOM_LEFT
  }
]
export const openerIcons = ['message', 'comments', 'message-bot', 'seal-question', 'message-smile']
export const hideBrandingOptions = [
  { label: 'Hide mevo branding from the widget', value: true },
  { label: 'Keep mevo branding on the widget', value: false }
]
export const skipWelcomeOptions = [
  { label: 'Show welcome view before chat', value: false },
  { label: 'Skip welcome view', value: true }
]
export const notificationTypeOptions = [
  { label: 'Email notification', value: NotificationType.EMAIL },
  { label: 'Webhook notification', value: NotificationType.WEBHOOK }
]
export const leadCaptureOptions = [
  { label: 'No need to capture leads', value: ShowForm.NONE },
  { label: 'Show email input after the user has sent the first message', value: ShowForm.IN_CHAT },
  { label: 'Do not allow to start chat without email', value: ShowForm.BEFORE_CHAT }
]
export const themeColorOptions = [
  {
    label: 'Gray',
    value: 'gray'
  },
  {
    label: 'Blue',
    value: 'blue'
  },
  {
    label: 'Yellow',
    value: 'yellow'
  },
  {
    label: 'Pink',
    value: 'pink'
  },
  {
    label: 'Purple',
    value: 'purple'
  },
  {
    label: 'Green',
    value: 'green'
  },
  {
    label: 'Indigo',
    value: 'indigo'
  },
  {
    label: 'Red',
    value: 'red'
  }
  // {
  //   label: 'Hex code',
  //   value: 'hex'
  // }
]
export const modelOptionsForSelect = [
  {
    label: 'gpt-3.5-turbo-1106 ~ deprecated',
    value: Models.GPT_3_5_TURBO_1106
  },
  { label: 'gpt-4o ~ 16 credits per message', value: Models.GPT_4_O },
  { label: 'gpt-4-turbo ~ 45 credits per message', value: Models.GPT_4_TURBO },
  { label: 'gpt-4o-mini ~ 1 credit per message', value: Models.GPT_4_O_MINI }
]

export const legacyModelOptionsForSelect = [
  {
    label: 'gpt-3.5-turbo-1106',
    value: Models.GPT_3_5_TURBO_1106
  },
  { label: 'gpt-4o', value: Models.GPT_4_O },
  { label: 'gpt-4-turbo', value: Models.GPT_4_TURBO },
  { label: 'gpt-4o-mini', value: Models.GPT_4_O_MINI }
]
export const layoutOptionsForSelect = [
  {
    label: 'Chat on the left',
    value: BotLayout.CHAT_LEFT
  },
  {
    label: 'Chat on the middle',
    value: BotLayout.CHAT_MIDDLE
  },
  {
    label: 'Chat on the right',
    value: BotLayout.CHAT_RIGHT
  }
]
export const backgroundTypeOptions = [
  {
    label: 'Color',
    value: BotBackgroundType.COLOR
  },
  {
    label: 'Image',
    value: BotBackgroundType.IMAGE
  }
]
export const backgroundOptions = [
  {
    id: 1,
    title: 'Background 1',
    value: 'background-1.png'
  },
  {
    id: 2,
    title: 'Background 2',
    value: 'background-2.png'
  },
  {
    id: 3,
    title: 'Background 3',
    value: 'background-3.png'
  },
  {
    id: 4,
    title: 'Background 4',
    value: 'background-4.png'
  },
  {
    id: 5,
    title: 'Background 5',
    value: 'background-5.png'
  },
  {
    id: 6,
    title: 'Background 6',
    value: 'background-6.png'
  },
  {
    id: 7,
    title: 'Background 7',
    value: 'background-7.png'
  },
  {
    id: 8,
    title: 'Background 8',
    value: 'background-8.png'
  },
  {
    id: 9,
    title: 'Background 9',
    value: 'background-9.png'
  },
  {
    id: 10,
    title: 'Background 10',
    value: 'background-10.png'
  },
  {
    id: 11,
    title: 'Background 11',
    value: 'background-11.jpg'
  },
  {
    id: 12,
    title: 'Background 12',
    value: 'background-12.jpg'
  },
  {
    id: 13,
    title: 'Background 13',
    value: 'background-13.jpg'
  },
  {
    id: 14,
    title: 'Background 14',
    value: 'background-14.png'
  },
  {
    id: 15,
    title: 'Background 15',
    value: 'background-15.png'
  },
  {
    id: 16,
    title: 'Background 16',
    value: 'background-16.png'
  },
  {
    id: 17,
    title: 'Background 17',
    value: 'background-17.jpg'
  },
  {
    id: 18,
    title: 'Background 18',
    value: 'background-18.jpg'
  },
  {
    id: 19,
    title: 'Background 19',
    value: 'background-19.jpg'
  },
  {
    id: 20,
    title: 'Background 20',
    value: 'background-20.jpg'
  }
]
export const colorOptions = [
  { name: 'Blue', bgColor: 'blue', selectedColor: 'ring-blue-500' },
  { name: 'Pink', bgColor: 'pink', selectedColor: 'ring-pink-500' },
  { name: 'Purple', bgColor: 'purple', selectedColor: 'ring-purple-500' },
  { name: 'Green', bgColor: 'green', selectedColor: 'ring-green-500' },
  { name: 'Yellow', bgColor: 'yellow', selectedColor: 'ring-yellow-500' },
  { name: 'Slate', bgColor: 'slate', selectedColor: 'ring-slate-500' }
]

export const genericOptions = {
  brandName: 'mevo',
  brandLogoUrl: 'https://cdn.usemevo.com/assets/images/mevo.png',
  prodDomain: 'app.usemevo.com',
  countlyServerUrl: 'https://stats.usemevo.com',
  countlyProdAppKey: 'be28bc524510e2d041ec25e956e12c20dafd867c',
  countlyLocalAppKey: 'c4f2e2e2a3b3a3b3a3b3a3b3a3b3a3b3a3b3a3b3',
  mixpanelProdToken: 'c9cd6c0395a83605e98134198daafa21',
  mixpanelLocalToken: '16a3862317289a2097a65845a3118a07',
  itemsPerPage: 10
}
export enum BotTemplate {
  SAAS = 'saas'
}
export const botTemplates = {
  saas: {
    prompt: {
      systemMessage: 'Be kind and try to get email address from user.',
      initialMessage: ''
    },
    represented: 'Mevo',
    firstMessage: 'Hello there 👋',
    fallbackMessage: "I'm not sure about it. If you leave your email, I'll get back to you.",
    model: Models.GPT_3_5_TURBO,
    withHistory: 0,
    showPredefinedQuestions: true,
    feed: [
      {
        type: 'PRODUCT_SERVICES',
        data: [
          {
            name: 'SuperSaaS Free',
            price: 'Free',
            description: "It's our free plan which contain 100 blog post limit monthly."
          },
          {
            name: 'SuperSaaS Pro',
            price: '$20/month',
            description:
              "It's Pro plan for individual creators, comes with 10000 posts monthly and white labeling support."
          },
          {
            name: 'SuperSaaS XL',
            price: '$1000',
            description:
              'Our bigger plan for those need more than ever. Comes with 250000 posts limits monthly, premium level customer support and more.'
          }
        ]
      },
      {
        type: 'GENERAL',
        data: [
          {
            q: 'Do you have free trial?',
            a: "We don't have a free trial but we have a free plan; SuperSaaS Free."
          },
          {
            q: "What's your refund policy?",
            a: 'You can refund in 15 days without any questions.'
          }
        ]
      }
    ],
    embeddings: {
      rawText: '',
      values: [],
      refs: []
    },
    fileSources: [],
    domainSources: [],
    useAssistantAPI: false,
    assistantID: ''
  }
}
