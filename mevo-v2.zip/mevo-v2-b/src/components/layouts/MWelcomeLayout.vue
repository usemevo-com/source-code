<template>
  <div class="flex h-screen w-screen relative">
    <div class="h-screen flex flex-col justify-center items-center w-full sm:w-1/2 p-8 sm:p-0">
      <!-- <div class="text-5xl font-bold absolute top-8 left-[%50]" >mevo</div> -->
      <div class="flex flex-col w-full max-w-sm space-y-2 items-start">
        <img src="/mevo.png" alt="logo" class="h-32 mb-8 -ml-1" />
        <h1 class="text-3xl font-bold leading-tight">
          {{ title }}
        </h1>
        <p v-if="description" class="max-w-[750px] text-lg text-muted-foreground sm:text-lg">
          {{ description }}
        </p>
      </div>
      <div class="max-w-sm w-full mt-8">
        <slot />
      </div>
    </div>
    <div class="relative hidden sm:flex sm:w-1/2 h-screen bg-[url('/mevo-background.png')] bg-cover bg-top flex-col items-center">
      <div class="absolute top-16 px-16">
          <div class="text-white text-center text-2xl font-bold antialiased">
            Our chatbots drive results
          </div>
          <div class="text-white text-center antialiased">
            Visitors engage faster, ask more, and convert better when there’s a smart chatbot guiding them from the first second.
          </div>
      </div>
      <img src="/chatbot_preview.png" class="w-[400px] rounded-t-lg shadow absolute bottom-0 right-[calc(50%_-_200px)]" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue';

defineProps<{
  title: string
  description: string
}>()

const reviews = [
  {
    img: 'https://usemevo.com/user_avatar_3.png',
    name: 'Paul Franklin',
    company: 'Webx Solutions',
    review: '“I\'ve explored various AI chatbot messaging systems, and none of them quite met the mark until Mevo. It stands out as the best by a significant margin.”',
  },
  {
    img: 'https://usemevo.com/user_avatar_4.png',
    name: 'Tino Umo',
    company: 'Searchgage Media, LLC',
    review: '“This is, for me, one of the best AI tools I\'ve bought. As an agency owner, this will allow me to demonstrate and share AI-generated bots with prospective clients. If I were you, I would buy without hesitation.”',
  },{
    img: 'https://usemevo.com/user_avatar_1.png',
    name: 'Nikki Brown',
    company: 'A happy Mevo user',
    review: '“I was looking for a way to create chatbots that I could use for different aspects of my business. I don\'t have much experience with creating GPTs or training chatbots, so I was concerned that it would be too complicated. I was pleasantly surprised at how user friendly Mevo is.”',
  }, {
    img: 'https://usemevo.com/user_avatar_2.png',
    name: 'Hirbis Girolli',
    company: 'Finantor',
    review: '“I echo the positive reviews of Mevo and its development team that I\'ve read here! I\'ve also been keeping an eye on offerings from similar platforms in recent months, and I haven\'t found anything this good and promising and the roadmap for this and other features makes Mevo what seems like a unique solution at present.”',
  }
]

const randomReviewIndex = Math.floor(Math.random() * reviews.length)
</script>
