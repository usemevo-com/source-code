<template>
    <div class="flex w-screen h-screen overflow-x-hidden relative">
        <router-link v-if="is_logged_in" :to="`/o/${oid}/home`">
            <img src="/mevo.png" alt="logo" class="hidden sm:block h-16 w-16 absolute top-[30px] left-10" />
        </router-link>
        <router-link v-else :to="`/get-started`">
            <img src="/mevo.png" alt="logo" class="hidden sm:block h-16 w-16 absolute top-[30px] left-10" />
        </router-link>
        <!-- <BrandAnimation @click="() => toggleAnimation" :infinite="isAnimationActive" class="cursor-pointer absolute top-[54px] left-10 h-[60px] w-[60px]" /> -->
        <div v-if="$route.name !== 'finalize-setup'" class="z-[9] w-full absolute top-0 left-0 bg-gray-100 h-1">
            <div class="bg-mevo h-1" :style="{ width: `${percentageMap[route.name as keyof typeof percentageMap]}%` }">
            </div>
        </div>
        <Motion
            :initial="{ opacity: 0, y: -15 }"
            :animate="{ opacity: 1, y: 0 }"
            :transition="{ duration: 0.25 }"
            :class="[isRightSideActive ? 'sm:w-1/2 w-full' : 'w-full']"
        >
            
            <div class="flex flex-col items-center justify-center w-full px-8 py-[52px]">
                <div :class="[isRightSideActive ? 'max-w-md' : 'max-w-xl']" class="w-full h-[calc(100vh-104px)] flex flex-col justify-between">
                    <div class="col-span-2 flex justify-between items-center">
                        <div class="flex flex-col items-start gap-1">
                            <div v-if="$route.name !== 'finalize-setup'" class="text-sm">Step {{ activeStep }} of {{ totalSteps }}</div>
                            <div class="text-xl font-bold">{{ titleMap[route.name as keyof typeof titleMap] }}</div>
                            <div class="antialiased text-sm text-gray-500">{{ subtitleMap[route.name as keyof typeof subtitleMap] }}</div>
                        </div>
                    </div>
                    <slot />
                </div>
            </div>
        </Motion>
        <Motion
            :initial="{ opacity: 0, x: 100 }"
            :animate="{ opacity: 1, x: 0 }"
            :transition="{ duration: 0.5 }"
            v-if="showRightSide"
            class="sm:w-1/2 sm:block hidden"
        >
            <div class="flex-1 bg-mevo-light h-full flex items-center justify-center">
                <slot name="right" />
            </div>
        </Motion>
    </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { verify } from '@/modules/prelogin/services/UserService'

const route = useRoute()
const isRightSideActive = computed(() => route.name === 'set-up-account')
const showRightSide = ref(false)

const is_logged_in = ref(false)
const auth_user = ref({})
const oid = ref('')

// Yarım saniye gecikme ile sağ tarafı göster
watch(isRightSideActive, (newValue) => {
    if (newValue) {
        showRightSide.value = false
        setTimeout(() => {
            showRightSide.value = true
        }, 500)
    } else {
        showRightSide.value = false
    }
}, { immediate: true })

const percentageMap = computed(() => ({
    'get-started': is_logged_in.value ? 33 : 20,
    'choose-pages': is_logged_in.value ? 100 : 60,
    'set-up-account': is_logged_in.value ? 100 : 80,
    'set-branding': is_logged_in.value ? 66 : 40,
    'finalize-setup': is_logged_in.value ? 100 : 100,
}))

const titleMap = computed(() => {
    if (is_logged_in.value) {
        return {
            'get-started': 'Get started',
            'set-branding': 'Make it yours',
            'choose-pages': 'Choose pages',
            'finalize-setup': 'Set your workspace up',
        }
    }
    return {
        'get-started': 'Get started',
        'set-branding': 'Make it yours',
        'choose-pages': 'Choose pages',
        'set-up-account': 'Set up account',
        'finalize-setup': 'Set your workspace up',
    }
})

const subtitleMap = computed(() => {
    if (is_logged_in.value) {
        return {
            'get-started': 'Choose a template to start',
            'set-branding': 'Let your chatbot know about your brand and business',
            'choose-pages': 'Decide which pages will be used for training',
            'finalize-setup': 'You can invite your team members to this workspace after setting it up.',
        }
    }
    return {
        'get-started': 'Choose a template to start',
        'set-branding': 'Let your chatbot know about your brand and business',
        'choose-pages': 'Decide which pages will be used for training',
        'set-up-account': 'Complete setup by linking this chatbot to your account',
        'finalize-setup': 'You can invite your team members to this workspace after setting it up.',
    }
})

const activeStep = computed(() => {
    return Object.keys(titleMap.value).indexOf(route.name as string) + 1
})

const totalSteps = computed(() => {
    return Object.keys(titleMap.value).length
})

onMounted(async () => {
    const verify_response = await verify()

    if (verify_response.isOk()) {
        is_logged_in.value = true;
        auth_user.value = verify_response.value.payload;
        oid.value = localStorage.getItem('mevo:oid') || '';
    } else {
        is_logged_in.value = false;
    }
})
</script>