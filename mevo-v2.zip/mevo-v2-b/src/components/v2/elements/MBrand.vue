<template>
  <div class="flex items-center">
    <div class="flex items-center text-indigo-500 font-bold text-[24px]">
      <BrandAnimation class="h-12 w-fit" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { genericOptions } from '@/constants'
import { useSubscription } from '@/composables/useSubscription'
import { PlanType } from '@/modules/organization/types/IPlan'
import BrandAnimation from '@/components/basic/BrandAnimation.vue'

export interface MBrandProps {
  variant: string
  showBadge?: boolean
}

withDefaults(defineProps<MBrandProps>(), {
  variant: 'navbar',
  showBadge: false
})

const { activePlan } = useSubscription()

// get brand name and logo from generic options
const brandName = ref(genericOptions.brandName)
const brandLogoUrl = ref(genericOptions.brandLogoUrl)
</script>
