<template>
  <Menu as="div" class="relative inline-block text-left">
    <MenuButton
      :class="[!disableOpenerHover && 'hover:bg-gray-100']"
      class="py-2 text-sm flex max-w-[200px] items-center text-overflow truncate justify-end rounded-md font-medium text-gray-700 hover:text-gray-800 rounded-md"
    >
      <slot name="opener">
        <div class="flex items-center">
          <div
            class="w-fit max-w-[calc(220px_-_2rem)] overflow-hidden truncate"
          >
            {{ label }}
          </div>
          <ChevronDownIcon
            class="w-4 h-4 ml-2 text-gray-500"
            aria-hidden="true"
          /></div
      ></slot>
    </MenuButton>

    <transition
      enter-active-class="transition ease-out duration-100"
      enter-from-class="transform opacity-0 scale-95"
      enter-to-class="transform opacity-100 scale-100"
      leave-active-class="transition ease-in duration-75"
      leave-from-class="transform opacity-100 scale-100"
      leave-to-class="transform opacity-0 scale-95"
    >
      <MenuItems
        :class="[
          to === 'left' && 'left-0 origin-top-left',
          to === 'right' && 'right-0 origin-top-right',
        ]"
        class="absolute z-50 mt-2 w-56 divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
      >
        <div v-if="withFirstSection" class="px-4 py-3">
          <slot name="first-section"></slot>
        </div>

        <div class="py-1" v-for="section in sections">
          <MenuItem
            v-slot="{ active: isHovered }"
            v-for="subsection in section.subsections"
          >
            <div
              @click="() => $emits('event', subsection.eventKey)"
              :class="[
                isHovered ? 'bg-gray-50 text-gray-900' : 'text-gray-700',
                subsection.active
                  ? 'font-bold flex justify-between items-center'
                  : '',
                'block px-4 py-2 text-sm w-full truncate text-overflow cursor-pointer',
              ]"
            >
              {{ subsection.label }}
              <check-icon
                v-if="subsection.active"
                class="w-4 h-4 text-primary"
              />
            </div>
          </MenuItem>
        </div>
      </MenuItems>
    </transition>
  </Menu>
</template>

<script lang="ts" setup>
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/vue";
import { ChevronDownIcon, CheckIcon } from "@heroicons/vue/24/outline";

export interface MDropdownProps {
  to: string;
  label?: string;
  sections: {
    subsections: { label: string; eventKey: string; active?: boolean }[];
  }[];
  disableOpenerHover?: boolean;
  withFirstSection?: boolean;
}

withDefaults(defineProps<MDropdownProps>(), {
  to: "left",
  label: "Not specified",
  disableOpenerHover: false,
  withFirstSection: false,
});

const $emits = defineEmits(["event"]);
</script>
