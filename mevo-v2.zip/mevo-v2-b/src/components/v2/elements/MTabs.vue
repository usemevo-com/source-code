<template>
  <div>
    <div class="mt-8">
      <div class="border-b border-gray-200">
        <nav class="-mb-px flex space-x-8" aria-label="Tabs">
          <a
            v-for="tab in tabs"
            :key="tab.name"
            href="javascript:void(0)"
            @click="$emits('switch', tab.key)"
            :class="[
              tab.current
                ? 'border-black text-black'
                : 'border-transparent text-gray-500 hover:border-gray-200 hover:text-gray-700',
              'flex whitespace-nowrap border-b-2 py-2 px-1 text-sm font-medium',
            ]"
            :aria-current="tab.current ? 'page' : undefined"
          >
            {{ tab.name }}
            <span
              v-if="tab.count"
              :class="[
                tab.current
                  ? 'bg-black text-white'
                  : 'bg-gray-100 text-gray-900',
                'ml-3 hidden rounded-full py-0.5 px-2.5 text-xs font-medium md:inline-block',
              ]"
              >{{ tab.count }}</span
            >
          </a>
        </nav>
      </div>
    </div>
    <div v-for="tab in tabs" :class="[!tab.current && 'hidden']">
      <slot :name="tab.key"></slot>
    </div>
  </div>
</template>

<script setup lang="ts">
export interface TabProps {
  tabs: {
    key: string;
    name: string;
    current: boolean;
    count?: number;
  }[];
}

const props = defineProps<TabProps>();
const $emits = defineEmits(["switch"]);
</script>
