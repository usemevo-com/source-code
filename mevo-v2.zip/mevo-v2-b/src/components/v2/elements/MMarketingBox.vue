<template>
  <div
    v-if="!isHidden"
    class="col-span-12 rounded-md p-5 flex-col space-y-8 border border-primary-gray"
    :class="[
      variant === 'white' && 'bg-white',
      variant === 'standard' && 'bg-primary-light',
      size === '1' && 'sm:col-span-4',
      size === '2' && 'sm:col-span-8',
      size === '3' && 'sm:col-span-12 !space-y-2',
    ]"
  >
    <div class="flex justify-between">
      <div class="font-bold">{{ title }}</div>
      <div @click="onClose" class="cursor-pointer" v-if="closable">
        <x-mark-icon class="w-4 h-4 text-gray" />
      </div>
    </div>

    <div class="font-medium text-sm">{{ description }}</div>
    <m-button @click="$emits('action')" type="link">
      {{ actionButtonText }}
      <arrow-right-icon
        v-if="icon === 'arrow'"
        class="w-4 h-4 text-primary ml-2 group-hover:translate-x-1 transition"
      />
      <play-circle-icon
        v-if="icon === 'play'"
        class="w-4 h-4 text-primary ml-2 group-hover:translate-x-1 transition"
      />
      <bolt-icon v-if="icon === 'bolt'" class="w-4 h-4 text-primary ml-2" />
    </m-button>
  </div>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import {
  XMarkIcon,
  ArrowRightIcon,
  BoltIcon,
  PlayCircleIcon,
} from "@heroicons/vue/24/outline";
import MButton from "./MButton.vue";

export interface MMarketingBoxProps {
  title: string;
  description: string;
  actionButtonText: string;
  variant: "white" | "standard";
  icon: "arrow" | "play" | "bolt";
  size: "1" | "2" | "3";
  closable: boolean;
}

withDefaults(defineProps<MMarketingBoxProps>(), {
  icon: "arrow",
});
const $emits = defineEmits(["action", "close"]);

const isHidden = ref(false);

const onClose = () => {
  isHidden.value = true;
  $emits("close");
};
</script>
