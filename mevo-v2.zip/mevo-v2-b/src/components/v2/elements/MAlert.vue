<!-- :class="[hoverEffect && 'hover:-translate-y-1 transition']" -->
<template>
  <div
    :class="[
      type === 'warning' && 'bg-yellow-50',
      type === 'danger' && 'bg-red-50',
      type === 'success' && 'bg-green-50',
      type === 'information' && 'bg-blue-50',
    ]"
    class="rounded-md p-4 shadow-sm"
  >
    <div class="flex">
      <div
        :class="[
          type === 'warning' && 'text-yellow-400',
          type === 'danger' && 'text-red-400',
          type === 'success' && 'text-green-400',
          type === 'information' && 'text-blue-400',
        ]"
        class="flex-shrink-0"
      >
        <i
          v-if="!showLoading && (type === 'warning' || type === 'danger')"
          class="fa fa-sharp fa-exclamation-circle"
        ></i>
        <i
          v-if="!showLoading && type === 'success'"
          class="fa fa-sharp fa-circle-check"
        ></i>
        <i
          v-if="!showLoading && type === 'information'"
          class="fa fa-sharp fa-circle-info"
        ></i>
        <i
          v-if="showLoading"
          class="animate-spin fa-sharp fa-spinner-third"
        ></i>
      </div>
      <div class="ml-3">
        <h3
          :class="[
            type === 'warning' && 'text-yellow-800',
            type === 'danger' && 'text-red-800',
            type === 'success' && 'text-green-800',
            type === 'information' && 'text-blue-800',
          ]"
          class="text-sm font-medium"
        >
          {{ title }}
        </h3>
        <div
          :class="[
            type === 'warning' && 'text-yellow-700',
            type === 'danger' && 'text-red-700',
            type === 'success' && 'text-green-700',
            type === 'information' && 'text-blue-700',
          ]"
          class="mt-2 text-sm"
        >
          <p>
            {{ text }}
          </p>
        </div>
        <div v-if="hasButton" class="mt-4">
          <div class="-mx-2 -my-1.5 flex">
            <button
              :class="[
                type === 'warning' &&
                  'bg-yellow-50 text-yellow-800 hover:bg-yellow-100 focus:ring-yellow-600 focus:ring-offset-yellow-50',
                type === 'danger' &&
                  'bg-red-50 text-red-800 hover:bg-red-100 focus:ring-red-600 focus:ring-offset-red-50',
                type === 'success' &&
                  'bg-green-50 text-green-800 hover:bg-green-100 focus:ring-green-600 focus:ring-offset-green-50',
                type === 'information' &&
                  'bg-blue-50 text-blue-800 hover:bg-blue-100 focus:ring-blue-600 focus:ring-offset-blue-50',
              ]"
              @click="$emit('clicked')"
              type="button"
              class="rounded-md px-2 py-1.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-offset-2"
            >
              {{ buttonText }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
export interface MAlertProps {
  type: "warning" | "danger" | "success" | "information";
  title: string;
  text: string;
  buttonText?: string;
  hasButton?: boolean;
  showLoading?: boolean;
}

withDefaults(defineProps<MAlertProps>(), {
  type: "warning",
  title: "",
  text: "",
  buttonText: "Do something",
  hasButton: false,
  showLoading: false,
});

const $emit = defineEmits(["clicked"]);
</script>
