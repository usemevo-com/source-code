<template>
  <Card class="bg-white p-4 border-b shadow rounded-lg w-full overflow-y-auto">
    <CardContent
      :class="[isHorizontal && 'flex-row items-center', !isHorizontal && 'flex-col']"
      class="flex justify-between pb-0 py-6"
    >
      <div class="flex justify-between">
        <m-headline :title="title" :description="description" />
        <slot name="header-right"></slot>
      </div>

      <div :class="[!isHorizontal && 'mt-8']">
        <slot></slot>
      </div>
      <div v-if="hasFooter" class="sm:grid sm:grid-cols-3 sm:gap-4 flex items-center">
        <slot name="footer-section"></slot>
      </div>
    </CardContent>
  </Card>
</template>

<script lang="ts" setup>
import { Card, CardContent } from '@/components/ui/card'
import MHeadline from '@/components/basic/MHeadline.vue'

export interface ISettingsSectionProps {
  title: string
  description: string
  isHorizontal?: boolean
  hasFooter?: boolean
}

withDefaults(defineProps<ISettingsSectionProps>(), {
  isHorizontal: false,
  hasFooter: true
})
</script>
