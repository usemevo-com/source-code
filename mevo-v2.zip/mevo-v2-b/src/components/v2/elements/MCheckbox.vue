<template>
  <fieldset>
    <div class="space-y-5 cursor-pointer" @click="onClicked">
      <div
        class="relative flex justify-end"
        :class="[justifyBetween && 'justify-between']"
      >
        <div class="flex h-6 items-center">
          <input
            :disabled="disabled"
            v-model="model"
            :id="key"
            :aria-describedby="`${key}-description`"
            :name="key"
            type="checkbox"
            class="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary-hover"
            :class="[disabled && 'cursor-not-allowed']"
          />
        </div>
        <div v-if="label" class="ml-3 text-sm leading-6">
          <label :for="key" class="font-medium text-gray-900 cursor-pointer">{{
            label
          }}</label>
          <p id="comments-description" class="text-gray-500">
            {{ description }}
          </p>
        </div>
      </div>
    </div>
  </fieldset>
</template>

<script lang="ts" setup>
import { computed } from "vue";

export interface MCheckboxProps {
  key?: string;
  label?: string;
  description?: string;
  modelValue: boolean;
  justifyBetween?: boolean;
  disabled?: boolean;
}

const props = withDefaults(defineProps<MCheckboxProps>(), {});
const $emits = defineEmits(["update:modelValue"]);

const model = computed({
  get: () => props.modelValue,
  set: (value: boolean) => {
    $emits("update:modelValue", value);
  },
});

const onClicked = () => {
  model.value = !model.value;
};
</script>
