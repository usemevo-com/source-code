<template>
  <div>
    <label class="text-base font-semibold text-gray-900">{{ label }}</label>
    <p class="text-sm text-gray-500">
      {{ description }}
    </p>
    <fieldset class="mt-2">
      <legend class="sr-only">{{ description }}</legend>
      <div class="space-y-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-10">
        <div
          v-for="(option, index) in options"
          :key="option.value"
          class="flex items-center"
        >
          <input
            type="radio"
            :id="option.value"
            :data-val="option.value"
            :checked="model === option.value"
            @change="onChange"
            class="h-4 w-4 border-gray-300 text-primary focus:ring-primary-hover"
          />
          <label
            :for="option.value"
            class="ml-3 block text-sm font-medium leading-6 text-gray-900"
            >{{ $t(option.title) }}</label
          >
        </div>
      </div>
    </fieldset>
  </div>
</template>

<script lang="ts" setup>
import { computed } from "vue";

export interface MRadioGroupProps {
  label: string;
  description: string;
  modelValue: string;
  options: {
    title: string;
    value: string;
  }[];
}

const props = withDefaults(defineProps<MRadioGroupProps>(), {});
const $emits = defineEmits(["update:modelValue"]);

const model = computed(() => props.modelValue);

const onChange = (event: any) => {
  $emits("update:modelValue", event.target.dataset.val);
};
</script>
