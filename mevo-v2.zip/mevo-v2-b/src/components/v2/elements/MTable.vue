<template>
  <!-- !w-[100px] !w-[150px] !w-[200px] !w-[300px] !w-[400px] !w-[500px] -->
  <div class="mt-8 flow-root">
    <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
      <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
        <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
          <table class="min-w-full divide-y divide-gray-300">
            <thead class="bg-gray-50">
              <tr>
                <th
                  :key="index"
                  v-for="(column, index) in columns"
                  scope="col"
                  class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 capitalize"
                  :class="[column.width && `!w-[${column.width}]`]"
                >
                  {{ column.type !== 'action' ? column.label : '' }}
                </th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
              <tr v-for="(row, index) in rows" :key="index">
                <td
                  :key="colIndex"
                  v-for="(column, colIndex) in columns"
                  class="text-ellipsis overflow-hidden pl-6 py-4 text-sm text-gray-500"
                  :class="[
                    column.type === 'action' &&
                      'font-medium hover:text-gray-500 hover:underline text-gray-700 cursor-pointer',
                    column.width && column.width !== 'fill' ? `!w-[${column.width}]` : 'flex-1'
                  ]"
                >
                  <Badge v-if="column.type === 'badge'" :variant="row[column.key] === 'failed' ? 'destructive' : 'default'">
                    {{ row[column.key] }}
                  </Badge>
                  <div @click="onAction(row._id, column.key)" v-else-if="column.type === 'action'">
                    {{ column.label }}
                  </div>
                  <div v-else-if="column.type === 'url'">
                    <a :href="row[column.key]" target="_blank" class="text-primary underline">
                      {{ row[column.key] }} <i class="fa fa-external-link-alt"></i>
                    </a>
                  </div>
                  <div v-else-if="column.type === 'boolean'">
                    <i class="fa-solid fa-circle-check text-primary" v-if="row[column.key]" />
                    <i class="fa-solid fa-circle-x text-primary" v-else />
                  </div>
                  <div
                    v-else-if="column.type === 'long_content'"
                    :title="row[column.key]"
                    class="cursor-pointer"
                  >
                    {{ row[column.key].substr(0, 100) }} ...
                  </div>
                  <div v-else-if="column.type === 'JSON'" class="cursor-pointer">
                    <pre class="mt-4"
                      >{{ JSON.stringify(row[column.key], null, 2) }}
                    </pre>
                  </div>
                  <div v-else>{{ row[column.key] }}</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <div class="w-full flex justify-between py-4 items-center">
    <div class="text-sm text-gray-500">
      Showing <strong>{{ from }}</strong> to <strong>{{ rows.length }}</strong> of
      <strong>{{ totalRecords }}</strong> entries
    </div>
    <Pagination
      v-model:page="activePage"
      v-slot="{ page }"
      :total="totalRecords"
      :items-per-page="itemsPerPage"
      :default-page="1"
      :show-edges="false"
    >
      <PaginationList v-slot="{ items }" class="flex items-center gap-1">
        <PaginationFirst />
        <PaginationPrev />
        <template v-for="(link, index) in items">
          <PaginationListItem v-if="link.type === 'page'" :key="index" :value="link.value" as-child>
            <Button
              size="sm"
              class="w-10 h-10 p-0"
              :variant="link.value === page ? 'default' : 'outline'"
            >
              {{ link.value }}
            </Button>
          </PaginationListItem>
          <PaginationEllipsis v-else :key="link.type" :index="index" />
        </template>
        <PaginationNext />
        <PaginationLast />
      </PaginationList>
    </Pagination>
  </div>
</template>

<script lang="ts" setup>
import { defineProps, ref, watch, computed } from 'vue'
import {
  Pagination,
  PaginationList,
  PaginationListItem,
  PaginationFirst,
  PaginationPrev,
  PaginationNext,
  PaginationLast,
  PaginationEllipsis
} from '@/components/ui/pagination'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

// props
export interface MTableProps {
  columns: {
    key: string
    label: string
    width: string
    type: 'action' | 'badge' | 'url' | 'boolean' | 'long_content' | 'JSON'
  }[]
  rows: Record<string, any>[]
  totalRecords: number
  itemsPerPage: number
  currentPage: number
}

const props = defineProps<MTableProps>()

// state
const activePage = ref(props.currentPage)

// emits
const $emit = defineEmits(['change', 'action'])

// computed
const from = computed(() => (activePage.value - 1) * props.itemsPerPage + 1)

const onAction = (_id: string, key: string) => {
  console.log('action', _id, key)
  $emit('action', { _id, key })
}

watch(activePage, () => {
  $emit('change', activePage.value)
})
</script>
