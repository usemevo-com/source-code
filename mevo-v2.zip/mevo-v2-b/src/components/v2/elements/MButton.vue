<template>
  <button
    v-bind="$attrs"
    :disabled="disabled || loading"
    @click="onClick"
    :class="{
      'rounded-md text-white bg-primary hover:bg-primary-hover':
        type === 'primary',
      'rounded-md text-primary bg-secondary hover:bg-secondary-hover hover:text-white':
        type === 'secondary',
      'rounded-md text-gray-700 border bg-gray-50 hover:bg-white hover:text-indigo-500':
        type === 'white',
      'rounded-md text-white bg-danger hover:bg-danger-hover':
        type === 'danger',
      'rounded-md text-danger bg-danger-secondary hover:danger-secondary-hover':
        type === 'danger-light',
      'rounded-md text-primary': type === 'link',
      'cursor-not-allowed opacity-50': disabled,
      'px-3 py-2': type !== 'link',
      'py-3 px-6 text-xl !font-bold': big,
    }"
    class="inline-flex items-center justify-center rounded-md text-sm font-medium focus:outline-none"
  >
    <slot></slot>
    <div v-if="loading">
      <i
        class="animate-spin text-white fa-sharp fa-light fa-spinner-third ml-2"
      ></i>
    </div>
  </button>
</template>

<script setup lang="ts">
export interface MButtonProps {
  type:
    | "primary"
    | "secondary"
    | "white"
    | "danger"
    | "danger-light"
    | "link"
    | "custom";
  disabled?: boolean;
  big?: boolean;
  loading?: boolean;
}

withDefaults(defineProps<MButtonProps>(), {
  label: "Not specified",
  type: "primary",
  disabled: false,
  big: false,
  loading: false,
});
const $emits = defineEmits(["clicked"]);

const onClick = (e: Event) => {
  $emits("clicked");
};
</script>
