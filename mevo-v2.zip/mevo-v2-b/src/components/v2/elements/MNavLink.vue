<template>
  <div
    @click="() => handleNavigation(to)"
    class="rounded-md px-3 py-2 text-sm font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100 flex items-center cursor-pointer"
  >
    <div v-if="label">{{ label }}</div>
    <div v-else>
      <slot></slot>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useRouter } from "vue-router";
import { useRouteGlobals } from "@/composables/useRouteGlobals";

export interface MNavLinkProps {
  label?: string;
  to: string;
  root?: boolean;
}

const props = withDefaults(defineProps<MNavLinkProps>(), {
  to: "home",
  root: false,
});

const { oid } = useRouteGlobals();
const $router = useRouter();

const handleNavigation = (to: string) => {
  if (props.root) $router.push(`/${to}`);
  else $router.push(`/o/${oid.value}/${to}`);
};
</script>
