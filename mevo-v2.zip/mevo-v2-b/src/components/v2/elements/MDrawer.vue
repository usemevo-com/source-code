<template>
  <TransitionRoot as="template" :show="open">
    <Dialog as="div" class="relative z-50" @close="$emits('close')">
      <TransitionChild
        as="template"
        enter="ease-in-out duration-500"
        enter-from="opacity-0"
        enter-to="opacity-100"
        leave="ease-in-out duration-500"
        leave-from="opacity-100"
        leave-to="opacity-0"
      >
        <div
          class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
        />
      </TransitionChild>

      <div class="fixed inset-0" />

      <div class="fixed inset-0 overflow-hidden">
        <div class="absolute inset-0 overflow-hidden">
          <div
            class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10"
          >
            <TransitionChild
              as="template"
              enter="transform transition ease-in-out duration-500 sm:duration-700"
              enter-from="translate-x-full"
              enter-to="translate-x-0"
              leave="transform transition ease-in-out duration-500 sm:duration-700"
              leave-from="translate-x-0"
              leave-to="translate-x-full"
            >
              <DialogPanel
                class="pointer-events-auto w-screen max-w-2xl relative"
              >
                <div
                  class="flex h-full flex-col overflow-y-scroll bg-white py-6 shadow-xl"
                >
                  <div class="px-4 sm:px-6">
                    <div class="flex items-start justify-between">
                      <DialogTitle>
                        <m-page-header :title="title" :subtitle="subtitle" />
                      </DialogTitle>
                      <div class="ml-3 flex h-7 items-center">
                        <button
                          type="button"
                          class="rounded-md bg-white text-gray-400 hover:text-gray-500 focus:outline-none"
                          @click="$emits('close')"
                        >
                          <span class="sr-only">Close panel</span>
                          <XMarkIcon class="h-6 w-6" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </div>
                  <div
                    class="relative mt-6 flex-1 overflow-y-auto px-4 sm:px-6"
                  >
                    <div>
                      <slot></slot>
                    </div>
                    <div
                      v-if="!noButtons"
                      class="fixed bg-white w-full bottom-0 right-0 flex flex-shrink-0 justify-end p-6 max-w-2xl"
                    >
                      <m-button
                        :disabled="disabled"
                        class="ml-2"
                        @clicked="$emits('submit')"
                        type="primary"
                      >
                        {{ $t("common.SAVE") }}
                      </m-button>
                    </div>
                  </div>
                </div>
              </DialogPanel>
            </TransitionChild>
          </div>
        </div>
      </div>
    </Dialog>
  </TransitionRoot>
</template>

<script lang="ts" setup>
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  TransitionChild,
  TransitionRoot,
} from "@headlessui/vue";
import { XMarkIcon } from "@heroicons/vue/24/outline";
import MButton from "./MButton.vue";
import MPageHeader from "./MPageHeader.vue";

export interface DrawerProps {
  title: string;
  subtitle: string;
  open: boolean;
  disabled?: boolean;
  noButtons?: boolean;
}

withDefaults(defineProps<DrawerProps>(), {
  open: false,
  disabled: false,
  noButtons: false,
});

const $emits = defineEmits(["close", "submit"]);
</script>
