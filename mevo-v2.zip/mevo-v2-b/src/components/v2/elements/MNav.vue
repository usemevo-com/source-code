<template>
  <div class="bg-white w-[50px] h-screen border-r fixed">
    <TooltipProvider>
      <div class="flex flex-col h-screen justify-between">
        <div class="px-2">
          <!-- <img src="/mevo.png" alt="Mevo" class="w-8 my-8 mx-auto" /> -->
          <Nav :links="navbarLinks" is-collapsed />
        </div>
        <div class="flex flex-col justify-center items-center px-2 pb-4 space-y-2">
          <!-- <Tooltip :delay-duration="0">
            <TooltipTrigger as-child>
              <span
                :class="
                  cn(
                    buttonVariants({ variant: 'ghost', size: 'icon' }),
                    'h-9 w-9 cursor-pointer mevo-ideas'
                  )
                "
              >
                <i :class="`fa-regular fa-message-smile `"></i>
              </span>
            </TooltipTrigger>
            <TooltipContent side="right" class="flex items-center gap-4">
              Suggest a feature
            </TooltipContent>
          </Tooltip>
          <Tooltip :delay-duration="0">
            <TooltipTrigger as-child>
              <span
                :class="
                  cn(
                    buttonVariants({ variant: 'ghost', size: 'icon' }),
                    'h-9 w-9 cursor-pointer mevo-announcements'
                  )
                "
              >
                <i :class="`fa-regular fa-megaphone `"></i>
              </span>
            </TooltipTrigger>
            <TooltipContent side="right" class="flex items-center gap-4">
              Product updates
            </TooltipContent>
          </Tooltip> -->
          <Tooltip :delay-duration="0">
            <TooltipTrigger @click="isOrganizationsDrawerOpen = true" as-child>
              <span
                :class="
                  cn(buttonVariants({ variant: 'ghost', size: 'icon' }), 'h-9 w-9 cursor-pointer')
                "
              >
                <i :class="`fa-regular fa-folders `"></i>
              </span>
            </TooltipTrigger>
            <TooltipContent side="right" class="flex items-center gap-4">
              Switch workspace
            </TooltipContent>
          </Tooltip>
          <UserDropdown />
        </div>
      </div>
    </TooltipProvider>
  </div>
  <organizations-drawer
    :no-buttons="true"
    @close="isOrganizationsDrawerOpen = false"
    :open="isOrganizationsDrawerOpen"
  />
</template>

<script lang="ts" setup>
import { computed, ref } from 'vue'
import { cn } from '@/lib/utils'
import { useRouteGlobals } from '@/composables/useRouteGlobals'
import { buttonVariants } from '@/components/ui/button'
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip'
import Nav, { type LinkProp } from '@/components/v2/partials/Nav.vue'
import UserDropdown from '@/components/v2/partials/UserDropdown.vue'
import OrganizationsDrawer from '@/modules/common/containers/OrganizationsDrawer.vue'

const { oid } = useRouteGlobals()
const isOrganizationsDrawerOpen = ref(false)

const navbarLinks: LinkProp[] = computed(() => [
  {
    title: 'Home',
    icon: 'house',
    variant: 'ghost',
    to: `/o/${oid.value}/home`
  },
  {
    title: 'Settings',
    icon: 'gear',
    variant: 'ghost',
    to: `/o/${oid.value}/settings/account`
  },
  {
    title: 'Invite teammate',
    icon: 'user-plus',
    variant: 'ghost',
    to: `/o/${oid.value}/settings/team`
  }
])
</script>