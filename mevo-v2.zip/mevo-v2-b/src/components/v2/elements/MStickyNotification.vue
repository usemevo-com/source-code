<template>
  <div
    :class="typeToClassMap[type]"
    class="z-50 top-0 left-0 w-[100vw] py-4 text-white text-center flex items-center justify-center font-medium"
  >
    {{ text }}
  </div>
</template>

<script lang="ts" setup>
export interface MStickyNotificationProps {
  text: string;
  type: "success" | "error" | "warning" | "info";
}

const typeToClassMap = {
  success: "bg-green-100 text-green-700",
  error: "bg-red-100 text-red-700",
  warning: "bg-yellow-100 text-yellow-700",
  info: "bg-blue-100 text-blue-700",
};

withDefaults(defineProps<MStickyNotificationProps>(), {
  text: "Not specified",
  type: "info",
});
</script>
