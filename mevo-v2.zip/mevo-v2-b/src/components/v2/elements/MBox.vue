<template>
  <!-- :class="[hoverEffect && 'hover:-translate-y-1 transition']" -->
  <div
    @click="$emits('clicked')"
    class="bg-white rounded-md border-b p-4"
    :class="[
      hoverEffect && 'hover:-translate-y-1 transition',
      !isUpgradeModalOpen && 'shadow',
    ]"
  >
    <slot></slot>
  </div>
</template>

<script lang="ts" setup>
import { storeToRefs } from "pinia";
import { useCommonStore } from "@/stores/common";

export interface MBoxProps {
  hoverEffect?: boolean;
}

const commonStore = useCommonStore();
const { isUpgradeModalOpen } = storeToRefs(commonStore);

withDefaults(defineProps<MBoxProps>(), {
  hoverEffect: false,
});

const $emits = defineEmits(["clicked"]);
</script>
