<template>
  <div
    :class="[
      type === 'success' && 'bg-indigo-100 text-indigo-500',
      type === 'green' && 'bg-green-100 text-green-500',
      type === 'gray' && 'bg-gray-100 text-gray-500',
      type === 'danger' && 'bg-red-100 text-red-500',
      type === 'info' && 'bg-blue-100 text-blue-500',
      type === 'fuchsia' && 'bg-fuchsia-100 text-fuchsia-500',
      type === 'warning' && 'bg-amber-100 text-amber-500',
      type === 'primary' && 'bg-indigo-100 text-indigo-500',
      'shrink-0 text-center py-1 px-2 rounded font-bold text-xs relative'
    ]"
  >
    <div v-if="text">{{ text }}</div>
    <div v-else><slot></slot></div>
    <div v-if="unread" class="w-3 h-3 rounded-full bg-primary absolute -right-1 -top-1"></div>
  </div>
</template>

<script lang="ts" setup>
export interface MBadgeProps {
  text?: string
  type: 'success' | 'danger' | 'info' | 'warning' | 'primary' | 'gray' | 'green' | 'fuchsia'
  unread?: boolean
}

withDefaults(defineProps<MBadgeProps>(), {
  type: 'success',
  unread: false
})
</script>
