<template>
  <div>
    <div :class="[center && 'text-center']">
      <h2 class="text-2xl font-bold tracking-tight">{{ title }}</h2>
      <p class="text-muted-foreground">{{ subtitle }}</p>
    </div>
  </div>
</template>

<script lang="ts" setup>
export interface MPageHeaderProps {
  title: string
  subtitle?: string
  center?: boolean
}

withDefaults(defineProps<MPageHeaderProps>(), {
  title: 'Not specified',
  subtitle: '',
  center: false
})
</script>
