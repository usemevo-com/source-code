<template>
  <m-marketing-box
    v-if="activePlan && activePlan.name === BasicPlan.name"
    @action="onUpgradeClicked"
    class="mb-4"
    :closable="true"
    @close="onClose"
    icon="bolt"
    size="1"
    variant="standard"
    :action-button-text="$t('settings.UPGRADE_NOW')"
    :title="`Hi, ${user.name.split(' ')[0]}! 👋`"
    :description="$t('settings.UPGRADE_TO_PRO_DESCRIPTION')"
  />
</template>

<script lang="ts" setup>
// internals
import { useAuthStore, useCommonStore, useOnboardingStore } from "@/stores";
import { useSubscription } from "@/composables/useSubscription";
import { BasicPlan } from "@/modules/organization/types/IPlan";

// components
import MMarketingBox from "../elements/MMarketingBox.vue";

const { user } = useAuthStore();
const { upgradePlan, activePlan } = useSubscription();
const onboardingStore = useOnboardingStore();
const { setUpgradeModal } = useCommonStore();

// methods
const onClose = () => {
  onboardingStore.setStepDone("close-popup-1");
};

const onUpgradeClicked = () => {
  setUpgradeModal(true);
};
</script>
