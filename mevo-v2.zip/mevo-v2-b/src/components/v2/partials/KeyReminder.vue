<template>
  <div
    v-if="activePlan && activePlan.name !== BasicPlan.name"
    class="col-span-12 bg-white rounded-md p-4 flex justify-between items-center shadow"
  >
    <div
      class="flex sm:items-center w-full justify-between sm:flex-row flex-col items-end"
    >
      <div class="flex items-center">
        <exclamation-triangle-icon
          class="shrink-0 w-8 h-8 text-yellow-500 mr-4"
        />
        <div>
          <div class="font-bold">
            {{ $t("marketing.ADD_YOUR_OPEN_AI_API_KEY") }}
          </div>
          <div class="text-gray-700 text-sm">
            {{ $t("marketing.ADD_YOUR_OPEN_AI_API_KEY_DESCRIPTION") }}
          </div>
        </div>
      </div>
      <div
        class="flex mt-4 sm:mt-0 w-full sm:w-fit justify-between sm:justify-start"
      >
        <m-button
          @clicked="goVideoTutorial"
          class="sm:h-fit sm:w-fit w-1/2 mr-4"
          type="white"
          >{{ $t("marketing.NEED_HELP") }}</m-button
        >
        <m-button
          class="w-1/2 sm:w-fit sm:h-fit"
          @clicked="goOrganizationSettings"
          type="primary"
          >{{ $t("marketing.BRING_ME_THERE") }}</m-button
        >
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ExclamationTriangleIcon } from "@heroicons/vue/24/outline";
import { useSubscription } from "@/composables/useSubscription";
import { BasicPlan } from "@/modules/organization/types/IPlan";
import { useOnboardingStore } from "@/stores";
import MButton from "@/components/v2/elements/MButton.vue";
import { useRouter } from "vue-router";

const $router = useRouter();
const { activePlan } = useSubscription();
const onboardingStore = useOnboardingStore();

const onClose = () => {
  onboardingStore.setStepDone("close-popup-3");
};

const goOrganizationSettings = function () {
  $router.push({ name: "organization-settings" });
};

const goVideoTutorial = () => {
  window.open("https://youtu.be/Om6f_mcyub0", "_blank");
};
</script>
