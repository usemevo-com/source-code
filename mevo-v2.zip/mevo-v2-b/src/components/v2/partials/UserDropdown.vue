<template>
  <DropdownMenu>
    <DropdownMenuTrigger as-child>
      <Avatar class="w-8 h-8 bg-primary text-secondary cursor-pointer">
        <img :src="userAvatar" alt="User" class="w-full h-full object-cover" />
        <AvatarFallback v-if="!userAvatar">{{ initials }}</AvatarFallback>
      </Avatar>
    </DropdownMenuTrigger>
    <DropdownMenuContent class="ml-5">
      <DropdownMenuLabel>{{ userDropdownLabel }}</DropdownMenuLabel>
      <DropdownMenuSeparator />
      <DropdownMenuItem :key="index" @click="signOut" class="space-x-4 cursor-pointer">
        <i class="fa-solid fa-arrow-right-from-bracket"></i>
        <span>Log out</span>
      </DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
</template>

<script lang="ts" setup>
import md5 from 'md5'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { computed, onMounted, reactive } from 'vue'
import { useAuthStore } from '@/stores'
import MDropdown from '../elements/MDropdown.vue'
import { useI18n } from 'vue-i18n'
import { useOrganizations } from '@/composables/useOrganizations'
import { logout } from '@/modules/prelogin/services/UserService'
import { useRouter } from 'vue-router'

const $router = useRouter()
const { user, setLoggedIn, setUser } = useAuthStore()
const { refreshOrganizations } = useOrganizations()
const { t } = useI18n()

const sections = reactive({
  data: [
    {
      subsections: [
        {
          label: t('user_menu.SIGN_OUT'),
          eventKey: 'sign-out'
        }
      ]
    }
  ]
})

const userAvatar = computed(() => {
  return `https://gravatar.com/avatar/${md5(user.email)}?d=identicon`
})

const userDropdownLabel = computed(() => {
  return user.email
})

const initials = computed(() => {
  return user.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
})

onMounted(() => {
  refreshOrganizations()

})

const signOut = async () => {
  await logout()
  setLoggedIn(false)
  setUser({ name: '', email: '', _id: '' })
  localStorage.removeItem('mevo:last_visited_route')
  $router.replace('/loading')
}

// const onDropdownEvent = async (eventKey: string) => {
//   if (eventKey === 'sign-out') {
//     // handle logout event
//   } else if (eventKey === 'create-organization') {
//     // navigate to create organization page
//     $router.push('/organization-create')
//   } else if (eventKey.startsWith('switch_organization_')) {
//     localStorage.removeItem('unsaved_gpt_bot')
//     // switch organization
//     const orgId = eventKey.split('_')[2]
//     $router.push(`/o/${orgId}/home`)
//   }
// }
</script>
