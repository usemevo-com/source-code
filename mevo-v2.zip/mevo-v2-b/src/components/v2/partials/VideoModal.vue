<template>
  <m-modal :show-close="false" big @close="$emits('close')" without-buttons>
    <video width="800" height="auto" autoplay muted loop>
      <source
        :src="`https://cdn.usemevo.com/videos/${video}`"
        type="video/mp4"
      />
      Your browser does not support the video tag.
    </video>
  </m-modal>
</template>

<script lang="ts" setup>
import MModal from "../elements/MModal.vue";

export interface VideoModalProps {
  video: string;
}

withDefaults(defineProps<VideoModalProps>(), {});

const $emits = defineEmits(["close"]);
</script>
