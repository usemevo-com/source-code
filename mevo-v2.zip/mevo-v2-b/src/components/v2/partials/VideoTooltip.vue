<template>
  <div class="group">
    <question-mark-circle-icon class="w-6 h-6 text-gray-500 cursor-pointer" />
    <div
      class="group-hover:block hidden absolute w-screen h-screen flex items-center justify-center left-10 -bottom-100 bg-white p-4 shadow rounded-md"
    ></div>
  </div>
</template>

<script lang="ts" setup>
import { QuestionMarkCircleIcon } from "@heroicons/vue/20/solid";

export interface VideoTooltipProps {
  video: string;
}

withDefaults(defineProps<VideoTooltipProps>(), {});
</script>
