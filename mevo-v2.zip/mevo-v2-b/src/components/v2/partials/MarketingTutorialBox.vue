<template>
  <m-marketing-box
    class="mb-4"
    icon="play"
    :closable="true"
    @close="onClose"
    @action="goYoutubeChannel"
    size="1"
    variant="white"
    action-button-text="Watch tutorials"
    title="Need help to start? 🛟"
    description="We have video tutorials for you to get started. Watch and learn how to start!"
  />
</template>

<script lang="ts" setup>
import { useOnboardingStore } from "@/stores";
import MMarketingBox from "../elements/MMarketingBox.vue";
import { useI18n } from "vue-i18n";

const { t } = useI18n();
const onboardingStore = useOnboardingStore();

const onClose = () => {
  onboardingStore.setStepDone("close-popup-2");
};

const goYoutubeChannel = () => {
  window.open(
    "https://www.youtube.com/playlist?list=PLjh_KaLz0kIlCMiVcGHLYZdfPntM0W6vo",
    "_blank"
  );
};
</script>
