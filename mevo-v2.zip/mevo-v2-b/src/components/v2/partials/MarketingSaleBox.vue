<template>
  <m-marketing-box
    v-if="activePlan && activePlan.name === BasicPlan.name"
    class="mb-4"
    size="1"
    :closable="true"
    @action="onUpgradeClicked"
    @close="onClose"
    variant="white"
    :action-button-text="$t('marketing.BRING_ME_THERE')"
    :title="$t('marketing.OFF_50')"
    :description="$t('marketing.OFF_50_DESCRIPTION')"
  />
</template>

<script lang="ts" setup>
import MMarketingBox from "../elements/MMarketingBox.vue";
import { useSubscription } from "@/composables/useSubscription";
import { BasicPlan } from "@/modules/organization/types/IPlan";
import { useCommonStore, useOnboardingStore } from "@/stores";

const { activePlan } = useSubscription();
const onboardingStore = useOnboardingStore();
const { setUpgradeModal } = useCommonStore();

const onClose = () => {
  onboardingStore.setStepDone("close-popup-3");
};

const onUpgradeClicked = () => {
  setUpgradeModal(true);
};
</script>
