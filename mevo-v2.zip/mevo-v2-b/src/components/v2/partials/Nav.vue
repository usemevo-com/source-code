<script lang="ts" setup>
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { Inbox, UsersRound, Route, Link, File, Text, MessagesSquare, Palette, Bell, Brain, Code } from 'lucide-vue-next'

export interface LinkProp {
  key: string
  title: string
  label?: string
  icon: string
  variant: 'default' | 'ghost'
}

interface NavProps {
  isCollapsed: boolean
  links: LinkProp[]
  title?: string
}

defineProps<NavProps>()
</script>

<template>
  <div v-if="title" :class="[isCollapsed ? 'opacity-0' : '']" class="text-[10px] font-medium text-gray-400 ml-5 mt-4 uppercase">
    {{ title }}
  </div>
  <div
    :data-collapsed="isCollapsed"
    class="group flex flex-col gap-4 py-2 data-[collapsed=true]:py-2"
  >
    <nav
      class="grid gap-1.5 px-2 group-[[data-collapsed=true]]:justify-center group-[[data-collapsed=true]]:px-2"
    >
      <template v-for="(link, index) of links">
        <Tooltip v-if="isCollapsed" :key="`1-${index}`" :delay-duration="0">
          <TooltipTrigger as-child>
            <router-link
              :to="link.to"
              :class="
                cn(
                  buttonVariants({ variant: link.variant, size: 'icon' }),
                  'h-9 w-9',
                  link.variant === 'default' &&
                    ''
                )
              "
            >
              <i :class="`fa-regular fa-${link.icon} `"></i>
              <span class="sr-only">{{ link.title }}</span>
            </router-link>
          </TooltipTrigger>
          <TooltipContent side="right" class="flex items-center gap-4">
            {{ link.title }}
            <span v-if="link.label" class="ml-auto text-muted-foreground">
              {{ link.label }}
            </span>
          </TooltipContent>
        </Tooltip>

        <router-link
          v-else
          :to="link.to"
          :key="`2-${index}`"
          :class="
            cn(
              // buttonVariants({ variant: link.variant, size: 'sm' }),
              link.variant === 'default' && `hover:bg-primary-hover`,
              link.variant !== 'default' && `hover:bg-mevo-light`,
              link.variant === 'default' &&
                `font-medium bg-mevo text-white`,
              `justify-start font-[400] flex space-x-2 text-sm py-2 px-3 w-full rounded-lg items-center`
            )
          "
          :id="`button-${link.key}`"
        >
          <UsersRound v-if="link.icon === 'users'" class="w-4 h-4 mr-2" />
          <Inbox v-if="link.icon === 'inbox'" class="w-4 h-4 mr-2" />
          <Route v-if="link.icon === 'arrow-progress'" class="w-4 h-4 mr-2" />
          <Link v-if="link.icon === 'link'" class="w-4 h-4 mr-2" />
          <File v-if="link.icon === 'file-lines'" class="w-4 h-4 mr-2" />
          <Text v-if="link.icon === 'text'" class="w-4 h-4 mr-2" />
          <MessagesSquare v-if="link.icon === 'comments-question-check'" class="w-4 h-4 mr-2" />
          <Palette v-if="link.icon === 'palette'" class="w-4 h-4 mr-2" />
          <Bell v-if="link.icon === 'bell'" class="w-4 h-4 mr-2" />
          <Brain v-if="link.icon === 'brain'" class="w-4 h-4 mr-2" />
          <Code v-if="link.icon === 'code'" class="w-4 h-4 mr-2" />
          {{ link.title }}
        </router-link>
      </template>
      <!-- <div v-if="title === 'Knowledge'" class="font-[400] text-sm py-2 px-3 flex space-x-2 w-full rounded-lg items-center">
        <i class="text-[#96bf48] fab fa-shopify w-4 h-4"></i>
        <span>Shopify</span>
      </div>
      <div v-if="title === 'Knowledge'" class="font-[400] text-sm py-2 px-3 flex space-x-2 w-full rounded-lg items-center">
        <i class="text-[#5433FF] fab fa-stripe w-4 h-4"></i>
        <span>Stripe</span>
      </div> -->
    </nav>
  </div>
</template>