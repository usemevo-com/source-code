<template>
  <div class='relative flex flex-col space-y-4 p-3'>
    <slot></slot>
  </div>
</template>
