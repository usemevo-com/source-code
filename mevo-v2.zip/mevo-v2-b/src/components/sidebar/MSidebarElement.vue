<template>
  <div :class='`mb-${3 * space}`'>
    <slot></slot>
  </div>
</template>

<script lang='ts'>
export default {
  props: {
    space: {
      type: Number,
      default: 1,
    },
  },
}
</script>
