<template>
  <div class='flex items-center flex-col'>
    <slot></slot>
  </div>
</template>
