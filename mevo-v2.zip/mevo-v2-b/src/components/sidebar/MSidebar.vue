<template>
  <div class="h-screen z-50">
    <div class="w-75px bg-white h-full flex flex-col items-center justify-between py-5 border-r border-gray-100">
      <slot></slot>
    </div>
  </div>
</template>
