<template>
  <a
    :title="title"
    :href="href"
    :class="[
      isException && '!bg-gray-50 !text-gray-500 hover:!bg-gray-100 hover:!text-gray-900',
      isActive ? 'bg-blue-500 text-white' : 'bg-blue-50 text-blue-500 hover:bg-blue-200 hover:text-white',
      'group w-full p-3 rounded-md flex flex-col items-center text-xs font-medium cursor-pointer',
    ]"
  >
    <slot></slot>
  </a>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  props: {
    isActive: {
      type: Boolean,
      required: true,
    },
    isException: {
      type: Boolean,
      required: false,
    },
    href: {
      type: String,
      required: false,
    },
    title: {
      type: String,
      required: true,
    },
  },
})
</script>
