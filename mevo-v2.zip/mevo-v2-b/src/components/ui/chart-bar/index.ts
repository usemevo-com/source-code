export { default as BarChart } from './BarChart.vue'
