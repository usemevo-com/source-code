export { default as AspectRatio } from './AspectRatio.vue'
