<template>
    <div class="w-[200px] bg-slate-100 border my-2 h-[calc(100vh_-_16px)] p-2 rounded-l-lg">
      <!-- SIDEBAR HEADER -->
      <div class="flex justify-between items-center mt-1 mx-2">
        <div class="font-semibold text-lg">AI Settings</div>
        <div class="flex items-center space-x-2">
          
        </div>
      </div>
      <!-- SIDEBAR HEADER -->
  
      <!-- SIDEBAR CONTENT -->
      <div class="flex justify-between items-center mt-4 mx-2">
        <div class="font-medium text-sm">Knowledge Base</div>
      </div>
      <div class="mt-2">
        <SidebarListItem :active="true">
          <template #icon>
            <AtSign :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Articles</template>
          <template #count>0</template>
        </SidebarListItem>
        <SidebarListItem :active="false">
          <template #icon>
            <GalleryVerticalEnd :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Links</template>
          <template #count>5</template>
        </SidebarListItem>
        <SidebarListItem :active="false">
          <template #icon>
            <GalleryVerticalEnd :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Products</template>
          <template #count>6</template>
        </SidebarListItem>
        <SidebarListItem :active="false">
          <template #icon>
            <GalleryVerticalEnd :size="16" :stroke-width="1.5" />
          </template>
          <template #label>FAQs</template>
          <template #count>2</template>
        </SidebarListItem>
        <SidebarListItem :active="false">
          <template #icon>
            <GalleryVerticalEnd :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Files</template>
          <template #count>9</template>
        </SidebarListItem>
      </div>
      <div class="flex justify-between items-center mt-2 mx-2">
        <div class="font-medium text-sm">Preferences</div>
      </div>
      <div class="mt-2">
        <SidebarListItem>
          <template #icon>
            <MessagesSquare :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Model settings</template>
        </SidebarListItem>
        <SidebarListItem @select="emit('filterChange', InboxFilter.AI_RESOLVED)" :active="sidebarState.activeFilter === InboxFilter.AI_RESOLVED">
          <template #icon>
            <MessageCircleHeart :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Resolved</template>
          <template #count>{{ conversationsState.conversations[InboxFilter.AI_RESOLVED].length }}</template>
        </SidebarListItem>
        <SidebarListItem @select="emit('filterChange', InboxFilter.AI_ASSIGNED)" :active="sidebarState.activeFilter === InboxFilter.AI_ASSIGNED">
          <template #icon>
            <Route :size="16" :stroke-width="1.5" />
          </template>
          <template #label>Assigned</template>
          <template #count>{{ conversationsState.conversations[InboxFilter.AI_ASSIGNED].length }}</template>
        </SidebarListItem>
      </div>
      <!-- SIDEBAR CONTENT -->
    </div>
  </template>
  
  <script setup lang="ts">
  import { Search, MessageSquareDiff, AtSign, GalleryVerticalEnd, MessagesSquare, MessageCircleHeart, Route } from 'lucide-vue-next'
  import SidebarListItem from './SidebarListItem.vue'
  import IconButton from './IconButton.vue'
  import { InboxFilter, type InboxConversationsState, type InboxSidebarState } from '@/modules/v3/data/inbox.state'
  
  defineProps<{
    isOpen: boolean
  }>()
  
  const emit = defineEmits(['filterChange'])
  </script>