<template>
  <div v-if="isEvent" class="flex w-full items-center justify-center text-sm py-4 text-gray-500">
    <Heart v-if="content === UserEvent.HELPED" class="w-4 h-4 mr-2" />
    <Headset v-if="content === UserEvent.HUMAN_DEMAND" class="w-4 h-4 mr-2" />
    {{ eventMap[content] }}
  </div>
  <div
    v-else
    :class="[
      'flex space-x-2 items-end',
      align === 'right' ? 'justify-end' : 'justify-start'
    ]"
  >
    <template v-if="align === 'left'">
      <div v-if="initial" :class="['p-2 w-8 h-8 font-bold flex items-center justify-center rounded-lg', initialBg, initialText]">
        {{ initial }}
      </div>
      <div v-else-if="avatar" class="w-8 h-8 flex items-center justify-center rounded-lg">
        <img :src="avatar" class="w-8 h-8 rounded-full" />
      </div>
    </template>
    <div :class="[bubbleClass, 'w-fit h-fit p-4 max-w-[480px] rounded-lg']">
      <vue-markdown
        :options="markdownOptions"
        :source="content.replaceAll(/【(.*)】/g, '')"
        :plugins="plugins"
      />
    </div>
    <template v-if="align === 'right'">
      <div v-if="icon" :class="[iconBg, 'w-8 h-8 flex items-center justify-center rounded-lg']">
        <component :is="icon" :size="20" stroke-width="1.5" />
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { defineProps } from 'vue'
import { Heart, Headset } from 'lucide-vue-next'
import VueMarkdown from 'vue-markdown-render'
import MarkdownItAnchor from 'markdown-it-anchor'
import { UserEvent } from '@/modules/v3/data/inbox.state'

const plugins = [MarkdownItAnchor]

const markdownOptions = {
  breaks: true, // Convert '\n' in paragraphs into <br>
  html: true
}

const eventMap: { [key: string]: string } = {
  'MEVO_EVENT_HELPED': 'User found the answer helpful', 
  'MEVO_EVENT_HUMAN_DEMAND': 'User asked for human assistance',
}

defineProps<{
  align: 'left' | 'right'
  initial?: string
  initialBg?: string
  initialText?: string
  avatar?: string
  icon?: any
  iconBg?: string
  bubbleClass?: string
  content: string
  isEvent?: boolean
}>()
</script>