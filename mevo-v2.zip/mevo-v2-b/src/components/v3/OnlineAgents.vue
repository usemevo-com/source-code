<template>
  <div class="flex items-center justify-between w-full">
    <div class="flex space-x-1">
      <div v-for="(agent, idx) in agents.slice(0, 3)" :key="idx" class="relative w-8 h-8">
        <img :title="agent.name" :src="agent.image" class="w-8 h-8 rounded-lg" />
      </div>
      <div v-if="agents.length > 3" class="relative w-8 h-8">
        <div class="absolute top-0 left-0 w-8 h-8 bg-gray-200 rounded-lg flex items-center justify-center cursor-pointer">
          <span class="text-xs font-medium text-gray-500">+{{ agents.length - 3 }}</span>
        </div>
      </div>
    </div>
    <div class="font-light text-sm text-gray-400">
      {{ label }}
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  agents: { image: string; name: string, _id: string }[]
  label: string
}>()
</script>