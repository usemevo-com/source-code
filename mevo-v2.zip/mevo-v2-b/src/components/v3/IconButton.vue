<template>
  <button
    :class="[
      'p-1.5 w-fit flex items-center justify-center transition rounded-lg',
      bgClass,
      'hover:bg-slate-50',
      'cursor-pointer'
    ]"
    @click="onClick"
    type="button"
  >
    <component :class="[spin && 'animate-spin']" :is="icon" :size="size" :stroke-width="strokeWidth" />
  </button>
</template>

<script setup lang="ts">
import { defineProps, defineEmits } from 'vue'
const props = defineProps<{
  icon: any
  size?: number
  strokeWidth?: number
  bgClass?: string
  spin?: boolean
}>()
const emit = defineEmits(['click'])
function onClick(e: MouseEvent) {
  emit('click', e)
}
</script>