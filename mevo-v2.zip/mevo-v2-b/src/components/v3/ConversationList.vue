<template>
  <div :class="[!showLeft && 'rounded-l-lg']" class="w-[380px] border-y border-r bg-slate-100 h-[calc(100vh_-_16px)] my-2 flex flex-col justify-between">
    <!-- CONVERSATION LIST HEADER -->
    <div class="h-[52px] px-4 flex space-x-5 items-center border-b justify-between">
      <IconButton
        id="left-panel-toggle"
        :icon="showLeft ? PanelLeftClose : PanelLeftOpen"
        :size="16"
        :stroke-width="1.5"
        bgClass="bg-slate-200"
        @click="onToggleLeft"
      />
      <div class="font-medium">
        {{ data.agentName }}
      </div>
      <IconButton
        :icon="RefreshCw"
        :size="16"
        :stroke-width="1.5"
        bgClass="bg-slate-200"
        @click="onRefresh"
        :spin="isConversationsLoading"
      />
    </div>
    <!-- CONVERSATION LIST HEADER -->

    <!-- CONVERSATION LIST CONTENT -->
    <div class="flex-1 p-4 overflow-y-auto flex flex-col space-y-2">
      <ConversationListItem
        @click="$emit('conversationChange', conversation)"
        v-for="(conversation, index) in data.conversations[activeFilter]"
        :active="conversation._id === activeConversation"
        :conversation="conversation"
        :initial="'A'"
        initialBg="p-1 bg-[#EBEBEB]"
        initialText=""
        :name="conversation.title"
        :message="conversation.lastMessage"
        :time="conversation.lastMessageDate"
        :borderBottom="false"
        :hoverable="true"
        :colorIndex="index % 5"
      >
      </ConversationListItem>
    </div>
    <!-- CONVERSATION LIST HEADER -->

    <!-- CONVERSATION LIST FOOTER -->
    <div class="p-4 flex items-center border-t">
      <OnlineAgents
        :agents="data.onlineAgents"
        :label="data.onlineAgents.length + ' agents online'"
      />
    </div>
    <!-- CONVERSATION LIST FOOTER -->
  </div>
</template>

<script setup lang="ts">
import { PanelLeftClose, PanelLeftOpen, RefreshCw } from 'lucide-vue-next'
import IconButton from './IconButton.vue'
import ConversationListItem from './ConversationListItem.vue'
import OnlineAgents from './OnlineAgents.vue'
import type { InboxConversationsState, InboxFilter } from '@/modules/v3/data/inbox.state';

defineProps<{
  activeFilter: InboxFilter
  activeConversation: string
  showLeft: boolean
  data: InboxConversationsState
  isConversationsLoading: boolean
  onToggleLeft: () => void
  onRefresh: () => void
}>()
</script>