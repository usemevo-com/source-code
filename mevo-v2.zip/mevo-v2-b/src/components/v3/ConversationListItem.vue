<template>
  <div
    @click="$emit('click')"
    :class="[
      'p-4 cursor-pointer',
      borderBottom ? 'border-b' : '',
      'flex space-x-4 items-center',
      !active && hoverable ? 'hover:bg-slate-50 hover:rounded-lg' : '',
      active ? 'bg-white rounded-lg' : '',
    ]"
  >
    <div :class="['w-8 h-8 flex items-center justify-center font-bold rounded-lg', colors[colorIndex], initialText]">
      {{ getTitle(conversation).charAt(0).toUpperCase() }}
    </div>
    <div class="flex-1">
      <div class="font-medium text-[13px]">{{ getTitle(conversation) }}</div>
      <div class="flex justify-between items-center text-gray-500 mt-0.5">
        <div class="font-light text-[13px]">{{ conversation.lastMessage.length > 24 ? conversation.lastMessage.substr(0, 24) + '...' : conversation.lastMessage }}</div>
        <div class="text-[12px] shrink-0">{{ moment(conversation.lastCreatedAt).fromNow() }}</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import moment from 'moment'
import type { InboxConversation } from '@/modules/v3/data/inbox.state';
import { getConversationTitle } from '@/utils/helpers/toolkit';

const colors = [
  'bg-red-100 text-red-500',
  'bg-blue-100 text-blue-500',
  'bg-green-100 text-green-500',
  'bg-yellow-100 text-yellow-500',
  'bg-purple-100 text-purple-500',
  'bg-pink-100 text-pink-500',
];

defineProps<{
  conversation: InboxConversation
  active?: boolean
  avatar?: string
  initial?: string
  initialBg?: string
  initialText?: string
  name: string
  message: string
  time: string
  borderBottom?: boolean
  hoverable?: boolean
  colorIndex: number
}>()

const $emit = defineEmits<{
  (e: 'click'): void
}>()

const getTitle = (conversation: InboxConversation) => {
  return getConversationTitle(conversation)
}
</script>