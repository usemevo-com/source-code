<template>
  <div class="mr-2 w-[380px] bg-white border h-[calc(100vh_-_16px)] my-2 flex flex-col rounded-r-lg">
    <!-- COPILOT HEADER -->
    <div class="px-4 h-[52px] flex space-x-5 items-center border-b justify-between">
      <div class="flex items-center space-x-3">
        <div class="font-light text-gray-500">
          Details
        </div>
        <div class="font-medium border-b border-teal-500 h-[52px] flex items-center">
          Copilot
        </div>
      </div>
    </div>
    <!-- COPILOT HEADER -->

    <!-- COPILOT CONTENT -->
    <div class="flex-1 flex items-center justify-center flex flex-col p-8">
      <div class="font-medium">Copilot is ready to help</div>
      <div class="font-light text-sm text-gray-500 mt-2 text-center">
        It can help you to find the answers for the questions you receive from users. You can ask it anything and it will try to find the best answer for you.
      </div>
    </div>
    <!-- COPILOT CONTENT -->

    <!-- COPILOT INPUT -->
    <div class="justify-between rounded-lg">
      <div class="border h-[48px] m-4 flex flex-col relative rounded-lg">
        <input class="resize-none w-full h-[48px] p-2 text-sm rounded-lg" placeholder="Ask help for any topic" />
        <div class="space-x-1 text-sm rounded-lg absolute bottom-[4px] right-[4px] flex items-center justify-between px-2 bg-teal-500 hover:bg-teal-700 cursor-pointer w-fit h-[36px] text-white">
          <span>Ask</span> <Sparkle :size="16" :stroke-width="1.5" />
        </div>
      </div>
    </div>
    <!-- COPILOT INPUT -->
  </div>
</template>

<script setup lang="ts">
import { Sparkle } from 'lucide-vue-next'
defineProps<{
  isOpen: boolean
}>()
</script>