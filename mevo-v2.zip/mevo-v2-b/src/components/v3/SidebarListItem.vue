<template>
  <div
    @click="() => $emit('select')"
    :class="[
      'flex space-x-2 items-center justify-between px-3 py-2 rounded-lg',
      { 'bg-white': active, 'cursor-pointer hover:bg-slate-50': !active }
    ]"
  >
    <div class="flex items-center space-x-2 font-light">
      <slot name="icon" />
      <div :class="['text-sm', active && 'font-normal']">
        <slot name="label" />
      </div>
    </div>
    <div class="text-sm text-gray-500 font-light">
      <slot name="count" />
    </div>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  active?: boolean
  fontClass?: string
}>()

const $emit = defineEmits(['select'])
</script>