<template>
  <div class="w-[200px] bg-slate-100 border my-2 h-[calc(100vh_-_16px)] p-2 rounded-l-lg">
    <!-- SIDEBAR HEADER -->
    <div class="flex justify-between items-center mt-1 mx-2">
      <div class="font-semibold text-lg">Inbox</div>
      <div class="flex items-center space-x-2">
        <IconButton
          :icon="Search"
          :size="16"
          :stroke-width="1.5"
          bgClass="bg-slate-200"
        />
        <IconButton
          :icon="MessageSquareDiff"
          :size="16"
          :stroke-width="1.5"
          bgClass="bg-slate-200"
        />
      </div>
    </div>
    <!-- SIDEBAR HEADER -->

    <!-- SIDEBAR CONTENT -->
    <div class="flex justify-between items-center mt-4 mx-2">
      <div class="font-medium text-sm">Human Agents</div>
    </div>
    <div class="mt-2">
      <SidebarListItem @select="() => emit('filterChange', InboxFilter.HUMAN_YOURS)" :active="sidebarState.activeFilter === InboxFilter.HUMAN_YOURS">
        <template #icon>
          <img src="https://media.licdn.com/dms/image/v2/D4D03AQHzJwmC3LRTQw/profile-displayphoto-shrink_800_800/profile-displayphoto-shrink_800_800/0/1667311696103?e=1754524800&v=beta&t=DRFQPCSyDyZw0_hCnwgu_MZxU-KCnxeCGHwNjJsSYJE" class="w-4 h-4" />
        </template>
        <template #label>Yours</template>
        <template #count>{{ conversationsState.conversations[InboxFilter.HUMAN_YOURS].length }}</template>
      </SidebarListItem>
      <SidebarListItem @select="emit('filterChange', InboxFilter.HUMAN_MENTIONS)" :active="sidebarState.activeFilter === InboxFilter.HUMAN_MENTIONS">
        <template #icon>
          <AtSign :size="16" :stroke-width="1.5" />
        </template>
        <template #label>Mentions</template>
        <template #count>{{ conversationsState.conversations[InboxFilter.HUMAN_MENTIONS].length }}</template>
      </SidebarListItem>
      <SidebarListItem @select="emit('filterChange', InboxFilter.HUMAN_ALL)" :active="sidebarState.activeFilter === InboxFilter.HUMAN_ALL">
        <template #icon>
          <GalleryVerticalEnd :size="16" :stroke-width="1.5" />
        </template>
        <template #label>All</template>
        <template #count>{{ conversationsState.conversations[InboxFilter.HUMAN_ALL].length }}</template>
      </SidebarListItem>
    </div>
    <div class="flex justify-between items-center mt-2 mx-2">
      <div class="font-medium text-sm">AI Agent</div>
    </div>
    <div class="mt-2">
      <SidebarListItem @select="emit('filterChange', InboxFilter.AI_ALL)" :active="sidebarState.activeFilter === InboxFilter.AI_ALL">
        <template #icon>
          <MessagesSquare :size="16" :stroke-width="1.5" />
        </template>
        <template #label>Conversations</template>
        <template #count>{{ conversationsState.conversations[InboxFilter.AI_ALL].length }}</template>
      </SidebarListItem>
      <SidebarListItem @select="emit('filterChange', InboxFilter.AI_RESOLVED)" :active="sidebarState.activeFilter === InboxFilter.AI_RESOLVED">
        <template #icon>
          <MessageCircleHeart :size="16" :stroke-width="1.5" />
        </template>
        <template #label>Resolved</template>
        <template #count>{{ conversationsState.conversations[InboxFilter.AI_RESOLVED].length }}</template>
      </SidebarListItem>
      <SidebarListItem @select="emit('filterChange', InboxFilter.AI_ASSIGNED)" :active="sidebarState.activeFilter === InboxFilter.AI_ASSIGNED">
        <template #icon>
          <Route :size="16" :stroke-width="1.5" />
        </template>
        <template #label>Assigned</template>
        <template #count>{{ conversationsState.conversations[InboxFilter.AI_ASSIGNED].length }}</template>
      </SidebarListItem>
    </div>
    <!-- SIDEBAR CONTENT -->
  </div>
</template>

<script setup lang="ts">
import { Search, MessageSquareDiff, AtSign, GalleryVerticalEnd, MessagesSquare, MessageCircleHeart, Route } from 'lucide-vue-next'
import SidebarListItem from './SidebarListItem.vue'
import IconButton from './IconButton.vue'
import { InboxFilter, type InboxConversationsState, type InboxSidebarState } from '@/modules/v3/data/inbox.state'

defineProps<{
  isOpen: boolean
  sidebarState: InboxSidebarState
  conversationsState: InboxConversationsState
}>()

const emit = defineEmits(['filterChange'])
</script>