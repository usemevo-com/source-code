<template>
  <div class="ml-2 flex-1 bg-white border h-[calc(100vh_-_16px)] my-2 flex flex-col justify-between" :class="[!isRightOpen && 'rounded-r-lg']">
    <!-- CONVERSATION AREA HEADER -->
    <div class="px-4 h-[52px] flex space-x-5 items-center border-b justify-between">
      <div class="font-medium">
        {{ data.user.email ? data.user.email : data.user.name }}
      </div>
      <div class="flex space-x-2">
        <IconButton
          :icon="Check"
          :size="16"
          :stroke-width="1.5"
          bgClass="bg-slate-200"
        />
        <IconButton
          v-if="isRightOpen"
          id="right-panel-toggle"
          :icon="PanelRightClose"
          :size="16"
          :stroke-width="1.5"
          bgClass="bg-slate-200"
          @click="onToggleRight"
        />
        <IconButton
          v-else
          id="right-panel-toggle"
          :icon="PanelRightOpen"
          :size="16"
          :stroke-width="1.5"
          bgClass="bg-slate-200"
          @click="onToggleRight"
        />
      </div>
    </div>
    <!-- CONVERSATION AREA HEADER -->

    <!-- CONVERSATION AREA CONTENT -->
    <div class="flex-1 py-4 px-4 overflow-y-auto flex flex-col space-y-4">
      <MessageBubble
        v-for="(message, index) in data.conversation.messages"
        :is-event="message.isEvent"
        :align="message.sender === MessageSender.USER ? 'left' : 'right'"
        :initial="message.sender === MessageSender.USER ? 'Y' : 'G'"
        :icon="Brain"
        iconBg="bg-black text-white"
        initial-bg="bg-blue-500 text-white"
        :bubbleClass="message.sender === MessageSender.USER ? 'bg-gray-100' : 'bg-blue-100'"
        :content="message.text"
      />
    </div>
    <!-- CONVERSATION AREA CONTENT -->

    <!-- CONVERSATION AREA INPUT -->
    <div class="border h-[80px] mx-4 mb-4 flex flex-col relative rounded-lg">
      <!-- <div class="border-b flex space-x-2 items-center text-xs font-light px-2 bg-gray-100">
        <div class="py-1 px-2 font-medium cursor-pointer">Reply</div>
        <div class="py-1 px-2 cursor-pointer hover:underline">Edit</div>
        <div class="py-1 px-2 cursor-pointer hover:underline">Note</div>
        <div class="py-1 px-2 cursor-pointer hover:underline">Reminder</div>
        <div class="py-1 px-2 cursor-pointer hover:underline">Shortcut</div>
        <div class="py-1 px-2 cursor-pointer hover:underline">Knowledge Base</div>
      </div> -->
      <textarea class="bg-slate-50 resize-none w-full h-[100px] p-2 rounded-lg" placeholder="Type your message here..."></textarea>
      <div class="hover:bg-white absolute bottom-2 right-2 flex items-center justify-between px-4 py-2 cursor-pointer w-fit h-fit rounded-lg">
        Send
      </div>
    </div>
    <!-- CONVERSATION AREA INPUT -->
  </div>
</template>

<script setup lang="ts">
import { MessageSender } from '@/modules/v3/data/inbox.state'
import { Brain, Check, PanelRightClose, PanelRightOpen, SendHorizontal } from 'lucide-vue-next'
import IconButton from './IconButton.vue'
import MessageBubble from './MessageBubble.vue'
import type { InboxConversationState } from '@/modules/v3/data/inbox.state';

defineProps<{
  data: InboxConversationState
  isRightOpen: boolean
  onToggleRight: () => void
}>()
</script>