<template>
<div class="relative flex items-center justify-center">
    <img src="/mevo.png" class="h-28 object-contain" />
</div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

const props = defineProps({
    infinite: {
        type: Boolean,
        default: false
    }
})

const emit = defineEmits(['click'])

const showAnimation = ref(false)

const triggerAnimation = () => {
    showAnimation.value = !showAnimation.value
}

// Otomatik başlatmak için (isteğe bağlı)
onMounted(() => {
    if (props.infinite) {
        setInterval(() => {
            triggerAnimation()
        }, 1000)
    } else {
        triggerAnimation()
    }
})
</script>