<template>
  <div class="flex justify-between py-6 max-w-6xl mx-auto w-full items-center">
    <div>
      <router-link to="/"
        ><img src="/mevo-brand.png" class="w-28"
      /></router-link>
    </div>
    <div class="h-[45px] flex items-center">
      <div
        class="font-semibold px-4 py-2 flex text-sm items-center mr-4 cursor-pointer hover:bg-gray-100 rounded-md"
      >
        Settings
      </div>
      <Menu as="div" class="relative inline-block text-left">
        <div>
          <MenuButton
            class="flex max-w-[220px] items-center text-overflow truncate justify-end rounded-md px-4 py-2 text-sm font-semibold text-gray-900 hover:bg-gray-100 rounded-md"
          >
            <div
              class="w-fit max-w-[calc(220px_-_2rem)] overflow-hidden truncate"
            >
              Furkan Başaran
            </div>
            <ChevronDownIcon
              class="w-4 h-4 ml-2 text-gray-500"
              aria-hidden="true"
            />
          </MenuButton>
        </div>

        <transition
          enter-active-class="transition ease-out duration-100"
          enter-from-class="transform opacity-0 scale-95"
          enter-to-class="transform opacity-100 scale-100"
          leave-active-class="transition ease-in duration-75"
          leave-from-class="transform opacity-100 scale-100"
          leave-to-class="transform opacity-0 scale-95"
        >
          <MenuItems
            class="absolute right-0 z-10 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
          >
            <div class="px-4 py-3">
              <p class="text-sm">Signed in as</p>
              <p class="truncate text-sm font-medium text-gray-900">
                tom@example.com
              </p>
            </div>
            <div class="py-1">
              <MenuItem v-slot="{ active }">
                <a
                  href="#"
                  :class="[
                    active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                    'block px-4 py-2 text-sm font-bold w-full truncate text-overflow',
                  ]"
                  >Mevo Software Services LTD</a
                >
              </MenuItem>
              <MenuItem v-slot="{ active }">
                <a
                  href="#"
                  :class="[
                    active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                    'block px-4 py-2 text-sm',
                  ]"
                  >Countly LTD</a
                >
              </MenuItem>
            </div>
            <div class="py-1">
              <MenuItem v-slot="{ active }">
                <button
                  :class="[
                    active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                    'block w-full px-4 py-2 text-left text-sm',
                  ]"
                >
                  Create an organization
                </button>
              </MenuItem>
            </div>
            <div class="py-1">
              <form method="POST" action="#">
                <MenuItem v-slot="{ active }">
                  <button
                    type="submit"
                    :class="[
                      active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                      'block w-full px-4 py-2 text-left text-sm',
                    ]"
                  >
                    Sign out
                  </button>
                </MenuItem>
              </form>
            </div>
          </MenuItems>
        </transition>
      </Menu>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { RouterLink } from "vue-router";
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/vue";
import { ChevronDownIcon, CogIcon } from "@heroicons/vue/24/outline";
</script>
