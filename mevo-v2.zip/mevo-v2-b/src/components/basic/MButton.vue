<template>
  <!-- rounded-md START -->
  <button
    :disabled="disabled"
    @click="onClick"
    v-bind="$attrs"
    v-if="type === 'rounded-md'"
    type="button"
    class="inline-flex items-center p-2 border border-transparent rounded-md shadow-sm text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500"
  >
    <slot></slot>
  </button>
  <!-- rounded-md END -->
  <button
    v-bind="$attrs"
    :disabled="disabled"
    @click="onClick"
    v-else
    :class="{
      'rounded-md shadow text-white bg-primary hover:bg-primary-hover':
        type === 'primary',
      'shadow border-transparent rounded-md text-pink-700 bg-secondary hover:bg-secondary-hover':
        type === 'secondary',
      'rounded-md text-gray-700 bg-white hover:bg-gray-100': type === 'white',
      'rounded-md shadow text-white bg-red-600 hover:bg-red-700':
        type === 'danger',
      'rounded-md shadow text-red-600 bg-red-100 hover:bg-red-200':
        type === 'danger-light',
      'rounded-md shadow': type === 'custom',
      'text-primary hover:bg-gray-100': type === 'link',
      'cursor-not-allowed opacity-50': disabled,
    }"
    class="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold focus:outline-none"
  >
    <span v-if="label">{{ label }}</span>
    <slot v-else></slot>
  </button>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  props: {
    label: {
      type: String,
    },
    type: {
      type: String,
      default: "primary",
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  emits: ["clicked"],
  methods: {
    onClick(e: Event): void {
      this.$emit("clicked", e);
    },
  },
});
</script>
