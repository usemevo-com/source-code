<template>
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-1.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-1.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-2.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-2.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-3.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-3.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-4.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-4.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-5.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-5.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-6.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-6.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-7.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-7.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-8.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-8.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-8.jpeg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-9.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-9.jpeg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-10.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-10.jpeg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-11.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-11.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-12.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-12.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-13.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-13.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-14.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-15.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-16.png')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-17.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-18.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-19.jpg')] -->
  <!-- bg-[url('https://cdn.usemevo.com/bg/background-20.jpg')] -->
  <RadioGroup :disabled="disabled" v-model="model" :class="[withImages && 'relative']">
    <RadioGroupLabel class="text-sm font-medium text-gray-700">{{
      label
    }}</RadioGroupLabel>
    <p class="text-gray-400 text-sm">
      {{ description }}
    </p>
    <div
      :class="[
        !withImages &&
          'mt-4 grid grid-cols-1 gap-y-6 sm:grid-cols-4 sm:gap-x-4',
        withImages && 'w-full overflow-auto flex images-wrapper py-2 px-1',
        vertical && 'sm:grid-cols-1',
        disabled && 'opacity-50',
      ]"
    >
      <RadioGroupOption
        as="template"
        v-for="option in options"
        :key="option.id"
        :value="option.value"
        v-slot="{ checked, active }"
      >
        <div
          v-if="!withImages"
          :class="[
            checked ? 'border-transparent' : 'border-gray-300',
            active ? 'border-primary ring-2 ring-primary' : '',
            'relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none',
            disabled && '!cursor-not-allowed',
          ]"
        >
          <span class="flex flex-1">
            <span class="flex flex-col">
              <RadioGroupLabel
                as="span"
                class="block text-sm font-medium text-gray-900"
                >{{ $t(option.title) }}</RadioGroupLabel
              >
              <RadioGroupDescription
                as="span"
                class="mt-1 flex items-center text-sm text-gray-500"
                >{{ option.description }}</RadioGroupDescription
              >
              <img
                v-if="withIcons"
                class="w-12 mt-4"
                :src="`https://cdn.usemevo.com/svg/${option.value}.svg`"
              />
            </span>
          </span>
          <CheckCircleIcon
            :class="[!checked ? 'invisible' : '', 'h-5 w-5 text-primary-hover']"
            aria-hidden="true"
          />
          <span
            :class="[
              active ? 'border' : 'border-2',
              checked ? 'border-primary' : 'border-transparent',
              'pointer-events-none absolute -inset-px rounded-lg',
            ]"
            aria-hidden="true"
          />
        </div>
        <div
          :class="[
            `cursor-pointer bg-[url('https://cdn.usemevo.com/bg/${option.value}')] bg-cover rounded-lg shrink-0 w-[150px] mr-2 h-[90px] mr-2 opacity-70`,
            checked &&
              'border-primary ring-2 ring-primary flex items-center justify-center !opacity-100',
          ]"
          v-else
        >
          <div
            v-if="checked"
            class="bg-white rounded-full flex flex-col items-center justify-center"
          >
            <check-circle-icon class="w-8 h-8 text-primary" />
          </div>
        </div>
      </RadioGroupOption>
    </div>
  </RadioGroup>
</template>

<script lang="ts" setup>
import { computed } from "vue";
import {
  RadioGroup,
  RadioGroupDescription,
  RadioGroupLabel,
  RadioGroupOption,
} from "@headlessui/vue";
import { CheckCircleIcon } from "@heroicons/vue/20/solid";

export interface Props {
  modelValue: string;
  label: string;
  vertical: boolean;
  disabled: boolean;
  options: {
    id: number;
    value: string;
    title: string;
    description?: string;
  }[];
  description: string;
  withIcons: boolean;
  withImages: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  options: () => [{ id: 0, value: "", title: "", description: "" }],
  withIcons: false,
  withImages: false,
  vertical: false,
  disabled: false,
});

const emit = defineEmits(["update:modelValue"]);
const model = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit("update:modelValue", value);
  },
});
</script>
