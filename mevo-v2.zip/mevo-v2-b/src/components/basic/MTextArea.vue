<template>
  <div>
    <div class="flex justify-between items-end">
      <label
        :for="name"
        class="block text-sm font-medium leading-6 text-gray-900"
        >{{ label }}</label
      >
    </div>
    <div class="text-gray-500 text-sm">{{ description }}</div>
    <div
      class="relative rounded-md shadow-sm"
      :class="[(label || description) && 'mt-2']"
    >
      <textarea
        :rows="`${rows}`"
        :disabled="disabled"
        :id="name"
        :name="name"
        v-model="model"
        :placeholder="placeholder"
        class="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
        :class="[disabled && 'cursor-not-allowed bg-gray-100']"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from "vue";
import { createDebounce } from "@/utils/helpers";

export interface MTextInputProps {
  disabled?: boolean;
  label?: string;
  description?: string;
  removable?: boolean;
  rows: number;
  rules?: string;
  name?: string;
  type: string;
  placeholder?: string;
  modelValue: string;
}

const timeout = ref(null);
const props = withDefaults(defineProps<MTextInputProps>(), {
  type: "text",
  disabled: false,
  rows: 4,
  removable: false,
});

const $emits = defineEmits(["update:modelValue", "remove"]);
const model = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    createDebounce(timeout)(() => {
      $emits("update:modelValue", value);
    });
  },
});
</script>
