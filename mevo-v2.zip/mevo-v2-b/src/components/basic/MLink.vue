<template>
  <router-link v-if="href" :to="href">
    <div class="underline cursor-pointer text-sm">
      {{ label }}
    </div>
  </router-link>
  <div v-else class="underline cursor-pointer text-sm" @click="clicked()">
    {{ label }}
  </div>
</template>

<script lang="ts">
export default {
  props: {
    label: {
      type: String,
      required: true,
    },
    href: {
      type: String,
      required: false,
    },
  },
  emits: ['clicked'],
  methods: {
    clicked() {
      this.$emit('clicked')
    },
  },
}
</script>
