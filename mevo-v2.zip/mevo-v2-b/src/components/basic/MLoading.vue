<template>
  <div class="flex w-fit bg-gray-100 rounded-2xl px-4 py-2">
    <span class="flex items-center h-3 w-3 mx-1">
      <span
        class="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-gray-400 opacity-75"
      ></span>
      <span
        class="relative inline-flex rounded-full h-2 w-2 bg-gray-400"
      ></span>
    </span>
    <span class="flex items-center h-3 w-3 mx-1">
      <span
        class="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-gray-400 opacity-75"
      ></span>
      <span
        class="relative inline-flex rounded-full h-2 w-2 bg-gray-400"
      ></span>
    </span>
    <span class="flex items-center h-3 w-3 mx-1">
      <span
        class="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-gray-400 opacity-75"
      ></span>
      <span
        class="relative inline-flex rounded-full h-2 w-2 bg-gray-400"
      ></span>
    </span>
  </div>
</template>
