<template>
  <div>
    <label
      v-if="label"
      :for="elementKey"
      class="block text-sm font-medium leading-6 text-gray-900"
      >{{ label }}</label
    >
    <div v-if="description" class="text-gray-500 text-sm">
      {{ description }}
    </div>
    <select
      :disabled="disabled"
      v-model="model"
      :id="elementKey"
      :name="elementKey"
      class="mt-2 w-full rounded-md p-2 text-gray-900 ring-1 ring-inset ring-gray-300"
      :class="[disabled && 'cursor-not-allowed']"
    >
      <option :value="option.value" v-for="option in options">
        {{ option.label }}
      </option>
    </select>
  </div>
</template>

<script lang="ts" setup>
import { computed } from "vue";

export interface MSelectProps {
  label?: string;
  elementKey: string;
  options: { value: any; label: string }[];
  modelValue: any;
  description?: string;
  disabled?: boolean;
}

const props = withDefaults(defineProps<MSelectProps>(), {
  disabled: false,
});
const $emits = defineEmits(["update:modelValue"]);

const model = computed({
  get() {
    return props.modelValue;
  },
  set(value: any) {
    $emits("update:modelValue", value);
  },
});
</script>
