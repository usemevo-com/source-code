<template>
  <section>
    <div class='bg-white shadow sm:rounded-lg'>
      <div class='px-4 py-5 sm:p-6'>
        <slot></slot>
      </div>
      <div v-if="hasFooter" class='px-4 py-3 bg-gray-50 text-right sm:px-6 rounded-b-lg'>
        <slot name="footer"></slot>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  props: {
    hasFooter: {
      type: Boolean,
      default: false,
    },
  },
})
</script>