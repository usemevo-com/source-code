<template>
  <fieldset v-bind="$attrs" class="px-4">
    <slot></slot>
  </fieldset>
</template>
