<template>
  <div
    v-bind="$attrs"
    :class="[
      fixed && `w-[45px] !px-0`,
      `px-2 rounded bg-${color}-100 text-xs font-semibold py-0.5 text-center text-${color}-800`,
    ]"
  >
    {{ text }}
  </div>
  <!-- bg-yellow-100 bg-blue-100 bg-red-100 bg-green-100 -->
  <!-- text-yellow-800 text-blue-800 text-red-800 text-green-800 -->
</template>

<script lang="ts">
export default {
  props: {
    color: {
      type: String,
      default: 'blue',
    },
    fixed: {
      type: Boolean,
      default: false,
    },
    text: String,
  },
}
</script>
