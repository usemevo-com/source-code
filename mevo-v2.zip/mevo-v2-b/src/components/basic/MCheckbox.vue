<template>
  <fieldset class="space-y-2">
    <div class="relative flex items-start">
      <div class="flex h-5 items-center">
        <input
          :id="`${name}-checkbox-input`"
          :name="`${name}-checkbox-input`"
          type="checkbox"
          class="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          v-model="model"
        />
      </div>
      <div class="ml-3 text-sm">
        <label
          :for="`${name}-checkbox-input`"
          class="font-medium text-gray-700 block"
        >
          <div v-if="label">{{ label }}</div>
          <div v-else><slot></slot></div>
        </label>
        <label :for="`${name}-checkbox-input`" class="text-gray-500 block">
          {{ description }}
        </label>
      </div>
    </div>
  </fieldset>
</template>

<script lang="ts" setup>
import { computed } from "vue";

const props = defineProps({
  name: String,
  label: String,
  description: String,
  modelValue: Boolean,
});

const emit = defineEmits(["update:modelValue"]);
const model = computed({
  get() {
    return props.modelValue;
  },
  set(value) {
    emit("update:modelValue", value);
  },
});
</script>
