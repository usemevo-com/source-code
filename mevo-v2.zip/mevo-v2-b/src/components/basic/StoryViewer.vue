<template>
  <div class="grid items-start w-full h-full gap-4 grid-cols-1 lg:[grid-template-columns:1fr_220px]">
    <div class="relative flex flex-col items-center justify-start h-full">
      <div
        class="relative h-[90vh] aspect-[9/16] bg-black rounded-xl overflow-hidden shadow-2xl mt-[5vh]"
        @mouseenter="pause()"
        @mouseleave="resume()"
      >
        <div class="absolute z-10 flex w-auto gap-1 pointer-events-none top-2 left-2 right-2">
          <div
            v-for="(s, i) in stories"
            :key="`progress-${i}`"
            class="flex-1 h-[3px] bg-white/35 rounded-full overflow-hidden"
          >
            <div
              class="h-full bg-white transition-all duration-100 ease-linear"
              :style="{ width: `${progressWidthFor(i)}%` }"
            />
          </div>
        </div>

        <img
          v-if="currentStory"
          class="w-full h-full object-cover select-none"
          :src="currentStory.src"
          :alt="currentStory.alt || `story-${currentIndex}`"
          draggable="false"
        />

        <button
          class="absolute inset-y-0 left-0 w-1/2 cursor-pointer bg-transparent [appearance:none] outline-none"
          @click="prev()"
          aria-label="Previous"
        />
        <button
          class="absolute inset-y-0 right-0 w-1/2 cursor-pointer bg-transparent [appearance:none] outline-none"
          @click="next()"
          aria-label="Next"
        />

        <div class="absolute inset-x-2 bottom-2 flex items-center">
          <button class="bg-black/50 text-white border border-white/20 px-3 py-1.5 rounded-lg" @click="prev()">‹</button>
          <div class="flex-1" />
          <button class="bg-black/50 text-white border border-white/20 px-3 py-1.5 rounded-lg" @click="togglePause()">{{ isPaused ? '▶' : '⏸' }}</button>
          <div class="flex-1" />
          <button class="bg-black/50 text-white border border-white/20 px-3 py-1.5 rounded-lg" @click="next()">›</button>
        </div>
      </div>
    </div>
  </div>
  
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'

export type StoryItem = {
  src: string
  alt?: string
  thumb?: string
  id?: string | number
}

const props = defineProps<{
  stories: StoryItem[]
  autoPlayMs?: number
  startIndex?: number
  showNextCount?: number
  loop?: boolean
}>()

const emit = defineEmits<{
  (e: 'change', index: number): void
}>()

const AUTO_MS = computed(() => Math.max(1000, props.autoPlayMs ?? 4000))
const SHOW_NEXT = computed(() => Math.max(0, props.showNextCount ?? 4))
const SHOULD_LOOP = computed(() => props.loop ?? true)

const currentIndex = ref(Math.min(Math.max(props.startIndex ?? 0, 0), Math.max(props.stories.length - 1, 0)))
const isPaused = ref(false)
const progressMs = ref(0)
let rafId: number | null = null
let lastTs = 0

const currentStory = computed(() => props.stories[currentIndex.value])

const nextStories = computed(() => {
  const start = currentIndex.value + 1
  const endExclusive = Math.min(props.stories.length, start + SHOW_NEXT.value)
  return props.stories.slice(start, endExclusive)
})

function progressWidthFor(i: number): number {
  if (i < currentIndex.value) return 100
  if (i > currentIndex.value) return 0
  return Math.min(100, (progressMs.value / AUTO_MS.value) * 100)
}

function tick(ts: number) {
  if (isPaused.value) {
    lastTs = ts
  } else {
    if (lastTs === 0) lastTs = ts
    const delta = ts - lastTs
    lastTs = ts
    progressMs.value += delta
    if (progressMs.value >= AUTO_MS.value) {
      progressMs.value = 0
      next()
    }
  }
  rafId = requestAnimationFrame(tick)
}

function start() {
  stop()
  progressMs.value = 0
  lastTs = 0
  rafId = requestAnimationFrame(tick)
}

function stop() {
  if (rafId !== null) {
    cancelAnimationFrame(rafId)
    rafId = null
  }
}

function pause() {
  isPaused.value = true
}

function resume() {
  isPaused.value = false
}

function togglePause() {
  isPaused.value = !isPaused.value
}

function jumpTo(index: number) {
  const clamped = Math.min(Math.max(index, 0), props.stories.length - 1)
  if (clamped === currentIndex.value) return
  currentIndex.value = clamped
  progressMs.value = 0
  emit('change', currentIndex.value)
}

function next() {
  const atLast = currentIndex.value >= props.stories.length - 1
  if (atLast) {
    if (SHOULD_LOOP.value) {
      currentIndex.value = 0
    } else {
      pause()
      return
    }
  } else {
    currentIndex.value += 1
  }
  progressMs.value = 0
  emit('change', currentIndex.value)
}

function prev() {
  const atFirst = currentIndex.value <= 0
  if (atFirst) {
    if (SHOULD_LOOP.value) {
      currentIndex.value = Math.max(props.stories.length - 1, 0)
    } else {
      return
    }
  } else {
    currentIndex.value -= 1
  }
  progressMs.value = 0
  emit('change', currentIndex.value)
}

onMounted(() => {
  start()
  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'ArrowRight') next()
    if (e.key === 'ArrowLeft') prev()
    if (e.code === 'Space') togglePause()
  }
  window.addEventListener('keydown', onKey)
  onBeforeUnmount(() => window.removeEventListener('keydown', onKey))
})

onBeforeUnmount(() => {
  stop()
})

watch(
  () => props.stories,
  (arr) => {
    if (!arr || arr.length === 0) {
      pause()
      stop()
    } else if (currentIndex.value >= arr.length) {
      currentIndex.value = arr.length - 1
      progressMs.value = 0
      start()
    }
  },
  { deep: true }
)
</script>


