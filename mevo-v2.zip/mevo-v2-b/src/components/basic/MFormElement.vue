<template>
  <div class="flex flex-col mb-6">
    <slot></slot>
  </div>
</template>
