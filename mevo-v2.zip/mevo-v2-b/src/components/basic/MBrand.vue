<template>
  <span v-if="short">
    <img class="w-10" src="/mevo.png" />
  </span>
  <span v-else class="flex items-center font-bold text-black text-2xl">
    <img src="/mevo.png" />
  </span>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  props: {
    short: {
      type: Boolean,
      default: false
    }
  }
})
</script>
