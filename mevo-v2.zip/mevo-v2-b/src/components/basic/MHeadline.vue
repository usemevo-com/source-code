<template>
  <div class="flex flex-col" :class="[center && 'items-center']">
    <div class="font-bold text-xl w-full" :class="[center && 'text-center']">
      {{ title }}
    </div>
    <p
      class="text-gray-500 text-sm sm:w-full w-72 text-overflow"
      :class="[center && 'text-center', moreSpace && 'mt-6']"
    >
      {{ description }}
    </p>
  </div>
</template>

<script lang="ts" setup>
export interface MHeadlineProps {
  title: string;
  description?: string;
  center?: boolean;
  moreSpace?: boolean;
}

withDefaults(defineProps<MHeadlineProps>(), {
  center: false,
  moreSpace: false,
});
</script>
