<template>
  <div>
    <div class="flex justify-between items-end">
      <label for="email" class="block text-sm font-medium leading-6 text-gray-900">{{
        label
      }}</label>
      <ErrorMessage :name="name" v-slot="{ message }">
        <p class="text-sm text-red-600" id="email-error">
          {{ message }}
        </p>
      </ErrorMessage>
    </div>
    <div class="text-gray-500 text-sm">{{ description }}</div>
    <div class="relative rounded-md shadow-sm" :class="[(label || description) && 'mt-2']">
      <Field
        @keyup.enter="$emit('enter')"
        :rules="rules"
        :disabled="disabled"
        :id="name"
        :name="name"
        :type="type"
        autocomplete="off"
        :class="{
          'cursor-not-allowed bg-gray-100': disabled
        }"
        class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
        :placeholder="placeholder"
        v-model="model"
      />
      <div
        @click="$emits('clicked-badge')"
        v-if="badge"
        class="absolute top-[9px] right-[48px] text-sm bg-black text-white font-medium px-4 rounded-full cursor-pointer"
        v-html="badge"
      ></div>
      <ErrorMessage :name="name" v-slot="{ message }">
        <div
          v-if="message"
          class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3"
        >
          <exclamation-circle-icon class="h-5 w-5 text-red-500" aria-hidden="true" />
        </div>
      </ErrorMessage>
      <div
        v-if="removable"
        @click="$emits('remove')"
        class="cursor-pointer absolute inset-y-0 right-0 flex items-center pr-3"
      >
        <x-mark-icon class="h-5 w-5 text-red-500" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import { Field, ErrorMessage } from 'vee-validate'
import { createDebounce } from '@/utils/helpers'
import { ExclamationCircleIcon, XMarkIcon } from '@heroicons/vue/24/outline'

export interface MTextInputProps {
  disabled?: boolean
  label?: string
  description?: string
  removable?: boolean
  rules?: string
  name?: string
  type?: string
  placeholder?: string
  modelValue: string
  badge?: string
}

const timeout = ref(null)
const props = withDefaults(defineProps<MTextInputProps>(), {
  type: 'text',
  disabled: false,
  removable: false
})

const $emits = defineEmits(['update:modelValue', 'remove', 'clicked-badge'])
const model = computed({
  get() {
    return props.modelValue
  },
  set(value) {
    createDebounce(timeout)(() => {
      $emits('update:modelValue', value)
    })
  }
})
</script>
