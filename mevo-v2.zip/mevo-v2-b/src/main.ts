import { createApp } from 'vue'
import { vueDebounce } from 'vue-debounce'
import Vue3ColorPicker from 'vue3-colorpicker'
import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'
import ElementPlus from 'element-plus'
import { VueClipboard } from '@soerenmartius/vue3-clipboard'
import { QuillEditor } from '@vueup/vue-quill'
import GoogleSignInPlugin from 'vue3-google-signin'

import '@vueup/vue-quill/dist/vue-quill.snow.css'
import 'vue3-colorpicker/style.css'
import 'vue-multiselect/dist/vue-multiselect.css'

import App from './App.vue'
import router from './router'
import i18n from './utils/locales/i18n'
import appConfig from './utils/helpers/app-config'
import './utils/validation/validators'
// import 'maz-ui/css/main.css'
import 'element-plus/dist/index.css'
import './assets/style.css'
import './assets/tooltip.css'

const app = createApp(App)
app.component('QuillEditor', QuillEditor)

// TODO: Fix this ts-ignore
// @ts-ignore
app.config.globalProperties = appConfig

const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)

app.use(GoogleSignInPlugin, {
  clientId: '999393968400-htujr68amrhogn58bg7h4m7i4hoae8mj.apps.googleusercontent.com'
})
app.use(pinia)
app.use(router)
app.use(i18n)
app.use(ElementPlus)
app.use(VueClipboard)
app.use(Vue3ColorPicker)
app.directive('debounce', vueDebounce({ lock: true }))
app.mount('#app')
