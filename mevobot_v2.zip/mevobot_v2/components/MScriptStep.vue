<template>
  <!-- 
      bg-gray-500 bg-blue-500 bg-pink-500 bg-yellow-500 bg-green-500 bg-purple-500 bg-red-500  bg-indigo-500
      bg-gray-100 bg-blue-100 bg-pink-100 bg-yellow-100 bg-green-100 bg-purple-100 bg-red-100  bg-indigo-100
      border-gray-500 border-blue-500 border-pink-500 border-yellow-500 border-green-500 border-purple-500 border-red-500 border-indigo-500
      text-gray-500 text-blue-500 text-pink-500 text-yellow-500 text-green-500 text-purple-500 text-red-500 text-indigo-500
      text-gray-700 text-blue-700 text-pink-700 text-yellow-700 text-green-700 text-purple-700 text-red-700 text-indigo-700
      hover:bg-gray-500 hover:bg-blue-500 hover:bg-purple-500 hover:bg-green-500 hover:bg-yellow-500 hover:bg-pink-500 hover:bg-red-500 hover:bg-indigo-500
      hover:border-gray-500 hover:border-blue-500 hover:border-purple-500 hover:border-green-500 hover:border-yellow-500 hover:border-pink-500 hover:border-red-500 hover:border-indigo-500 -->
  <div
    class="flex items-end px-6 space-x-4"
    :class="[primary && 'justify-start', !primary && 'justify-end']"
  >

    <img
      v-if="primary && hasBrandImage"
      :src="image"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200"
    />
    <!-- <div
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200"
      v-else-if="primary && !hasBrandImage"
    ></div> -->

    <div class="flex flex-col flex-1" :class="[primary && 'items-start', !primary && 'items-end']">
      <div
        class="rounded-xl px-5 py-4 w-fit text-sm"
        :class="[
          primary && 'bg-[#ecf0f1]',
          !primary && `bg-${theme}-600 text-white`,
        ]"
        id="message-content"
        v-html="cleanMessage"
      ></div>

      <div class="flex w-full flex-wrap">
        <div
          @click="
            () => {
              onOptionSelect(option);
            }
          "
          class="text-sm px-4 py-2 border h-fit rounded-xl font-medium w-fit mt-2 cursor-pointer"
          :class="[
            !option && 'hidden',
            `border-${theme}-500 text-${theme}-700`,
            selected && '!cursor-not-allowed',
            !selected &&
              `hover:bg-${theme}-500 hover:border-${theme}-500 hover:text-white`,
          ]"
          :key="index"
          v-for="(option, index) in step.data.options"
        >
          {{ option }}
        </div>
        <div
          v-if="step.isSkippable"
          @click="onStepSkip"
          class="text-sm px-4 py-2 border h-fit rounded-xl font-medium w-fit mt-2 cursor-pointer mx-1"
          :class="[
            step.data.options.length < 2 && !step.data.options[0] && 'mt-2',
            `border-${theme}-500 text-${theme}-700`,
            selected && 'cursor-not-allowed',
            !selected &&
              `hover:bg-${theme}-500 hover:border-${theme}-500 hover:text-white`,
          ]"
        >
          Skip this question
        </div>
      </div>
    </div>

    <!-- <div
      v-if="!primary"
      class="w-8 h-8 rounded-lg mb-2 flex items-center justify-center"
      :class="`bg-${theme}-500`"
    >
      <i class="fa fa-user text-sm text-white"></i>
    </div> -->
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, computed } from "vue";
import VueMarkdown from "vue-markdown-render";
import { BotType } from "@/modules/bot/types/IBot";
import { ScriptStepType } from "@/modules/bot/types/IScriptStep";

const props = defineProps({
  image: String,
  step: {
    type: Object,
    required: true,
    default: () => ({
      data: {
        message: "",
        options: [""],
      },
      isSkippable: false,
      type: "",
    }),
  },
  preventMarkdown: {
    type: Boolean,
    required: false,
    default: false,
  },
  type: {
    type: String,
    required: true,
    default: BotType.SCRIPTED,
  },
  primary: {
    type: Boolean,
    default: false,
  },
  activeStep: {
    type: Number,
    required: true,
  },
  stepIndex: {
    type: Number,
    required: true,
  },
  theme: {
    type: String,
    required: true,
    default: "",
  },
  sender: {
    type: String,
  },
  lastStep: {
    type: Number,
    required: true,
  },
  hideBranding: {
    type: Boolean,
    default: false,
  }
});
const emit = defineEmits(["next", "skip"]);
const selected = ref(false);
const isOptionVisible = ref(false);

const onOptionSelect = function (option: string) {
  if (!selected.value) {
    selected.value = true;
    isOptionVisible.value = false;
    emit("next", option);
  }
};

// function convertLinksToMarkdown(text) {
//   // Regular expression to match URLs
//   var urlRegex = /https:\/\/[\w\.\/#-]+(?=\b|\.)/g;

//   // Replace URLs with Markdown link format with target="_blank"
//   var markdownText = text.replace(urlRegex, function (url) {
//     // return `[${url}](${url}){:target="_blank"}`;
//     return `<a class="underline text-blue-700 font-medium" href="${url}" target="_blank">${url.split("https://")[1]} <i class="fa-regular fa-arrow-up-right-from-square"></i></a>`;
//   });

//   return markdownText;
// }

const cleanMessage = computed(() => {
  if (typeof props.step.data.message !== "string") {
    return props.step.data.message;
  } else {
    return props.step.data.message.replaceAll("__MEVO__", "");
  }
});

const hasBrandImage = computed(
  () => props.image !== "" && props.image !== "https://placehold.co/150x150"
);

const onStepSkip = function () {
  selected.value = true;
  isOptionVisible.value = false;
  emit("next", "Skip");
};

onMounted(() => {
  if (props.step.type === ScriptStepType.MESSAGE) {
    setTimeout(() => {
      emit("next");
    }, 750);
  }

  document.querySelectorAll(".message-item a").forEach((el) => {
    el.setAttribute("target", "_blank");
  });

  setTimeout(() => {
    isOptionVisible.value = true;
  }, 1250);
});
</script>

<style>
.message-item a {
  text-decoration: underline !important;
  color: #3182ce !important;
}
</style>
