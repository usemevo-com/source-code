<template>
  <Form @submit="onPressedEnter">
    <template v-slot="{ meta }">
      <div
        :class="[
          meta.touched && !meta.valid && 'h-[90px] border-t-0 border-gray-100',
          meta.valid && 'h-[60px] border-t border-gray-100',
        ]"
        class="relative w-full flex flex-col items-center justify-center"
      >
        <ErrorMessage
          v-if="!meta.valid"
          name="WidgetTextInput"
          v-slot="{ message }"
        >
          <div class="h-[36px] flex items-center">
            <TriangleAlert
              class="text-amber-500 w-4 h-4 inline-block mr-2"
            />
            <div>{{ message }}</div>
          </div>
        </ErrorMessage>
        <div
          @click="
            () => {
              if (meta.valid) {
                onPressedEnter();
                meta.touched = true;
              }
            }
          "
          class="p-3 rounded-full bg-gray-100 hover:bg-gray-200 right-4 absolute cursor-pointer z-[999]"
          :class="[
            meta.touched && !meta.valid && 'bottom-[6px]',
            meta.valid && 'bottom-[8px]',
          ]"
        >
          <SendHorizontal 
            class="text-gray-500 w-5 h-5"
            stroke-width="1.5"
          />
        </div>
        <el-date-picker
          v-if="type === ScriptStepType.DATE"
          v-model="message"
          type="date"
          placeholder="22.12.2021"
          size="large"
          class="!w-full !h-[59px] border-t border-gray-100"
          format="DD.MM.YYYY"
          value-format="DD MMMM YYYY"
        />
        <el-input-number
          v-else-if="type === ScriptStepType.NUMBER"
          v-model="message"
          :min="0"
          size="large"
          class="!h-[59px] border-t border-gray-100"
        />
        <MazPhoneNumberInput
          @keydown.enter="onPressedEnter"
          v-else-if="type === ScriptStepType.PHONE_NUMBER"
          v-model="message"
          color="info"
          class="w-full"
          orientation="row"
          @update="results = $event"
          :success="results?.isValid"
        />
        <Field
          v-else-if="mode === 'GPT'"
          :disabled="disabled"
          id="widget-text-input"
          name="WidgetTextInput"
          :placeholder="inputPlaceholder"
          v-model="message"
          class="w-full h-[59px] !outline-none !outline-0 pl-4 pr-[80px] sm:px-4 border-t border-gray-100 text-base"
          :class="[meta.touched && !meta.valid && 'border-t border-gray-100']"
          autocomplete="off"
          v-slot="{ field }"
        >
          <textarea
            :disabled="disabled"
            class="!ring-0 pr-16 pt-4 border-none w-full h-full resize-none !outline-none !outline-0 text-[16px]"
            :class="[disabled && 'bg-gray-50']"
            v-bind="field"
            :rows="rows"
            @input="adjustTextarea"
            @keydown="handleKeydown"
            :placeholder="inputPlaceholder"
          ></textarea>
        </Field>
        <Field
          v-else
          :rules="TypeRuleMap[type]"
          id="widget-text-input"
          name="WidgetTextInput"
          :placeholder="inputPlaceholder"
          v-model="message"
          class="w-full h-[59px] !outline-none !outline-0 pl-4 pr-[80px] sm:px-4 border-t border-gray-100"
          :class="[meta.touched && !meta.valid && 'border-t border-gray-100']"
          autocomplete="off"
        />
      </div>
    </template>
  </Form>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import { SendHorizontal, TriangleAlert } from 'lucide-vue-next';
import { Form, Field, ErrorMessage } from "vee-validate";
import { ScriptStepType } from "@/modules/bot/types/IScriptStep";
import { useStepValidation } from "@/composables/useStepValidation";

const props = defineProps({
  type: {
    type: String,
    default: ScriptStepType.MESSAGE,
  },
  mode: {
    type: String,
    default: "SCRIPTED",
  },
  inputPlaceholder: {
    type: String,
    default: "Type your message",
  },
  disabled: {
    type: Boolean,
    default: false,
  },
});
const $emits = defineEmits(["submit", "error"]);
const { TypeRuleMap } = useStepValidation();
const message = ref("");
const results = ref();
const rows = ref(1);

const onPressedEnter = function () {
  if (props.type === ScriptStepType.PHONE_NUMBER && !results.value?.isValid) {
    return;
  }
  if (!message.value) {
    return;
  }
  $emits("submit", message.value);
  message.value = "";
  setTimeout(() => {
    message.value = "";
  }, 100);
};

const adjustTextarea = (event) => {
  const lines = event.target.value.split("\n").length;
  rows.value = lines;
};

const handleKeydown = (event: any) => {
  if (!event.shiftKey && event.key === "Enter") {
    // Prevent default behavior if you don't want a new line to be added
    event.preventDefault();

    onPressedEnter();
  }
};

const onAppend = function (value: string) {
  message.value += value;
};
</script>

<style>
.el-input__wrapper {
  box-shadow: none !important;
}
.el-input__inner,
.el-input__inner:focus,
.el-input__inner:hover {
  outline: none !important;
  border: none !important;
  --tw-ring-color: transparent !important;
}
.m-input-wrapper {
  border-color: white !important;
}
.m-input-wrapper-right {
  border-right-color: gray !important;
}

:root {
  --el-color-primary: #6366f1 !important;
}
</style>
