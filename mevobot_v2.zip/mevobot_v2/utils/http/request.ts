import { Result, ok, err } from "neverthrow";

const API_ROOT = "http://localhost/api";

export interface GenericResponse<T = any> {
  message?: string;
  code?: number;
  payload?: T;
}

export enum HTTPMethods {
  GET = "GET",
  POST = "POST",
  PUT = "PUT",
  PATCH = "PATCH",
  DELETE = "DELETE",
}

export type HTTPResultAsync<T = any> = Promise<
  Result<GenericResponse<T>, Error>
>;

class HTTPError extends Error {
  constructor(public message: string) {
    super(message);
  }
}

export async function sendHTTPRequest(
  method: HTTPMethods,
  endpoint: string,
  body?: object,
  headers?: object,
  files?: { [x: string]: File }
): Promise<GenericResponse> {
  const requestOptions: any = {
    method,
    headers: {},
  };

  if (!files) {
    requestOptions.headers["Content-Type"] = "application/json";
  }

  if (files && Object.keys(files).length) {
    const formData = new FormData();
    Object.keys(files).forEach((key) => formData.append(key, files[key]));
    if (body) {
      Object.keys(body).forEach((key) => {
        formData.append(key, (body as any)[key]);
      });
    }
    requestOptions.body = formData;
  } else if (body) {
    requestOptions.body = JSON.stringify(body);
  }

  if (typeof headers !== "undefined") {
    requestOptions.headers = { ...requestOptions.headers, headers };
  }

  const response = await fetch(`${API_ROOT}${endpoint}`, requestOptions);

  let parsedResponse: {
    message?: string;
    status?: string;
  };

  try {
    parsedResponse = await response.json();
  } catch {
    parsedResponse = {};
  }

  if (response.status === 401) {
    // TODO: end session
    // TODO: show notification user for invalid or expired token
  }

  if (response.status < 200 || response.status >= 400) {
    throw new HTTPError(`${parsedResponse.message}`);
  }

  return {
    code: response.status,
    payload: parsedResponse,
  };
}

export async function send(
  method: HTTPMethods,
  endpoint: string,
  body?: object,
  headers?: object,
  files?: { [x: string]: File }
) {
  try {
    const nativeHTTPResponse = await sendHTTPRequest(
      method,
      endpoint,
      body,
      headers,
      files
    );
    const ntedHTTPResponse = ok(nativeHTTPResponse);
    return ntedHTTPResponse;
  } catch (ex) {
    return err(ex as Error);
  }
}
