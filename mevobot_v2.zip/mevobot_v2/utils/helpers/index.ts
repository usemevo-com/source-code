import type { Ref } from "vue";

export const createDebounce = function (timeout: Ref<any>) {
  return function (fnc: Function, delayMs?: number) {
    clearTimeout(timeout.value);
    timeout.value = setTimeout(() => {
      fnc();
    }, delayMs || 500);
  };
};

export enum BuilderTabKey {
  KNOWLEDGE = "knowledge",
  SETTINGS = "settings",
  PREVIEW = "preview",
}

export const builderTabs = [
  {
    label: "Knowledge",
    key: BuilderTabKey.KNOWLEDGE,
    current: true,
    hide: false,
  },
  {
    label: "Settings",
    key: BuilderTabKey.SETTINGS,
    current: false,
    hide: false,
  },
  {
    label: "Preview",
    key: BuilderTabKey.PREVIEW,
    current: false,
    hide: false,
  },
];

export enum TextSource {
  INPUT = "input",
  FILE = "file",
}
