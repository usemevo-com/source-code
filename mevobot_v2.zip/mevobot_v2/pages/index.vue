<template>
  <div class="flex justify-center items-center w-full h-screen">
    <!-- <i class="fa-thin fa-spinner-third animate-spin text-4xl text-gray-500"></i> -->
  </div>
</template>

<script lang="ts" setup>
import { onMounted } from "vue";
import { useRouter } from "vue-router";
import { getBotByDomain } from "@/modules/bot/services/BotService";
import { type IBot } from "@/modules/bot/types/IBot";

const $router = useRouter();

onMounted(async () => {
  const domain = window.location.hostname;

  if (domain !== "bot.usemevo.com" && domain !== "app.usemevo.com") {
    const domainCheckResponse = await getBotByDomain({
      domain,
    });

    if (domainCheckResponse.isOk()) {
      const bot: IBot = domainCheckResponse.value.payload;

      $router.push({
        name: "id-welcome",
        params: {
          id: bot._id,
        },
      });
    } else {
      window.location.href = "https://usemevo.com";
    }
  } else {
    window.location.href = "https://usemevo.com";
  }
});
</script>
