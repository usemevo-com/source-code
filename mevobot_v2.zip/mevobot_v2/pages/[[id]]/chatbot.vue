<template>
  <div class="h-dvh w-screen bg-white flex justify-center items-center relative">
    <!-- 
    from-gray-100 to-gray-300
    from-red-100 to-red-300
    from-yellow-100 to-yellow-300
    from-green-100 to-green-300
    from-blue-100 to-blue-300
    from-indigo-100 to-indigo-300
    from-purple-100 to-purple-300
    from-pink-100 to-pink-300
    -->
    <div
      v-if="chatbot_state.is_error_occurred"
      class="flex justify-center items-center w-full h-dvh border"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div>
          <div class="text-black font-medium text-lg">Error</div>
          <div
            class="text-gray-500 font-light text-sm"
            v-if="chatbot_state.error_message"
          >
            {{ chatbot_state.error_message }}
          </div>
          <div v-else class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <div
      v-else-if="chatbot_state.is_bot_data_loading"
      class="flex justify-center items-center w-full h-dvh"
    >
      <!-- <i
        class="fa-thin fa-spinner-third animate-spin text-4xl text-gray-500"
      ></i> -->
    </div>
    <div
      v-else
      class="flex flex-col justify-between sm:w-[750px] w-full h-full sm:h-[750px] relative"
    >
      <div
        class="w-full py-5 px-6 flex items-center justify-between rounded-t-xl"
      >
        <!-- <div
          v-if="!fallback.appearance.skipWelcomePage"
          @click="on_back"
          class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer bg-gray-50 hover:bg-gray-100"
        >
          <i class="fa-solid fa-chevron-left text-white text-xl"></i>
        </div> -->

        <div
          class="font-semibold antialiased flex flex-col justify-end flex-1 items-start"
        >
          <div class="text-xl">{{ chatbot_state.bot.appearance.title }}</div>
          <div class="text-gray-500 font-light text-sm">{{ chatbot_state.bot.appearance.description }}</div>
        </div>
        <div class="flex space-x-2">
          <div
            @click="on_reset"
            class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer bg-[#ecf0f1] hover:bg-gray-200"
          >
            <Motion v-if="chatbot_state.is_restarting" :transition="{ duration: 0.5 }" :animate="{ rotate: 360 }"><RefreshCcw stroke-width="1.5" class="text-gray-500 w-5 h-5" /></Motion>
            <RefreshCcw stroke-width="1.5" v-else class="text-gray-500 w-5 h-5" />
          </div>
          <div
            v-if="chatbot_state.show_close"
            @click="post_message('chatbox-closed')"
            class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer bg-[#ecf0f1] hover:bg-gray-200"
          >
            <X stroke-width="1.5" class="text-gray-500 w-5 h-5" />
          </div>
        </div>
      </div>
      <div
        class="flex-1 overflow-y-auto space-y-4 py-4 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
        id="message-container"
      >
        <Motion
          v-for="(step, index) in chatbot_state.scene.steps"
          :key="index"
          :initial="{ opacity: 0, y: -15 }"
          :animate="{ opacity: 1, y: 0 }"
          :transition="{ delay: 0.5, duration: 0.5 }" 
          >
          <m-script-step
            :key="index"
            :theme="fallback.appearance.theme"
            :step="step"
            :primary="step && typeof step.response === 'undefined'"
            :active-step="chatbot_state.active_step"
            :step-index="index"
            :last-step="chatbot_state.scene.steps.length - 1"
            @next="on_next"
            @skip="on_skip"
            :image="fallback.appearance.brandImage"
            :hide-branding="chatbot_state.bot.appearance.hideBranding"
          />
        </Motion>
      </div>
      <div class="w-full relative">
        <widget-input
          class="w-full h-full text-sm ring-none focus:ring-none outline-none rounded-b-xl"
          :input-placeholder="fallback.appearance.placeholderText"
          :type="chatbot_state.bot.script.steps[chatbot_state.active_step].type"
          @submit="on_text_submit"
          v-if="!input_disabled"
        />
      </div>

      <div
        v-if="chatbot_state.bot && chatbot_state.bot.appearance && !chatbot_state.bot.appearance.hideBranding"
        class="sm:hidden text-xs py-2 w-full flex items-center justify-center space-x-2 border-t border-gray-100"
      >
        <!-- <i class="fa-solid fa-bolt text-amber-500"></i> -->
        <span class="text-gray-500 font-light"
          >runs on
          <a href="https://usemevo.com" target="_blank"
            ><span class="font-bold text-black">mevo</span></a
          ></span
        >
      </div>
    </div>
    <div v-if="chatbot_state.bot && chatbot_state.bot.appearance && !chatbot_state.bot.appearance.hideBranding" class="absolute bottom-8 left-8 px-4 py-2 rounded-xl w-fit justify-center items-center bg-gray-100 hidden sm:flex">
      runs on <a class="font-bold ml-1" href="https://usemevo.com" target="_blank">mevo</a>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, computed } from "vue";
import { RefreshCcw, X } from 'lucide-vue-next';
import { useRoute, useRouter } from "vue-router";
import { v4 as uuidv4 } from "uuid";
import {
  get_bot_public,
  createUserResponse,
  sendBotEvent,
} from "../../modules/bot/services/BotService";
import { BotEventType, type IBot } from "../../modules/bot/types/IBot";
import MScriptStep from "../../components/MScriptStep.vue";
import WidgetInput from "../../components/WidgetInput.vue";

enum ScriptStepType {
  MESSAGE = "builder.MESSAGE_STEP_TYPE",
  QUESTION_TEXT = "builder.QUESTION_TEXT_STEP_TYPE",
  EMAIL = "builder.EMAIL_STEP_TYPE",
  PHONE_NUMBER = "builder.PHONE_NUMBER_STEP_TYPE",
  NUMBER = "builder.NUMBER_STEP_TYPE",
  SINGLE_SELECT = "builder.SINGLE_SELECT_STEP_TYPE",
  YES_NO = "builder.YES_NO_STEP_TYPE",
  URL = "builder.URL_STEP_TYPE",
  DATE = "builder.DATE_STEP_TYPE",
  USERNAME = "builder.USERNAME_STEP_TYPE",
  // placeholder only
  RESPONSE = "User response",
}

interface IScriptStep {
  description?: string;
  data: {
    message: string;
    options: string[];
    jumps: string[];
  };
  id?: string;
  stepId?: string;
  type: ScriptStepType;
  isSkippable?: boolean;
  hasOption?: boolean;
  isManualInputAllowed?: boolean;
  response?: boolean;
  index?: number;
}
// state
interface ChatbotState {
  bot: IBot;
  fetched_bot_data: IBot;
  response: {
    value: string;
    id: string;
  }[];
  scene: {
    steps: IScriptStep[];
  };
  active_step: number;
  skips: string[];
  is_error_occurred: boolean;
  error_message: string;
  is_loading: boolean;
  is_bot_data_loading: boolean;
  is_completed: boolean;
  is_bot_reset_blocked: boolean;
  show_close: boolean;
  is_restarting: boolean;
}

const chatbot_state: ChatbotState = reactive({
  bot: {} as IBot,
  fetched_bot_data: {} as IBot,
  response: [],
  scene: {
    steps: [],
  },
  active_step: 0,
  skips: [],
  is_error_occurred: false,
  error_message: "",
  is_loading: false,
  is_bot_data_loading: true,
  is_completed: false,
  is_bot_reset_blocked: false,
  show_close: false,
  is_restarting: false,
});

const fallback = {
  meta: {
    title: "AI Assistant",
    description: "Start a conversation with our AI assistant",
    keywords: "AI, Assistant, Chatbot",
    og_image: "",
  },
  appearance: {
    placeholderText: "Type a message...",
    brandImage: "https://images.unsplash.com/photo-1596367407372-96cb88503db6",
    theme: "blue",
    greeting: "Hello!",
    talkWithAgentMessage: "Talk with an agent",
    hideBranding: false,
    firstMessage: "Hello! How can I help you today?",
    skipWelcomePage: false,
  },
};

// hooks
const $route = useRoute();
const $router = useRouter();

// methods
const initialize = async function (id: string): Promise<void> {
  const bot_detail_response = await get_bot_public($route.params.id as string);

  if (bot_detail_response.isOk()) {
    if (bot_detail_response.value.payload.bot.config) {
      fallback.meta = bot_detail_response.value.payload.bot.config.meta;
    }

    if (bot_detail_response.value.payload.bot.appearance) {
      fallback.appearance = bot_detail_response.value.payload.bot.appearance;
    }

    useSeoMeta({
      title: fallback.meta.title,
      ogTitle: fallback.meta.title,
      description: fallback.meta.description,
      ogDescription: fallback.meta.description,
      ogImage: fallback.meta.og_image,
      twitterCard: "summary_large_image",
      keywords: fallback.meta.keywords,
    });

    useHead({
      link: [
        {
          rel: "icon",
          type: "image/x-icon",
          href: fallback.appearance.brandImage,
        },
      ],
    });

    chatbot_state.is_bot_data_loading = false;
    // mixpanel.track("view_bot", {
    //   id: botDetailResponse.value.payload._id,
    //   name: botDetailResponse.value.payload.name,
    //   organization: botDetailResponse.value.payload.organization.name,
    // });

    // if (!bot_detail_response.value.payload.isActive) {
    //   chatbot_state.is_error_occurred = true;
    //   return;
    // }

    // store bot data for cache
    chatbot_state.fetched_bot_data = bot_detail_response.value.payload;
    // assign to bot state
    chatbot_state.bot = bot_detail_response.value.payload.bot;
    // push first step into scene
    chatbot_state.scene.steps.push(
      chatbot_state.bot.script.steps[chatbot_state.active_step]
    );
    // set loading flag true and start flow
    if (
      chatbot_state.bot.script.steps[chatbot_state.active_step].type ===
      ScriptStepType.MESSAGE
    ) {
      chatbot_state.is_loading = true;
    }
  } else {
    chatbot_state.is_error_occurred = true;
    chatbot_state.error_message = "BOT_NOT_FOUND";
  }
};

// conversation restart event handler
const on_restart_conversation = async function (
  refetch: boolean = false
): Promise<void> {
  if (refetch) {
    await initialize($route.params.id as string);
  } else {
    chatbot_state.skips = [];
    // reset state to initial
    chatbot_state.bot = chatbot_state.fetched_bot_data;
    chatbot_state.response = [];
    chatbot_state.scene.steps = [];
    chatbot_state.active_step = 0;
    chatbot_state.is_error_occurred = false;
    chatbot_state.is_loading = false;
    chatbot_state.is_completed = false;
    // start flow
    chatbot_state.scene.steps.push(
      chatbot_state.bot.script.steps[chatbot_state.active_step]
    );
    chatbot_state.is_loading = true;
  }
};

const on_reset = function () {
  if (chatbot_state.is_bot_reset_blocked) {
    return;
  }

  chatbot_state.skips = [];
  chatbot_state.is_bot_reset_blocked = true;
  // reset state to initial
  // chatbot_state.bot = chatbot_state.fetched_bot_data;
  chatbot_state.response = [];
  chatbot_state.scene.steps = [];
  chatbot_state.active_step = 0;
  chatbot_state.is_error_occurred = false;
  chatbot_state.is_loading = false;
  chatbot_state.is_completed = false;
  // start flow
  chatbot_state.scene.steps.push(
    chatbot_state.bot.script.steps[chatbot_state.active_step]
  );

  setTimeout(() => {
    if (
      chatbot_state.bot.script.steps[chatbot_state.active_step].type ===
      ScriptStepType.MESSAGE
    ) {
      chatbot_state.is_loading = true;
    }
  }, 1000);
  setTimeout(() => {
    on_next();
    chatbot_state.is_bot_reset_blocked = false;
  }, 1500);

  chatbot_state.is_restarting = true;
  setTimeout(() => {
    chatbot_state.is_restarting = false;
  }, 500);
};

const on_back = function () {
  $router.push({
    name: "id-welcome",
    params: {
      id: $route.params.id,
    },
    query: {
      demo: $route.query.demo === "1" ? "1" : "0",
    },
  });
};

const post_message = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

const scroll_to_bottom = function (selector: string) {
  nextTick(() => {
    const container = document.querySelector(selector);
    container?.scrollTo({
      top: container?.scrollHeight,
      left: 0,
      behavior: "smooth",
    });
  });
};

const user_response_object_factory = function (
  message: string,
  id: number
): IScriptStep {
  return {
    data: {
      message,
      options: [""],
      jumps: [],
    },
    response: true,
    description: "",
    type: ScriptStepType.RESPONSE,
    isSkippable: false,
    isManualInputAllowed: false,
    id: `${id}`,
    hasOption: false,
  };
};

// script step next event handler
// only work for non-text-required steps
const on_next = function (reply: string = "") {
  let jumpTarget: string | null = null;
  let targetIndex = null;
  // does this step has reply?
  // we're checking this because it may a message which does not require any reply
  if (reply) {
    if (
      chatbot_state.bot.script.steps[chatbot_state.active_step].type ===
        ScriptStepType.SINGLE_SELECT ||
      chatbot_state.bot.script.steps[chatbot_state.active_step].type ===
        ScriptStepType.YES_NO
    ) {
      const optionIndex = chatbot_state.bot.script.steps[
        chatbot_state.active_step
      ].data.options.findIndex((option) => option === reply);

      if (
        typeof chatbot_state.bot.script.steps[chatbot_state.active_step].data
          .jumps !== "undefined" &&
        chatbot_state.bot.script.steps[chatbot_state.active_step].data.jumps
          .length
      ) {
        jumpTarget =
          chatbot_state.bot.script.steps[chatbot_state.active_step].data.jumps[
            optionIndex
          ];

        if (jumpTarget && jumpTarget.includes("bot:")) {
          setTimeout(() => {
            // @ts-ignore
            window.location.href = "/" + jumpTarget.split(":")[1];
          }, 1000);
        } else {
          targetIndex = chatbot_state.bot.script.steps.findIndex(
            (step) => step.id === jumpTarget
          );
          const otherJumps = chatbot_state.bot.script.steps[
            chatbot_state.active_step
          ].data.jumps.filter((jump) => jump !== jumpTarget);

          otherJumps.forEach((jump) => {
            chatbot_state.bot.script.steps
              .filter((step) => step.id === jump)
              .forEach((step) => {
                step.data.jumps.forEach((jump) => {
                  if (jump) {
                    chatbot_state.skips.push(jump);
                  }
                });
              });
          });

          for (let i = 0; i < otherJumps.length; i++) {
            chatbot_state.skips.push(otherJumps[i]);
          }
        }
      }
    }

    chatbot_state.response.push({
      value: reply,
      id: chatbot_state.bot.script.steps[chatbot_state.active_step].id || "",
    });

    chatbot_state.scene.steps.push(
      user_response_object_factory(reply, chatbot_state.scene.steps.length)
    );
    scroll_to_bottom("#message-container");
    chatbot_state.is_loading = true;
  }

  if (jumpTarget) {
    chatbot_state.active_step = targetIndex as number;
    calculate_next_step(true);
  } else {
    // increase active step index
    chatbot_state.active_step++;
    // calculate next step and proceed flow
    calculate_next_step();
  }
};

// script step skip event handler
const on_skip = function () {
  chatbot_state.response.push({
    value: "SKIPPED",
    id: chatbot_state.bot.script.steps[chatbot_state.active_step].id || "",
  });

  const currentStep = chatbot_state.bot.script.steps[chatbot_state.active_step];

  if (currentStep.data.jumps) {
    for (let i = 0; i < currentStep.data.jumps.length; i++) {
      chatbot_state.skips.push(
        chatbot_state.bot.script.steps[chatbot_state.active_step].data.jumps[i]
      );
    }
  }

  scroll_to_bottom("#message-container");
  chatbot_state.is_loading = true;
  chatbot_state.active_step++;
  calculate_next_step();
};

// script step text event handler
// only work for steps which manual input required
const on_text_submit = function (message: string) {
  // set loading before next script step appear
  chatbot_state.is_loading = true;
  // push text into responses array
  chatbot_state.response.push({
    value: message,
    id: chatbot_state.bot.script.steps[chatbot_state.active_step].id || "",
  });
  // push user response object into scene
  chatbot_state.scene.steps.push(
    user_response_object_factory(message, chatbot_state.scene.steps.length)
  );
  // scroll to bottom
  scroll_to_bottom("#message-container");
  // increase active step
  chatbot_state.active_step++;
  // calculate next step and proceed flow
  calculate_next_step();
};

// calculate next step of bot flow
// make assignments or end flow
const calculate_next_step = function (allow_skippables: boolean = false): void {
  // skip this step if it's in skips array
  if (
    chatbot_state.bot.script.steps.length > chatbot_state.active_step &&
    chatbot_state.skips.includes(
      chatbot_state.bot.script.steps[chatbot_state.active_step].id as string
    ) &&
    !allow_skippables
  ) {
    chatbot_state.active_step++;
    calculate_next_step();
    return;
  }

  // remove loading indicator after a half second
  setTimeout(() => {
    chatbot_state.is_loading = false;
  }, 500);
  // create 250ms gap between loading dissolve and new message appear transition
  setTimeout(async () => {
    // check is this end of bot flow?
    if (chatbot_state.bot.script.steps.length > chatbot_state.active_step) {
      // if not
      // push next step into scene
      chatbot_state.scene.steps.push(
        chatbot_state.bot.script.steps[chatbot_state.active_step]
      );
      // scroll scene to bottom
      scroll_to_bottom("#message-container");

      // focus to text input if this step require manual input
      setTimeout(() => {
        if (
          chatbot_state.bot.script.steps[chatbot_state.active_step]
            .isManualInputAllowed
        ) {
          document.getElementById("widget-text-input")?.focus();
        }
      }, 500);

      // if this step is a message? show loading indicator
      // because we know, if the type is message
      // m-script-step component will emit "replied" event after 500ms
      // so we need to show loading indicator till it'll emit that
      if (
        chatbot_state.bot.script.steps[chatbot_state.active_step].type ===
        ScriptStepType.MESSAGE
      ) {
        chatbot_state.is_loading = true;
      }
    } else {
      const result = await createUserResponse({
        bot: chatbot_state.bot._id || "fallback_id",
        values: chatbot_state.response,
      });
      if (result.isOk()) {
        chatbot_state.is_completed = true;
        $router.push({
          name: "id-finish",
          params: {
            id: chatbot_state.bot._id,
          },
          query: {
            show_close: $route.query.show_close,
          }
        });
      } else {
        if (result.error.message.includes("ThrottlerException")) {
          chatbot_state.error_message =
            "You have reached the submission limit for this chatbot.";
        }
        chatbot_state.is_error_occurred = true;
      }
    }
  }, 500);
};

const track_bot_event = async function (type: BotEventType) {
  await sendBotEvent({
    bot: chatbot_state.bot._id + "",
    type,
  });
};

// computeds
const is_branding_visible = computed(() => {
  return !fallback.appearance.hideBranding;
});

const input_disabled = computed(() => {
  return !(
    !chatbot_state.is_loading &&
    chatbot_state.bot?.script?.steps[chatbot_state.active_step]
      ?.isManualInputAllowed
  );
});

watch(chatbot_state.response, async (responses) => {
  if (responses.length === 1) {
    await track_bot_event(BotEventType.START);
  }
});

watch(
  () => chatbot_state.is_completed,
  async (_isCompleted) => {
    if (_isCompleted) {
      await track_bot_event(BotEventType.COMPLETED);
    }
  }
);

onMounted(async () => {
  // init mevo identity
  if (!localStorage.getItem("mevo_device_id")) {
    localStorage.setItem("mevo_device_id", uuidv4());
  }

  await initialize($route.params.id as string);

  if ($route.query.show_close === "1") {
    chatbot_state.show_close = true;
  }
});
</script>

<style>
/* #message-container {
  scrollbar-gutter: stable both-edges;
} */
</style>
