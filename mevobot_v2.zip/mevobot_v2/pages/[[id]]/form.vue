<template>
  <div class="h-screen w-full bg-white flex justify-center">
    <div
      class="flex justify-center items-center w-full h-screen"
      v-if="form_state.is_error"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div>
          <div class="text-black font-medium text-lg">Something went wrong</div>
          <div class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <div
      class="flex justify-center items-center w-full h-screen"
      v-else-if="form_state.is_loading"
    >
      <i
        class="fa-thin fa-spinner-third animate-spin text-4xl text-gray-500"
      ></i>
    </div>
    <div
      v-else
      class="h-screen w-full bg-white flex flex-col justify-between sm:w-2/3 lg:w-2/5 shadow"
    >
      <div
        class="w-full py-5 px-6 flex items-center justify-between shadow-md"
        :class="`bg-${form_state.bot.appearance.theme}-500`"
      >
        <div
          @click="go_welcome"
          class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer"
          :class="`bg-${form_state.bot.appearance.theme}-700 hover:bg-${form_state.bot.appearance.theme}-700`"
        >
          <i class="fa-solid fa-chevron-left text-white text-xl"></i>
        </div>

        <div
          class="text-white font-semibold antialiased flex flex-col justify-end items-end"
        >
          <div class="text-sm">{{ form_state.bot.leadCaptureFormTitle }}</div>
          <!-- <div class="text-gray-400 text-xs font-light">AI Agent</div> -->
        </div>
      </div>
      <form
        class="flex-1 space-y-6 px-6 flex flex-col justify-center"
        @submit="onFormSubmit"
      >
        <FormField v-slot="{ componentField }" name="name">
          <FormItem>
            <FormLabel>{{ form_state.bot.nameLabel }} *</FormLabel>
            <Input
              v-bind="componentField"
              type="text"
              class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
              :placeholder="form_state.bot.namePlaceholder"
            />
            <FormMessage />
          </FormItem>
        </FormField>
        <FormField v-slot="{ componentField }" name="organization">
          <FormItem>
            <FormLabel>{{ form_state.bot.organizationLabel }}</FormLabel>
            <Input
              v-bind="componentField"
              type="text"
              class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
              :placeholder="form_state.bot.organizationPlaceholder"
            />
            <FormMessage />
          </FormItem>
        </FormField>
        <FormField v-slot="{ componentField }" name="email">
          <FormItem>
            <FormLabel>{{ form_state.bot.emailLabel }} *</FormLabel>
            <Input
              v-bind="componentField"
              type="text"
              class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
              :placeholder="form_state.bot.emailPlaceholder"
            />
            <FormMessage />
          </FormItem>
        </FormField>
        <div>
          <Button
            @click="onFormSubmit"
            class="w-full p-3 text-sm ring-none focus:ring-none text-white rounded-lg"
            :class="[
              `bg-${form_state.bot.appearance.theme}-500`,
              `hover:bg-${form_state.bot.appearance.theme}-700`,
              form_state.is_disabled &&
                `cursor-not-allowed bg-${form_state.bot.appearance.theme}-300`,
            ]"
          >
            <span class="font-medium">{{
              form_state.bot.formSubmitButton
            }}</span>
          </Button>
        </div>
        <div>
          <p class="text-gray-500 text-sm">
            {{ form_state.bot.leadCaptureFormDescription }}
          </p>
          <!-- <p class="text-gray-500 text-xs">
            By clicking "Start conversation", you agree to our
            <a href="#" class="text-blue-500">Terms of Service</a> and
            <a href="#" class="text-blue-500">Privacy Policy</a>.
          </p> -->
        </div>
      </form>

      <!-- <div class="w-full border-t">
      <Input
        type="text"
        class="border-none w-full h-full p-4 text-sm ring-none focus:ring-none"
        placeholder="Type a message..."
      />
    </div> -->
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from "vue";
import { useRouter, useRoute } from "vue-router";
import { toTypedSchema } from "@vee-validate/zod";
import * as z from "zod";
import { useForm } from "vee-validate";

import {
  get_bot_public,
  sendLead,
} from "../../modules/bot/services/BotService";
import { Input } from "../../components/ui/input";
import { Button } from "../../components/ui/button";
import {
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import type { IBot } from "../../modules/bot/types/IBot";

export interface FormState {
  bot: IBot;
  email: string;
  name: string;
  organization: string;
  session_id: string;
  chatbot_id: string;
  device_id: string;
  is_loading: boolean;
  is_error: boolean;
  is_disabled: boolean;
}

const form_state: FormState = reactive({
  bot: {
    appearance: {
      theme: "blue",
    },
  } as IBot,
  email: "",
  name: "",
  organization: "",
  session_id: "",
  chatbot_id: "1",
  device_id: "1",
  is_loading: true,
  is_error: false,
  is_disabled: false,
});

const fallback = {
  meta: {
    title: "AI Assistant",
    description: "Start a conversation with our AI assistant",
    keywords: "AI, Assistant, Chatbot",
    og_image: "",
  },
  appearance: {
    placeholderText: "Type a message...",
    brandImage: "https://images.unsplash.com/photo-1596367407372-96cb88503db6",
    theme: "blue",
    greeting: "Hello!",
    talkWithAgentMessage: "Talk with an agent",
    hideBranding: false,
    firstMessage: "Hello! How can I help you today?",
  },
};

const $router = useRouter();
const $route = useRoute();

const { handleSubmit } = useForm({
  validationSchema: toTypedSchema(
    z.object({
      name: z.string({
        required_error: "Please do not leave the name empty",
      }),
      organization: z.string().optional(),
      email: z
        .string({
          required_error: "Please do not leave the email empty",
        })
        .email({
          message: "Please enter a valid email",
        }),
    })
  ),
});

const onFormSubmit = handleSubmit(async (values: Record<string, any>) => {
  form_state.is_disabled = true;

  const send_lead_response = await sendLead({
    bot: form_state.chatbot_id,
    email: values.email,
    name: values.name,
    company: values.organization,
    device_id: form_state.device_id,
    is_demo: $route.query.demo === "1",
  });

  if (send_lead_response.isOk()) {
    form_state.is_disabled = false;
    $router.push({
      name: "id-conversation",
      params: { id: form_state.chatbot_id },
    });
  } else {
    form_state.is_disabled = false;
  }
});

const go_welcome = () => {
  $router.push({
    name: "id-welcome",
    params: { id: form_state.chatbot_id },
  });
};

onMounted(async () => {
  form_state.chatbot_id = $route.params.id as string;
  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    form_state.is_loading = false;
    form_state.is_error = false;
    form_state.bot = public_bot_response.value.payload.bot as IBot;

    if (public_bot_response.value.payload.bot.config) {
      fallback.meta = public_bot_response.value.payload.bot.config.meta;
    }

    if (public_bot_response.value.payload.bot.appearance) {
      fallback.appearance = public_bot_response.value.payload.bot.appearance;
    }

    useSeoMeta({
      title: fallback.meta.title,
      ogTitle: fallback.meta.title,
      description: fallback.meta.description,
      ogDescription: fallback.meta.description,
      ogImage: fallback.meta.og_image,
      twitterCard: "summary_large_image",
      keywords: fallback.meta.keywords,
    });

    useHead({
      link: [
        {
          rel: "icon",
          type: "image/x-icon",
          href: public_bot_response.value.payload.bot.appearance.brandImage,
        },
      ],
    });
  } else {
    form_state.is_loading = false;
    form_state.is_error = true;
  }

  form_state.session_id = JSON.parse(
    localStorage.getItem(
      "mevo:" + form_state.chatbot_id + ":session_id"
    ) as string
  ).id;
  form_state.chatbot_id = $route.params.id as string;
  form_state.device_id = localStorage.getItem("mevo_device_id") as string;
});
</script>
