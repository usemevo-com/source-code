<template>
  <div class="h-dvh w-full bg-white flex justify-center">
    <!-- <div
      v-if="!conversation_state.is_loading"
      class="h-screen flex-1 hidden sm:block"
      :class="[
        `bg-gradient-to-r from-${conversation_state.bot.appearance.theme}-100 to-${conversation_state.bot.appearance.theme}-300`,
      ]"
    ></div> -->
    <div
      class="flex justify-center items-center w-full h-screen"
      v-if="conversation_state.is_error"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div>
          <div class="text-black font-medium text-lg">Something went wrong</div>
          <div class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <div
      class="flex justify-center items-center w-full h-screen"
      v-else-if="conversation_state.is_loading"
    >
      <i
        class="fa-thin fa-spinner-third animate-spin text-4xl text-gray-500"
      ></i>
    </div>
    <div
      v-else
      class="flex flex-col justify-between sm:w-2/3 lg:w-2/5 w-full shadow"
    >
      <div
        class="w-full py-5 px-6 flex items-center justify-between shadow-md"
        :class="`bg-${fallback.appearance.theme}-500`"
      >
        <div
          v-if="!fallback.appearance.skipWelcomePage"
          @click="go_welcome"
          class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer"
          :class="`bg-${fallback.appearance.theme}-700 hover:bg-${fallback.appearance.theme}-700`"
        >
          <i class="fa-solid fa-chevron-left text-white text-xl"></i>
        </div>

        <div
          class="text-white font-semibold antialiased flex flex-col justify-end items-end"
          :class="{
            'w-full items-center': fallback.appearance.skipWelcomePage,
          }"
        >
          <div class="text-sm">
            {{ conversation_state.bot.appearance.title }}
          </div>
          <!-- <div class="text-gray-400 text-xs font-light">AI Agent</div> -->
        </div>
        <div
          @click="post_message('chatbox-closed')"
          class="sm:hidden w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer"
          :class="`bg-${fallback.appearance.theme}-700 hover:bg-${fallback.appearance.theme}-700`"
        >
          <i class="fa-sharp fa-xmark text-white text-xl"></i>
        </div>
      </div>
      <div
        class="flex-1 overflow-y-scroll space-y-4 py-4"
        id="message-container"
      >
        <!-- <previous-conversations
          :image="fallback.appearance.brandImage"
          :theme="fallback.appearance.theme"
          :conversations="conversation_state.previous_conversations"
        /> -->
        <message-item
          :show_ai_indicator="conversation_state.show_ai_indicator"
          :image="fallback.appearance.brandImage"
          :theme="fallback.appearance.theme"
          :key="index"
          :text="message.text"
          :sent_at="message.sent_at"
          :sender="message.sender"
          :sender_meta="message.sender_meta"
          v-for="(message, index) in conversation_state.messages"
        />
        <typing
          :image="fallback.appearance.brandImage"
          v-if="conversation_state.is_typing"
        />
        <div
          class="bg-gray-50 px-5 py-4 text-[15px] rounded-xl mx-6 relative"
          v-if="
            conversation_state.is_lead_capture_form_active &&
            !conversation_state.is_lead_capture_dismissed
          "
        >
          <div class="font-medium">
            {{ conversation_state.bot.inChatEmailInputTitle }}

            <i
              @click="hide_lead_capture_form"
              class="cursor-pointer fa fa-xmark text-gray-500 absolute top-5 right-5"
            />
          </div>
          <div class="text-sm font-light">
            {{ conversation_state.bot.inChatEmailInputDescription }}
          </div>
          <div class="flex space-x-2 mt-2">
            <Input
              :disabled="conversation_state.is_lead_capture_form_disabled"
              v-model="conversation_state.lead_capture_email"
              :placeholder="conversation_state.bot.emailPlaceholder"
              class="flex-1"
            />
            <Button
              @click="submit_lead_capture_form"
              :disabled="conversation_state.is_lead_capture_form_disabled"
              :class="`bg-${fallback.appearance.theme}-700 hover:bg-${conversation_state.bot.appearance.theme}-500 text-white`"
              >{{ conversation_state.bot.inChatEmailSubmitButtonLabel }}</Button
            >
          </div>
        </div>
        <div
          v-if="conversation_state.show_feedback_options"
          class="bg-gray-50 p-4 text-[15px] rounded-xl mx-6 relative"
        >
          <div class="flex space-y-4 flex-col">
            <Button
              @click="handleFeedbackOption('yes')"
              :class="`bg-white border border-gray-200 hover:bg-gray-100 rounded text-black`"
              >{{ conversation_state.bot.surveyYes }}</Button
            >
            <Button
              @click="handleFeedbackOption('continue')"
              :class="`bg-white border border-gray-200 hover:bg-gray-100 rounded text-black`"
              >{{ conversation_state.bot.surveyNo }}</Button
            >
            <Button
              @click="handleFeedbackOption('human')"
              :class="`bg-white border border-gray-200 hover:bg-gray-100 rounded text-black`"
              >{{ conversation_state.bot.surveyHuman }}</Button
            >
          </div>
        </div>
        <div
          v-if="conversation_state.show_human_email_form"
          class="bg-gray-50 px-5 py-4 text-[15px] rounded-xl mx-6 relative"
        >
          <div class="font-medium">{{ conversation_state.bot.inChatEmailInputTitle }}</div>
          <div class="text-sm font-light">
            {{ conversation_state.bot.inChatEmailInputDescription }}
          </div>
          <div class="flex space-x-2 mt-2">
            <Input
              v-model="conversation_state.human_contact_email"
              :placeholder="conversation_state.bot.emailPlaceholder"
              class="flex-1"
            />
            <Button
              @click="submitHumanContactEmail"
              :disabled="conversation_state.is_human_email_submitting"
              :class="`bg-${fallback.appearance.theme}-700 hover:bg-${conversation_state.bot.appearance.theme}-500 text-white`"
              >{{ conversation_state.bot.inChatEmailSubmitButtonLabel }}</Button
            >
          </div>
        </div>
        <div
          v-if="conversation_state.show_new_conversation_button"
          class="mx-6 flex flex-col"
        >
          <div class="flex space-x-4 items-center w-full pb-4">
            <div class="border-b w-1/4"></div>
            <div class="text-xs w-1/2 text-center text-gray-500">Conversation end</div>
            <div class="border-b w-1/4"></div>
          </div>
          <Button
            @click="startNewConversation"
            :class="`w-full bg-${fallback.appearance.theme}-700 hover:bg-${conversation_state.bot.appearance.theme}-500 text-white`"
            >Start a new conversation</Button
          >
        </div>
      </div>
      <div v-if="!conversation_state.show_new_conversation_button && !conversation_state.show_feedback_options && !conversation_state.show_human_email_form" class="border relative flex items-center py-2 justify-center space-x-2 m-4 rounded-3xl transition-all duration-200
          focus-within:border-gray-400 focus-within:shadow-lg overflow-hidden">
        <textarea
          ref="messageInput"
          :disabled="is_input_disabled"
          v-model="conversation_state.message"
          @input="adjustTextareaHeight"
          @keydown.enter="handleEnterPress"
          rows="1"
          class="flex-1 max-w-full min-h-[40px] px-2 pr-20 py-2 pl-4 text-[16px] resize-none overflow-y-auto ring-none focus:ring-none outline-none bg-transparent border-box"
          :placeholder="fallback.appearance.placeholderText"
          :class="[is_input_disabled ? 'bg-gray-50' : 'bg-white']"
        ></textarea>
        <div
          class="absolute bg-gray-200 hover:bg-gray-300 w-9 h-9 rounded-full flex items-center justify-center cursor-pointer right-4 bottom-[10px]"
          @click="on_submit"
          :disabled="is_input_disabled"
        >
          <i
            class="fa-solid fa-paper-plane-top text-black text-xl"
          ></i>
          <!-- <i
            v-else
            class="fa fa-spinner-third animate-spin text-gray-500 text-xl"
          ></i> -->
        </div>
      </div>
      <div
        v-if="!conversation_state.bot.appearance.hideBranding"
        class="text-xs py-2 w-full flex items-center justify-center space-x-2 border-t border-gray-50"
      >
        <!-- <i class="fa-solid fa-bolt text-amber-500"></i> -->
        <span class="text-gray-500 font-light"
          >powered by
          <a href="https://usemevo.com" target="_blank"
            ><span class="font-bold text-black">mevo</span></a
          ></span
        >
      </div>
    </div>
    <!-- 
    from-gray-100 to-gray-300
    from-red-100 to-red-300
    from-yellow-100 to-yellow-300
    from-green-100 to-green-300
    from-blue-100 to-blue-300
    from-indigo-100 to-indigo-300
    from-purple-100 to-purple-300
    from-pink-100 to-pink-300
  --></div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, computed, ref, nextTick } from "vue";
import { useRoute, useRouter } from "vue-router";
import { v4 as uuidv4 } from "uuid";

import {
  check_chatbot_response,
  interact_with_chatbot,
  get_conversations_by_device,
  get_bot_public,
  check_lead,
  sendLead,
} from "../../modules/bot/services/BotService";
import { useWidget } from "../../modules/widget/composables/useWidget";
import MessageItem from "../../modules/bot/containers/MessageItem.vue";
import Typing from "../../modules/bot/containers/Typing.vue";
import { MessageSender } from "../../modules/bot/types/MessageSender";
import { NodeType, ShowForm, type BotFlowChild, type IBot } from "../../modules/bot/types/IBot";

const messageInput = ref<HTMLTextAreaElement | null>(null);
// state
export interface ConversationState {
  bot: IBot;
  message: string;
  is_submitting: boolean;
  is_typing: boolean;
  session_id: string;
  chatbot_id: string;
  device_id: string;
  messages: {
    text: string;
    sender: MessageSender;
    sent_at: string;
    sender_meta?: { _id: string, name: string, title: string, photo: string };
  }[];
  previous_conversations: any[];
  is_previous_conversations_visible: boolean;
  is_loading: boolean;
  is_error: boolean;
  is_interacted_once: boolean;
  is_lead_capture_dismissed: boolean;
  is_lead_capture_form_active: boolean;
  lead_capture_email: string;
  is_lead_capture_form_disabled: boolean;
  message_acc: string;
  show_feedback_options: boolean;
  show_new_conversation_button: boolean;
  show_human_email_form: boolean;
  is_human_email_submitting: boolean;
  human_contact_email: string;
  human_communication_mode: boolean;
  human_mode_information_shown: boolean;
  is_lead_captured: boolean;
  is_survey_disabled: boolean;
  show_ai_indicator: boolean;
  captured_lead: {
    name: string;
    email: string;
    company: string;
  }
  current_flow_node: BotFlowChild | null;
}

const conversation_state: ConversationState = reactive({
  bot: {} as IBot,
  message: "",
  is_submitting: false,
  is_typing: false,
  session_id: "",
  chatbot_id: "",
  device_id: "",
  messages: [],
  previous_conversations: [],
  is_previous_conversations_visible: false,
  is_loading: true,
  is_error: false,
  is_interacted_once: false,
  is_lead_capture_dismissed: false,
  is_lead_capture_form_active: false,
  lead_capture_email: "",
  is_lead_capture_form_disabled: false,
  is_survey_disabled: false,
  show_ai_indicator: true,
  message_acc: "",
  show_feedback_options: false,
  show_new_conversation_button: false,
  show_human_email_form: false,
  is_human_email_submitting: false,
  human_contact_email: "",
  human_communication_mode: false,
  human_mode_information_shown: false,
  is_lead_captured: false,
  captured_lead: {
    name: "",
    email: "",
    company: "",
  },
  current_flow_node: null,
});

const adjustTextareaHeight = (event: Event | null = null) => {
    const textarea = messageInput.value;
    if (!textarea) return;
    
    if (!event) {
        textarea.style.height = '40px';
        return;
    }
    
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
};

const fallback = {
  meta: {
    title: "AI Assistant",
    description: "Start a conversation with our AI assistant",
    keywords: "AI, Assistant, Chatbot",
    og_image: "",
  },
  appearance: {
    placeholderText: "Type a message...",
    brandImage: "https://images.unsplash.com/photo-1596367407372-96cb88503db6",
    theme: "blue",
    greeting: "Hello!",
    title: "AI Assistant",
    talkWithAgentMessage: "Talk with an agent",
    hideBranding: false,
    firstMessage: "Hello! How can I help you today?",
    skipWelcomePage: false,
  },
};

// hooks
const $route = useRoute();
const $router = useRouter();
const { scrollToBottom } = useWidget();
const handleEnterPress = (event: KeyboardEvent) => {
    if (event.key === 'Enter') {
        if (event.shiftKey) {
            return;
        } else {
            event.preventDefault();
            on_submit();
        }
    }
};

// methods
const on_submit = async () => {
  if (!conversation_state.message.trim() || 
    conversation_state.message.replace(/\s/g, '') === '') {
    return;
  }

  if (!conversation_state.message) return;

  conversation_state.messages.push({
    text: conversation_state.message,
    sender: MessageSender.USER,
    sent_at: new Date().toISOString(),
  });

  if (conversation_state.human_communication_mode) {
    if (!conversation_state.human_mode_information_shown) {
      conversation_state.messages.push({
        text: 'It may take a while to get a response. You will receive an email notification when our support team replied to your message.',
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      conversation_state.human_mode_information_shown = true;
    }
    messageInput.value?.focus();
  } else {
    conversation_state.is_typing = true;
  }

  conversation_state.message_acc = conversation_state.message;
  conversation_state.message = "";
  scrollToBottom("#message-container");
  adjustTextareaHeight(null);

  // show loader
  conversation_state.is_submitting = true;

  const interact_with_chatbot_response = await interact_with_chatbot(
    conversation_state.chatbot_id,
    {
      message: conversation_state.message_acc,
      sid: conversation_state.session_id,
      did: conversation_state.device_id,
      is_demo: $route.query.demo === "1",
      human_communication_mode: conversation_state.human_communication_mode
    }
  );

  if (interact_with_chatbot_response.isOk()) {
    if (interact_with_chatbot_response.value.payload) {
      conversation_state.message = "";
      conversation_state.is_submitting = false;
      conversation_state.is_interacted_once = true;
      if (!conversation_state.human_communication_mode) {
        await check_response();
      }
      adjustTextareaHeight(null);
      messageInput.value?.focus();
    } else {
      conversation_state.messages.push({
        text: "We can not answer this question now, could you please try again later?",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      conversation_state.is_submitting = false;
      conversation_state.message = "";
      scrollToBottom("#message-container");
      await nextTick();
      adjustTextareaHeight(null);
      messageInput.value?.focus();
    }
  } else {
    conversation_state.is_submitting = false;
    await nextTick();
    conversation_state.message = "";
    adjustTextareaHeight(null);
    messageInput.value?.focus();
    if (
      interact_with_chatbot_response.error.message ===
      "chatbot_interaction.TOKEN_LIMIT_REACHED"
    ) {
      conversation_state.messages.push({
        text: "This chatbot is currently out of service. Please try to contact us through a different communication channel.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      await nextTick();
      messageInput.value?.focus();
      conversation_state.message = "";
      adjustTextareaHeight(null);
    }
  }
};

const post_message = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

const check_response = async () => {
  conversation_state.is_typing = true;
  const chatbot_response = await check_chatbot_response(
    conversation_state.session_id,
    conversation_state.chatbot_id,
    conversation_state.device_id,
    $route.query.demo === "1"
  );

  if (chatbot_response.isOk()) {
    if (chatbot_response.value.payload.status) {
      conversation_state.is_typing = false;
      await nextTick();
      messageInput.value?.focus();
      conversation_state.messages.push({
        text: chatbot_response.value.payload.message,
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      check_lead_capture_status();
      scrollToBottom("#message-container");
      if (!conversation_state.is_survey_disabled) {
        // Show feedback options after AI responds
        conversation_state.show_feedback_options = true;
        conversation_state.messages.push({
          text: conversation_state.bot.surveyMessage,
          sender: MessageSender.AI,
          sent_at: new Date().toISOString(),
        });
      }
    } else {
      setTimeout(() => {
        check_response();
      }, 1000);
    }
  } else {
    setTimeout(() => {
      check_response();
    }, 1000);
  }
};

const handleFeedbackOption = async (option: string) => {
  // Add the user's response to the conversation
  conversation_state.messages.push({
    text: option === 'yes' ? conversation_state.bot.surveyYes : 
          option === 'continue' ? conversation_state.bot.surveyNo : 
          conversation_state.bot.surveyHuman,
    sender: MessageSender.USER,
    sent_at: new Date().toISOString(),
  });
  
  if (option === 'yes') {
    // User is satisfied, show new conversation button
    conversation_state.show_feedback_options = false;
    conversation_state.show_new_conversation_button = true;
    scrollToBottom("#message-container");
    await interact_with_chatbot(
      conversation_state.chatbot_id,
      {
        message: 'MEVO_EVENT_HELPED',
        sid: conversation_state.session_id,
        did: conversation_state.device_id,
        is_demo: $route.query.demo === "1",
        human_communication_mode: conversation_state.human_communication_mode
      }
    );
  } else if (option === 'continue') {
    // User wants to continue, hide feedback options and show input
    conversation_state.show_feedback_options = false;
    scrollToBottom("#message-container");
    await nextTick();
    messageInput.value?.focus();
  } else if (option === 'human') {
    // User wants to talk to a human
    conversation_state.show_feedback_options = false;
    
    if (conversation_state.is_lead_captured) {
      // Add system message about human contact
      conversation_state.messages.push({
        text: `Our team contact you via ${conversation_state.captured_lead.email} email address.`,
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });

      conversation_state.show_new_conversation_button = true;
    } else {
      conversation_state.show_human_email_form = true;
      // Add system message about human contact
      conversation_state.messages.push({
        text: "If you leave your email, our team will contact you as soon as possible.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
    }

    await interact_with_chatbot(
      conversation_state.chatbot_id,
      {
        message: 'MEVO_EVENT_HUMAN_DEMAND',
        sid: conversation_state.session_id,
        did: conversation_state.device_id,
        is_demo: $route.query.demo === "1",
        human_communication_mode: conversation_state.human_communication_mode
      }
    );

    scrollToBottom("#message-container");
  }
};

const startNewConversation = async () => {
  // Generate a new session ID
  conversation_state.session_id = uuidv4();
  
  // Reset conversation state
  conversation_state.show_new_conversation_button = false;
  conversation_state.messages = [];
  conversation_state.message = '';
  conversation_state.is_typing = false;
  conversation_state.is_submitting = false;
  conversation_state.is_interacted_once = false;
  conversation_state.is_lead_capture_form_active = false;
  conversation_state.is_lead_capture_dismissed = false;
  conversation_state.lead_capture_email = '';
  conversation_state.is_lead_capture_form_disabled = false;
  conversation_state.message_acc = '';
  conversation_state.show_feedback_options = false;
  conversation_state.show_human_email_form = false;
  conversation_state.is_human_email_submitting = false;
  conversation_state.human_contact_email = '';
  
  // Add welcome message if needed
  await init_first_message();
  
  // Focus on input
  await nextTick();
  messageInput.value?.focus();
};

const submitHumanContactEmail = async () => {
  if (!conversation_state.human_contact_email || 
      !conversation_state.human_contact_email.includes('@')) {
    return; // Basic validation
  }
  
  conversation_state.is_human_email_submitting = true;
  
  try {
    // Submit the email as a lead
    const lead_response = await sendLead({
      bot: conversation_state.bot._id || "",
      email: conversation_state.human_contact_email,
      device_id: conversation_state.device_id,
      is_demo: $route.query.demo === "1",
    });
    
    if (lead_response.isOk()) {
      // Add confirmation message
      conversation_state.messages.push({
        text: "Thank you! Our team will contact you soon and you will receive an email notification, keep your eye on your inbox.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      
      // Show new conversation button
      conversation_state.show_human_email_form = false;
      conversation_state.show_new_conversation_button = true;
    } else {
      // Show error message
      conversation_state.messages.push({
        text: "Sorry, we couldn't process your request. Please try again later.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
    }
  } catch (error) {
    console.error("Error submitting human contact email:", error);
    // Show error message
    conversation_state.messages.push({
      text: "Sorry, we couldn't process your request. Please try again later.",
      sender: MessageSender.AI,
      sent_at: new Date().toISOString(),
    });
  } finally {
    conversation_state.is_human_email_submitting = false;
    scrollToBottom("#message-container");
  }
};

const on_show_prev_conversations = () => {
  conversation_state.is_previous_conversations_visible = true;
};

const hide_lead_capture_form = () => {
  conversation_state.is_lead_capture_form_active = false;
  conversation_state.is_lead_capture_dismissed = true;
  localStorage.setItem(
    "lead_capture_dismissed-" + conversation_state.bot._id,
    "true"
  );
};

const go_welcome = () => {
  $router.push({
    name: "id-welcome",
    params: { id: conversation_state.bot._id },
    query: {
      demo: $route.query.demo === "1" ? "1" : "0",
      "force-new-conversation":
        $route.query["force-new-conversation"] === "1" ? "1" : "0",
    },
  });
};

const init_first_message = () => {
  conversation_state.messages.push({
    text: fallback.appearance.firstMessage,
    sender: MessageSender.AI,
    sent_at: new Date().toISOString(),
  });
};

// check if lead capture form should be shown
// after the first interaction
const check_lead_capture_status = () => {
  // if lead capture is not enabled, return
  if (
    conversation_state.bot &&
    conversation_state.bot.showForm !== ShowForm.IN_CHAT
  )
    return;

  // set lead capture form active if the user is interacted once
  // and the lead capture form is not shown
  if (
    conversation_state.is_interacted_once &&
    !conversation_state.is_lead_capture_dismissed
  ) {
    conversation_state.is_lead_capture_form_active = true;
  }
};

const submit_lead_capture_form = async () => {
  conversation_state.is_lead_capture_form_disabled = true;
  const send_lead_response = await sendLead({
    bot: conversation_state.bot._id || "",
    email: conversation_state.lead_capture_email,
    device_id: conversation_state.device_id,
    is_demo: $route.query.demo === "1",
  });

  if (send_lead_response.isOk()) {
    conversation_state.is_lead_capture_form_active = false;
    conversation_state.is_lead_capture_dismissed = true;
    localStorage.setItem(
      "lead_capture_dismissed-" + conversation_state.bot._id,
      "true"
    );
  } else {
    conversation_state.is_lead_capture_form_disabled = false;
  }
};

const get_next_node = () => {
  const flow = conversation_state.bot.flow;
  let current_node = conversation_state.current_flow_node;

  if (!current_node) {
    conversation_state.current_flow_node = flow[0].children[2];
  } else {
    console.log(current_node.children);
  }

  console.log(current_node);
}

// computeds
const is_input_disabled = computed(
  () => conversation_state.is_submitting || conversation_state.is_typing
);

window.addEventListener(
  "message",
  (event) => {
    try {
      var data = JSON.parse(event.data);
      if (data.kind === "user-message") {
        conversation_state.message = data.data;
        on_submit();
      }
    } catch (e) {
      console.error("[MEVO] Unable to parse message", event.data);
    }
  },
  false
);

onMounted(async () => {

  if (localStorage.getItem(`mevo_${$route.params.id}_lead`)) {
    conversation_state.is_lead_captured = true;
    const lead = JSON.parse(localStorage.getItem(`mevo_${$route.params.id}_lead`) || "{}");
    conversation_state.captured_lead = {
      name: lead.name,
      email: lead.email,
      company: lead.company
    }
  }

  // init mevo identity
  if (
    !localStorage.getItem("mevo_device_id") ||
    $route.query["force-new-conversation"] === "1"
  ) {
    // init device id
    localStorage.setItem("mevo_device_id", uuidv4());
    // init session id
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: uuidv4(),
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  if ($route.query.device_id) {
    conversation_state.device_id = $route.query.device_id as string;
    localStorage.setItem('mevo_device_id', $route.query.device_id as string);
  }

  if (!$route.query.session) {
    const new_session_id = uuidv4();
    // init session id
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: new_session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
    // update session id in query
    conversation_state.session_id = new_session_id;
    $router.replace({
      name: "id-conversation",
      params: { id: $route.params.id },
      query: {
        session: new_session_id,
        ...$route.query,
      }
    })
  }

  if ($route.query.hcm) {
    conversation_state.human_communication_mode = true;
  }

  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    conversation_state.is_loading = false;
    conversation_state.is_error = false;
    conversation_state.bot = public_bot_response.value.payload.bot as IBot;
    conversation_state.show_ai_indicator = conversation_state.bot.config?.show_ai_indicator ?? true;
    conversation_state.is_survey_disabled = conversation_state.bot.config?.is_survey_disabled ?? false;

    if (public_bot_response.value.payload.bot.config?.meta) {
      fallback.meta = public_bot_response.value.payload.bot.config.meta;
    }

    if (public_bot_response.value.payload.bot.appearance) {
      fallback.appearance = public_bot_response.value.payload.bot.appearance;
    }

    init_first_message();

    useSeoMeta({
      title: fallback.meta.title,
      ogTitle: fallback.meta.title,
      description: fallback.meta.description,
      ogDescription: fallback.meta.description,
      ogImage: fallback.meta.og_image,
      twitterCard: "summary_large_image",
      keywords: fallback.meta.keywords,
    });

    useHead({
      link: [
        {
          rel: "icon",
          type: "image/x-icon",
          href: fallback.appearance.brandImage,
        },
      ],
    });
  } else {
    conversation_state.is_loading = false;
    conversation_state.is_error = true;
  }

  // check mevo_session in local storage
  const mevo_session = JSON.parse(
    // @ts-ignore
    localStorage.getItem(`mevo:${$route.params.id}:session_id`)
  );

  // if we have a valid session, use it
  if (mevo_session && mevo_session.exp > new Date().getTime() / 1000) {
    conversation_state.session_id = mevo_session.id;

    // and update the expire time to 1 hour
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: conversation_state.session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }
  // if we don't have a valid session, create a new one
  else {
    conversation_state.session_id = uuidv4();
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: conversation_state.session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  conversation_state.chatbot_id = $route.params.id as string;
  conversation_state.device_id = localStorage.getItem(
    "mevo_device_id"
  ) as string;

  if (!conversation_state.device_id) {
    $router.push({
      name: "id-welcome",
      params: { id: conversation_state.chatbot_id },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
      },
    });
  }

  if ($route.query.session) {
    conversation_state.session_id = $route.query.session as string;
  }

  // check if we have previous sessions
  const previous_sessions_response = await get_conversations_by_device(
    conversation_state.chatbot_id,
    conversation_state.device_id
  );

  if (previous_sessions_response.isOk()) {
    let sessions = previous_sessions_response.value.payload;

    const current_session = sessions.find(
      (session: any) => session._id === conversation_state.session_id
    );

    if (current_session) {
      let messages = sessions.find(
        (session: any) => session._id === conversation_state.session_id
      ).messages;

      messages.forEach(
        (message: { text: string; sender: MessageSender; sent_at: string; sender_meta: { _id: string, name: string, title: string, photo: string } }) => {
          conversation_state.messages.push({
            text: message.text,
            sender: message.sender,
            sent_at: message.sent_at,
            sender_meta: message.sender_meta
          });
        }
      );

      conversation_state.previous_conversations = sessions.filter(
        (session: any) => session._id !== conversation_state.session_id
      );
    } else {
      conversation_state.previous_conversations = sessions;
    }
  }

  // check if any messages passed as query params
  if ($route.query.message) {
    conversation_state.message = $route.query.message as string;
    on_submit();
  }

  // if in chat lead capture enabled
  // we need to check existing leads for this device
  if (conversation_state.bot.showForm === ShowForm.IN_CHAT) {
    const lead_check_response = await check_lead({
      bot_id: $route.params.id as string,
      device_id: localStorage.getItem("mevo_device_id") as string,
    });

    // if the user is already a lead, dismiss the lead capture form
    if (lead_check_response.isOk()) {
      if (lead_check_response.value.payload) {
        conversation_state.is_lead_capture_dismissed = true;
      }
    }
  }

  const is_lead_capture_dismissed = localStorage.getItem(
    "lead_capture_dismissed-" + conversation_state.bot._id
  );

  if (is_lead_capture_dismissed) {
    conversation_state.is_lead_capture_dismissed = true;
  }

  scrollToBottom("#message-container");

  messageInput.value?.focus();

  get_next_node()
  get_next_node()
});
</script>
