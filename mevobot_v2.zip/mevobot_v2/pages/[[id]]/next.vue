<template>
  <div class="h-dvh w-full bg-white flex justify-center">
    
    <!-- ERROR STATE -->
    <div
      class="flex justify-center items-center w-full h-screen"
      v-if="conversation_state.is_error"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div>
          <div class="text-black font-medium text-lg">Something went wrong</div>
          <div class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <!-- ERROR STATE -->

    <!-- LOADING STATE -->
    <div
      class="flex justify-center items-center w-full h-screen"
      v-else-if="conversation_state.is_loading"
    >
      <!-- <LoaderCircle
        class="animate-spin text-gray-500"
        :size="32"
        stroke-width="1"
        color="currentColor"
      /> -->
    </div>
    <!-- LOADING STATE -->
    
    <div v-else-if="!conversation_state.bot.isActive && $route.query.demo !== '1'">
      <div class="flex flex-col items-center justify-center h-screen">
        <CirclePause :size="48" />
        <div class="mt-4 text-2xl font-bold">This chatbot is not active</div>
        <div class="mt-2 w-2/3 text-center text-gray-500">The owner of the chatbot has paused it, which may be due to maintenance or a service change.</div>
        <!-- <div class="mt-4 w-2/3 text-center text-xs">If you are the admin and don't know how to activate it, please contact hi@usemevo.com.</div> -->
      </div>
    </div>

    <!-- CHATBOT BODY -->
    <div
      v-else
      class="flex flex-col justify-between sm:w-2/3 lg:w-2/5 w-full relative"
    >
      <!-- <div v-if="$route.query.demo === '1'" class="bg-[#3834FF] text-[#F0F0FF] p-4 w-full h-fit flex justify-center items-center text-sm space-x-2">
        <Info class="w-4 h-4" />
        <span>Conversations won't be saved in demo mode.</span>
      </div> -->
      <!-- CHATBOT HEADER -->
      <!-- :class="`bg-${fallback.appearance.theme}-500`" -->
      <div
        class="w-full py-3 px-4 flex items-center justify-between border-b border-gray-100"
      >
        <!-- BACK BUTTON -->
        <!-- :class="`bg-${fallback.appearance.theme}-700 hover:bg-${fallback.appearance.theme}-700`" -->
        <!-- <div
          v-if="!fallback.appearance.skipWelcomePage"
          @click="go_welcome"
          class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer"
        >
          <i class="fa-solid fa-chevron-left text-white text-xl"></i>
        </div> -->
        <div class="flex items-center space-x-2">
          <!-- <div v-if="!fallback.appearance.skipWelcomePage" class="hover:bg-[#e2e4e8] cursor-pointer bg-[#f8fafd] rounded-full p-1" @click="go_welcome">
            <ArrowLeft class="text-[#81868d]" :size="14" :stroke-width="2" />
          </div> -->
          <div class="hover:bg-[#e2e4e8] cursor-pointer bg-[#f8fafd] rounded-full p-1" @click="go_welcome">
            <ArrowLeft class="text-[#81868d]" :size="14" :stroke-width="2" />
          </div>
          <div class="hover:bg-[#e2e4e8] cursor-pointer bg-[#f8fafd] rounded-full p-1" @click="create_new_session">
            <Plus class="text-[#81868d]" :size="14" :stroke-width="2" />
          </div>
        </div>
        <!-- BACK BUTTON -->

        <!-- CHATBOT TITLE -->
        <div
          class="font-medium antialiased flex flex-col justify-end items-end"
          :class="{
            'w-full items-center': fallback.appearance.skipWelcomePage,
          }"
        >
          <div class="text-sm">
            {{ conversation_state.bot.appearance.title }}
          </div>
          <!-- <div class="text-gray-400 text-xs font-light">AI Agent</div> -->
        </div>
        <!-- CHATBOT TITLE -->

        <!-- CLOSE ICON -->
        <!-- :class="`bg-${fallback.appearance.theme}-700 hover:bg-${fallback.appearance.theme}-700`" -->
        <div class="flex items-center space-x-2">
          <div class="opacity-0 hover:bg-[#e2e4e8] cursor-pointer bg-[#f8fafd] rounded-full p-1">
            <X class="text-[#81868d]" :size="14" :stroke-width="2" />
          </div>
          <div @click="post_message('chatbox-closed')" class="hover:bg-[#e2e4e8] cursor-pointer bg-[#f8fafd] rounded-full p-1">
            <X class="text-[#81868d]" :size="14" :stroke-width="2" />
          </div>
        </div>
        <!-- CLOSE ICON -->
      </div>
      <!-- CHATBOT HEADER -->

      <!-- CHATBOT MESSAGES AREA -->
      <div class="flex-1 overflow-y-scroll py-4" id="message-container">
        
          <!-- <previous-conversations
            :image="fallback.appearance.brandImage"
            :theme="fallback.appearance.theme"
            :conversations="conversation_state.previous_conversations"
          /> -->

          <!-- MESSAGES LOOP -->
          
            <div v-if="conversation_state.messages.length" class="flex flex-col">
              <Motion
                v-for="(message, index) in conversation_state.messages"
                :key="index"
                :initial="{ opacity: 0, y: -5 }"
                :animate="{ opacity: 1, y: 0 }"
                :transition="{ duration: 0.25 }" 
                >
                <message-item
                    :is-last-message="index === conversation_state.messages.length - 1"
                    @option-click="handleOptionClick"
                    :show_ai_indicator="conversation_state.show_ai_indicator"
                    :image="fallback.appearance.brandImage"
                    :theme="conversation_state.primary_color"
                    :text="message.text"
                    :sent_at="message.sent_at"
                    :sender="message.sender"
                    :sender_meta="message.sender_meta"
                    :show-metadata="isLastInGroup(index)"
                    :streaming="conversation_state.is_streaming"
                    :hex="true"
                    :message="message"
                    :primary-color="conversation_state.primary_color"
                    :light-color="conversation_state.light_color"
                    :class="[
                      isLastInGroup(index) && (index !== conversation_state.messages.length - 1) ? 'mb-4' : '',
                      !isLastInGroup(index) && 'mb-2'
                    ]"
                    :showYesNoInput="index === conversation_state.messages.length - 1 && isYesOrNoInput"
                    :yesNoOptions="['Yes', 'No']"
                  />
              </Motion>
              <!-- <div v-if="!conversation_state.messages.length" class="pt-2 pl-4 flex flex-col items-start space-y-2">
                <Skeleton class="w-[180px] h-[36px]" />
                <Skeleton class="w-[270px] h-[36px]" />
              </div>
              <div v-else-if="conversation_state.show_chat_starters" class="px-4 pt-2 flex gap-2 flex-wrap">
                <div @click="send_chat_starter(chat_starter)" class="cursor-pointer w-fit px-3 py-2 rounded-lg text-sm font-medium" :style="{ backgroundColor: conversation_state.light_color, color: conversation_state.primary_color  }" :key="index" v-for="(chat_starter, index) in conversation_state.chat_starters">{{
                  chat_starter
                }}</div>
              </div> -->
            </div>
            <div class="flex flex-col gap-4" v-else>
              <div class="px-4 space-x-4 flex items-end w-full" >
                <div>
                  <Skeleton class="rounded-[8px] w-[32px] h-[32px]" />
                </div>
                <div class="space-y-2">
                  <Skeleton class="w-[120px] h-[40px]" />
                  <Skeleton class="w-[200px] h-[40px]" />
                </div>
              </div>
              <div class="px-4 space-x-4 flex items-end justify-end w-full" >
                <div class="flex flex-col items-end space-y-2">
                  <Skeleton class="w-[120px] h-[40px]" />
                  <Skeleton class="w-[200px] h-[40px]" />
                </div>
              </div>
            </div>
          <!-- </Motion> -->
          <!-- MESSAGES LOOP -->
          <!-- <typing
            :image="fallback.appearance.brandImage"
            v-if="!conversation_state.is_streaming && conversation_state.is_typing"
          /> -->
          <!-- TYPING INDICATOR -->
          

          <message-item
            class="mt-4"
            v-if="conversation_state.is_typing"
            :image="fallback.appearance.brandImage"
            :theme="fallback.appearance.theme"
            :text="conversation_state.current_streaming_message"
            :sender="MessageSender.AI"
            :sender_meta="conversation_state.messages[0].sender_meta"
            :sent_at="conversation_state.messages[0].sent_at"
            :streaming="true"
            :show-metadata="true"
          />
            
            <!-- <div class="flex space-x-3">
              <img
                :src="fallback.appearance.brandImage"
                class="w-8 h-8 rounded-full object-cover"
                alt="AI"
              />
              <div
                class="bg-gray-100 p-4 rounded-lg flex-1 text-[15px] leading-relaxed"
              >
                <div class="whitespace-pre-wrap">{{ conversation_state.current_streaming_message }}</div>
                <div class="typing-indicator">
                  <span class="animate-pulse">▋</span>
                </div>
              </div>
            </div> -->
          
          <!-- TYPING INDICATOR -->

          <!-- LEAD CAPTURE FORM -->
          <div
            class="bg-gray-50 px-5 py-4 text-[15px] rounded-xl mx-6 relative"
            v-if="
              conversation_state.is_lead_capture_form_active &&
              !conversation_state.is_lead_capture_dismissed
            "
          >
            <div class="font-medium">
              {{ conversation_state.bot.inChatEmailInputTitle }}

              <i
                @click="hide_lead_capture_form"
                class="cursor-pointer fa fa-xmark text-gray-500 absolute top-5 right-5"
              />
            </div>
            <div class="text-sm font-light">
              {{ conversation_state.bot.inChatEmailInputDescription }}
            </div>
            <div class="flex space-x-2 mt-2">
              <Input
                :disabled="conversation_state.is_lead_capture_form_disabled"
                v-model="conversation_state.lead_capture_email"
                :placeholder="conversation_state.bot.emailPlaceholder"
                class="flex-1"
              />
              <Button
                @click="submit_lead_capture_form"
                :disabled="conversation_state.is_lead_capture_form_disabled"
                :class="`bg-${fallback.appearance.theme}-700 hover:bg-${conversation_state.bot.appearance.theme}-500 text-white`"
                >{{ conversation_state.bot.inChatEmailSubmitButtonLabel }}</Button
              >
            </div>
          </div>
          <!-- LEAD CAPTURE FORM -->

          <!-- RESPONSE FEEDBACK SURVEY -->
          <div
            v-if="conversation_state.show_feedback_options"
            class="bg-gray-50 p-4 text-[15px] rounded-xl mx-6 relative"
          >
            <div class="flex space-y-4 flex-col">
              <Button
                @click="handleFeedbackOption('yes')"
                :class="`bg-white border border-gray-200 hover:bg-gray-100 rounded text-black`"
                >{{ conversation_state.bot.surveyYes }}</Button
              >
              <Button
                @click="handleFeedbackOption('continue')"
                :class="`bg-white border border-gray-200 hover:bg-gray-100 rounded text-black`"
                >{{ conversation_state.bot.surveyNo }}</Button
              >
              <Button
                @click="handleFeedbackOption('human')"
                :class="`bg-white border border-gray-200 hover:bg-gray-100 rounded text-black`"
                >{{ conversation_state.bot.surveyHuman }}</Button
              >
            </div>
          </div>
          <!-- RESPONSE FEEDBACK SURVEY -->

          <!-- CONDITIONAL FEEDBACK SURVEY RESULT ACTIONS -->
          <div
            v-if="conversation_state.show_human_email_form"
            class="bg-gray-50 px-5 py-4 text-[15px] rounded-xl mx-6 relative"
          >
            <div class="font-medium">{{ conversation_state.bot.inChatEmailInputTitle }}</div>
            <div class="text-sm font-light">
              {{ conversation_state.bot.inChatEmailInputDescription }}
            </div>
            <div class="flex space-x-2 mt-2">
              <Input
                v-model="conversation_state.human_contact_email"
                :placeholder="conversation_state.bot.emailPlaceholder"
                class="flex-1"
              />
              <Button
                @click="submitHumanContactEmail"
                :disabled="conversation_state.is_human_email_submitting"
                :class="`bg-${fallback.appearance.theme}-700 hover:bg-${conversation_state.bot.appearance.theme}-500 text-white`"
                >{{ conversation_state.bot.inChatEmailSubmitButtonLabel }}</Button
              >
            </div>
          </div>
          <div
            v-if="conversation_state.show_new_conversation_button"
            class="mx-4 flex flex-col mt-4"
          >
            <div class="flex space-x-4 items-center w-full pb-4">
              <div class="border-b w-1/4"></div>
              <div class="text-xs w-1/2 text-center text-gray-500">Conversation end</div>
              <div class="border-b w-1/4"></div>
            </div>
            <Button
              @click="startNewConversation"
              :class="`w-full text-white`"
              :style="{ backgroundColor: conversation_state.primary_color, color: conversation_state.light_color }"
              >OK</Button
            >
          </div>
          <!-- CONDITIONAL FEEDBACK SURVEY RESULT ACTIONS -->
      </div>
      <!-- CHATBOT MESSAGES AREA -->

      <!-- INPUT AREA -->
      <div class="border-t">
          <transition name="fade">
            <div v-if="conversation_state.is_input_visible && !isYesOrNoInput" 
            :class="[
                    'relative flex items-center justify-center transition-all duration-200 overflow-hidden',
                    !isDateInput && 'py-2 space-x-2 my-2 mx-4 rounded-3xl border bg-gray-50',
                    isDateInput && 'my-2 mx-4'
                  ]">
                  <el-date-picker
                    v-if="isDateInput"
                    :model-value="conversation_state.date_value"
                    @update:model-value="handleDateChange"
                    type="date"
                    :placeholder="todayPlaceholder"
                    size="default"
                    class="!w-full !h-[50px] border-t !rounded-3xl"
                    format="MM.DD.YYYY"
                    value-format="MM-DD-YYYY"
                  />
                  <div v-if="isFileInput" class="w-full flex items-center justify-between gap-2 px-2">
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,image/*"
                      class="w-full text-sm"
                      @change="(e:any)=> onFilePicked(e)"
                    />
                    <Button class="absolute text-white hover:bg-gray-50 w-8 h-8 rounded-full flex items-center justify-center cursor-pointer right-2" size="icon" :disabled="!conversation_state.selected_file || conversation_state.is_streaming || conversation_state.is_typing" @click="on_file_submit">
                      <ArrowUp :size="20" :stroke-width="3" />
                    </Button>
                  </div>
                  <!-- <MazPhoneNumberInput
                    v-if="isPhoneInput"
                    v-model="conversation_state.phone_value"
                    color="info"
                    class="w-full pr-12 border-none --top" 
                    orientation="row"
                  /> -->
                
                <textarea
                  v-if="!isDateInput && !isFileInput"
                  :disabled="conversation_state.is_streaming || conversation_state.is_typing"
                  ref="messageInput"
                  v-model="conversation_state.message"
                  @input="adjustTextareaHeight"
                  @keydown.enter="handleEnterPress"
                  rows="1"
                  class="flex-1 max-w-full px-2 pr-20 py-1 pl-4 text-[14px] resize-none overflow-y-auto outline-none bg-transparent border-box"
                  :placeholder="fallback.appearance.placeholderText"
                ></textarea>
  
              <div
                  :class="[
                    ((conversation_state.message || conversation_state.date_value) && !conversation_state.is_streaming && !conversation_state.is_typing)
                      ? `bg-${fallback.appearance.theme}-500`
                      : 'bg-gray-100'
                  ]"
                  class="absolute text-white hover:bg-gray-50 w-8 h-8 rounded-full flex items-center justify-center cursor-pointer right-2 bottom-[8px]"
                  v-if="!isFileInput"
                  @click="on_submit"
                  :style="{
                    backgroundColor:
                      (conversation_state.message || conversation_state.date_value) && (!conversation_state.is_streaming && !conversation_state.is_typing)
                        ? conversation_state.primary_color
                        : '#ebebeb',
                    color:
                      (conversation_state.message || conversation_state.date_value) && (!conversation_state.is_streaming && !conversation_state.is_typing)
                        ? conversation_state.light_color
                        : 'white'
                  }"
                >
                  <ArrowUp :size="20" :stroke-width="3" />
                </div>
            </div>
          </transition>
        </div>
      <div class="flex justify-between items-center py-2 px-4 border-t border-gray-100">
        <!-- INPUT AREA -->
        <div class="text-xs flex items-center justify-start space-x-2 text-gray-500 antialiased flex-1">
          <span>By chatting you agree to our <a class="font-bold hover:underline" href="https://usemevo.com/gdpr/privacy-policy" target="_blank">Privacy Policy.</a></span>
        </div>
        <!-- BRANDING FOOTER -->
        <div
          v-if="!conversation_state.bot.appearance.hideBranding"
          class="text-xs w-fit flex items-center justify-end space-x-2"
        >
          <!-- <i class="fa-solid fa-bolt text-amber-500"></i> -->
          <span class="text-gray-500 font-light"
            >runs on
            <a href="https://usemevo.com" target="_blank"
              ><span class="font-bold text-[#3834FF]">mevo</span></a
            ></span
          >
        </div>
      </div>
      <!-- BRANDING FOOTER -->
    </div>
    <!-- CHATBOT BODY -->

    <!-- 
    from-gray-100 to-gray-300
    from-red-100 to-red-300
    from-yellow-100 to-yellow-300
    from-green-100 to-green-300
    from-blue-100 to-blue-300
    from-indigo-100 to-indigo-300
    from-purple-100 to-purple-300
    from-pink-100 to-pink-300
    focus-within:border-gray-300
    focus-within:border-blue-300
    focus-within:border-red-300
    focus-within:border-yellow-300
    focus-within:border-green-300
    focus-within:border-indigo-300
    focus-within:border-purple-300
    focus-within:border-pink-300
    hover:bg-blue-50
    hover:bg-red-50
    hover:bg-yellow-50
    hover:bg-green-50
    hover:bg-indigo-50
    hover:bg-purple-50
    hover:bg-pink-50
    hover:bg-gray-50
    -->
  </div>
</template>

<script lang="ts" setup>
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, ArrowUp, CirclePause, Plus, X } from "lucide-vue-next";
// import { v4 as uuidv4 } from "uuid";
import { computed, nextTick, onMounted, reactive, ref } from "vue";
import { useRoute, useRouter } from "vue-router";

import { dayjs } from "element-plus";
import { FlowEventType, type IFlowEvent } from "~/modules/bot/types/IFlowEvent";
import MessageItem from "../../modules/bot/containers/MessageItemNext.vue";
import {
    check_lead,
    get_bot_public,
    get_conversations_by_device,
    getActiveNodeForSession,
    interact_with_chatbot,
    interact_with_chatbot_stream,
    processNode,
    sendLead,
    uploadResponseFile
} from "../../modules/bot/services/BotService";
import { NodeType, ShowForm, type BotFlowChild, type IBot } from "../../modules/bot/types/IBot";
import { MessageSender } from "../../modules/bot/types/MessageSender";
import { useWidget } from "../../modules/widget/composables/useWidget";

const messageInput = ref<HTMLTextAreaElement | null>(null);
  const todayPlaceholder = dayjs().format('MM.DD.YYYY');
// state
export interface ConversationState {
  bot: IBot;
  message: string;
  display_message?: string;
  is_submitting: boolean;
  is_typing: boolean;
  session_id: string;
  chatbot_id: string;
  device_id: string;
  messages: {
    type?: string;
    text: string;
    sender: MessageSender;
    sent_at: string;
    sender_meta?: { _id: string, name: string, title: string, photo: string };
    node_id?: string;
  }[];
  previous_conversations: any[];
  is_previous_conversations_visible: boolean;
  is_loading: boolean;
  is_error: boolean;
  is_interacted_once: boolean;
  is_lead_capture_dismissed: boolean;
  is_lead_capture_form_active: boolean;
  lead_capture_email: string;
  is_lead_capture_form_disabled: boolean;
  message_acc: string;
  show_feedback_options: boolean;
  show_new_conversation_button: boolean;
  show_human_email_form: boolean;
  is_human_email_submitting: boolean;
  human_contact_email: string;
  human_communication_mode: boolean;
  human_mode_information_shown: boolean;
  is_lead_captured: boolean;
  is_survey_disabled: boolean;
  show_ai_indicator: boolean;
  captured_lead: {
    name: string;
    email: string;
    company: string;
  }
  active_node: BotFlowChild | null;
  is_input_visible: boolean;
  input_validation_rule: 'any' | 'email' | 'business-email' | 'yes-no' | 'one-to-ten' | 'phone' | 'number' | 'text' | 'url' | 'date' | 'file';
  input_validation_error_message: string;
  date_value: string;
  phone_value: string;
  selected_file?: File | null;
  yes_no: string;
  nodeMap: { [key: string]: BotFlowChild };
  is_streaming: boolean;
  current_streaming_message: string;
  use_streaming: boolean;
  chat_starters: string[];
  show_chat_starters: boolean;
  primary_color: string;
  light_color: string;
  light_hover_color: string;
  show_close_icon: boolean;
}

const conversation_state: ConversationState = reactive({
  bot: {} as IBot,
  message: "",
  display_message: "",
  is_submitting: false,
  is_typing: false,
  session_id: "",
  chatbot_id: "",
  device_id: "",
  messages: [],
  previous_conversations: [],
  is_previous_conversations_visible: false,
  is_loading: true,
  is_error: false,
  is_interacted_once: false,
  is_lead_capture_dismissed: false,
  is_lead_capture_form_active: false,
  lead_capture_email: "",
  is_lead_capture_form_disabled: false,
  is_survey_disabled: false,
  show_ai_indicator: true,
  message_acc: "",
  show_feedback_options: false,
  show_new_conversation_button: false,
  show_human_email_form: false,
  is_human_email_submitting: false,
  human_contact_email: "",
  human_communication_mode: false,
  human_mode_information_shown: false,
  is_lead_captured: false,
  captured_lead: {
    name: "",
    email: "",
    company: "",
  },
  active_node: null,
  is_input_visible: false,
  input_validation_rule: 'any',
  input_validation_error_message: 'Please provide a valid answer.',
  date_value: "",
  phone_value: "",
  selected_file: null,
  yes_no: "",
  nodeMap: {},
  is_streaming: false,
  current_streaming_message: "",
  use_streaming: true,
  chat_starters: [],
  show_chat_starters: false,
  primary_color: "#3834FF",
  light_color: "#F0F0FF",
  light_hover_color: "#E0E0FF",
  show_close_icon: false,
});
const isDateInput = computed(() => conversation_state.input_validation_rule === 'date');
const isPhoneInput = computed(() => conversation_state.input_validation_rule === 'phone');
const isYesOrNoInput = computed(() => conversation_state.input_validation_rule === 'yes-no');
const isFileInput = computed(() => conversation_state.input_validation_rule === 'file');
const validationFactory = {
  any: (value: string) => true,
  email: (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
  'business-email': (value: string) => {
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    if (!valid) return false;
    const domain = (value.split('@')[1] || '').toLowerCase();
    const freeDomains = new Set([
      'gmail.com','yahoo.com','hotmail.com','outlook.com','live.com','aol.com','icloud.com','proton.me','protonmail.com','yandex.com','yandex.ru','mail.com','gmx.com','zoho.com','pm.me','me.com','msn.com','ymail.com','rocketmail.com'
    ]);
    return domain.length > 0 && !freeDomains.has(domain);
  },
  'yes-no': (value: string) => /^(yes|no)$/i.test(value),
  phone: (value: string) => /^\+?[1-9]\d{1,14}$/.test(value),
  number: (value: string) => !isNaN(Number(value)) && value.trim() !== '',
  'one-to-ten': (value: string) => {
    const n = Number(value);
    return !isNaN(n) && Number.isFinite(n) && n >= 1 && n <= 10;
  },
  alphanumeric: (value: string) =>
    /^[a-zA-Z0-9\s]+$/.test(value.trim()),

  url: (value: string) =>
    /^(https?:\/\/)?([\w.-]+)\.([a-z]{2,6})([\/\w .-]*)*\/?$/.test(value.trim()),

  date: (value: string) => {
    const parsedDate = Date.parse(value);
    return !isNaN(parsedDate);
  },
  // Add more validation types as needed  
}

const isLastInGroup = (currentIndex: number): boolean => {
  const messages = conversation_state.messages;
  const currentMessage = messages[currentIndex];
  
  // If this is the last message, show metadata
  if (currentIndex === messages.length - 1) {
    return true;
  }
  
  // If the next message has a different sender, show metadata
  const nextMessage = messages[currentIndex + 1];
  return currentMessage.sender !== nextMessage.sender;
};

const handleOptionClick = (option: string | { label: string; value: string; isSelectNumber: boolean }) => {
  if (typeof option === 'object' && option.isSelectNumber) {
    // For select-number, use label for display and value for backend
    conversation_state.message = option.value; // Backend gets the value
    conversation_state.display_message = option.label; // Display shows the label
  } else {
    conversation_state.message = option as string;
    conversation_state.display_message = option as string;
  }
  on_submit();
}

const adjustTextareaHeight = (event: Event | null = null) => {
  const textarea = messageInput.value;
  if (!textarea) return;

  if (!event) {
    textarea.style.height = '40px';
    return;
  }
  
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
};

const send_chat_starter = (chat_starter: string) => {
  conversation_state.message = chat_starter;
  on_submit();
  conversation_state.show_chat_starters = false;
}

const fallback = {
  meta: {
    title: "AI Assistant",
    description: "Start a conversation with our AI assistant",
    keywords: "AI, Assistant, Chatbot",
    og_image: "",
  },
  appearance: {
    placeholderText: "Type a message...",
    brandImage: "https://images.unsplash.com/photo-1596367407372-96cb88503db6",
    theme: "blue",
    greeting: "Hello!",
    title: "AI Assistant",
    talkWithAgentMessage: "Talk with an agent",
    hideBranding: false,
    firstMessage: "Hello! How can I help you today?",
    skipWelcomePage: false,
  },
};

// hooks
const $route = useRoute();
const $router = useRouter();
const { scrollToBottom } = useWidget();

// Enhanced scroll function for better reliability with animation
const scrollToBottomEnhanced = (selector: string) => {
  nextTick(() => {
    setTimeout(() => {
      const container = document.querySelector(selector);
      if (container) {
        // First try smooth scroll with animation
        container.scrollTo({
          top: container.scrollHeight,
          left: 0,
          behavior: 'smooth',
        });
        
        // Fallback to ensure we reach the bottom if smooth scroll fails
        setTimeout(() => {
          if (container.scrollTop < container.scrollHeight - container.clientHeight - 10) {
            container.scrollTop = container.scrollHeight;
          }
        }, 500);
      }
    }, 10);
  });
};

const create_new_session = () => {
  const new_session_id = (Math.random().toString(36).slice(2) + Date.now().toString(36));
  // init session id
  localStorage.setItem(
    `mevo:${$route.params.id}:session_id`,
    JSON.stringify({
      id: new_session_id,
      exp: new Date().getTime() / 1000 + 3600,
    })
  );

  $router.replace({
    name: "id-next",
    params: { id: $route.params.id },
    query: {
      ...$route.query,
      session: new_session_id,
    },
  }).then(() => {
    window.location.reload();
  });
}

// methods
const handleEnterPress = async (event: KeyboardEvent) => {
    if (event.key === 'Enter') {
        if (event.shiftKey) {
            return;
        } else {
            event.preventDefault();
            on_submit();
        }
    }
};
function formatDateForDisplay(dateStr: string): string {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${month}/${day}/${year}`;
}
const on_submit = () => {
    conversation_state.show_chat_starters = false;
    
    if (!conversation_state.is_input_visible) return;
  
    const isDate = conversation_state.input_validation_rule === 'date';
    const inputValue = isDate ? conversation_state.date_value : conversation_state.message;
  
    if (!inputValue?.trim()) return;
  
    const rule = conversation_state.input_validation_rule as keyof typeof validationFactory;
    const isValid = validationFactory[rule]?.(inputValue as any);
    if (!isValid) {
      execute_event({
        type: FlowEventType.PUSH_MESSAGE,
        payload: conversation_state.input_validation_error_message,
      });
      return;
    }
  
    const displayMessage = isDate
      ? formatDateForDisplay(inputValue)
      : (conversation_state.display_message || inputValue);
  
    const payloadMessage = isDate
      ? formatDateForDisplay(inputValue)
      : inputValue;
  
    conversation_state.message_acc = payloadMessage;
    conversation_state.message = "";
    conversation_state.display_message = "";
    conversation_state.date_value = "";
    conversation_state.input_validation_rule = 'any';
  
    if (conversation_state.active_node) {
      process_event_on_server(conversation_state.active_node, conversation_state.message_acc);
      conversation_state.messages.push({
        text: displayMessage,
        sender: MessageSender.USER,
        sent_at: new Date().toISOString(),
      });
      conversation_state.is_typing = true;
      scrollToBottom("#message-container");
    }
  };

  const onFilePicked = (e: Event) => {
    const target = e.target as HTMLInputElement;
    const file = target.files && target.files[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      execute_event({ type: FlowEventType.PUSH_MESSAGE, payload: 'File is too large. Max 10MB.' });
      return;
    }
    conversation_state.selected_file = file;
  };

  const on_file_submit = async () => {
    if (!conversation_state.selected_file || !conversation_state.active_node) return;
    try {
      const resp = await uploadResponseFile({
        botId: String(conversation_state.bot._id || ''),
        file: conversation_state.selected_file,
        stepId: conversation_state.active_node.id,
        deviceId: conversation_state.device_id,
      });
      if (resp.isOk()) {
        // show a simple confirmation and pass a placeholder as user's message
        conversation_state.messages.push({
          text: (conversation_state.selected_file && conversation_state.selected_file.name) ? conversation_state.selected_file.name : 'Attachment',
          sender: MessageSender.USER,
          sent_at: new Date().toISOString(),
        });
    const payload = resp.value.payload as any;
    const id: string = (payload && (payload.id || payload.payload?.id)) ? (payload.id || payload.payload?.id) : 'unknown';
    conversation_state.message_acc = `file:${id}`;
        conversation_state.selected_file = null;
        conversation_state.input_validation_rule = 'any';
        process_event_on_server(conversation_state.active_node, conversation_state.message_acc);
        conversation_state.is_typing = true;
        scrollToBottom("#message-container");
      } else {
        execute_event({ type: FlowEventType.PUSH_MESSAGE, payload: 'Upload failed. Please try again.' });
      }
    } catch (err: any) {
      if (String(err?.message || '').includes('429')) {
        execute_event({ type: FlowEventType.PUSH_MESSAGE, payload: 'You can upload up to 2 files per hour.' });
      } else {
        execute_event({ type: FlowEventType.PUSH_MESSAGE, payload: 'Upload failed. Please try again.' });
      }
    }
  };

  const handleDateChange = (val: string) => {
      conversation_state.date_value = val;
    };
// const on_submit = async () => {
//   if (!conversation_state.message.trim() || 
//     conversation_state.message.replace(/\s/g, '') === '') {
//     return;
//   }

//   if (!conversation_state.message) return;

//   conversation_state.messages.push({
//     text: conversation_state.message,
//     sender: MessageSender.USER,
//     sent_at: new Date().toISOString(),
//   });

//   if (conversation_state.human_communication_mode) {
//     if (!conversation_state.human_mode_information_shown) {
//       conversation_state.messages.push({
//         text: 'It may take a while to get a response. You will receive an email notification when our support team replied to your message.',
//         sender: MessageSender.AI,
//         sent_at: new Date().toISOString(),
//       });
//       conversation_state.human_mode_information_shown = true;
//     }
//     messageInput.value?.focus();
//   } else {
//     conversation_state.is_typing = true;
//   }

//   conversation_state.message_acc = conversation_state.message;
//   conversation_state.message = "";
//   scrollToBottom("#message-container");
//   adjustTextareaHeight(null);

//   // show loader
//   conversation_state.is_submitting = true;

//   const interact_with_chatbot_response = await interact_with_chatbot(
//     conversation_state.chatbot_id,
//     {
//       message: conversation_state.message_acc,
//       sid: conversation_state.session_id,
//       did: conversation_state.device_id,
//       is_demo: $route.query.demo === "1",
//       human_communication_mode: conversation_state.human_communication_mode
//     }
//   );

//   if (interact_with_chatbot_response.isOk()) {
//     if (interact_with_chatbot_response.value.payload) {
//       conversation_state.message = "";
//       conversation_state.is_submitting = false;
//       conversation_state.is_interacted_once = true;
//       if (!conversation_state.human_communication_mode) {
//         await check_response();
//       }
//       adjustTextareaHeight(null);
//       messageInput.value?.focus();
//     } else {
//       conversation_state.messages.push({
//         text: "We can not answer this question now, could you please try again later?",
//         sender: MessageSender.AI,
//         sent_at: new Date().toISOString(),
//       });
//       conversation_state.is_submitting = false;
//       conversation_state.message = "";
//       scrollToBottom("#message-container");
//       await nextTick();
//       adjustTextareaHeight(null);
//       messageInput.value?.focus();
//     }
//   } else {
//     conversation_state.is_submitting = false;
//     await nextTick();
//     conversation_state.message = "";
//     adjustTextareaHeight(null);
//     messageInput.value?.focus();
//     if (
//       interact_with_chatbot_response.error.message ===
//       "chatbot_interaction.TOKEN_LIMIT_REACHED"
//     ) {
//       conversation_state.messages.push({
//         text: "This chatbot is currently out of service. Please try to contact us through a different communication channel.",
//         sender: MessageSender.AI,
//         sent_at: new Date().toISOString(),
//       });
//       await nextTick();
//       messageInput.value?.focus();
//       conversation_state.message = "";
//       adjustTextareaHeight(null);
//     }
//   }
// };

const post_message = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

// const input_hidden = computed(() => {
//   return conversation_state.messages && conversation_state.messages.length && conversation_state.messages[conversation_state.messages.length - 1].text.includes('__MEVO__')
// })

// const check_response = async () => {
//   conversation_state.is_typing = true;
//   const chatbot_response = await check_chatbot_response(
//     conversation_state.session_id,
//     conversation_state.chatbot_id,
//     conversation_state.device_id,
//     $route.query.demo === "1"
//   );

//   if (chatbot_response.isOk()) {
//     if (chatbot_response.value.payload.status) {
//       conversation_state.is_typing = false;
//       await nextTick();
//       messageInput.value?.focus();
//       conversation_state.messages.push({
//         text: chatbot_response.value.payload.message,
//         sender: MessageSender.AI,
//         sent_at: new Date().toISOString(),
//       });
//       check_lead_capture_status();
//       scrollToBottomEnhanced("#message-container");
//       if (!conversation_state.is_survey_disabled) {
//         // Show feedback options after AI responds
//         conversation_state.show_feedback_options = true;
//         conversation_state.messages.push({
//           text: conversation_state.bot.surveyMessage,
//           sender: MessageSender.AI,
//           sent_at: new Date().toISOString(),
//         });
//       }
//     } else {
//       setTimeout(() => {
//         check_response();
//       }, 1000);
//     }
//   } else {
//     setTimeout(() => {
//       check_response();
//     }, 1000);
//   }
// };

const handleFeedbackOption = async (option: string) => {
  // Add the user's response to the conversation
  conversation_state.messages.push({
    text: option === 'yes' ? conversation_state.bot.surveyYes : 
          option === 'continue' ? conversation_state.bot.surveyNo : 
          conversation_state.bot.surveyHuman,
    sender: MessageSender.USER,
    sent_at: new Date().toISOString(),
  });
  
  if (option === 'yes') {
    // User is satisfied, show new conversation button
    conversation_state.show_feedback_options = false;
    conversation_state.show_new_conversation_button = true;
    scrollToBottomEnhanced("#message-container");
    await interact_with_chatbot(
      conversation_state.chatbot_id,
      {
        message: 'MEVO_EVENT_HELPED',
        sid: conversation_state.session_id,
        did: conversation_state.device_id,
        is_demo: $route.query.demo === "1",
        human_communication_mode: conversation_state.human_communication_mode
      }
    );
  } else if (option === 'continue') {
    // User wants to continue, hide feedback options and show input
    conversation_state.show_feedback_options = false;
    scrollToBottomEnhanced("#message-container");
    await nextTick();
    messageInput.value?.focus();
  } else if (option === 'human') {
    // User wants to talk to a human
    conversation_state.show_feedback_options = false;
    
    if (conversation_state.is_lead_captured) {
      // Add system message about human contact
      conversation_state.messages.push({
        text: `Our team contact you via ${conversation_state.captured_lead.email} email address.`,
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });

      conversation_state.show_new_conversation_button = true;
    } else {
      conversation_state.show_human_email_form = true;
      // Add system message about human contact
      conversation_state.messages.push({
        text: "If you leave your email, our team will contact you as soon as possible.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
    }

    await interact_with_chatbot(
      conversation_state.chatbot_id,
      {
        message: 'MEVO_EVENT_HUMAN_DEMAND',
        sid: conversation_state.session_id,
        did: conversation_state.device_id,
        is_demo: $route.query.demo === "1",
        human_communication_mode: conversation_state.human_communication_mode
      }
    );

    scrollToBottomEnhanced("#message-container");
  }
};

const startNewConversation = async () => {
  // Hide the button immediately for UX
  conversation_state.show_new_conversation_button = false;
  // Reuse existing session creation flow (updates localStorage, route, and reloads)
  create_new_session();
};

const submitHumanContactEmail = async () => {
  if (!conversation_state.human_contact_email || 
      !conversation_state.human_contact_email.includes('@')) {
    return; // Basic validation
  }
  
  conversation_state.is_human_email_submitting = true;
  
  try {
    // Submit the email as a lead
    const lead_response = await sendLead({
      bot: conversation_state.bot._id || "",
      email: conversation_state.human_contact_email,
      device_id: conversation_state.device_id,
      is_demo: $route.query.demo === "1",
    });
    
    if (lead_response.isOk()) {
      // Add confirmation message
      conversation_state.messages.push({
        text: "Thank you! Our team will contact you soon and you will receive an email notification, keep your eye on your inbox.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      
      // Show new conversation button
      conversation_state.show_human_email_form = false;
      conversation_state.show_new_conversation_button = true;
    } else {
      // Show error message
      conversation_state.messages.push({
        text: "Sorry, we couldn't process your request. Please try again later.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
    }
  } catch (error) {
    console.error("Error submitting human contact email:", error);
    // Show error message
    conversation_state.messages.push({
      text: "Sorry, we couldn't process your request. Please try again later.",
      sender: MessageSender.AI,
      sent_at: new Date().toISOString(),
    });
  } finally {
    conversation_state.is_human_email_submitting = false;
    scrollToBottomEnhanced("#message-container");
  }
};

const on_show_prev_conversations = () => {
  conversation_state.is_previous_conversations_visible = true;
};

const hide_lead_capture_form = () => {
  conversation_state.is_lead_capture_form_active = false;
  conversation_state.is_lead_capture_dismissed = true;
  localStorage.setItem(
    "lead_capture_dismissed-" + conversation_state.bot._id,
    "true"
  );
};

const go_welcome = () => {
  $router.push({
    name: "id-welcome",
    params: { id: conversation_state.bot._id },
    query: {
      demo: $route.query.demo === "1" ? "1" : "0",
      "force-new-conversation":
        $route.query["force-new-conversation"] === "1" ? "1" : "0",
    },
  });
};

// const init_first_message = () => {
//   conversation_state.messages.push({
//     text: fallback.appearance.firstMessage,
//     sender: MessageSender.AI,
//     sent_at: new Date().toISOString(),
//   });
// };

// check if lead capture form should be shown
// after the first interaction
const check_lead_capture_status = () => {
  // if lead capture is not enabled, return
  if (
    conversation_state.bot &&
    conversation_state.bot.showForm !== ShowForm.IN_CHAT
  )
    return;

  // set lead capture form active if the user is interacted once
  // and the lead capture form is not shown
  if (
    conversation_state.is_interacted_once &&
    !conversation_state.is_lead_capture_dismissed
  ) {
    conversation_state.is_lead_capture_form_active = true;
  }
};

const submit_lead_capture_form = async () => {
  conversation_state.is_lead_capture_form_disabled = true;
  const send_lead_response = await sendLead({
    bot: conversation_state.bot._id || "",
    email: conversation_state.lead_capture_email,
    device_id: conversation_state.device_id,
    is_demo: $route.query.demo === "1",
  });

  if (send_lead_response.isOk()) {
    conversation_state.is_lead_capture_form_active = false;
    conversation_state.is_lead_capture_dismissed = true;
    localStorage.setItem(
      "lead_capture_dismissed-" + conversation_state.bot._id,
      "true"
    );
  } else {
    conversation_state.is_lead_capture_form_disabled = false;
  }
};

function traverseFlow(map: { [key: string]: any }, flow: BotFlowChild[]) {
    flow.forEach((node: BotFlowChild) => {
        map[node.id] = node;
        if (node.children && node.children.length > 0) {
            traverseFlow(map, node.children);
        }
    });
}

const handleStreamingInteraction = async () => {
  conversation_state.is_typing = true;
  conversation_state.is_streaming = true;
  conversation_state.current_streaming_message = '';

  try {
    await interact_with_chatbot_stream(
      conversation_state.chatbot_id,
      {
        message: conversation_state.message_acc,
        sid: conversation_state.session_id,
        did: conversation_state.device_id,
        is_demo: $route.query.demo === "1",
        human_communication_mode: conversation_state.human_communication_mode
      },
      // onMessage callback
      (chunk) => {
        conversation_state.current_streaming_message += chunk.content;
        scrollToBottom("#message-container");
      },
      // onComplete callback
      (fullResponse) => {
        // Set both streaming states to false simultaneously to prevent blinking
        conversation_state.is_streaming = false;
        conversation_state.is_typing = false;
        
        // Add final message to conversation
        // conversation_state.messages.push({
        //   text: fullResponse,
        //   sender: MessageSender.AI,
        //   sent_at: new Date().toISOString(),
        // });
        execute_event({
          type: FlowEventType.PUSH_MESSAGE,
          payload: fullResponse
        });
        
        conversation_state.current_streaming_message = '';
        conversation_state.is_submitting = false;
        conversation_state.is_interacted_once = true;
        
        // check_lead_capture_status();
        
        // if (!conversation_state.is_survey_disabled) {
        //   conversation_state.show_feedback_options = true;
        //   conversation_state.messages.push({
        //     text: conversation_state.bot.surveyMessage,
        //     sender: MessageSender.AI,
        //     sent_at: new Date().toISOString(),
        //   });
        // }

        // execute_event({
        //   type: FlowEventType.SHOW_INPUT,
        // });
        execute_event({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: conversation_state.bot.flow[0].children[1].children[0].id
        });
        
        scrollToBottom("#message-container");
        messageInput.value?.focus();
      },
      // onError callback
      (error) => {
        conversation_state.is_streaming = false;
        conversation_state.is_submitting = false;
        conversation_state.is_typing = false;
        conversation_state.current_streaming_message = '';
        
        conversation_state.messages.push({
          text: "We can not answer this question now, could you please try again later?",
          sender: MessageSender.AI,
          sent_at: new Date().toISOString(),
        });

        execute_event({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: conversation_state.bot.flow[0].children[0].children[0].id
        });
        
        scrollToBottom("#message-container");
        messageInput.value?.focus();
      }
    );
  } catch (error) {
    conversation_state.is_streaming = false;
    conversation_state.is_submitting = false;
    conversation_state.current_streaming_message = '';
    console.error('Streaming interaction error:', error);
  }
};

const execute_event = (event: IFlowEvent) => {
    if ($route.query.demo === '1')  {
      post_message('BOT_EVENT', JSON.stringify(event));
    }

    switch (event.type) {
        case FlowEventType.PROCESS_ON_SERVER:
            if (conversation_state.active_node?.data.type === NodeType.AI_ASSIST) {
              process_event_on_server(conversation_state.active_node as BotFlowChild, conversation_state.message_acc);
            } else {
              process_event_on_server(conversation_state.active_node as BotFlowChild);
            }
            break;
        case FlowEventType.SHOW_INPUT:
            conversation_state.message = "";
            conversation_state.is_input_visible = true;
            conversation_state.is_typing = false;
            break;
        case FlowEventType.HIDE_INPUT:
            conversation_state.is_input_visible = false;
            break;
            case FlowEventType.PUSH_MESSAGE:
              if (event.meta?.contentType === 'image') {
                  conversation_state.messages.push({
                      type: 'image',
                      text: event.payload,
                      sender: MessageSender.AI,
                      sent_at: new Date().toISOString(),
                  });
              } else {
                  conversation_state.messages.push({
                      type: 'text',
                      text: event.payload,
                      sender: MessageSender.AI,
                      sent_at: new Date().toISOString(),
                  });
              }

              conversation_state.is_typing = false;
              scrollToBottomEnhanced("#message-container");
              break;
        case FlowEventType.SET_ACTIVE_NODE:
            const node = conversation_state.nodeMap[event.payload];

            if (node) {
                conversation_state.active_node = node;

                execute_event({
                  type: FlowEventType.PROCESS_ON_SERVER,
                  payload: node
                });
            } else {
                conversation_state.is_error = true;
                console.warn('Node not found in flow:', event.payload);
            }
            break;
        case FlowEventType.SET_INPUT_VALIDATION_RULE:
            conversation_state.input_validation_rule = event.payload.type;
            conversation_state.input_validation_error_message = event.payload.errorMessage || 'Please provide a valid answer';
            break;
      case FlowEventType.END_FLOW:
        conversation_state.is_input_visible = false;
        conversation_state.show_new_conversation_button = true;
        break;
        default:
            console.warn("Unhandled event type:", event.type);
            break;
    }
}

const init_chatbot_flow = (flow: BotFlowChild[]) => {
  if (flow && flow.length > 0 && flow[0].children && flow[0].children.length > 2) {
    const session_device_internal = setInterval(() => {
      if (conversation_state.session_id && conversation_state.device_id) {
        clearInterval(session_device_internal);

        // Eğer aktif node QUESTION tipindeyse ve mesajlar varsa, tekrar işleme
        if (conversation_state.active_node?.data.type === NodeType.QUESTION && conversation_state.messages.length > 0) {
          execute_event({
            type: FlowEventType.SHOW_INPUT,
          });
        } else {
          execute_event({
            type: FlowEventType.SET_ACTIVE_NODE,
            payload: conversation_state.active_node?.id || '3',
          });
        }
      }

      // if ($route.query.message) {
      //   conversation_state.message = $route.query.message as string;
      //   conversation_state.is_input_visible = true;
      //   on_submit();
      // }
    }, 500)
  } else {
    console.warn("There is a problem with this chatbot flow.");
    conversation_state.is_error = true;
  }
}

const find_node_by_id = (node: BotFlowChild, nodeId: string): BotFlowChild | null => {
    if (node.id === nodeId) return node;
    if (!node.children) return null;
    for (const child of node.children) {
        const found = find_node_by_id(child, nodeId);
        if (found) return found;
    }
    return null;
}

const process_event_on_server = async (node: BotFlowChild, message?: string) => {
  if (conversation_state.bot._id && conversation_state.active_node) {
      let payload = {
        botId: conversation_state.bot._id || "",
        sessionId: conversation_state.session_id,
        deviceId: conversation_state.device_id,
        nodeId: conversation_state.active_node?.id || "",
        is_demo: $route.query.demo === "1"
      };

      if (message) {
        // @ts-ignore
        payload.message = message;
      }

      const processNodeResponse = await processNode(payload);

      if (processNodeResponse.isOk()) {
        const events = processNodeResponse.value.payload || [];
        events.forEach((event: IFlowEvent) => execute_event(event));
      } else {
        console.error("Error processing node:", processNodeResponse.error);
      }
  } else {
    console.error("Bot ID or active node is not set.");
  }
}

// computeds
window.addEventListener(
  "message",
  (event) => {
    try {
      var data = JSON.parse(event.data);
      if (data.kind === "user-message") {
        conversation_state.message = data.data;
        on_submit();
      }
    } catch (e) {}
  },
  false
);

function lightenColor(hexColor: string, amount = 0.9) {
  // Hex formatını temizle ve doğrula
  let hex = hexColor.replace('#', '');
  
  // 3 karakter hex ise 6 karaktere çevir (#FFF -> #FFFFFF)
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  
  // Geçerli hex olup olmadığını kontrol et
  if (hex.length !== 6 || !/^[0-9A-Fa-f]{6}$/.test(hex)) {
    console.error('Geçersiz hex renk kodu:', hexColor);
    return hexColor; // Hatalı durumda orijinal değeri döndür
  }
  
  // Hex'i RGB'ye çevir
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  
  // NaN kontrolü
  if (isNaN(r) || isNaN(g) || isNaN(b)) {
    console.error('RGB değerleri parse edilemedi:', { r, g, b });
    return hexColor;
  }
  
  // Beyaz ile karıştır
  const newR = Math.round(r + (255 - r) * amount);
  const newG = Math.round(g + (255 - g) * amount);
  const newB = Math.round(b + (255 - b) * amount);
  
  // RGB'yi tekrar hex'e çevir (padStart ile 2 karakter garantisi)
  const toHex = (value: number) => {
    const hex = Math.max(0, Math.min(255, value)).toString(16);
    return hex.padStart(2, '0');
  };
  
  return `#${toHex(newR)}${toHex(newG)}${toHex(newB)}`;
}

onMounted(async () => {
  if (localStorage.getItem(`mevo_${$route.params.id}_lead`)) {
    conversation_state.is_lead_captured = true;
    const lead = JSON.parse(localStorage.getItem(`mevo_${$route.params.id}_lead`) || "{}");
    conversation_state.captured_lead = {
      name: lead.name,
      email: lead.email,
      company: lead.company
    }
  }

  // init mevo identity
  if (
    !localStorage.getItem("mevo_device_id") ||
    $route.query["force-new-conversation"] === "1"
  ) {
    // init device id
    localStorage.setItem("mevo_device_id", (Math.random().toString(36).slice(2) + Date.now().toString(36)));
    // init session id
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: (Math.random().toString(36).slice(2) + Date.now().toString(36)),
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  if ($route.query.device_id) {
    conversation_state.device_id = $route.query.device_id as string;
    localStorage.setItem('mevo_device_id', $route.query.device_id as string);
  }

  if (!$route.query.session) {
    const new_session_id = (Math.random().toString(36).slice(2) + Date.now().toString(36));
    // init session id
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: new_session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
    // update session id in query
    conversation_state.session_id = new_session_id;
    $router.replace({
      name: "id-next",
      params: { id: $route.params.id },
      query: {
        session: new_session_id,
        ...$route.query,
      }
    })
  }

  if ($route.query.hcm) {
    conversation_state.human_communication_mode = true;
  }

  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    if (public_bot_response.value.payload.bot.appearance.theme !== '#000') {
      conversation_state.primary_color = public_bot_response.value.payload.bot.appearance.theme;
      conversation_state.light_color = lightenColor(public_bot_response.value.payload.bot.appearance.theme, 0.95);
      conversation_state.light_hover_color = lightenColor(public_bot_response.value.payload.bot.appearance.theme, 0.98);
    }

    conversation_state.is_loading = false;
    conversation_state.is_error = false;
    conversation_state.bot = public_bot_response.value.payload.bot as IBot;
    conversation_state.show_ai_indicator = conversation_state.bot.config?.show_ai_indicator ?? true;
    conversation_state.is_survey_disabled = conversation_state.bot.config?.is_survey_disabled ?? false;

    if (public_bot_response.value.payload.bot.config?.meta) {
      fallback.meta = public_bot_response.value.payload.bot.config.meta;
    }

    if (public_bot_response.value.payload.bot.appearance) {
      fallback.appearance = public_bot_response.value.payload.bot.appearance;
    }

    conversation_state.chat_starters =
      public_bot_response.value.payload.chat_starters.map((chat_starter: any) => {
        return chat_starter.question;
      });

    // init_first_message();
    traverseFlow(
      conversation_state.nodeMap,
      public_bot_response.value.payload.bot.flow || []
    );
    
    useSeoMeta({
      title: fallback.meta.title,
      ogTitle: fallback.meta.title,
      description: fallback.meta.description,
      ogDescription: fallback.meta.description,
      ogImage: fallback.meta.og_image,
      twitterCard: "summary_large_image",
      keywords: fallback.meta.keywords,
    });

    useHead({
      link: [
        {
          rel: "icon",
          type: "image/x-icon",
          href: fallback.appearance.brandImage,
        },
      ],
    });
  } else {
    conversation_state.is_loading = false;
    conversation_state.is_error = true;
  }

  // check mevo_session in local storage
  const mevo_session = JSON.parse(
    // @ts-ignore
    localStorage.getItem(`mevo:${$route.params.id}:session_id`)
  );

  // if we have a valid session, use it
  if (mevo_session && mevo_session.exp > new Date().getTime() / 1000) {
    conversation_state.session_id = mevo_session.id;

    // and update the expire time to 1 hour
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: conversation_state.session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }
  // if we don't have a valid session, create a new one
  else {
    conversation_state.session_id = (Math.random().toString(36).slice(2) + Date.now().toString(36));
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: conversation_state.session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  conversation_state.chatbot_id = $route.params.id as string;
  conversation_state.device_id = localStorage.getItem(
    "mevo_device_id"
  ) as string;

  if (!conversation_state.device_id) {
    $router.push({
      name: "id-welcome",
      params: { id: conversation_state.chatbot_id },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
      },
    });
  }

  if ($route.query.session) {
    conversation_state.session_id = $route.query.session as string;
  }

  // check if we have previous sessions
  const previous_sessions_response = await get_conversations_by_device(
    conversation_state.chatbot_id,
    conversation_state.device_id
  );

  if (previous_sessions_response.isOk()) {
    let sessions = previous_sessions_response.value.payload;

    const current_session = sessions.find(
      (session: any) => session._id === conversation_state.session_id
    );

    

    if (current_session) {
      let messages = sessions.find(
        (session: any) => session._id === conversation_state.session_id
      ).messages;

      messages.forEach(
        (message: { text: string; sender: MessageSender; sent_at: string; sender_meta: { _id: string, name: string, title: string, photo: string } }) => {
          conversation_state.messages.push({
            text: message.text,
            sender: message.sender,
            sent_at: message.sent_at,
            sender_meta: message.sender_meta
          });
        }
      );

      conversation_state.previous_conversations = sessions.filter(
        (session: any) => session._id !== conversation_state.session_id
      );

      const at_least_one_message_is_from_user = messages.some((message: { sender: MessageSender }) => message.sender === MessageSender.USER);

      if (at_least_one_message_is_from_user) {
        localStorage.setItem(`mevo_${$route.query.session}_chat_starter_shown`, 'true');
        conversation_state.show_chat_starters = false;
      } else {
        conversation_state.show_chat_starters = true;
      }

    } else {
      conversation_state.previous_conversations = sessions;
    }
  }

  // if in chat lead capture enabled
  // we need to check existing leads for this device
  if (conversation_state.bot.showForm === ShowForm.IN_CHAT) {
    const lead_check_response = await check_lead({
      bot_id: $route.params.id as string,
      device_id: localStorage.getItem("mevo_device_id") as string,
    });

    // if the user is already a lead, dismiss the lead capture form
    if (lead_check_response.isOk()) {
      if (lead_check_response.value.payload) {
        conversation_state.is_lead_capture_dismissed = true;
      }
    }
  }

  const is_lead_capture_dismissed = localStorage.getItem(
    "lead_capture_dismissed-" + conversation_state.bot._id
  );

  if (is_lead_capture_dismissed) {
    conversation_state.is_lead_capture_dismissed = true;
  }

  const active_node_response = await getActiveNodeForSession(conversation_state.session_id);
  
  if (active_node_response.isOk()) {
    const node = conversation_state.nodeMap[active_node_response.value.payload];
    conversation_state.active_node = node;
  }

  init_chatbot_flow(
    conversation_state.bot.flow
  );

  scrollToBottomEnhanced("#message-container");

  messageInput.value?.focus();
});
</script>

<style>
@keyframes spin-smooth {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.icon-spin {
  animation: spin-smooth 1s cubic-bezier(0.65, 0.05, 0.36, 1) infinite;
  display: inline-block;
}

.el-input__wrapper {
  border-radius: 1.5rem !important;
  overflow: hidden;
  background-color: #f9fafb;
}
.m-phone-number-input{
  border: 0rem !important;
}
.m-input-input{
  border: 0rem !important;
}
.m-input-wrapper-input{
  border: 0rem !important;
}
.m-select-list__scroll-wrapper{
  z-index: 1020;
}
</style>