<template>
  <div class="flex flex-col items-center justify-center h-screen w-full">
    <div
      class="flex items-center justify-center items-center flex-col space-y-4"
    >
      <CircleCheckBig
        class="text-blue-500 w-12 h-12" />
      <div class="flex flex-col items-center">
        <div class="font-medium text-lg">Done!</div>
        <div class="text-gray-500">We've received your submission</div>
      </div>
      <div v-if="show_close" @click="post_message('chatbox-closed')" class="sm:hidden underline cursor-pointer text-sm text-gray-500">
        Close
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { CircleCheckBig } from 'lucide-vue-next';

const $route = useRoute();

const post_message = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

const show_close = ref(false);

onMounted(() => {
  show_close.value = $route && $route.query && $route.query.show_close === '1';
})
</script>
