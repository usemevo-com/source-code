<template>
  <div class="flex justify-center items-center w-full h-screen">
    <!-- <LoaderCircle
      class="animate-spin text-gray-500"
      :size="32"
      stroke-width="1"
      color="currentColor"
    /> -->
  </div>
</template>

<script lang="ts" setup>
import { onMounted } from "vue";
import { LoaderCircle } from "lucide-vue-next";
import { useRoute, useRouter } from "vue-router";
import { get_bot_public } from "~/modules/bot/services/BotService";
import { BotType } from "~/modules/bot/types/IBot";

const $route = useRoute();
const $router = useRouter();

onMounted(async () => {
  let target_route = "id-welcome";

  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    if (
      public_bot_response.value.payload.bot.appearance &&
      public_bot_response.value.payload.bot.config
    ) {
      const skipWelcomePage =
        public_bot_response.value.payload.bot.appearance.skipWelcomePage;
      const botType = public_bot_response.value.payload.bot.type;
      const hasFlow = public_bot_response.value.payload.bot.flow;

      if (skipWelcomePage || hasFlow) {
        target_route =
          botType === BotType.GPT ? hasFlow ? "id-welcome" : "id-conversation" : "id-chatbot";
      }
    }
  }

  $router.push({
    name: target_route,
    params: {
      id: $route.params.id,
    },
    query: {
      demo: $route.query.demo === "1" ? "1" : "0",
    },
  });



  // const public_bot_response = await get_bot_public($route.params.id as string);

  // if (public_bot_response.isOk()) {
  //   $router.push({
  //     name: public_bot_response.value.payload.bot.type === BotType.SCRIPTED ? "id-chatbot" : public_bot_response.value.payload.bot.flow ? "id-next" : "id-conversation",
  //     params: {
  //       id: $route.params.id,
  //     },
  //     query: {
  //       demo: $route.query.demo === "1" ? "1" : "0",
  //     },
  //   });
  // }
});
</script>
