<template>
  <div class="h-screen w-full bg-white flex justify-center overflow-y-auto">
    <div
      class="flex justify-center items-center w-full h-screen"
      v-if="welcome_state.is_error"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div v-if="welcome_state.error_message === 'bots.INVALID_API_KEY'">
          <div class="text-black font-medium text-lg">
            Invalid OpenAI API Key
          </div>
          <div class="text-gray-500 font-light text-sm">
            The OpenAI API key you provided is invalid. Please check your API
            key and try again.
          </div>
        </div>
        <div v-else>
          <div class="text-black font-medium text-lg">Something went wrong</div>
          <div class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <div
      class="flex justify-center items-center w-full h-screen"
      v-else-if="welcome_state.is_loading"
    >
      <LoaderCircle
        class="animate-spin text-gray-500"
        :size="32"
        stroke-width="1"
        color="currentColor"
      />
    </div>
    <div
      v-else
      class="flex flex-col justify-between sm:w-2/3 lg:w-2/5 w-full"
    >
      <div class="bg-white w-full h-screen flex flex-col justify-between">
        <!-- Condition: if welcome_state.bot.flow is undefined, use Tailwind classes -->
        <div
          v-if="typeof welcome_state.bot.flow === 'undefined'"
          class="bg-gradient-to-tl relative min-h-[45%]"
          :class="[
            welcome_state.bot.type === BotType.GPT ? 'h-[55%]' : 'h-[65%]',
            `from-${fallback.appearance.theme}-900 via-${fallback.appearance.theme}-500 to-${fallback.appearance.theme}-100`,
          ]"
        >
          <div v-if="
                fallback.appearance.brandImage &&
                fallback.appearance.brandImage !==
                  'https://placehold.co/150x150'
              " class="absolute top-6 left-6 bg-white rounded-lg">
            <img
              :src="fallback.appearance.brandImage"
              class="w-12 h-12 rounded-lg"
            />
          </div>
          <div
            @click="post_message('chatbox-closed')"
            class="sm:hidden absolute top-2 right-6 w-16 h-16 flex items-center justify-end"
          >
            <i
              class="fa-sharp fa-xmark font-light text-2xl cursor-pointer"
              :style="{
                color: welcome_state.primary_color,
              }"
            ></i>
          </div>
          <div class="absolute bottom-12 px-6 w-full font-bold text-3xl">
            <div class="text-white">
              {{ welcome_state.bot.appearance?.title || fallback.meta.title }}
            </div>
            <div
              v-if="welcome_state.bot.appearance.description"
              class="text-white text-sm font-light mt-3"
            >
              {{
                welcome_state.bot?.appearance?.description ||
                fallback.meta.description
              }}
            </div>
            <!-- <div v-if="welcome_state.is_lead_set" class="text-white">
              {{ welcome_state.lead_name }}
            </div> -->
          </div>

          <div
            @click="() => start_conversation()"
            class="cursor-pointer text-gray-700 h-[54px] px-6 w-[calc(100%_-_53px)] absolute mx-[24px] shadow -bottom-[27px] font-medium bg-white shadow-xl shadow-black/5 hover:text-black-500 ring-1 ring-slate-700/10 rounded-lg flex justify-between items-center"
          >
            <div class="text-sm">
              {{ fallback.appearance.talkWithAgentMessage }}
            </div>
            <ArrowRight class="text-sm" />
          </div>
        </div>
        <!-- Condition: if welcome_state.bot.flow is defined, use inline styles -->
        <div
          v-else
          class="bg-gradient-to-tl relative min-h-[45%]"
          :class="[
            welcome_state.bot.type === BotType.GPT ? 'h-[55%]' : 'h-[65%]',
          ]"
          :style="{
            background: `linear-gradient(to top, ${welcome_state.primary_color}, ${welcome_state.light_color})`,
          }"
        >
          <div v-if="
                fallback.appearance.brandImage &&
                fallback.appearance.brandImage !==
                  'https://placehold.co/150x150'
              " class="absolute top-6 left-6 bg-white rounded-lg">
            <img
              :src="fallback.appearance.brandImage"
              class="w-12 h-12 rounded-lg"
            />
          </div>
          <div
            @click="post_message('chatbox-closed')"
            class="sm:hidden absolute top-2 right-6 w-16 h-16 flex items-center justify-end"
          >
            <i
              class="fa-sharp fa-xmark font-light text-2xl cursor-pointer"
              :style="{
                color: welcome_state.primary_color,
              }"
            ></i>
          </div>
          <div class="absolute bottom-12 px-6 w-full font-bold text-3xl">
            <div class="text-white">
              {{ welcome_state.bot.appearance?.title || fallback.meta.title }}
            </div>
            <div
              v-if="welcome_state.bot.appearance.description"
              class="text-white text-sm font-light mt-3"
            >
              {{
                welcome_state.bot?.appearance?.description ||
                fallback.meta.description
              }}
            </div>
            <!-- <div v-if="welcome_state.is_lead_set" class="text-white">
              {{ welcome_state.lead_name }}
            </div> -->
          </div>

          <div
            @click="() => start_conversation()"
            class="cursor-pointer text-gray-700 h-[54px] px-6 w-[calc(100%_-_53px)] absolute mx-[24px] shadow -bottom-[27px] font-medium bg-white shadow-xl shadow-black/5 hover:text-black-500 ring-1 ring-slate-700/10 rounded-lg flex justify-between items-center"
          >
            <div class="text-sm">
              {{ fallback.appearance.talkWithAgentMessage }}
            </div>
            <ArrowRight class="text-sm" />
          </div>
        </div>
        <div class="space-y-5 flex-1 pt-12 pb-8">
          <div
            v-if="welcome_state.previous_conversations.length"
            class="cursor-pointer text-gray-700 p-2 w-[calc(100%_-_53px)] antialiased mx-[24px] font-medium bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
          >
            <div class="py-2 px-4 text-sm">Recent conversations</div>
            <div
              @click="() => start_previous_session(conversation._id)"
              :key="index"
              v-for="(conversation, index) in [...welcome_state.previous_conversations].reverse().slice(0, 3)"
              class="space-x-4 flex justify-between items-center py-2 px-4 hover:text-black-500 rounded-lg hover:bg-gray-100"
            >
              <div class="text-sm flex space-x-2 items-center">
                <!-- <i
                  class="fa fa-solid fa-message text-gray-500 mr-2 text-lg"
                ></i> -->
                <MessageSquare class="text-gray-500 mr-2 text-lg" />
                <div>
                  <div class="font-normal">
                    {{
                      conversation.messages[conversation.messages.length - 1].text.substring(0, 24) + '...'
                    }}
                  </div>
                  <div class="font-light text-xs">
                    {{ moment(conversation.messages[conversation.messages.length - 1].sent_at).fromNow() }}
                  </div>
                </div>
              </div>
              <ArrowRight class="text-sm" />
            </div>
          </div>
          <div
            v-if="welcome_state.chat_starters.length && typeof welcome_state.bot.flow === 'undefined'"
            class="cursor-pointer text-gray-700 p-2 w-[calc(100%_-_53px)] mx-[24px] antialiased bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
          >
            <div class="font-medium py-2 px-4 text-sm">Frequently asked questions</div>
            <div
              @click="start_conversation(chat_starter)"
              :key="index"
              v-for="(chat_starter, index) in welcome_state.chat_starters"
              class="space-x-4 flex justify-between items-center py-3 px-4 hover:text-black-500 rounded-lg hover:bg-gray-100"
            >
              <div class="text-sm flex items-center space-x-2">
                <MessageCircleQuestion class="text-gray-500 mr-2 text-lg" />
                <div>
                  {{
                    chat_starter.length > 35
                      ? chat_starter.slice(0, 35) + "..."
                      : chat_starter
                  }}
                </div>
              </div>
              <ArrowRight class="text-sm" />
            </div>
          </div>
          <div
            v-for="(news, index) in welcome_state.news"
            :key="index"
            class="hidden cursor-pointer text-gray-700 w-[calc(100%_-_48px)] mx-[24px] font-medium bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
          >
          <a target="_blank" :href="news.href">
            <div class="p-4 border-b">
              <img
                class="rounded-lg"
                :src="news.og_image"
              />
            </div>
            <div
              class="flex flex-col p-4 hover:text-black-500 hover:bg-gray-100 space-y-1"
            >
              <div class="text-sm font-medium">
                {{ news.title }}
              </div>
              <div class="text-sm text-[#737376] font-light">
                {{ news.description }}
              </div>
            </div>
          </a>
          </div>
<!-- 
      <div
        class="cursor-pointer text-gray-700 w-[calc(100%_-_48px)] mx-[24px] font-medium bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
      >
        <div class="p-4 border-b">
          <img
            class="rounded-lg"
            src="https://interviewwith.ai/blog/wp-content/uploads/2024/04/christin-hume-Hcfwew744z4-unsplash-1.png"
          />
        </div>
        <div
          class="flex flex-col p-4 hover:text-black-500 hover:bg-gray-100 space-y-1"
        >
          <div class="text-sm font-medium">
            Online Job Interview Checklist: Must read list before interview
          </div>
          <div class="text-sm text-[#737376] font-light">
            The traditional handshake-and-portfolio interview scene is evolving.
            Today, online interviews are becoming increasingly common, offering
            flexibility and convenience for both employers and candidates.
          </div>
        </div>
      </div> -->
        </div>
        <div
          v-if="!fallback.appearance.hideBranding"
          class="text-xs py-2 w-full flex items-center justify-center space-x-2 border-t border-gray-50"
        >
          <!-- <i class="fa-solid fa-bolt text-amber-500"></i> -->
          <span class="text-gray-500 font-light"
            >runs on
            <a href="https://usemevo.com" target="_blank"
              ><span class="font-bold text-[#3834FF]">mevo</span></a
            ></span
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from "vue";
import moment from "moment";
import { useRoute, useRouter } from "vue-router";
import { v4 as uuidv4 } from "uuid";
import {
  check_lead,
  get_bot_public,
  get_conversations_by_device,
  get_news
} from "../../modules/bot/services/BotService";
import { BotType, ShowForm, type IBot } from "../../modules/bot/types/IBot";
import { LoaderCircle, MessageSquare, ArrowRight, MessageCircleQuestion } from "lucide-vue-next";

const $route = useRoute();
const $router = useRouter();

interface WelcomeState {
  bot: IBot;
  chat_starters: string[];
  previous_conversations: string[];
  is_loading: boolean;
  is_error: boolean;
  is_lead_set: boolean;
  lead_name: string;
  error_message: string;
  news: { title: string; description: string; og_image: string; href: string; }[],
  primary_color: string;
  light_color: string;
  light_hover_color: string;
}

const welcome_state: WelcomeState = reactive({
  bot: {} as IBot,
  is_loading: true,
  is_error: false,
  chat_starters: [],
  previous_conversations: [],
  is_lead_set: false,
  lead_name: "",
  error_message: "",
  news: [],
  primary_color: "#3834FF",
  light_color: "#F0F0FF",
  light_hover_color: "#E0E0FF",
});

const fallback = {
  meta: { 
    title: "AI Assistant",
    description: "Start a conversation with our AI assistant",
    keywords: "AI, Assistant, Chatbot",
    og_image: "",
  },
  appearance: {
    brandImage: "https://images.unsplash.com/photo-1596367407372-96cb88503db6",
    theme: "blue",
    greeting: "Hello!",
    talkWithAgentMessage: "Talk with an agent",
    hideBranding: false,
  },
};

const start_previous_session = (session_id: string) => {
  if (typeof welcome_state.bot.flow !== 'undefined') {
    $router.push({
      name: "id-next",
      params: {
        id: $route.params.id,
      },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
        session: session_id,
      },
    });
  } else {
    $router.push({
      name: "id-conversation",
      params: {
        id: $route.params.id,
      },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
        session: session_id,
      },
    });
  }
}

const start_conversation = (chat_starter: string = "") => {
  if (welcome_state.bot.type === BotType.SCRIPTED) {
    $router.push({
      name: "id-chatbot",
      params: {
        id: $route.params.id,
      },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
        "force-new-conversation":
          $route.query["force-new-conversation"] === "1" ? "1" : "0",
      },
    });
    return;
  }

  if (
    welcome_state.bot.showForm === ShowForm.BEFORE_CHAT &&
    !welcome_state.is_lead_set
  ) {
    $router.push({
      name: "id-form",
      params: {
        id: $route.params.id,
      },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
      },
    });
  } else {
    const target_route = {
      name: welcome_state.bot.flow ? "id-next" : "id-conversation",
      params: {
        id: $route.params.id,
      },
      query: {
        demo: $route.query.demo === "1" ? "1" : "0",
      },
    };

    if (chat_starter) {
      target_route.query = {
        ...target_route.query,
        // @ts-ignore
        message: chat_starter,
      };
    }

    $router.push(target_route);
  }
};

const post_message = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

function lightenColor(hexColor: string, amount = 0.9) {
  // Hex formatını temizle ve doğrula
  let hex = hexColor.replace('#', '');
  
  // 3 karakter hex ise 6 karaktere çevir (#FFF -> #FFFFFF)
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  
  // Geçerli hex olup olmadığını kontrol et
  if (hex.length !== 6 || !/^[0-9A-Fa-f]{6}$/.test(hex)) {
    console.error('Geçersiz hex renk kodu:', hexColor);
    return hexColor; // Hatalı durumda orijinal değeri döndür
  }
  
  // Hex'i RGB'ye çevir
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  
  // NaN kontrolü
  if (isNaN(r) || isNaN(g) || isNaN(b)) {
    console.error('RGB değerleri parse edilemedi:', { r, g, b });
    return hexColor;
  }
  
  // Beyaz ile karıştır
  const newR = Math.round(r + (255 - r) * amount);
  const newG = Math.round(g + (255 - g) * amount);
  const newB = Math.round(b + (255 - b) * amount);
  
  // RGB'yi tekrar hex'e çevir (padStart ile 2 karakter garantisi)
  const toHex = (value: number) => {
    const hex = Math.max(0, Math.min(255, value)).toString(16);
    return hex.padStart(2, '0');
  };
  
  return `#${toHex(newR)}${toHex(newG)}${toHex(newB)}`;
}

onMounted(async () => {
  // init mevo identity
  if (
    !localStorage.getItem("mevo_device_id") ||
    $route.query["force-new-conversation"] === "1"
  ) {
    // init device id
    localStorage.setItem("mevo_device_id", uuidv4());
    // init session id
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: uuidv4(),
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  // check mevo_session in local storage
  const mevo_session = JSON.parse(
    // @ts-ignore
    localStorage.getItem(`mevo:${$route.params.id}:session_id`)
  );

  // if we have a valid session, use it
  if (mevo_session && mevo_session.exp > new Date().getTime() / 1000) {
    // and update the expire time to 1 hour
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: mevo_session.id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }
  // if we don't have a valid session, create a new one
  else {
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: uuidv4(),
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    if (public_bot_response.value.payload.bot.appearance.theme !== '#000') {
      welcome_state.primary_color = public_bot_response.value.payload.bot.appearance.theme;
      welcome_state.light_color = lightenColor(public_bot_response.value.payload.bot.appearance.theme, 0.50);
      welcome_state.light_hover_color = lightenColor(public_bot_response.value.payload.bot.appearance.theme, 0.98);
    }

    if (public_bot_response.value.payload.bot.config?.meta) {
      fallback.meta = public_bot_response.value.payload.bot.config.meta;
    }

    if (public_bot_response.value.payload.bot.appearance) {
      const skipWelcomePage =
        public_bot_response.value.payload.bot.appearance?.skipWelcomePage;
      const botType = public_bot_response.value.payload.bot.type;

      if (skipWelcomePage === true || botType === BotType.SCRIPTED) {
        $router.push({
          name: public_bot_response.value.payload.bot.type === BotType.SCRIPTED ? "id-chatbot" : public_bot_response.value.payload.bot.flow ? "id-next" : "id-conversation",
          params: {
            id: $route.params.id,
          },
          query: {
            demo: $route.query.demo === "1" ? "1" : "0",
          },
        });
      } else {
        welcome_state.is_loading = false;
      }

      fallback.appearance = public_bot_response.value.payload.bot.appearance;
    }

    welcome_state.is_error = false;
    welcome_state.bot = public_bot_response.value.payload.bot as IBot;
    welcome_state.chat_starters =
      public_bot_response.value.payload.chat_starters.map((chat_starter) => {
        return chat_starter.question;
      });

    useSeoMeta({
      title: fallback.meta.title,
      ogTitle: fallback.meta.title,
      description: fallback.meta.description,
      ogDescription: fallback.meta.description,
      ogImage: fallback.meta.og_image,
      twitterCard: "summary_large_image",
      keywords: fallback.meta.keywords,
    });

    useHead({
      link: [
        {
          rel: "icon",
          type: "image/x-icon",
          href: fallback.appearance.brandImage,
        },
      ],
    });
  } else {
    welcome_state.error_message = public_bot_response.error.message;
    welcome_state.is_loading = false;
    welcome_state.is_error = true;
    // TODO: handle error
  }

  const lead_check_response = await check_lead({
    bot_id: $route.params.id as string,
    device_id: localStorage.getItem("mevo_device_id") as string,
  });

  if (lead_check_response.isOk()) {
    if (lead_check_response.value.payload) {
      welcome_state.is_lead_set = true;
      localStorage.setItem(`mevo_${$route.params.id}_lead`, JSON.stringify(lead_check_response.value.payload));
      if (lead_check_response.value.payload.name) {
        welcome_state.lead_name =
          lead_check_response.value.payload.name.split(" ")[0];
      }
    }
  }

  const previous_sessions_response = await get_conversations_by_device(
    $route.params.id as string,
    localStorage.getItem("mevo_device_id") as string
  );

  if (previous_sessions_response.isOk()) {
    welcome_state.previous_conversations = previous_sessions_response.value.payload;
  }

  const news_response = await get_news($route.params.id as string);

  if (news_response.isOk()) {
    welcome_state.news = news_response.value.payload;
  }
});
</script>
