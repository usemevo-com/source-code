import { type IScriptStep, ScriptStepType } from '@/modules/bot/types/IScriptStep'
import { nextTick } from 'vue'

export function useWidget() {
  const scrollToBottom = function (selector: string) {
    nextTick(() => {
      // Multiple attempts for better reliability while keeping smooth animation
      setTimeout(() => {
        const container = document.querySelector(selector)
        if (container) {
          container.scrollTo({
            top: container.scrollHeight,
            left: 0,
            behavior: 'smooth',
          })
          
          // Fallback check after animation completes
          setTimeout(() => {
            if (container.scrollTop < container.scrollHeight - container.clientHeight - 5) {
              container.scrollTo({
                top: container.scrollHeight,
                left: 0,
                behavior: 'smooth',
              })
            }
          }, 500)
        }
      }, 20)
    })
  }

  const scrollToRight = function (selector: string) {
    nextTick(() => {
      const container = document.querySelector(selector)
      container?.scrollTo({
        top: 0,
        left: container?.scrollWidth,
        behavior: 'smooth',
      })
    })
  }

  const scrollToLeft = function (selector: string) {
    nextTick(() => {
      const container = document.querySelector(selector)
      container?.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      })
    })
  }

  const userResponseObjectFactory = function (message: string, id: number): IScriptStep {
    return {
      data: {
        message,
        options: [''],
      },
      response: true,
      description: '',
      type: ScriptStepType.RESPONSE,
      isSkippable: false,
      isManualInputAllowed: false,
      id: `${id}`,
      hasOption: false,
    }
  }

  return {
    scrollToBottom,
    scrollToLeft,
    scrollToRight,
    userResponseObjectFactory,
  }
}
