import Index from "./pages/Index.vue";
import Widget from "./pages/Widget.vue";
import WidgetGPT from "./pages/WidgetGPT.vue";
import Bot from "./pages/Bot.vue";
import Slide from "./pages/Slide.vue";
import Experiment from "./pages/Experiment.vue";
import ChatbotRoot from "./pages/widget-v2/ChatbotRoot.vue";
import Welcome from "./pages/widget-v2/Welcome.vue";
import Conversation from "./pages/widget-v2/Conversation.vue";
import Form from "./pages/widget-v2/Form.vue";

export const WidgetRoutes = [
  // {
  //   name: "widget-view",
  //   path: "/widget/:id",
  //   component: Widget,
  //   meta: { widget: true },
  // },
  // {
  //   name: "slide-view",
  //   path: "/slide/:id",
  //   component: Slide,
  //   meta: { widget: true },
  // },
  // {
  //   name: "gpt-view",
  //   path: "/gpt/:id",
  //   component: WidgetGPT,
  //   meta: { widget: true },
  // },
  // {
  //   name: "common-bot-view",
  //   path: "/b/:bid",
  //   component: Bot,
  // },
  // {
  //   name: "experimental",
  //   path: "/e",
  //   component: Experiment,
  //   meta: { widget: true },
  // },
  {
    name: "index-with-id",
    path: "/:id",
    component: ChatbotRoot,
    children: [
      {
        name: "chatbot_welcome",
        path: "welcome",
        component: Welcome,
      },
      {
        name: "chatbot_conversation",
        path: "conversation",
        component: Conversation,
      },
      {
        name: "chatbot_form",
        path: "form",
        component: Form,
      },
    ],
  },
  // {
  //   name: "index",
  //   path: "/",
  //   component: Index,
  // },
];
