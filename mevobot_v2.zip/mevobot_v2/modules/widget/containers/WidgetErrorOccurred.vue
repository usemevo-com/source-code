<template>
  <div
    class="w-full sm:w-2/3 bg-white shadow-lg flex flex-col justify-center items-center"
  >
    <div class="flex flex-col items-center">
      <ExclamationCircleIcon class="w-8 h-8 text-red-500" />
      <m-headline
        center
        :title="$t('widget.ERROR_OCCURRED')"
        :description="message"
      />
      <!-- <div
        @click="$emit('restart', true)"
        class="cursor-pointer text-blue-500 underline mt-4 flex items-center text-sm"
      >
        {{ $t("widget.TRY_AGAIN") }}
      </div> -->
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ExclamationCircleIcon } from "@heroicons/vue/20/solid";
import MHeadline from "@/components/basic/MHeadline.vue";

export interface WidgetErrorOccurredProps {
  message: string;
}

withDefaults(defineProps<WidgetErrorOccurredProps>(), {
  message: "Please try again later",
});

defineEmits(["restart"]);
</script>
