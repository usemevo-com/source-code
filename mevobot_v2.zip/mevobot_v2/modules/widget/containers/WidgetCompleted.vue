<template>
  <div
    class="w-full sm:w-2/3 bg-white shadow-lg flex flex-col justify-center items-center"
  >
    <div class="flex flex-col items-center">
      <CheckCircleIcon class="w-8 h-8 text-green-500" />
      <m-headline
        center
        :title="$t('widget.COMPLETED_THANKS')"
        :description="$t('widget.COMPLETED_DESCRIPTION')"
      />
      <!-- <div @click="$emit('restart')" class="cursor-pointer text-blue-500 underline mt-4 flex items-center text-sm">
        {{ $t('widget.COMPLETED_RESTART') }}
      </div> -->
      <a v-if="!noMevoMark" href="https://usemevo.com" target="_blank">
        <m-button class="mt-8" type="primary">
          {{ $t("widget.CREATE_A_BOT_LIKE_THIS") }}
        </m-button>
      </a>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { CheckCircleIcon } from "@heroicons/vue/20/solid";
import MHeadline from "@/components/basic/MHeadline.vue";
import MButton from "@/components/basic/MButton.vue";

export interface WidgetCompletedProps {
  noMevoMark: boolean;
}

withDefaults(defineProps<WidgetCompletedProps>(), {
  noMevoMark: false,
});

defineEmits(["restart"]);
</script>
