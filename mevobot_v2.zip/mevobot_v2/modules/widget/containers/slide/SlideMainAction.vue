<template>
  <div
    v-if="!hide"
    class="w-full flex"
    :class="[
      !isFirstStep && 'justify-between',
      isFirstStep && 'justify-center',
    ]"
  >
    <m-button @clicked="$emits('next')" class="px-4 w-full sm:w-fit mb-8">
      {{ isLastStep ? "Complete" : "Continue" }}
    </m-button>
  </div>
</template>

<script lang="ts" setup>
import MButton from "@/components/v2/elements/MButton.vue";

const props = defineProps({
  isLastStep: {
    type: Boolean,
    required: false,
  },
  isFirstStep: {
    type: Boolean,
    required: false,
  },
  hide: {
    type: Boolean,
    required: false,
  },
});

const $emits = defineEmits(["next"]);
</script>
