<template>
  <div class="h-1 w-screen absolute top-0 left-0 bg-white">
    <div
      :style="{ width: `${percentage}%` }"
      class="h-full bg-indigo-500"
    ></div>
  </div>
</template>

<script lang="ts" setup>
const props = defineProps({
  percentage: {
    type: Number,
    required: true,
  },
});
</script>
