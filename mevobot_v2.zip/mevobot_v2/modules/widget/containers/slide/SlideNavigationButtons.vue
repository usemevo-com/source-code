<template>
  <div class="flex mb-4">
    <m-button
      type="primary"
      :disabled="index === 0"
      @clicked="$emits('prev')"
      class="bg-indigo-500 rounded-md rounded-r-none cursor-pointer hover:bg-indigo-600"
    >
      <arrow-left-icon class="w-4 h-4 text-white" />
    </m-button>
    <m-button
      type="primary"
      :disabled="isNextDisable"
      @clicked="$emits('next')"
      class="bg-indigo-500 p-2 rounded-md rounded-l-none border-l border-indigo-400 cursor-pointer hover:bg-indigo-600"
    >
      <arrow-right-icon class="w-4 h-4 text-white" />
    </m-button>
  </div>
</template>

<script lang="ts" setup>
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/vue/24/outline";
import MButton from "@/components/v2/elements/MButton.vue";

const props = defineProps({
  index: {
    type: Number,
    default: 0,
  },
  isNextDisable: {
    type: Boolean,
    default: false,
  },
});

const $emits = defineEmits(["next", "prev"]);
</script>
