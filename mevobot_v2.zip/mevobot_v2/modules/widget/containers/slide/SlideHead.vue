<template>
  <div class="flex flex-col">
    <div
      class="font-medium text-3xl"
      :class="[!isFirst && 'text-left', isFirst && 'text-center']"
      v-html="title"
    ></div>
    <div v-if="description" class="text-gray-400 font-medium mt-2">
      {{ description }}
    </div>
  </div>
</template>

<script lang="ts" setup>
const props = defineProps({
  isFirst: {
    type: Boolean,
    required: false,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});
</script>
