<template>
  <div class="flex w-full">
    <div class="md:w-1/2 w-full relative">
      <video
        @ended="onEnded"
        autoplay
        muted
        class="h-[100vh] object-cover"
        :class="[interactionAllowed && 'blur-sm md:blur-none']"
        style="object-position: 55%"
        src="/welcomer.mp4"
      />
      <Transition name="fade">
        <div
          v-if="interactionAllowed"
          class="md:hidden flex justify-center items-center absolute z-90 top-0 left-0 w-[400px] h-[500px]"
        >
          <div class="space-y-4" :class="[!interactionAllowed && 'opacity-50']">
            <div
              class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer hover:border-white"
              :class="[!interactionAllowed && '!cursor-not-allowed']"
            >
              I'm just browsing
            </div>
            <div
              class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer hover:border-white"
              :class="[!interactionAllowed && '!cursor-not-allowed']"
            >
              Leave a message
            </div>
            <div
              @click="goChatbot"
              class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer hover:border-white"
              :class="[!interactionAllowed && '!cursor-not-allowed']"
            >
              Talk with AI assistant
            </div>
            <div
              @click="goScheduler"
              class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer hover:border-white"
              :class="[!interactionAllowed && '!cursor-not-allowed']"
            >
              Schedule a demo call
            </div>
          </div>
        </div>
      </Transition>
    </div>
    <div class="w-1/2 flex flex-col justify-center items-center hidden md:flex">
      <div class="space-y-4" :class="[!interactionAllowed && 'opacity-50']">
        <div
          class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer"
          :class="[!interactionAllowed && '!cursor-not-allowed']"
        >
          I'm just browsing
        </div>
        <div
          class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer"
          :class="[!interactionAllowed && '!cursor-not-allowed']"
        >
          Leave a message
        </div>
        <div
          @click="goChatbot"
          class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer"
          :class="[!interactionAllowed && '!cursor-not-allowed']"
        >
          Talk with AI assistant
        </div>
        <div
          @click="goScheduler"
          class="p-4 font-semibold text-white border rounded-md border-indigo-700 min-w-[300px] bg-indigo-700 hover:bg-white hover:text-indigo-700 cursor-pointer"
          :class="[!interactionAllowed && '!cursor-not-allowed']"
        >
          Schedule a demo call
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from "vue";
import { useRouter } from "vue-router";

const $router = useRouter();
const interactionAllowed = ref(false);

const onEnded = () => {
  interactionAllowed.value = true;
};

const goChatbot = () => {
  $router.push({
    name: "common-bot-view",
    params: {
      bid: "650237f7dbf6a9e1e7952e4b",
    },
  });
};

const goScheduler = () => {
  $router.push({
    name: "common-bot-view",
    params: {
      bid: "6504de16f886178fac01ee04",
    },
  });
};
</script>

<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
