<template>
  <div
    v-if="isLoading"
    class="h-screen w-full flex justify-center items-center bg-white"
  >
    <div class="flex flex-col items-center justify-center">
      <!-- <m-brand variant="logo-only" class="w-16" /> -->
      <i
        class="mt-4 animate-spin text-indigo-300 fa-sharp fa-light fa-spinner-third text-3xl"
      ></i>
    </div>
  </div>
  <div
    v-else-if="isNotFound"
    class="flex h-screen w-full justify-center items-center bg-indigo-500"
  >
    <div class="w-full sm:w-2/3 mx-auto flex sm:flex-row flex-col items-center">
      <div
        class="w-full sm:w-1/2 sm:border-r border-indigo-700 text-center sm:pr-12"
      >
        <span class="block sm:hidden text-4xl font-bold mb-2 text-white"
          >:(</span
        >
        <div class="text-white text-4xl font-bold mb-1">Bot not found</div>
        <div class="text-gray-200 text-lg">
          This bot is not exist or isn't active anymore.
        </div>
      </div>
      <div class="w-full sm:w-1/2 mt-32 sm:mt-0 sm:pl-12">
        <div class="text-center font-light text-white">
          Do you want to create your own
          <span class="font-bold">free</span> chatbot?<br />
          <m-button @clicked="goMevo()" class="mt-4" type="white"
            >Create your own chatbot</m-button
          >
        </div>
      </div>
    </div>
  </div>
  <!-- <widget
    :demo="isDemoMode"
    :id="botId"
    v-else-if="botType === BotType.SCRIPTED"
  /> -->
  <chatbot-root :id="botId" v-else-if="botType === BotType.GPT" />
  <!-- <widget-gpt :demo="isDemoMode" :id="botId" /> -->
</template>

<script lang="ts" setup>
import { onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import {
  getBotByDomain,
  getBotSafePublic,
} from "@/modules/bot/services/BotService";
import Widget from "./Widget.vue";
import WidgetGpt from "./WidgetGPT.vue";
import ChatbotRoot from "./widget-v2/ChatbotRoot.vue";
import MBrand from "@/components/v2/elements/MBrand.vue";
import MButton from "@/components/v2/elements/MButton.vue";
import type { IBot } from "@/modules/bot/types/IBot";

enum BotType {
  SCRIPTED = "scripted",
  GPT = "gpt",
}

const $route = useRoute();
const botType = ref<BotType>();
const botId = ref<string>();
const isNotFound = ref(false);
const isLoading = ref(true);
const isDemoMode = ref(false);

const goMevo = () => {
  window.location.href = "https://usemevo.com";
};

onMounted(async () => {
  isDemoMode.value = $route.query.demo === "true";

  const domain = window.location.host;

  if ($route.params.id) {
    const botResponse = await getBotSafePublic({
      id: $route.params.id as string,
    });
    isLoading.value = false;

    if (botResponse.isOk()) {
      const bot: IBot = botResponse.value.payload;

      botType.value = bot.type;
      botId.value = bot._id;

      console.log(botType.value, botId.value);
    } else {
      isLoading.value = false;
      window.location.href = "https://usemevo.com";
    }
  } else if (domain !== "bot.usemevo.com" && domain !== "app.usemevo.com") {
    const domainCheckResponse = await getBotByDomain({
      domain,
    });
    isLoading.value = false;

    if (domainCheckResponse.isOk()) {
      const bot: IBot = domainCheckResponse.value.payload;

      botType.value = bot.type;
      botId.value = bot._id;
    } else {
      isNotFound.value = true;
    }
  } else {
    window.location.href = "https://usemevo.com";
  }
});
</script>
