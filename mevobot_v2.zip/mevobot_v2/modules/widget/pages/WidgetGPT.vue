<template>
  <RouterView v-slot="{ Component }">
    <transition name="slide" mode="out-in">
      <Component />
    </transition>
  </RouterView>
</template>

<script lang="ts" setup>
// external dependencies
import mixpanel from "mixpanel-browser";
import { computed, onMounted, reactive, ref, watch, type Ref } from "vue";
import { useRoute } from "vue-router";
import { XMarkIcon } from "@heroicons/vue/24/outline";
import { useI18n } from "vue-i18n";
import { v4 as uuidv4 } from "uuid";

// internal dependencies
import {
  ScriptStepType,
  type IScriptStep,
} from "@/modules/bot/types/IScriptStep";
import {
  BotEventType,
  BotLayout,
  BotPosition,
  BotTheme,
  BotType,
  type IBot,
} from "@/modules/bot/types/IBot";
import {
  getBotSafePublic,
  interact,
  interactV2,
  retrieve,
  sendBotEvent,
  sendLead,
} from "@/modules/bot/services/BotService";
import { useWidget } from "../composables/useWidget";
// components
import MScriptStep from "@/components/basic/MScriptStep.vue";
import MLoading from "@/components/basic/MLoading.vue";
import MTextInput from "@/components/basic/MTextInput.vue";
import MButton from "@/components/v2/elements/MButton.vue";
import MHeadline from "@/components/basic/MHeadline.vue";
import WidgetCompleted from "../containers/WidgetCompleted.vue";
import WidgetInput from "../containers/WidgetInput.vue";
import WidgetLeftSide from "../containers/WidgetLeftSide.vue";
import WidgetErrorOccurred from "../containers/WidgetErrorOccurred.vue";
import { PlanType } from "@/modules/organization/types/IPlan";
import { useCommonStore } from "@/stores";
import { ShowForm } from "@/modules/bot/types/IBot";

export interface WidgetGPTProps {
  id?: string;
  demo?: boolean;
}
const props = withDefaults(defineProps<WidgetGPTProps>(), {
  id: "",
  demo: false,
});

const $route = useRoute();
const isCloseIconHidden = computed(() => {
  return $route.query.hideCloseIcon === "true";
});
const { setNotification } = useCommonStore();
const { scrollToBottom, userResponseObjectFactory } = useWidget();
const { t } = useI18n();
const isFormSubmitted = ref(false);
// fetched bot object
const bot: { data: IBot } = reactive({
  data: {
    showForm: "none",
    name: "",
    script: {
      steps: [],
    },
    design: {
      theme: BotTheme.pink,
      position: BotPosition.MIDDLE,
      layout: BotLayout.CHAT_RIGHT,
      background: "NO_BACKGROUND",
    },
    type: BotType.GPT,
    gptSettings: {
      firstMessage: "",
      fallbackMessage: "",
      represented: "",
      feed: [],
    },
    organization: {
      name: "Organization",
    },
    hideBranding: true,
    hideOrganization: false,
  },
});
const lead = reactive({
  name: "",
  email: "",
  organization: "",
});
const messageGenerationMap: { [key: number]: boolean } = reactive({});
const session: Ref<string> = ref("");
const hiddenFormFields = computed(() => {
  if (bot.data && bot.data.hiddenFormFields) {
    return bot.data.hiddenFormFields.split(",");
  }
  return [];
});

const isInChatFormVisible = computed(() => {
  return (
    isInteractedOnce.value &&
    !isFormSubmitted.value &&
    bot.data.showForm === ShowForm.IN_CHAT
  );
});

const isBeforeChatFormVisible = computed(() => {
  return bot.data.showForm === ShowForm.BEFORE_CHAT && !isFormSubmitted.value;
});

const isBrandingVisible = computed(() => {
  return !bot.data.hideBranding;
});

const isChatbotPageBrandingVisible = computed(() => {
  return false;
});
// array which hold user responses as string array
// we'll use this array for persist user responses
// at the end of conversation
const response: { data: { value: string; id: string }[] } = reactive({
  data: [],
});
// array which represent bot flow
// all script steps and user responses pushed in this array
const scene: { steps: IScriptStep[] } = reactive({
  steps: [],
});
// index for active step
// only count script steps, not user responses
const activeStep: Ref<number> = ref(0);
// filtered versions of scene
// which only returns script steps, not user responses
const botStepsOnly: Ref<IScriptStep[]> = computed(() =>
  scene.steps.filter(
    (step: IScriptStep) => step && typeof step.response === "undefined"
  )
);

const isEmailValid = computed(() => {
  return lead.email.match(
    // eslint-disable-next-line no-useless-escape
    /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
  );
});

// kind of cache for bot data
// we'll rely this when user want to restart conversaiton
let fetchedBotData: IBot = bot.data;
// some logical flags
const isErrorOccurred: Ref<boolean> = ref(false);
const errorMessage = ref("");
const isLoading: Ref<boolean> = ref(false);
const isBotDataLoading: Ref<boolean> = ref(true);
const isCompleted: Ref<boolean> = ref(false);
const isBotResetBlocked: Ref<boolean> = ref(false);
const started = ref(false);
const isInteractedOnce = ref(false);
const isSubmitDisabled = ref(false);
const isEmailInputShown = ref(false);

const onPredefinedOptionSelected = function (option: string) {
  onTextSubmit(option);
};

// conversation restart event handler
const onRestartConversation = async function (
  refetch: boolean = false
): Promise<void> {
  if (refetch) {
    await fetchBotAndSetAssignments($route.params.id as string);
  } else {
    // reset state to initial
    bot.data = fetchedBotData;
    response.data = [];
    scene.steps = [];
    activeStep.value = 0;
    isErrorOccurred.value = false;
    isLoading.value = false;
    isCompleted.value = false;
    // start flow
    scene.steps.push(bot.data.script.steps[activeStep.value]);
    isLoading.value = true;
  }
};

const onLeadSubmit = async function () {
  if (props.demo) {
    isFormSubmitted.value = true;
    return;
  }

  const sendLeadResponse = await sendLead({
    bot: bot.data._id || "",
    email: lead.email,
    name: lead.name,
    company: lead.organization,
    sid: session.value,
  });

  if (sendLeadResponse.isOk()) {
    isFormSubmitted.value = true;
    localStorage.setItem("mevo:form-submitted-" + session.value, "true");
  } else {
    console.log(sendLeadResponse.error.message);
  }
};

const onReset = function () {
  if (isBotResetBlocked.value) {
    return;
  }

  isBotResetBlocked.value = true;
  // reset state to initial
  bot.data = fetchedBotData;
  response.data = [];
  scene.steps = [];
  activeStep.value = 0;
  isErrorOccurred.value = false;
  isLoading.value = false;
  isCompleted.value = false;
  // start flow
  scene.steps.push(bot.data.script.steps[activeStep.value]);
  setTimeout(() => {
    if (
      bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
    ) {
      isLoading.value = true;
    }
  }, 1000);
  setTimeout(() => {
    onNext();
    isBotResetBlocked.value = false;
  }, 1500);
};

// script step next event handler
// only work for non-text-required steps
const onNext = function (reply: string = "") {
  // does this step has reply?
  // we're checking this because it may a message which does not require any reply
};

// script step skip event handler
const onSkip = function () {
  response.data.push({
    value: "SKIPPED",
    id: bot.data.script.steps[activeStep.value].id || "",
  });
  scrollToBottom("#message-container");
  isLoading.value = true;
  activeStep.value++;
  calculateNextStep();
};

const postMessage = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

window.addEventListener(
  "message",
  (event) => {
    try {
      var data = JSON.parse(event.data);
      if (data.kind === "user-message") {
        onTextSubmit(data.data);
      }
    } catch (e) {
      console.error("[MEVO] Unable to parse message", event.data);
    }
  },
  false
);

const retrieveAssistantResponse = async () => {
  const retrieveResponse = await retrieve(
    session.value,
    fetchedBotData._id || ""
  );

  if (retrieveResponse.isOk()) {
    if (retrieveResponse.value.payload.status) {
      isSubmitDisabled.value = false;
      isLoading.value = false;

      if (!messageGenerationMap[scene.steps.length - 1]) {
        messageGenerationMap[scene.steps.length - 1] = true;

        scene.steps.push({
          type: ScriptStepType.MESSAGE,
          data: {
            message: retrieveResponse.value.payload.message,
            options: [],
            jumps: [],
          },
        });
      }
    } else {
      setTimeout(() => {
        retrieveAssistantResponse();
      }, 1000);
    }
  } else {
    setTimeout(() => {
      retrieveAssistantResponse();
    }, 1000);
  }
};

// script step text event handler
// only work for steps which manual input required
const onTextSubmit = async function (message: string) {
  if (message.trim() === "") {
    return;
  }

  if (!started.value) {
    await trackBotEvent(BotEventType.START);
    started.value = true;
  }

  // set loading before next script step appear
  isLoading.value = true;
  // push user response object into scene
  scene.steps.push(userResponseObjectFactory(message, scene.steps.length));

  // scroll to bottom
  scrollToBottom("#message-container");

  if (bot.data.gptSettings.useAssistantAPI) {
    isSubmitDisabled.value = true;
    const aiSubmission = await interactV2(fetchedBotData._id || "id", {
      message,
      sid: session.value,
    });

    messageGenerationMap[scene.steps.length - 1] = false;
    if (aiSubmission.isOk()) {
      await retrieveAssistantResponse();
    } else {
      isLoading.value = false;
      isSubmitDisabled.value = false;
      scene.steps.push({
        type: ScriptStepType.MESSAGE,
        data: {
          message:
            "There is a problem with your bot configuration. Here are the possible reasons: <br/> <br/> <strong>1.</strong> Your OpenAI key is invalid. <br/> <strong>2.</strong> Your OpenAI key is valid but doesn't have access to GPT-4. You should buy at least $5 credits from OpenAI for enable GPT-4 access with API key. <br/> <strong>3.</strong> If you enabled Assistants API, your assistant id may invalid or your OpenAI key isn't belong to same account with your assistant. <br/> <strong>4.</strong> If you enabled Assistant API and key is correct, you may selected different model on Mevo's side than your assistant model on OpenAI side. Be sure your gpt-model is same both on Mevo and OpenAI sides. (ie: GPT-4 on both sides) <br/><br/>If you're not sure what is the reason, you can contact us with <a class='underline text-pink-500' href='mailto:hi@usemevo.com'>hi@usemevo.com</a>",
          options: [],
          jumps: [],
        },
        preventMarkdown: true,
      });
    }
  } else {
    // push text into responses array
    const aiResponse = await interact(fetchedBotData._id || "id", {
      message,
      sid: session.value,
    });

    if (aiResponse.isOk()) {
      scene.steps.push({
        type: ScriptStepType.MESSAGE,
        data: {
          message: aiResponse.value.payload.message,
          options: [],
          jumps: [],
        },
      });
      isLoading.value = false;
    } else {
      isLoading.value = false;
      scene.steps.push({
        type: ScriptStepType.MESSAGE,
        data: {
          message:
            "There is a problem with your bot configuration. Here are the possible reasons: <br/> <br/> <strong>1.</strong> Your OpenAI key is invalid. <br/> <strong>2.</strong> Your OpenAI key is valid but doesn't have access to GPT-4. You should buy at least $5 credits from OpenAI for enable GPT-4 access with API key. <br/> <strong>3.</strong> If you enabled Assistants API, your assistant id may invalid or your OpenAI key isn't belong to same account with your assistant. <br/> <strong>4.</strong> If you enabled Assistant API and key is correct, you may selected different model on Mevo's side than your assistant model on OpenAI side. Be sure your gpt-model is same both on Mevo and OpenAI sides. (ie: GPT-4 on both sides) <br/><br/>If you're not sure what is the reason, you can contact us with <a class='underline text-pink-500' href='mailto:hi@usemevo.com'>hi@usemevo.com</a>",
          options: [],
        },
      });
    }
  }

  if (!isInteractedOnce.value) isInteractedOnce.value = true;
  // scroll to bottom
  scrollToBottom("#message-container");
};

// calculate next step of bot flow
// make assignments or end flow
const calculateNextStep = function (): void {
  // remove loading indicator after a half second
  setTimeout(() => {
    isLoading.value = false;
  }, 500);
  // create 250ms gap between loading dissolve and new message appear transition
  setTimeout(async () => {
    // check is this end of bot flow?
    if (bot.data.script.steps.length > activeStep.value) {
      // if not
      // push next step into scene
      scene.steps.push(bot.data.script.steps[activeStep.value]);
      // scroll scene to bottom
      scrollToBottom("#message-container");

      // focus to text input if this step require manual input
      setTimeout(() => {
        if (bot.data.script.steps[activeStep.value].isManualInputAllowed) {
          document.getElementById("widget-text-input")?.focus();
        }
      }, 500);

      // if this step is a message? show loading indicator
      // because we know, if the type is message
      // m-script-step component will emit "replied" event after 500ms
      // so we need to show loading indicator till it'll emit that
      if (
        bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
      ) {
        isLoading.value = true;
      }
    } else {
      // const result = await createUserResponse({
      //   bot: bot.data._id || "fallback_id",
      //   values: response.data,
      // });
      // if (result.isOk()) {
      //   isCompleted.value = true;
      // } else {
      //   isErrorOccurred.value = true;
      //   errorMessage.value = t(result.error.message);
      // }
    }
  }, 750);
};

const fetchBotAndSetAssignments = async function (id: string): Promise<void> {
  const botDetailResponse = await getBotSafePublic({ id });
  isBotDataLoading.value = false;
  if (botDetailResponse.isOk()) {
    mixpanel.track("view_bot", {
      id: botDetailResponse.value.payload._id,
      name: botDetailResponse.value.payload.name,
      organization: botDetailResponse.value.payload.organization.name,
    });
    if (!botDetailResponse.value.payload.isActive) {
      isErrorOccurred.value = true;
      return;
    }
    // store bot data for cache
    fetchedBotData = botDetailResponse.value.payload;
    // assign to bot state
    bot.data = botDetailResponse.value.payload;
    // push first step into scene
    scene.steps.push({
      type: ScriptStepType.MESSAGE,
      data: {
        message: bot.data.gptSettings.firstMessage,
        options: [],
      },
    });

    if (bot.data.design.pageCustomCSS) {
      const style = document.createElement("style");
      style.innerHTML =
        "@media (min-width: 640px) {" + bot.data.design.pageCustomCSS + "}";
      document.head.appendChild(style);
    }

    if (typeof bot.data.design.openerColor === "undefined") {
      bot.data.design.openerColor = "indigo";
    }

    if (typeof bot.data.design.bubbleColor === "undefined") {
      bot.data.design.bubbleColor = "indigo";
    }

    if (typeof bot.data.design.openerIcon === "undefined") {
      bot.data.design.openerIcon = "message-smile";
    }

    if (typeof bot.data.design.backgroundType === "undefined") {
      bot.data.design.backgroundType = "image";
    }
  } else {
    isErrorOccurred.value = true;
    errorMessage.value = t("widget.BOT_NOT_FOUND");
  }
};

const trackBotEvent = async function (type: BotEventType) {
  await sendBotEvent({
    bot: bot.data._id + "",
    type,
  });
};

watch(isCompleted, async (_isCompleted) => {
  if (_isCompleted) {
    await trackBotEvent(BotEventType.COMPLETED);
  }
});

onMounted(async () => {
  setTimeout(async () => {
    await fetchBotAndSetAssignments(props.id as string);
  }, 1000);

  if (localStorage.getItem("mevo:sid") && !props.demo) {
    session.value = localStorage.getItem("mevo:sid") as string;
  } else {
    session.value = uuidv4();
    localStorage.setItem("mevo:sid", session.value);
  }

  if (localStorage.getItem("mevo:form-submitted-" + session.value)) {
    isFormSubmitted.value = true;
  }
});
</script>

<style>
.slide-enter-active,
.slide-leave-active {
  transition: all 0.25s ease;
}

.slide-enter-to {
  position: absolute;
  right: 0;
  left: 0;
  opacity: 1;
}

.slide-enter-from {
  position: absolute;
  right: -25%;
  opacity: 0;
}

.slide-leave-to {
  position: absolute;
  left: -25%;
  opacity: 0;
}

.slide-leave-from {
  position: absolute;
  left: 0;
  opacity: 1;
}
</style>
