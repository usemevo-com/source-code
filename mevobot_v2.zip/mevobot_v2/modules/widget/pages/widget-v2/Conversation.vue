<template>
  <!-- 
    bg-gray-700
    bg-red-700
    bg-blue-700
    bg-green-700
    bg-yellow-700
    bg-indigo-700
    bg-purple-700
    bg-pink-700
    bg-gray-600
    bg-red-600
    bg-blue-600
    bg-green-600
    bg-yellow-600
    bg-indigo-600
    bg-purple-600
    bg-pink-600
    hover:bg-gray-600
    hover:bg-red-600
    hover:bg-blue-600
    hover:bg-green-600
    hover:bg-yellow-600
    hover:bg-indigo-600
    hover:bg-purple-600
    hover:bg-pink-600
   -->
  <div class="h-screen w-full bg-white flex justify-center">
    <div
      class="flex justify-center items-center w-full h-screen"
      v-if="conversation_state.is_error"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div>
          <div class="text-black font-medium text-lg">Something went wrong</div>
          <div class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <div
      class="flex justify-center items-center w-full h-screen"
      v-else-if="conversation_state.is_loading"
    >
      <i
        class="fa-thin fa-spinner-third animate-spin text-4xl text-gray-500"
      ></i>
    </div>
    <div
      v-else
      class="flex flex-col justify-between sm:w-2/3 lg:w-2/5 w-full shadow"
    >
      <div
        class="w-full py-5 px-6 flex items-center justify-between shadow-md"
        :class="`bg-${conversation_state.bot.appearance.theme}-500`"
      >
        <div
          @click="go_welcome"
          class="w-10 h-10 rounded-lg flex justify-center items-center cursor-pointer"
          :class="`bg-${conversation_state.bot.appearance.theme}-700 hover:bg-${conversation_state.bot.appearance.theme}-700`"
        >
          <i class="fa-solid fa-chevron-left text-white text-xl"></i>
        </div>

        <div
          class="text-white font-semibold antialiased flex flex-col justify-end items-end"
        >
          <div class="text-sm">{{ conversation_state.bot.name }}</div>
          <!-- <div class="text-gray-400 text-xs font-light">AI Agent</div> -->
        </div>
      </div>
      <div
        class="flex-1 overflow-y-scroll space-y-4 py-4"
        id="message-container"
      >
        <previous-conversations
          :image="conversation_state.bot.appearance.brandImage"
          :theme="conversation_state.bot.appearance.theme"
          :conversations="conversation_state.previous_conversations"
        />
        <message-item
          :image="conversation_state.bot.appearance.brandImage"
          :theme="conversation_state.bot.appearance.theme"
          :key="index"
          :text="message.text"
          :sent_at="message.sent_at"
          :sender="message.sender"
          v-for="(message, index) in conversation_state.messages"
        />
        <typing
          :image="conversation_state.bot.appearance.brandImage"
          v-if="conversation_state.is_typing"
        />
      </div>
      <div class="w-full border-t relative">
        <input
          :disabled="is_input_disabled"
          @keyup.enter="on_submit"
          v-model="conversation_state.message"
          type="text"
          class="border-none w-full h-full py-4 px-6 text-sm ring-none focus:ring-none"
          :placeholder="conversation_state.bot.appearance.placeholderText"
          :class="[is_input_disabled ? 'bg-gray-50' : 'bg-white']"
        />
        <i
          v-if="conversation_state.is_submitting"
          class="top-5 right-5 fa fa-spinner-third animate-spin text-sm absolute text-gray-500"
        ></i>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import { v4 as uuidv4 } from "uuid";

import {
  check_chatbot_response,
  interact_with_chatbot,
  get_conversations_by_device,
  get_bot_public,
} from "@/modules/bot/services/BotService";
import { useWidget } from "@/modules/widget/composables/useWidget";
import MessageItem from "./containers/MessageItem.vue";
import PreviousConversations from "./containers/PreviousConversations.vue";
import Typing from "./containers/Typing.vue";
import { MessageSender } from "./types/MessageSender";
import { IBot } from "@/modules/bot/types/IBot";

// state
export interface ConversationState {
  bot: IBot;
  message: string;
  is_submitting: boolean;
  is_typing: boolean;
  session_id: string;
  chatbot_id: string;
  device_id: string;
  messages: {
    text: string;
    sender: MessageSender;
    sent_at: string;
  }[];
  previous_conversations: any[];
  is_previous_conversations_visible: boolean;
  is_loading: boolean;
  is_error: boolean;
}

const conversation_state: ConversationState = reactive({
  bot: {},
  message: "",
  is_submitting: false,
  is_typing: false,
  session_id: "",
  chatbot_id: "",
  device_id: "",
  messages: [],
  previous_conversations: [],
  is_previous_conversations_visible: false,
  is_loading: true,
  is_error: false,
});

// hooks
const $route = useRoute();
const $router = useRouter();
const { scrollToBottom } = useWidget();

// methods
const on_submit = async () => {
  // show loader
  conversation_state.is_submitting = true;

  const interact_with_chatbot_response = await interact_with_chatbot(
    conversation_state.chatbot_id,
    {
      message: conversation_state.message,
      sid: conversation_state.session_id,
      did: conversation_state.device_id,
    }
  );

  if (interact_with_chatbot_response.isOk()) {
    if (interact_with_chatbot_response.value.payload) {
      conversation_state.messages.push({
        text: conversation_state.message,
        sender: MessageSender.USER,
        sent_at: new Date().toISOString(),
      });
      scrollToBottom("#message-container");
      conversation_state.message = "";
      conversation_state.is_submitting = false;
      conversation_state.is_typing = true;
      await check_response();
    } else {
      conversation_state.messages.push({
        text: "It looks like something wrong with your chatbot configuration. Please check your settings and contact support.",
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      conversation_state.is_submitting = false;
      scrollToBottom("#message-container");
    }
  } else {
    conversation_state.is_submitting = false;
  }
};

const check_response = async () => {
  const chatbot_response = await check_chatbot_response(
    conversation_state.session_id,
    conversation_state.chatbot_id,
    conversation_state.device_id
  );

  if (chatbot_response.isOk()) {
    if (chatbot_response.value.payload.status) {
      conversation_state.is_typing = false;

      conversation_state.messages.push({
        text: chatbot_response.value.payload.message,
        sender: MessageSender.AI,
        sent_at: new Date().toISOString(),
      });
      scrollToBottom("#message-container");
    } else {
      setTimeout(() => {
        check_response();
      }, 1000);
    }
  } else {
    setTimeout(() => {
      check_response();
    }, 1000);
  }
};

const on_show_prev_conversations = () => {
  conversation_state.is_previous_sessions_visible = true;
};

const go_welcome = () => {
  $router.push({
    name: "chatbot_welcome",
    params: { id: conversation_state.chatbot_id },
  });
};

const init_first_message = () => {
  conversation_state.messages.push({
    text: conversation_state.bot.appearance.firstMessage,
    sender: MessageSender.AI,
    sent_at: new Date().toISOString(),
  });
};

// computeds
const is_input_disabled = computed(
  () => conversation_state.is_submitting || conversation_state.is_typing
);

onMounted(async () => {
  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    conversation_state.is_loading = false;
    conversation_state.is_error = false;
    conversation_state.bot = public_bot_response.value.payload.bot as IBot;

    init_first_message();
  } else {
    conversation_state.is_loading = false;
    conversation_state.is_error = true;
  }

  // check mevo_session in local storage
  const mevo_session = JSON.parse(
    localStorage.getItem(`mevo:${$route.params.id}:session_id`)
  );

  // if we have a valid session, use it
  if (mevo_session && mevo_session.exp > new Date().getTime() / 1000) {
    conversation_state.session_id = mevo_session.id;

    // and update the expire time to 1 hour
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: conversation_state.session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }
  // if we don't have a valid session, create a new one
  else {
    conversation_state.session_id = uuidv4();
    localStorage.setItem(
      `mevo:${$route.params.id}:session_id`,
      JSON.stringify({
        id: conversation_state.session_id,
        exp: new Date().getTime() / 1000 + 3600,
      })
    );
  }

  conversation_state.chatbot_id = $route.params.id as string;
  conversation_state.device_id = localStorage.getItem(
    "mevo_device_id"
  ) as string;

  // check if we have previous sessions
  const previous_sessions_response = await get_conversations_by_device(
    conversation_state.chatbot_id,
    conversation_state.device_id
  );

  if (previous_sessions_response.isOk()) {
    let sessions = previous_sessions_response.value.payload;

    const current_session = sessions.find(
      (session: any) => session._id === conversation_state.session_id
    );

    if (current_session) {
      conversation_state.messages = sessions.find(
        (session: any) => session._id === conversation_state.session_id
      ).messages;

      conversation_state.previous_conversations = sessions.filter(
        (session: any) => session._id !== conversation_state.session_id
      );
    } else {
      conversation_state.previous_conversations = sessions;
    }
  }

  // check if any messages passed as query params
  if ($route.query.message) {
    conversation_state.message = $route.query.message as string;
    on_submit();
  }

  scrollToBottom("#message-container");
});
</script>
