<template>
  <!-- from-gray-900 via-gray-500 to-gray-100 -->
  <!-- from-blue-900 via-blue-500 to-blue-100 -->
  <!-- from-red-900 via-red-500 to-red-100 -->
  <!-- from-indigo-900 via-indigo-500 to-indigo-100 -->
  <!-- from-green-900 via-green-500 to-green-100 -->
  <!-- from-yellow-900 via-yellow-500 to-yellow-100 -->
  <!-- from-pink-900 via-pink-500 to-pink-100 -->
  <!-- from-purple-900 via-purple-500 to-purple-100 -->
  <!-- from-amber-900 via-amber-500 to-amber-100 -->
  <!-- from-cyan-900 via-cyan-500 to-cyan-100 -->
  <!-- from-lime-900 via-lime-500 to-lime-100 -->
  <!-- from-emerald-900 via-emerald-500 to-emerald-100 -->
  <!-- from-teal-900 via-teal-500 to-teal-100 -->
  <!-- from-rose-900 via-rose-500 to-rose-100 -->
  <!-- from-fuchsia-900 via-fuchsia-500 to-fuchsia-100 -->
  <div class="h-screen w-full bg-white flex justify-center">
    <div
      class="flex justify-center items-center w-full h-screen"
      v-if="welcome_state.is_error"
    >
      <div class="flex flex-col space-y-4 w-2/3">
        <div class="font-bold text-4xl">:(</div>
        <div>
          <div class="text-black font-medium text-lg">Something went wrong</div>
          <div class="text-gray-500 font-light text-sm">
            We're sorry but we couldn't load this chatbot, please try again
            later. If the problem persists, please contact support.
          </div>
        </div>
      </div>
    </div>
    <div
      class="flex justify-center items-center w-full h-screen"
      v-else-if="welcome_state.is_loading"
    >
    </div>
    <div
      v-else
      class="flex flex-col justify-between sm:w-2/3 lg:w-2/5 w-full shadow"
    >
      <div class="bg-white w-full h-screen flex flex-col justify-between">
        <div
          class="bg-gradient-to-tl h-72 relative"
          :class="`from-${welcome_state.bot.appearance.theme}-900 via-${welcome_state.bot.appearance.theme}-500 to-${welcome_state.bot.appearance.theme}-100`"
        >
          <div class="absolute top-6 left-6">
            <img
              :src="welcome_state.bot.appearance.brandImage"
              class="w-12 h-12 rounded-lg"
            />
          </div>
          <div class="absolute bottom-12 px-6 w-full font-bold text-3xl">
            <div class="text-white">
              {{ welcome_state.bot.appearance.greeting }}
            </div>
            <!-- <div class="text-white">{{ welcome_state.bot.appearance }}</div> -->
          </div>
          <router-link to="conversation">
            <div
              class="cursor-pointer text-gray-700 h-[54px] px-6 w-[calc(100%_-_53px)] absolute mx-[24px] shadow -bottom-[27px] font-medium bg-white shadow-xl shadow-black/5 hover:text-black-500 ring-1 ring-slate-700/10 rounded-lg flex justify-between items-center"
            >
              <div class="text-sm">
                {{ welcome_state.bot.appearance.talkWithAgentMessage }}
              </div>
              <div><i class="fa-solid fa-paper-plane-top"></i></div>
            </div>
          </router-link>
        </div>
        <div class="space-y-4 flex-1 pt-12 pb-8 overflow-y-scroll">
          <div
            class="cursor-pointer text-gray-700 p-2 w-[calc(100%_-_48px)] mx-[24px] font-medium bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
          >
            <div
              @click="start_conversation(chat_starter)"
              :key="index"
              v-for="(chat_starter, index) in welcome_state.chat_starters"
              class="space-x-4 flex justify-between items-center py-2 px-4 hover:text-black-500 rounded-lg hover:bg-gray-100"
            >
              <div class="text-sm">{{ chat_starter }}</div>
              <div><i class="fa-solid fa-chevron-right text-sm"></i></div>
            </div>
          </div>
          <!-- <div
        class="cursor-pointer text-gray-700 w-[calc(100%_-_48px)] mx-[24px] font-medium bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
      >
        <div class="p-4 border-b">
          <img
            class="rounded-lg"
            src="https://interviewwith.ai/blog/wp-content/uploads/2024/04/sung-shin-KvFz3IXf8MM-unsplash-1.png"
          />
        </div>
        <div
          class="flex flex-col p-4 hover:text-black-500 hover:bg-gray-100 space-y-1"
        >
          <div class="text-sm font-medium">
            How to find an internship: Your Guide to Finding the Right
            Internship
          </div>
          <div class="text-sm text-[#737376] font-light">
            The internship: a rite of passage for many students, a chance to
            gain valuable work experience, explore career paths, and beef up
            that resume.
          </div>
        </div>
      </div>

      <div
        class="cursor-pointer text-gray-700 w-[calc(100%_-_48px)] mx-[24px] font-medium bg-white shadow-xl shadow-black/5 ring-1 ring-slate-700/10 rounded-lg"
      >
        <div class="p-4 border-b">
          <img
            class="rounded-lg"
            src="https://interviewwith.ai/blog/wp-content/uploads/2024/04/christin-hume-Hcfwew744z4-unsplash-1.png"
          />
        </div>
        <div
          class="flex flex-col p-4 hover:text-black-500 hover:bg-gray-100 space-y-1"
        >
          <div class="text-sm font-medium">
            Online Job Interview Checklist: Must read list before interview
          </div>
          <div class="text-sm text-[#737376] font-light">
            The traditional handshake-and-portfolio interview scene is evolving.
            Today, online interviews are becoming increasingly common, offering
            flexibility and convenience for both employers and candidates.
          </div>
        </div>
      </div> -->
        </div>
        <div
          v-if="!welcome_state.bot.appearance.hideBranding"
          class="text-xs py-2 w-full flex items-center justify-center space-x-2 border-t border-gray-50"
        >
          <!-- <i class="fa-solid fa-bolt text-amber-500"></i> -->
          <span class="text-gray-500 font-light"
            >powered by
            <a href="https://usemevo.com" target="_blank"
              ><span class="font-bold text-black">mevo</span></a
            ></span
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from "vue";
import { useRoute, useRouter } from "vue-router";
import { get_bot_public } from "@/modules/bot/services/BotService";
import { IBot } from "@/modules/bot/types/IBot";

const $route = useRoute();
const $router = useRouter();

interface WelcomeState {
  bot: IBot;
  chat_starters: string[];
  is_loading: boolean;
  is_error: boolean;
}

const welcome_state: WelcomeState = reactive({
  bot: {},
  is_loading: true,
  is_error: false,
  chat_starters: [],
});

const start_conversation = (chat_starter: string) => {
  $router.push({
    name: "chatbot_conversation",
    params: {
      id: $route.params.id,
    },
    query: {
      message: chat_starter,
    },
  });
};

onMounted(async () => {
  const public_bot_response = await get_bot_public($route.params.id as string);

  if (public_bot_response.isOk()) {
    welcome_state.is_loading = false;
    welcome_state.is_error = false;
    welcome_state.bot = public_bot_response.value.payload.bot as IBot;
    welcome_state.chat_starters =
      public_bot_response.value.payload.chat_starters.map((chat_starter) => {
        return chat_starter.question;
      });
  } else {
    welcome_state.is_loading = false;
    welcome_state.is_error = true;
    // TODO: handle error
  }
});
</script>
