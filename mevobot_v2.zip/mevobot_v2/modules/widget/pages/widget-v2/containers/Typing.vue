<template>
  <div class="flex items-end px-6 sm:px-2 space-x-4 justify-start">
    <img :src="image" class="w-8 h-8 rounded-lg mb-2 border border-gray-200" />

    <div class="flex flex-col">
      <div
        class="rounded-xl bg-gray-100 px-5 py-4 w-fit text-sm"
        id="message-content"
      >
        <i class="fa fa-spinner-third animate-spin text-md text-gray-300"></i>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, defineProps } from "vue";

const props = defineProps({
  image: String,
});
</script>
