<template>
  <div
    class="flex items-end px-6 space-x-4"
    :class="[
      sender === MessageSender.AI && 'justify-start',
      sender === MessageSender.USER && 'justify-end',
    ]"
  >
    <img
      v-if="sender === MessageSender.AI"
      :src="image"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200"
    />

    <div
      class="flex flex-col"
      :class="[sender === MessageSender.USER && 'items-end ']"
    >
      <div
        class="rounded-xl px-5 py-4 w-fit text-[15px] sm:max-w-[400px]"
        :class="[
          sender === MessageSender.USER && `bg-${theme}-600 text-white`,
          sender === MessageSender.AI && 'bg-gray-100',
        ]"
        id="message-content"
      >
        <vue-markdown :source="cleaned_text" :plugins="plugins" />
      </div>
      <div class="text-xs text-gray-500 mt-1">
        {{ moment(sent_at).fromNow() }}
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from "vue";
import moment from "moment";
import VueMarkdown from "vue-markdown-render";
import MarkdownItAnchor from "markdown-it-anchor";
import { MessageSender } from "../types/MessageSender";

const plugins = [MarkdownItAnchor];

interface MessageItemProps {
  text: string;
  sent_at: string;
  sender: MessageSender;
  theme: string;
  image: string;
}

const props = withDefaults(defineProps<MessageItemProps>(), {
  text: "",
  sent_at: "",
  sender: MessageSender.AI,
  theme: "indigo",
  image: "",
});

const cleaned_text = ref("");

onMounted(() => {
  cleaned_text.value = props.text.replaceAll(/【(.*)】/g, "");

  setTimeout(() => {
    const links = document.querySelectorAll("#message-content a");
    links.forEach((link) => {
      link.setAttribute("target", "_blank");
      if (!link.innerHTML.includes("fa-external-link-alt")) {
        link.innerHTML =
          link.innerHTML + '<i class="fa fa-external-link-alt ml-1"></i>';
      }
    });
  }, 100);
});
</script>

<style>
#message-content p:not(:first-of-type) {
  margin: 4px 0px 0px 0px;
}

#message-content ol {
  margin: 16px 0px 16px 0px;
}

#message-content ul {
  margin: 8px 0px 8px 0px;
}

#message-content ul > li,
#message-content ol > li {
  margin: 0px 0px 4px 0px;
}

#message-content p a {
  font-weight: 500;
  color: #0e449b;
  text-decoration: underline;
}
</style>
