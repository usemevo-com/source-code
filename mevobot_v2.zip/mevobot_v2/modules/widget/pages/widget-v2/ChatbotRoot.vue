<template>
  <RouterView v-slot="{ Component }">
    <transition name="slide" mode="out-in">
      <component :is="Component" />
    </transition>
  </RouterView>
</template>

<script setup>
import { onMounted } from "vue";
import { v4 as uuidv4 } from "uuid";

onMounted(() => {
  // init mevo identity
  if (!localStorage.getItem("mevo_device_id")) {
    localStorage.setItem("mevo_device_id", uuidv4());
  }
});
</script>

<style>
.slide-enter-active,
.slide-leave-active {
  transition: all 0.1s ease;
}

.slide-enter-to {
  position: absolute;
  right: 0;
  left: 0;
  opacity: 1;
}

.slide-enter-from {
  position: absolute;
  right: -75%;
  opacity: 0;
}

.slide-leave-to {
  position: absolute;
  left: -75%;
  opacity: 0;
}

.slide-leave-from {
  position: absolute;
  left: 0;
  opacity: 1;
}
</style>
