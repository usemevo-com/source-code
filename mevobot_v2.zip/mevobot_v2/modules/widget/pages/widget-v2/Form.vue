<template>
  <div class="h-screen w-full bg-white flex flex-col justify-between">
    <div class="w-full py-5 px-6 bg-black flex items-center justify-between">
      <i
        @click="$router.push({ name: 'welcome' })"
        class="fa-solid fa-chevron-left text-white cursor-pointer text-xl"
      ></i>

      <div
        class="text-white font-semibold antialiased flex flex-col justify-end items-end"
      >
        <div class="text-sm">Let us get to know you before start</div>
        <!-- <div class="text-gray-400 text-xs font-light">AI Agent</div> -->
      </div>
    </div>
    <div
      class="flex-1 overflow-y-scroll space-y-4 px-4 flex flex-col justify-center"
    >
      <div>
        <label class="font-medium text-sm">Your name</label>
        <input
          type="text"
          class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
          placeholder="John Doe"
        />
      </div>
      <div>
        <label class="font-medium text-sm">Organization</label>
        <input
          type="text"
          class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
          placeholder="Microsoft"
        />
      </div>
      <div>
        <label class="font-medium text-sm">Email</label>
        <input
          type="email"
          class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
          placeholder="john.doe@microsoft.com"
        />
      </div>
      <div>
        <label class="font-medium text-sm">Phone number</label>
        <input
          type="text"
          class="mt-1 w-full p-3 text-sm ring-none focus:ring-none rounded-lg border-gray-300"
          placeholder="+1 123 456 7890"
        />
      </div>
      <div>
        <button
          class="w-full p-3 text-sm ring-none focus:ring-none bg-black text-white rounded-lg"
        >
          <span class="font-medium">Start conversation</span>
        </button>
      </div>
      <div>
        <p class="text-gray-500 text-xs">
          By clicking "Start conversation", you agree to our
          <a href="#" class="text-blue-500">Terms of Service</a> and
          <a href="#" class="text-blue-500">Privacy Policy</a>.
        </p>
      </div>
    </div>
    <!-- <div class="w-full border-t">
      <input
        type="text"
        class="border-none w-full h-full p-4 text-sm ring-none focus:ring-none"
        placeholder="Type a message..."
      />
    </div> -->
  </div>
</template>

<script lang="ts" setup></script>
