export enum MessageSender {
  AI = "BOT",
  USER = "USER",
}
