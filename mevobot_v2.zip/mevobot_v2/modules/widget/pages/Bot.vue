<template>
  <div
    v-if="!isLoading && isNotFound"
    class="flex h-screen w-full justify-center items-center bg-indigo-500"
  >
    <div class="w-full sm:w-2/3 mx-auto flex sm:flex-row flex-col items-center">
      <div
        class="w-full sm:w-1/2 sm:border-r border-indigo-700 text-center sm:pr-12"
      >
        <span class="block sm:hidden text-4xl font-bold mb-2 text-white"
          >:(</span
        >
        <div class="text-white text-4xl font-bold mb-1">
          Bot not found <span class="hidden sm:inline-block">:(</span>
        </div>
        <div class="text-gray-200 text-lg">
          This bot is not exist or isn't active anymore.
        </div>
      </div>
      <div class="w-full sm:w-1/2 mt-32 sm:mt-0 sm:pl-12">
        <div class="text-center font-light text-white">
          Do you want to create your own
          <span class="font-bold">free</span> chatbot?<br />
          <m-button @clicked="goMevo()" class="mt-4" type="white"
            >Create your own chatbot</m-button
          >
        </div>
      </div>
    </div>
  </div>
  <div
    v-if="isLoading"
    class="h-screen w-full flex justify-center items-center bg-white"
  >
    <div class="flex flex-col items-center justify-center">
      <!-- <m-brand variant="logo-only" class="w-16" /> -->
      <i
        class="mt-4 animate-spin text-indigo-300 fa-sharp fa-light fa-spinner-third text-3xl"
      ></i>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { getBotSafePublic } from "@/modules/bot/services/BotService";
import MBrand from "@/components/v2/elements/MBrand.vue";
import MButton from "@/components/v2/elements/MButton.vue";
import { BotType } from "@/modules/bot/types/IBot";

const $route = useRoute();
const $router = useRouter();

const isLoading = ref(true);
const isNotFound = ref(false);

const goMevo = () => {
  window.location.href = "https://usemevo.com";
};

onMounted(async () => {
  if ($route.params.bid) {
    const botResponse = await getBotSafePublic({
      id: $route.params.bid as string,
    });

    if (botResponse.isOk()) {
      $router.push({
        name:
          botResponse.value.payload.type === BotType.SCRIPTED
            ? "widget-view"
            : "gpt-view",
        params: {
          id: botResponse.value.payload._id,
        },
        query: {
          ...$route.query,
        },
      });
    } else {
      isLoading.value = false;
      isNotFound.value = true;
    }
  } else {
    isNotFound.value = true;
    isLoading.value = false;
  }

  localStorage.removeItem("mevo:last_visited_route");
});
</script>
