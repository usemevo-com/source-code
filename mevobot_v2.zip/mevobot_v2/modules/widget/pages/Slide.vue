<template>
  <slide-progress
    v-if="bot.data.script"
    :percentage="((index + 1) / bot.data.script.steps.length) * 100"
  />
  <div
    v-if="!isCompleted && !isErrorOccurred"
    class="flex flex-col h-screen p-8 sm:p-4 bg-white"
  >
    <div class="flex flex-col flex-1 w-full items-center justify-center">
      <div class="w-full sm:max-w-lg space-y-8">
        <slide-head
          :title="bot.data.script && bot.data.script.steps[index].data.message"
          :description="
            isCurrentStepSingleSelect
              ? 'Choose one of the options below'
              : false
          "
          :is-first="index === 0"
        />

        <!-- <m-text-input
          @keyup.enter="onNext"
          v-model="responseStack.data[responseIndex].value"
          v-if="!isCurrentStepMessage && !isCurrentStepSingleSelect"
          placeholder="Type your answer here"
          class="w-full"
        /> -->
        <Field
          :rules="TypeRuleMap[currentStepType]"
          id="widget-text-input"
          name="WidgetTextInput"
          :placeholder="$t('placeholders.TYPE_YOUR_ANSWER')"
          class="w-full !outline-0 p-4 border rounded-md"
          autocomplete="off"
        />
        <!-- <div
          v-else-if="isCurrentStepSingleSelect"
          class="flex flex-col space-y-2 w-full"
        >
          <div
            @click="onSelect(option)"
            class="w-full sm:min-w-fit sm:w-[200px] hover:bg-indigo-200 hover:text-indigo-500 hover:border-indigo-200 border-2 border-indigo-50 cursor-pointer bg-indigo-50 px-4 py-2 rounded-md text-left flex justify-between items-center"
            :class="[
              responseStack.data[responseIndex] &&
                responseStack.data[responseIndex].value === option &&
                '!border-2 !border-indigo-500 text-indigo-500',
            ]"
            v-for="option in bot.data.script.steps[index].data.options"
          >
            <span>{{ option }}</span>
            <check-icon
              v-if="
                responseStack.data[responseIndex] &&
                responseStack.data[responseIndex].value === option
              "
              class="w-4 h-4 text-indigo-500"
            />
          </div>
        </div> -->

        <slide-main-action
          @next="onNext"
          :is-first-step="index === 0"
          :is-last-step="isCurrentStepLast"
        />
      </div>
    </div>

    <div class="flex items-center w-full justify-between">
      <slide-navigation-buttons
        :index="index"
        @next="onNext"
        @prev="onPrev"
        :is-next-disable="
          isCurrentStepMessage &&
          responseStack.data[responseIndex] &&
          responseStack.data[responseIndex].value === ''
        "
      />

      <div
        class="flex flex-col py-1 px-4 items-center rounded shadow bg-primary text-white hidden sm:block"
      >
        <a target="_blank" href="https://usemevo.com">
          <div class="text-sm font-medium">
            made with
            <span class="font-black">mevo</span>
          </div>
        </a>
      </div>
    </div>
  </div>
  <div v-else-if="isCompleted">
    <div class="flex flex-col justify-center items-center h-screen">
      <CheckCircleIcon class="w-8 h-8 text-green-500" />
      <m-headline
        center
        :title="$t('widget.COMPLETED_THANKS')"
        :description="$t('widget.COMPLETED_DESCRIPTION')"
      />
    </div>
  </div>
  <div v-else-if="isErrorOccurred">
    <div class="flex flex-col justify-center items-center h-screen">
      <ExclamationCircleIcon class="w-8 h-8 text-red-500" />
      <m-headline
        center
        :title="$t('widget.ERROR_OCCURRED')"
        :description="errorMessage"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute } from "vue-router";
import { CheckIcon } from "@heroicons/vue/24/outline";
import {
  CheckCircleIcon,
  ExclamationCircleIcon,
} from "@heroicons/vue/20/solid";
import { Form, Field, ErrorMessage } from "vee-validate";
import MTextInput from "@/components/basic/MTextInput.vue";
import MHeadline from "@/components/basic/MHeadline.vue";
import { ScriptStepType } from "@/modules/bot/types/IScriptStep";

import SlideProgress from "../containers/slide/SlideProgress.vue";
import SlideHead from "../containers/slide/SlideHead.vue";
import SlideMainAction from "../containers/slide/SlideMainAction.vue";
import SlideNavigationButtons from "../containers/slide/SlideNavigationButtons.vue";
import {
  createUserResponse,
  getBotSafePublic,
} from "@/modules/bot/services/BotService";
import { useStepValidation } from "../composables/useStepValidation";
import type { IBot } from "@/modules/bot/types/IBot";
import { NotificationType, useCommonStore } from "@/stores";

const $route = useRoute();
const { t } = useI18n();
const { setNotification } = useCommonStore();
const { TypeRuleMap } = useStepValidation();
const responseStack: { data: { value: string; id: string }[] } = reactive({
  data: [],
});
const isCompleted = ref(false);
const isErrorOccurred = ref(false);
const errorMessage = ref("");
const index = ref(0);
const responseIndex = ref(0);
const bot: { data: IBot } = reactive({
  data: {},
});

// computeds
const currentStepType = computed(() => {
  return bot.data.script
    ? bot.data.script.steps[index.value].type
    : ScriptStepType.MESSAGE;
});

const isCurrentStepMessage = computed(() => {
  return currentStepType.value === ScriptStepType.MESSAGE;
});

const isCurrentStepSingleSelect = computed(() => {
  return (
    currentStepType.value === ScriptStepType.SINGLE_SELECT ||
    currentStepType.value === ScriptStepType.YES_NO
  );
});

const isCurrentStepLast = computed(() => {
  return bot.data.script
    ? index.value === bot.data.script.steps.length - 1
    : false;
});

// methods
const onSelect = function (value: string) {
  // responseStack.data.push({
  //   id: bot.data.script.steps[index.value].id,
  //   value: "",
  // });
  // assign current selected option to current step in stack
  responseStack.data[responseIndex.value].value = value;

  // // step forward
  // index.value++;

  // // it means current step is manual input allowed
  // // bcz if next step is message, we don't need to push new item into stack
  // // and if next step is single select, we don't need to push new item into stack
  // // since it will be pushed when user select an option
  // if (!isCurrentStepSingleSelect.value && !isCurrentStepMessage.value) {
  //   responseStack.data.push({
  //     id: bot.data.script.steps[index.value].id,
  //     value: "",
  //   });
  // }
};

const onNext = async function () {
  if (
    !isCurrentStepMessage.value &&
    responseStack.data[responseIndex.value].value === ""
  ) {
    setNotification(
      "Please select an option or type your answer",
      NotificationType.ERROR
    );
    return;
  }

  if (!isCurrentStepMessage.value) {
    responseIndex.value++;
  }

  if (!isCurrentStepLast.value) {
    index.value++;
  } else {
    await saveUserResponse();
  }
};

const onPrev = function () {
  if (index.value === 0) return;
  index.value--;
  if (!isCurrentStepMessage.value) {
    responseIndex.value--;
  }
};

const fetchBotAndSetAssignments = async function (id: string): Promise<void> {
  const botDetailResponse = await getBotSafePublic({ id });

  if (botDetailResponse.isOk()) {
    bot.data = botDetailResponse.value.payload;
  } else {
    console.log("Bot not found");
  }
};

const saveUserResponse = async function () {
  const result = await createUserResponse({
    bot: bot.data._id || "fallback_id",
    values: responseStack.data.filter((item) => item.value !== ""),
  });

  if (result.isOk()) {
    isCompleted.value = true;
  } else {
    isErrorOccurred.value = true;
    errorMessage.value = t(result.error.message);
  }
};

// hooks
onMounted(async () => {
  await fetchBotAndSetAssignments($route.params.id as string);

  bot.data.script.steps.map((step) => {
    if (step.type !== ScriptStepType.MESSAGE) {
      responseStack.data.push({
        id: step.id,
        value: "",
      });
    }
  });
});
</script>

<style>
.slide-content-enter-active {
  transition: all 1s ease;
}
.slide-content-leave-active {
  transition: all 1s ease;
}
/* .slide-content-enter-from {
  opacity: 0;
  transform: translateX(-10px);
}
.slide-content-leave-to {
  opacity: 0;
  transform: translateX(30px);
} */
</style>
