<template>
  <div
    class="flex w-full relative widget-vh overflow-hidden h-screen"
    :style="{ backgroundColor: bot.data.design.backgroundColor }"
    :class="[
      bot.data.design.backgroundType === 'image' &&
        `bg-[url('https://cdn.usemevo.com/bg/${bot.data.design.background}')] bg-[length:300px_300px] bg-repeat`,
      'justify-center items-center ',
    ]"
  >
    <widget-left-side
      :no-mevo-mark="!isBrandingVisible"
      :theme="bot.data.design.theme"
      v-if="bot.data.design.layout === BotLayout.CHAT_RIGHT"
      :image="bot.data.design.background"
      :use-image="bot.data.design.backgroundType === 'image'"
      :color="bot.data.design.backgroundColor"
    />
    <div
      v-if="!isCompleted && !isErrorOccurred"
      class="w-full sm:w-2/3 bg-white shadow-lg flex flex-col widget-vh"
    >
      <div
        id="bot-header"
        class="py-4 px-5 border-b border-gray-100 flex justify-between items-center text-black"
      >
        <div id="bot-header-left" class="flex flex-col">
          <div
            v-if="!isBotDataLoading"
            :class="[bot.data.hideOrganization && 'flex items-center']"
          >
            <div id="bot-header-left-title" class="font-semibold">
              {{ bot.data.name }}
            </div>
            <div v-if="!bot.data.hideOrganization" class="flex flex-col">
              <div id="bot-header-left-organization" class="font-light text-xs">
                {{ bot.data.byText ? bot.data.byText : "by" }}
                <a
                  target="_blank"
                  :href="
                    bot.data.organization && bot.data.organization.domain
                      ? 'https://' + bot.data.organization.domain
                      : 'javascript:void(0)'
                  "
                  ><span class="font-bold text-gray-500">{{
                    bot.data.organization && bot.data.organization.name
                  }}</span></a
                >
              </div>
            </div>
          </div>
          <div
            v-else
            class="h-screen w-full flex justify-center items-center bg-white"
          >
            <div class="flex flex-col items-center justify-center">
              <!-- <m-brand variant="logo-only" class="w-16" /> -->
              <i
                class="animate-spin text-indigo-300 fa-sharp fa-light fa-spinner-third text-3xl"
              ></i>
            </div>
          </div>
        </div>
        <div id="bot-header-right" class="flex">
          <div
            v-if="!isBotDataLoading"
            v-tooltip="{
              text: 'Reset bot',
              theme: { placement: 'left', trigger: 'hover' },
            }"
            v-debounce:400ms="onReset"
            debounce-events="click"
            class="rounded-full bg-gray-100 hover:bg-gray-200 p-2 cursor-pointer"
          >
            <arrow-uturn-right-icon class="w-4 h-4 text-gray-700" />
          </div>
          <div
            @click="postMessage('chatbox-closed')"
            v-if="!isBotDataLoading && !isCloseIconHidden"
            v-tooltip="{
              text: 'Close popup',
              theme: { placement: 'left', trigger: 'hover' },
            }"
            class="rounded-full bg-gray-100 hover:bg-gray-200 p-2 cursor-pointer sm:hidden ml-4"
          >
            <x-mark-icon class="w-4 h-4 text-gray-700" />
          </div>
        </div>
      </div>
      <TransitionGroup
        name="widget-message-list"
        tag="div"
        v-if="scene.steps.length && !isBotDataLoading"
        class="grow w-full p-4 overflow-y-scroll"
        id="message-container"
      >
        <m-script-step
          :key="index"
          v-for="(step, index) in scene.steps"
          :theme="bot.data.design.bubbleColor"
          :step="step"
          :primary="step && typeof step.response === 'undefined'"
          :active-step="activeStep"
          :step-index="index"
          @next="onNext"
          @skip="onSkip"
        />
        <m-loading v-if="isLoading" />
      </TransitionGroup>
      <div v-else class="grow w-full p-4 animate-pulse space-y-2">
        <div class="ml-1 h-12 w-48 bg-gray-300 rounded-2xl"></div>
        <div class="ml-1 h-12 w-64 bg-gray-300 rounded-2xl"></div>
        <div class="ml-1 h-12 w-64 bg-gray-300 rounded-2xl"></div>
      </div>
      <widget-input
        :input-placeholder="bot.data.inputText"
        :type="bot.data.script.steps[activeStep].type"
        @submit="onTextSubmit"
        v-if="
          !isLoading &&
          bot.data &&
          bot.data.script &&
          bot.data.script.steps.length &&
          bot.data.script.steps[activeStep] &&
          bot.data.script.steps[activeStep].isManualInputAllowed
        "
      />
      <div
        v-if="isBrandingVisible"
        class="flex flex-col py-2 px-4 items-center sm:hidden border-t border-gray-100"
      >
        <div class="text-xs">
          made with
          <a target="_blank" href="https://usemevo.com"
            ><span class="font-black text-primary">mevo</span></a
          >
        </div>
      </div>
    </div>
    <widget-completed
      :no-mevo-mark="!isCallToActionVisible"
      :class="['h-screen']"
      v-else-if="isCompleted"
      @restart="onRestartConversation"
    />
    <widget-error-occurred
      :class="['h-screen']"
      v-else-if="isErrorOccurred"
      @restart="onRestartConversation"
      :message="errorMessage"
    />
    <widget-left-side
      :no-mevo-mark="!isBrandingVisible"
      v-if="bot.data.design.layout === BotLayout.CHAT_LEFT"
      :image="bot.data.design.background"
      :use-image="bot.data.design.backgroundType === 'image'"
      :color="bot.data.design.backgroundColor"
    />
  </div>
</template>

<script lang="ts" setup>
// external dependencies
import { computed, onMounted, reactive, ref, watch, type Ref } from "vue";
import { useRoute } from "vue-router";
import { ArrowUturnRightIcon, XMarkIcon } from "@heroicons/vue/24/outline";
import mixpanel from "mixpanel-browser";
// internal dependencies
import {
  ScriptStepType,
  type IScriptStep,
} from "@/modules/bot/types/IScriptStep";
import {
  BotEventType,
  BotLayout,
  BotPosition,
  BotTheme,
  type IBot,
} from "@/modules/bot/types/IBot";
import {
  createUserResponse,
  getBotSafePublic,
  sendBotEvent,
} from "@/modules/bot/services/BotService";
import { useWidget } from "../composables/useWidget";
// components
import MScriptStep from "@/components/basic/MScriptStep.vue";
import MLoading from "@/components/basic/MLoading.vue";
import WidgetCompleted from "../containers/WidgetCompleted.vue";
import WidgetInput from "../containers/WidgetInput.vue";
import WidgetLeftSide from "../containers/WidgetLeftSide.vue";
import WidgetErrorOccurred from "../containers/WidgetErrorOccurred.vue";
import { PlanType } from "@/modules/organization/types/IPlan";
import { useCommonStore } from "@/stores";
import { useI18n } from "vue-i18n";

export interface WidgetProps {
  id?: string;
}

const props = withDefaults(defineProps<WidgetProps>(), {
  id: "",
});

const $route = useRoute();
const isCloseIconHidden = $route.query.hideCloseIcon === "true";
const { setNotification } = useCommonStore();
const { scrollToBottom, userResponseObjectFactory } = useWidget();
const { t } = useI18n();
// fetched bot object
const bot: { data: IBot } = reactive({
  data: {
    name: "",
    script: {
      steps: [],
    },
    design: {
      theme: BotTheme.BLUE,
      position: BotPosition.MIDDLE,
      layout: BotLayout.CHAT_RIGHT,
      background: "NO_BACKGROUND",
    },
    organization: {
      name: "Organization",
    },
    hideBranding: true,
    hideOrganization: false,
  },
});

const isBrandingVisible = computed(() => {
  return !bot.data.hideBranding;
});

const isCallToActionVisible = computed(() => {
  return !bot.data.hideCta;
});

const isChatbotPageBrandingVisible = computed(() => {
  return false;
});
// array which hold user responses as string array
// we'll use this array for persist user responses
// at the end of conversation
const response: { data: { value: string; id: string }[] } = reactive({
  data: [],
});
// array which represent bot flow
// all script steps and user responses pushed in this array
const scene: { steps: IScriptStep[] } = reactive({
  steps: [],
});
// index for active step
// only count script steps, not user responses
const activeStep: Ref<number> = ref(0);
// filtered versions of scene
// which only returns script steps, not user responses
const botStepsOnly: Ref<IScriptStep[]> = computed(() =>
  scene.steps.filter(
    (step: IScriptStep) => step && typeof step.response === "undefined"
  )
);

// steps which will be skipped since logical jumps
const skips: { data: string[] } = reactive({ data: [] });

// kind of cache for bot data
// we'll rely this when user want to restart conversaiton
let fetchedBotData: IBot = bot.data;
// some logical flags
const isErrorOccurred: Ref<boolean> = ref(false);
const errorMessage = ref("");
const isLoading: Ref<boolean> = ref(false);
const isBotDataLoading: Ref<boolean> = ref(true);
const isCompleted: Ref<boolean> = ref(false);
const isBotResetBlocked: Ref<boolean> = ref(false);
// conversation restart event handler
const onRestartConversation = async function (
  refetch: boolean = false
): Promise<void> {
  if (refetch) {
    await fetchBotAndSetAssignments($route.params.id as string);
  } else {
    skips.data = [];
    // reset state to initial
    bot.data = fetchedBotData;
    response.data = [];
    scene.steps = [];
    activeStep.value = 0;
    isErrorOccurred.value = false;
    isLoading.value = false;
    isCompleted.value = false;
    // start flow
    scene.steps.push(bot.data.script.steps[activeStep.value]);
    isLoading.value = true;
  }
};

const onReset = function () {
  if (isBotResetBlocked.value) {
    return;
  }

  skips.data = [];
  isBotResetBlocked.value = true;
  // reset state to initial
  bot.data = fetchedBotData;
  response.data = [];
  scene.steps = [];
  activeStep.value = 0;
  isErrorOccurred.value = false;
  isLoading.value = false;
  isCompleted.value = false;
  // start flow
  scene.steps.push(bot.data.script.steps[activeStep.value]);
  setTimeout(() => {
    if (
      bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
    ) {
      isLoading.value = true;
    }
  }, 1000);
  setTimeout(() => {
    onNext();
    isBotResetBlocked.value = false;
  }, 1500);
};

const postMessage = function (kind: string, data?: any): void {
  if (window.top) {
    window.top.postMessage(
      JSON.stringify({
        kind,
        data,
      }),
      "*"
    );
  }
};

// script step next event handler
// only work for non-text-required steps
const onNext = function (reply: string = "") {
  let jumpTarget: string | null = null;
  let targetIndex = null;
  // does this step has reply?
  // we're checking this because it may a message which does not require any reply
  if (reply) {
    if (
      bot.data.script.steps[activeStep.value].type ===
      ScriptStepType.SINGLE_SELECT || bot.data.script.steps[activeStep.value].type ===
      ScriptStepType.YES_NO
    ) {
      const optionIndex = bot.data.script.steps[
        activeStep.value
      ].data.options.findIndex((option) => option === reply);

      if (
        typeof bot.data.script.steps[activeStep.value].data.jumps !==
          "undefined" &&
        bot.data.script.steps[activeStep.value].data.jumps.length
      ) {
        jumpTarget =
          bot.data.script.steps[activeStep.value].data.jumps[optionIndex];
        
        if (jumpTarget && jumpTarget.includes("bot:")) {
          setTimeout(() => {
            // @ts-ignore
            window.location.href = "/" + jumpTarget.split(":")[1];
          }, 1000);
        } else {
          targetIndex = bot.data.script.steps.findIndex(
            (step) => step.id === jumpTarget
          );
          const otherJumps = bot.data.script.steps[
            activeStep.value
          ].data.jumps.filter((jump) => jump !== jumpTarget);

          otherJumps.forEach((jump) => {
            bot.data.script.steps.filter((step) => step.id === jump).forEach((step) => {
              step.data.jumps.forEach((jump) => {
                if (jump) {
                  skips.data.push(jump);
                }
              });
            });
          });

          for (let i = 0; i < otherJumps.length; i++) {
            skips.data.push(otherJumps[i]);
          }
        }
      }
    }

    response.data.push({
      value: reply,
      id: bot.data.script.steps[activeStep.value].id || "",
    });

    scene.steps.push(userResponseObjectFactory(reply, scene.steps.length));
    scrollToBottom("#message-container");
    isLoading.value = true;
  }

  if (jumpTarget) {
    activeStep.value = targetIndex as number;
    calculateNextStep(true);
  } else {
    // increase active step index
    activeStep.value++;
    // calculate next step and proceed flow
    calculateNextStep();
  }
};

// script step skip event handler
const onSkip = function () {
  response.data.push({
    value: "SKIPPED",
    id: bot.data.script.steps[activeStep.value].id || "",
  });

  const currentStep = bot.data.script.steps[activeStep.value];

  if (currentStep.data.jumps) {
    for (let i = 0; i < currentStep.data.jumps.length; i++) {
      skips.data.push(bot.data.script.steps[activeStep.value].data.jumps[i]);
    }
  }

  scrollToBottom("#message-container");
  isLoading.value = true;
  activeStep.value++;
  calculateNextStep();
};

// script step text event handler
// only work for steps which manual input required
const onTextSubmit = function (message: string) {
  // set loading before next script step appear
  isLoading.value = true;
  // push text into responses array
  response.data.push({
    value: message,
    id: bot.data.script.steps[activeStep.value].id || "",
  });
  // push user response object into scene
  scene.steps.push(userResponseObjectFactory(message, scene.steps.length));
  // scroll to bottom
  scrollToBottom("#message-container");
  // increase active step
  activeStep.value++;
  // calculate next step and proceed flow
  calculateNextStep();
};

// calculate next step of bot flow
// make assignments or end flow
const calculateNextStep = function (allowSkippables: boolean = false): void {
  // skip this step if it's in skips array
  if (
    bot.data.script.steps.length > activeStep.value &&
    skips.data.includes(bot.data.script.steps[activeStep.value].id as string) &&
    !allowSkippables
  ) {
    activeStep.value++;
    calculateNextStep();
    return;
  }

  // remove loading indicator after a half second
  setTimeout(() => {
    isLoading.value = false;
  }, 500);
  // create 250ms gap between loading dissolve and new message appear transition
  setTimeout(async () => {
    // check is this end of bot flow?
    if (bot.data.script.steps.length > activeStep.value) {
      // if not
      // push next step into scene
      scene.steps.push(bot.data.script.steps[activeStep.value]);
      // scroll scene to bottom
      scrollToBottom("#message-container");

      // focus to text input if this step require manual input
      setTimeout(() => {
        if (bot.data.script.steps[activeStep.value].isManualInputAllowed) {
          document.getElementById("widget-text-input")?.focus();
        }
      }, 500);

      // if this step is a message? show loading indicator
      // because we know, if the type is message
      // m-script-step component will emit "replied" event after 500ms
      // so we need to show loading indicator till it'll emit that
      if (
        bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
      ) {
        isLoading.value = true;
      }
    } else {
      const result = await createUserResponse({
        bot: bot.data._id || "fallback_id",
        values: response.data,
      });

      if (result.isOk()) {
        isCompleted.value = true;
      } else {
        isErrorOccurred.value = true;
        errorMessage.value = t(result.error.message);
      }
    }
  }, 750);
};

const fetchBotAndSetAssignments = async function (id: string): Promise<void> {
  const botDetailResponse = await getBotSafePublic({ id });

  if (botDetailResponse.isOk()) {
    isBotDataLoading.value = false;
    mixpanel.track("view_bot", {
      id: botDetailResponse.value.payload._id,
      name: botDetailResponse.value.payload.name,
      organization: botDetailResponse.value.payload.organization.name,
    });
    if (!botDetailResponse.value.payload.isActive) {
      isErrorOccurred.value = true;
      return;
    }
    // store bot data for cache
    fetchedBotData = botDetailResponse.value.payload;
    // assign to bot state
    bot.data = botDetailResponse.value.payload;
    // push first step into scene
    scene.steps.push(bot.data.script.steps[activeStep.value]);
    // set loading flag true and start flow
    if (
      bot.data.script.steps[activeStep.value].type === ScriptStepType.MESSAGE
    ) {
      isLoading.value = true;
    }

    if (typeof bot.data.design.openerColor === "undefined") {
      bot.data.design.openerColor = "indigo";
    }

    if (typeof bot.data.design.bubbleColor === "undefined") {
      bot.data.design.bubbleColor = "indigo";
    }

    if (typeof bot.data.design.openerIcon === "undefined") {
      bot.data.design.openerIcon = "message-smile";
    }

    if (typeof bot.data.design.backgroundType === "undefined") {
      bot.data.design.backgroundType = "image";
    }
  } else {
    isErrorOccurred.value = true;
    errorMessage.value = t("widget.BOT_NOT_FOUND");
  }
};

const trackBotEvent = async function (type: BotEventType) {
  await sendBotEvent({
    bot: bot.data._id + "",
    type,
  });
};

watch(response.data, async (responses) => {
  if (responses.length === 1) {
    await trackBotEvent(BotEventType.START);
  }
});

watch(isCompleted, async (_isCompleted) => {
  if (_isCompleted) {
    await trackBotEvent(BotEventType.COMPLETED);
  }
});

onMounted(async () => {
  await fetchBotAndSetAssignments(props.id as string);
});
</script>

<style>
#message-container {
  scrollbar-gutter: stable both-edges;
}
</style>