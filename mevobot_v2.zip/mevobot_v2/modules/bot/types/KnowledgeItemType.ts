export enum KnowledgeItemType {
  PRODUCT = "PRODUCT_SERVICES",
  QUESTION = "GENERAL",
  TEXT = "TEXT",
  PROMPT = "PROMPT",
}
