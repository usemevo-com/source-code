export enum FlowEventType {
    END_FLOW = 'END_FLOW',
    PROCESS_ON_SERVER = 'PROCESS_ON_SERVER',
    SET_ACTIVE_NODE = 'SET_ACTIVE_NODE', 
    PUSH_MESSAGE = 'PUSH_MESSAGE',
    SHOW_INPUT = 'SHOW_INPUT',
    HIDE_INPUT = 'HIDE_INPUT',
    SET_INPUT_VALIDATION_RULE = 'SET_INPUT_VALIDATION_RULE',
    SEND_TO_AI = 'SEND_TO_AI',
    SHOW_OPTIONS = 'SHOW_OPTIONS'
}

export interface IFlowEvent {
    type: FlowEventType;
    payload?: any;
    meta?: {
      contentType?: 'text' | 'image';
      [key: string]: any;
    };
  }

/*
{
    type: FlowEventType.PROCESS_ON_SERVER,
    payload: {
        nodeId: "123-456-789",
        input?: 'Evet bence de öyle'
    }
}

{
    type: FlowEventType.SET_ACTIVE_NODE,
    payload: "123-456-789"
}

{
    type: FlowEventType.PUSH_MESSAGE,
    payload: "Size nasıl yardımcı olabilirim?"
}

{
    type: FlowEventType.SHOW_INPUT
}

{
    type: FlowEventType.SET_INPUT_VALIDATION_RULE,
    payload: "email"
}
*/