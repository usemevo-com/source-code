import type { IOrganization } from "@/modules/organization/types/IOrganization";
import type { IScriptStep } from "./IScriptStep";
import type { IUser } from "@/modules/prelogin/types/IUser";

export enum PreviewMode {
  POPUP = "popup",
  PAGE = "page",
  IFRAME = "iframe",
}

export enum EmbeddingType {
  TEXT = "TEXT",
  QA = "QA",
  FILE = "FILE",
  PRODUCT = "PRODUCT",
}

export enum BotTheme {
  BLUE = "blue",
  RED = "red",
  PURPLE = "purple",
  YELLOW = "yellow",
  PINK = "pink",
  INDIGO = "indigo",
}

export enum BotPosition {
  BOTTOM_RIGHT = "bottom-right",
  BOTTOM_LEFT = "bottom-left",
  MIDDLE = "center",
}

export enum BotLayout {
  CHAT_LEFT = "chat-left",
  CHAT_RIGHT = "chat-right",
  CHAT_MIDDLE = "chat-middle",
}

export enum BotBackgroundType {
  COLOR = "color",
  IMAGE = "image",
}

export enum BotEventType {
  START = "start",
  COMPLETED = "completed",
}

export enum BotType {
  SCRIPTED = "scripted",
  GPT = "gpt",
}

export interface GptFeed {
  type: string;
  data: { [key: string | number]: string }[];
}

export enum Models {
  GPT_3_5_TURBO = "gpt-3.5-turbo-1106",
  GPT_4 = "gpt-4-1106-preview",
}

export enum ChatHistory {
  ENABLED = 1,
  DISABLED = 0,
}

export interface GptSettings {
  represented: string;
  firstMessage: string;
  fallbackMessage: string;
  feed: GptFeed[];
  model: Models;
  withHistory: ChatHistory;
  showPredefinedQuestions: boolean;
  prompt: {
    systemMessage: string;
    initialMessage: string;
  };
  embeddings: {
    refs: string[];
    values: any[];
    rawText: string;
  };
  fileSources: {
    fileName: string;
  }[];
  useAssistantAPI: boolean;
  assistantID: string;
  domainSources: string[];
}

export enum ShowForm {
  NONE = "none",
  BEFORE_CHAT = "before_chat",
  IN_CHAT = "in_chat",
}

export enum NodeType {
  BOT_RESPONSE = 'bot-response',
  USER_INPUT = 'user-input',
  QUESTION = 'question',
  GO_TO_STEP = 'go-to-block',
  START = 'start',
  AI_ASSIST = 'ai-assist',
  FALLBACK = 'fallback',
  END_CONVERSATION = 'end-conversation',
}

export interface BotFlowChild {
  id: string;
  data: {
    label: string;
    id: string;
    type: NodeType;
    content: any;
  }
  type: NodeType;
  children: BotFlowChild[];
}

export type BotFlow = [BotFlowChild];

export interface IBot {
  config: {
    show_ai_indicator: boolean;
    is_survey_disabled: boolean;
  }, 
  appearance: {
    theme: BotTheme;
    position: BotPosition;
    hex: string;
    greeting: string;
    firstMessage: string;
    title: string;
    description: string;
    talkWithAgentMessage: string;
    hideBranding: boolean;
    skipWelcomePage: boolean;
    showAfterSeconds: number;
  };
  _id?: string;
  name: string;
  domain?: string;
  inputText: string;
  byText: string;
  nameLabel: string;
  emailLabel: string;
  organizationLabel: string;
  namePlaceholder: string;
  emailPlaceholder: string;
  emailReceivers: string[];
  organizationPlaceholder: string;
  leadCaptureFormTitle: string;
  leadCaptureFormDescription: string;
  formSubmitButton: string;
  inChatEmailInputTitle: string;
  inChatEmailInputDescription: string;
  inChatEmailSubmitButtonLabel: string;
  surveyMessage: string;
  surveyYes: string;
  surveyNo: string;
  surveyHuman: string;
  showForm: ShowForm;
  hiddenFormFields: string;
  showAfterSeconds: number;
  seo: {
    title: string;
    description: string;
    keywords: string;
    ogImage: string;
    favicon: string;
  };
  design: {
    openerColor: string;
    bubbleColor: string;
    openerIcon: string;
    theme: BotTheme;
    position: BotPosition;
    layout: BotLayout;
    background: string;
    backgroundColor: string;
    backgroundType: string;
    pageCustomCSS: string;
    popupCustomCSS: string;
  };
  script: {
    steps: IScriptStep[];
  };
  type: BotType;
  gptSettings: GptSettings;
  isActive?: boolean;
  createdAt?: Date;
  createdBy?: IUser;
  organization?: IOrganization;
  promptSettings: {
    systemMessage: string;
    firstMessage: string;
  };
  hideBranding: boolean;
  apiKeySet: boolean;
  hideOrganization: boolean;
  webhooks: string[];
  flow: BotFlow;
}
