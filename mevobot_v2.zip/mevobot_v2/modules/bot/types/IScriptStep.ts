export enum ScriptStepType {
  MESSAGE = "builder.MESSAGE_STEP_TYPE",
  QUESTION_TEXT = "builder.QUESTION_TEXT_STEP_TYPE",
  EMAIL = "builder.EMAIL_STEP_TYPE",
  PHONE_NUMBER = "builder.PHONE_NUMBER_STEP_TYPE",
  NUMBER = "builder.NUMBER_STEP_TYPE",
  SINGLE_SELECT = "builder.SINGLE_SELECT_STEP_TYPE",
  YES_NO = "builder.YES_NO_STEP_TYPE",
  URL = "builder.URL_STEP_TYPE",
  DATE = "builder.DATE_STEP_TYPE",
  USERNAME = "builder.USERNAME_STEP_TYPE",
  // placeholder only
  RESPONSE = "User response",
}

export interface IScriptStep {
  description?: string;
  data: {
    message: string;
    options: string[];
    jumps: string[];
  };
  id?: string;
  stepId?: string;
  type: ScriptStepType;
  isSkippable?: boolean;
  hasOption?: boolean;
  isManualInputAllowed?: boolean;
  response?: boolean;
  index?: number;
}
