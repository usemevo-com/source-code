import type { IBot } from "./IBot";

export interface IUserResponse {
  _id: string;
  values: { value: string; id: string }[];
  createdAt?: Date;
  bot?: IBot;
}
