export interface SendLeadRequest {
  name?: string;
  email: string;
  company?: string;
  bot: string;
  device_id: string;
  is_demo: boolean;
}
