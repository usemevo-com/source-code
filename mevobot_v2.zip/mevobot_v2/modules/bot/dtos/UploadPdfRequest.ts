export interface UploadPdfRequest {
  id: string;
  file: File;
}
