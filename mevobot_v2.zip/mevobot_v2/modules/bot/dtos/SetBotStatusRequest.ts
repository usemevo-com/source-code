export interface SetBotStatusRequest {
  isActive: boolean
}
