export interface RemoveBotRequest {
  id: string
}
