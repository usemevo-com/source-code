export interface GetByDomainRequest {
  domain: string;
}
