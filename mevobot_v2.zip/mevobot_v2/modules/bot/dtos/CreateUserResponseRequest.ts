export interface CreateUserResponseRequest {
  bot: string;
  values: { value: string; id: string }[];
}
