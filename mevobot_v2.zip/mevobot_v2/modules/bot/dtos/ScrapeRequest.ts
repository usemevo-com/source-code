export interface ScrapeRequest {
  domain: string;
  bot: string;
  isSinglePage: boolean;
}
