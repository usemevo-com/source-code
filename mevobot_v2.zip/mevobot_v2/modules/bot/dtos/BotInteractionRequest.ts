export interface BotInteractionRequest {
  message: string;
  sid: string;
  did: string;
  is_demo: boolean;
  human_communication_mode: boolean;
}
