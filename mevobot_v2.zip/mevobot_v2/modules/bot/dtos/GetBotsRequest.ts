export interface GetBotsRequest {
  oid: string
}
