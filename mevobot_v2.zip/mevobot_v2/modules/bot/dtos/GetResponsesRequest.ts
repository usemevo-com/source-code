export interface GetResponsesRequest {
  id: string;
  page: number;
}
