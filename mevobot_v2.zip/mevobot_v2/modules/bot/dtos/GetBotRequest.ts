export interface GetBotRequest {
  id: string
}
