import type { BotEventType } from '../types/IBot'

export interface BotEventRequest {
  type: BotEventType
  bot: string
}
