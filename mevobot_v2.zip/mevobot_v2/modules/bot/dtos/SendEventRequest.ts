import type { IFlowEvent } from "../types/IFlowEvent";

export interface SendEventRequest {
  event: IFlowEvent,
  botId: string,
  sessionId: string,
  deviceId: string,
}