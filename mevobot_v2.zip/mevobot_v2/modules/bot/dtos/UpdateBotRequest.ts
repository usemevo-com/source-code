import type {
  BotLayout,
  BotPosition,
  BotTheme,
  BotType,
  GptSettings,
} from "../types/IBot";
import type { IScriptStep } from "../types/IScriptStep";

export interface UpdateBotRequest {
  name?: string;
  design?: {
    theme: BotTheme;
    position: BotPosition;
    layout: BotLayout;
    background: string;
  };
  type?: BotType;
  gptSettings: GptSettings;
  script?: {
    steps: IScriptStep[];
  };
  isDraft?: boolean;
}
