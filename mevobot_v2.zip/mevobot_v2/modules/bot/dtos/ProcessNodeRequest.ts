export interface ProcessNodeRequest {
  nodeId: string,
  botId: string,
  sessionId: string,
  deviceId: string,
  message?: string,
  is_demo?: boolean
}