import { HTTPMethods, send, sendHTTPRequest } from "@/utils/http/request";
import type { BotEventRequest } from "../dtos/BotEventRequest";
import type { BotInteractionRequest } from "../dtos/BotInteractionRequest";
import type { CreateBotRequest } from "../dtos/CreateBotRequest";
import type { CreateUserResponseRequest } from "../dtos/CreateUserResponseRequest";
import type { GetBotRequest } from "../dtos/GetBotRequest";
import type { GetBotsRequest } from "../dtos/GetBotsRequest";
import type { GetByDomainRequest } from "../dtos/GetByDomainRequest";
import type { GetResponsesRequest } from "../dtos/GetResponsesRequest";
import type { ProcessNodeRequest } from "../dtos/ProcessNodeRequest";
import type { RemoveBotRequest } from "../dtos/RemoveBotRequest";
import type { ScrapeRequest } from "../dtos/ScrapeRequest";
import type { SendLeadRequest } from "../dtos/SendLeadRequest";
import type { SetBotStatusRequest } from "../dtos/SetBotStatusRequest";
import type { UpdateBotRequest } from "../dtos/UpdateBotRequest";
import type { UploadPdfRequest } from "../dtos/UploadPdfRequest";

export async function interact_with_chatbot_stream(
  bot_id: string,
  payload: BotInteractionRequest,
  onMessage: (chunk: { type: string; content: string }) => void,
  onComplete: (fullResponse: string) => void,
  onError: (error: string) => void
) {
  try {
    const response = await fetch(`http://localhost/api/bots/v2/${bot_id}/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    
    if (!reader) {
      throw new Error('No reader available');
    }

    let fullResponse = '';

    while (true) {
      const { done, value } = await reader.read();
      
      if (done) break;
      
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n');
      
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const data = JSON.parse(line.slice(6));
            
            if (data.type === 'text_delta') {
              onMessage(data);
              fullResponse += data.content;
            } else if (data.type === 'completed') {
              onComplete(data.content);
              return;
            } else if (data.type === 'error') {
              onError(data.error);
              return;
            }
          } catch (e) {
            // Ignore parsing errors for incomplete chunks
          }
        }
      }
    }
  } catch (error) {
    onError(error instanceof Error ? error.message : 'Unknown error');
  }
}

export async function getActiveNodeForSession(session_id: string) {
  return await send(
    HTTPMethods.GET,
    `/bots/active-node/${session_id}`
  );
}

export async function processNode(payload: ProcessNodeRequest) {
  return await send(
    HTTPMethods.POST,
    `/bots/v3/${payload.botId}/process-node`,
    {
      nodeId: payload.nodeId,
      sessionId: payload.sessionId,
      deviceId: payload.deviceId,
      message: payload.message,
      is_demo: payload.is_demo,
    }
  );
}

export async function getBots(payload: GetBotsRequest) {
  return await sendHTTPRequest(
    HTTPMethods.GET,
    `/bots?organization=${payload.oid}`
  );
}

export async function get_news(bot_id: string) {
  return await send(
    HTTPMethods.GET,
    `/bots/${bot_id}/news`
  );
}

export async function uploadPdf(payload: UploadPdfRequest) {
  return await send(
    HTTPMethods.POST,
    `/bots/pdf/${payload.id}`,
    undefined,
    undefined,
    { file: payload.file }
  );
}

export async function sendLead(payload: SendLeadRequest) {
  return await send(HTTPMethods.POST, `/leads/create/${payload.bot}`, payload);
}

export async function check_lead(payload: {
  device_id: string;
  bot_id: string;
}) {
  return await send(
    HTTPMethods.GET,
    `/leads/check?device_id=${payload.device_id}&bot_id=${payload.bot_id}`
  );
}

export async function getBot(payload: GetBotRequest) {
  return await sendHTTPRequest(HTTPMethods.GET, `/bots/${payload.id}?sr=true`);
}

export async function getBotByDomain(payload: GetByDomainRequest) {
  return await send(HTTPMethods.GET, `/bots/get-by-domain/${payload.domain}`);
}

export async function getBotSafe(payload: GetBotRequest) {
  return await send(HTTPMethods.GET, `/bots/${payload.id}`);
}

export async function getBotSafePublic(payload: GetBotRequest) {
  return await send(HTTPMethods.GET, `/bots/public/${payload.id}`);
}

export async function scrape(payload: ScrapeRequest) {
  return await send(HTTPMethods.POST, `/bots/scrape/${payload.bot}`, payload);
}

export async function getResponses(payload: GetResponsesRequest) {
  return await sendHTTPRequest(
    HTTPMethods.GET,
    `/user-responses?bot=${payload.id}&p=${payload.page}`
  );
}

export async function createUserResponse(payload: CreateUserResponseRequest) {
  return await send(HTTPMethods.POST, `/user-responses`, payload);
}
export async function createBot(payload: CreateBotRequest) {
  return await send(HTTPMethods.POST, `/bots`, payload);
}

export async function updateBot(id: string, payload: UpdateBotRequest) {
  return await send(HTTPMethods.PATCH, `/bots/${id}`, payload);
}

export async function removeBot(payload: RemoveBotRequest) {
  return await send(HTTPMethods.DELETE, `/bots/${payload.id}`);
}

export async function sendBotEvent(payload: BotEventRequest) {
  return await send(HTTPMethods.POST, `/bots/event`, payload);
}

export async function setBotStatus(id: string, payload: SetBotStatusRequest) {
  return await send(HTTPMethods.PATCH, `/bots/${id}`, payload);
}

export async function getHiddenResponseCount(id: string) {
  return await send(
    HTTPMethods.GET,
    `/user-responses/hidden-count-by-bot/${id}`
  );
}

export async function interact(id: string, payload: BotInteractionRequest) {
  return await send(HTTPMethods.POST, `/bots/interact/${id}`, payload);
}

export async function interactV2(id: string, payload: any) {
  return await send(HTTPMethods.POST, `/bots/interact-v2/${id}`, payload);
}

export async function retrieve(sid: string, bid: string) {
  return await send(HTTPMethods.POST, `/bots/retrieve`, { sid, bid });
}

export async function getSessions(
  id: string,
  page: number,
  setReaded: boolean = false
) {
  const checkedPage = typeof page === "undefined" ? 1 : page;
  return await send(
    HTTPMethods.GET,
    `/bots/sessions/${id}?p=${checkedPage}&sr=${setReaded}`
  );
}

export async function getMessages(bid: string, sid: string) {
  return await send(HTTPMethods.GET, `/bots/${bid}/messages/${sid}`);
}

export async function getResponseStats(bid: string) {
  return await send(HTTPMethods.GET, `/user-responses/response-stats/${bid}`);
}

/**
 * V2 Service Methods
 */

export async function interact_with_chatbot(
  bot_id: string,
  payload: BotInteractionRequest
) {
  return await send(HTTPMethods.POST, `/bots/v2/${bot_id}/interact`, payload);
}

export async function check_chatbot_response(
  session_id: string,
  bot_id: string,
  device_id: string,
  is_demo: boolean
) {
  return await send(HTTPMethods.POST, `/bots/v2/retrieve`, {
    sid: session_id,
    bid: bot_id,
    did: device_id,
    is_demo,
  });
}

export async function get_conversations_by_device(
  bot_id: string,
  device_id: string
) {
  return await send(
    HTTPMethods.GET,
    `/bots/v2/${bot_id}/fetch-sessions?device_id=${device_id}`
  );
}

export async function get_bot_public(bot_id: string) {
  return await send(HTTPMethods.GET, `/bots/v2/${bot_id}/public`);
}

export async function uploadResponseFile(payload: { botId: string; file: File; stepId: string; deviceId?: string }) {
  return await send(
    HTTPMethods.POST,
    `/bots/response-files/${payload.botId}`,
    { stepId: payload.stepId, deviceId: payload.deviceId },
    undefined,
    { file: payload.file }
  );
}

export async function getResponseFileUrl(payload: { id: string }) {
  return await send(HTTPMethods.GET, `/bots/response-files/${payload.id}/url`);
}
