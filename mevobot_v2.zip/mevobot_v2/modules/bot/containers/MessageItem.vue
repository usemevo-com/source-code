<template>
  <div
    class="flex items-end space-x-4 px-6"
    :class="[
      sender !== MessageSender.USER && 'justify-start',
      sender === MessageSender.USER && 'justify-end',
    ]"
  >
    <div
      v-if="sender === MessageSender.AGENT && !sender_meta.photo"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200 flex items-center justify-center"
      :class="`bg-white`"
    >
      <i class="fa fa-user text-sm text-black"></i>
    </div>
    <img
      v-if="sender === MessageSender.AGENT && sender_meta.photo"
      :src="sender_meta.photo"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200"
    />
    <img
      v-if="sender === MessageSender.AI && hasBrandImage"
      :src="image"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200"
    />
    <div
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200 bg-gray-200"
      v-if="sender !== MessageSender.AGENT && sender !== MessageSender.USER && !hasBrandImage"
    ></div>

    <div
      class="flex-1 flex flex-col"
      :class="[sender === MessageSender.USER && 'items-end ']"
    >
      <div
        class="rounded-xl px-5 py-4 w-fit text-[15px] sm:max-w-[400px]"
        :class="[
          sender === MessageSender.USER && `bg-${theme}-600 text-white`,
          sender !== MessageSender.USER && 'bg-gray-100',
        ]"
        id="message-content"
      >
        <vue-markdown :options="markdownOptions" :source="cleaned_text" :plugins="plugins" />
        <!-- <div
          v-if="urls.length"
          class="text-xs mt-2 text-gray-500 w-full flex justify-end items-center space-x-2"
        >
          <i class="fa-solid fa-paperclip text-xs"></i>
          <div>Clickables attached below.</div>
        </div> -->
      </div>
      <div class="text-xs text-gray-500 mt-1 flex space-x-2 items-center">
        <div class="bg-gray-100 w-fit px-2 py-1 rounded-lg font-medium text-gray-900" v-if="sender != MessageSender.USER && show_ai_indicator">
          {{ sender === MessageSender.AI ? 'AI' : sender_meta.name ? sender_meta.name : 'Support Team Member' }}
        </div>
        <div>{{ moment(sent_at).format("DD.MM.YYYY • hh:mm") }}</div>
      </div>
      <!-- <div class="mt-4 flex space-x-2" v-if="urls.length">
        <div
          :key="index"
          v-for="(link, index) in urls"
          class="flex items-center space-x-4 border text-sm text-gray-600 mt-2 py-2 px-3 rounded-md bg-white hover:bg-gray-100"
        >
          <div>
            <i class="fa-regular fa-external-link-alt"></i>
          </div>
          <a :href="link.url" class="underline" target="_blank">
            {{ link.title }}
          </a>
        </div>
      </div> -->
    </div>

    <div
      v-if="sender === MessageSender.USER"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200 flex items-center justify-center"
      :class="`bg-${theme}-500`"
    >
      <i class="fa fa-user text-sm text-white"></i>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from "vue";
import moment from "moment";
import VueMarkdown from "vue-markdown-render";
import MarkdownItAnchor from "markdown-it-anchor";
import { MessageSender } from "../types/MessageSender";

const plugins = [MarkdownItAnchor];
const markdownOptions = {
  breaks: true, // Convert '\n' in paragraphs into <br>
  html: true
}

interface MessageItemProps {
  text: string;
  sent_at: string;
  sender: MessageSender;
  sender_meta: { _id: string, name: string, title: string, photo: string };
  theme: string;
  image: string;
  show_ai_indicator: boolean;
}

const props = withDefaults(defineProps<MessageItemProps>(), {
  text: "",
  sent_at: "",
  sender_meta: () => ({ _id: "", name: "", title: "", photo: "" }),
  sender: MessageSender.AI,
  theme: "indigo",
  image: "",
  show_ai_indicator: false,
});

function extractURLsAndTitles(text: string): { title: string; url: string }[] {
  const markdownRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
  const results: { title: string; url: string }[] = [];

  // Markdown formatındaki linkleri işle
  let match;
  while ((match = markdownRegex.exec(text)) !== null) {
    results.push({ title: match[1], url: match[2] });
  }

  text = text.replaceAll(/【(.*)】/g, "");

  return results;
}

function replaceMarkdownLink(text: string): string {
  // const pattern = /\[.*?\]\(.*?\)/g;
  // const replacement = "*Link added below*";
  // return text.replace(pattern, replacement);

  return text;
}

const cleaned_text = ref("");
const urls = computed(() => {
  return extractURLsAndTitles(props.text);
});
const hasBrandImage = computed(
  () => props.image !== "" && props.image !== "https://placehold.co/150x150"
);

onMounted(() => {
  cleaned_text.value = replaceMarkdownLink(
    props.text.replaceAll(/【(.*)】/g, "")
  );

  setTimeout(() => {
    document.querySelectorAll("#message-content a").forEach((link) => {
      link.setAttribute("target", "_blank");
    });
  }, 500);
});
</script>

<style>
#message-content p:not(:first-of-type) {
  margin: 4px 0px 0px 0px;
}

#message-content ol {
  margin: 16px 0px 16px 0px;
}

#message-content ul {
  margin: 8px 0px 8px 0px;
}

#message-content ul > li,
#message-content ol > li {
  margin: 0px 0px 4px 0px;
}

#message-content p a {
  font-weight: 500;
  color: #0e449b;
  text-decoration: underline;
}
</style>