<template>
  <div
    v-if="
      !previous_conversations_state.is_previous_conversations_visible &&
      conversations.length
    "
    class="text-gray-500 text-sm w-full text-center py-4"
  >
    <div>
      You have {{ conversations.length }} previous conversation{{
        conversations.length > 1 ? "s" : ""
      }}
      with this chatbot
    </div>
    <div
      @click="on_show_prev_conversations"
      class="text-blue-500 underline mt-1 cursor-pointer hover:text-blue-700"
    >
      Show previous conversations
    </div>
  </div>
  <div v-else>
    <div
      :key="index"
      v-for="(conversation, index) in conversations"
      class="flex flex-col space-y-4 pb-4"
    >
      <div
        class="text-gray-500 text-sm w-full text-center py-4 flex justify-between space-x-4 items-center px-5"
      >
        <div class="flex-1 border-b border-gray-200"></div>
        <div>
          Conversation from
          {{ moment(conversation.messages[0].sent_at).fromNow() }}
        </div>
        <div class="flex-1 border-b border-gray-200"></div>
      </div>
      <message-item
        :image="image"
        :theme="theme"
        :key="index"
        :text="message.text"
        :sent_at="message.sent_at"
        :sender="message.sender"
        v-for="(message, index) in conversation.messages"
      />
    </div>
  </div>
  <div
    v-if="previous_conversations_state.is_previous_conversations_visible"
    class="text-gray-500 text-sm w-full text-center py-4 flex justify-between space-x-4 items-center px-5"
  >
    <div class="flex-1 border-b border-gray-200"></div>
    <div>Current conversation</div>
    <div class="flex-1 border-b border-gray-200"></div>
  </div>
</template>

<script lang="ts" setup>
import moment from "moment";
import { defineProps, reactive } from "vue";
import { MessageSender } from "../types/MessageSender";
import MessageItem from "./MessageItem.vue";

interface PreviousConversationsProps {
  conversations: {
    _id: string;
    messages: {
      text: string;
      sent_at: string;
      sender: MessageSender;
    }[];
  };
  image: string;
  theme: string;
}

interface PreviousConversationState {
  is_previous_conversations_visible: boolean;
}

defineProps<PreviousConversationsProps>();

const previous_conversations_state: PreviousConversationState = reactive({
  is_previous_conversations_visible: false,
});

const on_show_prev_conversations = () => {
  previous_conversations_state.is_previous_conversations_visible = true;
};
</script>
