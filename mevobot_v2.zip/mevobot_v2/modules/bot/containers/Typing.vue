<template>
  <div class="flex items-end px-6 space-x-4 justify-start">
    <img
      v-if="image && image !== 'https://placehold.co/150x150'"
      :src="image"
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200"
    />
    <div
      class="w-8 h-8 rounded-lg mb-2 border border-gray-200 bg-gray-200 flex-shrink-0"
      v-else
    ></div>

    <div class="flex-1 flex flex-col">
      <div
        class="rounded-xl bg-gray-100 px-5 py-4 w-fit text-sm"
        id="message-content"
      >
        <i class="fa fa-spinner-third animate-spin text-md text-gray-300"></i>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, defineProps } from "vue";

const props = defineProps({
  image: String,
});
</script>
