<template>
    <div
      class="flex items-end space-x-4 px-4"
      :class="[
        sender !== MessageSender.USER && 'justify-start',
        sender === MessageSender.USER && 'justify-end',
      ]"
    >
      <div
        v-if="sender === MessageSender.AGENT && !sender_meta.photo && showMetadata"
        class="w-8 h-8 rounded-lg border border-gray-200 flex items-center justify-center"
        :class="`bg-white`"
      >
        <i class="fa fa-user text-sm text-black"></i>
      </div>
      <img
        v-if="sender === MessageSender.AGENT && sender_meta.photo && showMetadata"
        :src="sender_meta.photo"
        class="w-8 h-8 rounded-lg border border-gray-200"
      />
      <img
        v-if="sender === MessageSender.AI && hasBrandImage && showMetadata && !imageLoadError"
        :src="image"
        class="w-8 h-8 rounded-lg border-gray-200"
        @error="imageLoadError = true"
      />
      <div
        class="w-8 h-8 rounded-lg border border-gray-200 bg-gray-200"
        v-if="imageLoadError"
      ></div>
      <div
        class="flex-1 flex flex-col"
        :class="[sender === MessageSender.USER && 'items-end', (!isLastMessage && hasBrandImage) && 'ml-12']"
      >
        <div
          class="rounded-xl w-fit text-[14px] sm:max-w-[400px] antialiased"
          :class="[
            sender === MessageSender.USER && !hex && `bg-${theme}-600 text-white`,
            sender !== MessageSender.USER && 'bg-gray-100',
            message.type !== 'image' && 'px-4 py-2'
          ]"
          :style="{ backgroundColor: sender === MessageSender.USER && hex ? theme : undefined, color: sender === MessageSender.USER && hex ? 'white' : undefined }"
          id="message-content"
        >
          <div v-if="message.type === 'image'">
            <img
              :src="message.text"
              alt="Uploaded image"
              class="rounded-lg max-w-full max-h-[300px] object-contain"
              @error="imageLoadError = true"
            />
          </div>
          <vue-markdown v-if="message.type !== 'image'" :options="markdownOptions" :source="cleaned_text" :plugins="plugins" />
          <div v-if="streaming && !cleaned_text.length" class="flex items-center space-x-2">
            <!-- <Sparkle :style="{ color: hex ? theme : undefined }" class="w-4 h-4 icon-spin" />  -->
            <span class="text-sm antialised">Thinking<span class="thinking-dots"></span></span>
          </div>
        </div>
        <div v-if="options.length && isLastMessage" class="mt-2 flex gap-2 flex-wrap">
          <div
            @click="handleOptionClick(option)"
            v-for="(option, index) in options"
            :key="index"
            :style="{ backgroundColor: lightColor, color: primaryColor, borderColor: lightColor }"
            class="cursor-pointer border px-2 py-1 rounded-lg antialiased text-sm flex items-center space-x-2"
          >
          <div>{{ option }}</div>
          <ArrowRight :size="12" class="text-mevo" />
          </div>
        </div>
        <div
          v-if="showYesNoInput && isLastMessage"
          class="mt-2 flex gap-2 flex-wrap"
        >
          <div
            v-for="(option, index) in yesNoOptions"
            :key="index"
            @click="handleOptionClick(option)"
            :style="{ backgroundColor: lightColor, color: primaryColor, borderColor: lightColor }"
            class="cursor-pointer border px-3 py-1 rounded-lg antialiased text-sm flex items-center space-x-2"
          >
            <div>{{ option }}</div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script lang="ts" setup>
  import { ArrowRight } from "lucide-vue-next";
import MarkdownItAnchor from "markdown-it-anchor";
import { onMounted, ref } from "vue";
import VueMarkdown from "vue-markdown-render";
import { MessageSender } from "../types/MessageSender";

  const plugins = [MarkdownItAnchor];
  const markdownOptions = {
    breaks: true, // Convert '\n' in paragraphs into <br>
    html: true
  }
  
  interface MessageItemProps {
    text: string;
    sent_at: string;
    sender: MessageSender;
    sender_meta: { _id: string, name: string, title: string, photo: string };
    theme: string;
    image: string;
    show_ai_indicator: boolean;
    showMetadata?: boolean;
    streaming?: boolean;
    hex?: boolean;
    message: any;
    isLastMessage: boolean;
    primaryColor: string;
    lightColor: string;
    showYesNoInput?: boolean;
    yesNoOptions?: string[];
  }
  
  const props = withDefaults(defineProps<MessageItemProps>(), {
    text: "",
    sent_at: "",
    sender_meta: () => ({ _id: "", name: "", title: "", photo: "" }),
    sender: MessageSender.AI,
    theme: "indigo",
    image: "",
    show_ai_indicator: false,
    showMetadata: false,
    streaming: false,
    hex: false,
    message: () => ({}),
    isLastMessage: false,
    primaryColor: "#3834FF",
    lightColor: "#F0F0FF",
    showYesNoInput: false,
    yesNoOptions: () => ['Yes', 'No']
  });
  
  const emit = defineEmits([
    'option-click'
  ]);

  function handleOptionClick(option: string) {
    // If it's a select-number type, find the corresponding value
    if (selectNumberOptions.value.length > 0) {
      const selectedOption = selectNumberOptions.value.find(opt => opt.label === option);
      if (selectedOption) {
        // Emit both label and value for select-number
        emit('option-click', {
          label: selectedOption.label,
          value: String(selectedOption.value),
          isSelectNumber: true
        });
      } else {
        emit('option-click', option);
      }
    } else {
      emit('option-click', option);
    }
    options.value = [];
  }

  function extractURLsAndTitles(text: string): { title: string; url: string }[] {
    const markdownRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
    const results: { title: string; url: string }[] = [];
  
    // Markdown formatındaki linkleri işle
    let match;
    while ((match = markdownRegex.exec(text)) !== null) {
      results.push({ title: match[1], url: match[2] });
    }
  
    text = text.replaceAll(/【(.*)】/g, "");
  
    return results;
  }
  
  function replaceMarkdownLink(text: string): string {
    // const pattern = /\[.*?\]\(.*?\)/g;
    // const replacement = "*Link added below*";
    // return text.replace(pattern, replacement);
  
    return text;
  }
  
  const cleaned_text = ref("");
  const options = ref([]);
  const selectNumberOptions = ref([]);
  const imageLoadError = ref(false);
  const urls = computed(() => {
    return extractURLsAndTitles(props.text);
  });
  const hasBrandImage = computed(
    () => props.image !== "" && props.image !== "https://placehold.co/150x150"
  );
  
  onMounted(() => {
    let baseText = props.text.replaceAll(/【(.*)】/g, "");

    const parts = baseText.split('__MEVO__');
    cleaned_text.value = replaceMarkdownLink(parts[0]);

    try {
      const parsedData = JSON.parse(parts[1]);
      
      // Check if it's select-number type with options array
      if (parsedData && typeof parsedData === 'object' && parsedData.type === 'select-number' && Array.isArray(parsedData.options)) {
        // Store the original options with label/value pairs for later use
        selectNumberOptions.value = parsedData.options;
        // Display only the labels as options
        options.value = parsedData.options.map(opt => opt.label);
      } else {
        // Legacy format: array of strings
        options.value = Array.isArray(parsedData) ? parsedData : [];
        selectNumberOptions.value = [];
      }
    } catch (e) {
      options.value = [];
      selectNumberOptions.value = [];
    }

    setTimeout(() => {
      document.querySelectorAll("#message-content a").forEach((link) => {
        link.setAttribute("target", "_blank");
      });
    }, 500);
  });
  </script>
  
  <style>
  #message-content p:not(:first-of-type) {
    margin: 4px 0px 0px 0px;
  }
  
  #message-content ol {
    margin: 16px 0px 16px 0px;
  }
  
  #message-content ul {
    margin: 8px 0px 8px 0px;
  }
  
  #message-content ul > li,
  #message-content ol > li {
    margin: 0px 0px 4px 0px;
  }
  
  #message-content p a {
    font-weight: 500;
    color: #0e449b;
    text-decoration: underline;
  }
  
  .thinking-dots {
    animation: thinking 1.2s infinite;
    display: inline-block;
  }
  
  @keyframes thinking {
    0% { content: "."; }
    33% { content: ".."; }
    66% { content: "..."; }
    100% { content: ""; }
  }
  
  .thinking-dots::after {
    content: "";
    animation: thinking-content 1.2s infinite;
  }
  
  @keyframes thinking-content {
    0%, 25% { content: "."; }
    26%, 50% { content: ".."; }
    51%, 75% { content: "..."; }
    76%, 100% { content: ""; }
  }
  </style>
  