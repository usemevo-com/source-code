const animate = require("tailwindcss-animate");

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  safelist: [
    "text-[#81868d]",
    "text-[#3834FF]",
    "hover:text-[#81868d]",
    "hover:text-blue-500",
    "dark",
    "text-center",
    "text-blue-500",
    "underline",
    "bg-[#f8fafd]",
    "my-5",
    "rounded-2xl",
    "mx-4",
    "ml-12",
    {
      pattern:
        /bg-(gray|red|blue|green|yellow|indigo|purple|pink|amber|purple)-(100|200|300|400|500|600|700)/,
    },
    {
      pattern:
        /hover:bg-(gray|red|blue|green|yellow|indigo|purple|pink|amber|purple)-(100|200|300|400|500|600|700)/,
    },
    {
      pattern: /rounded-(xl)/,
    },
    {
      pattern: /px-(1|2|3|4|5)/,
    },
    {
      pattern: /py-(1|2|3|4|5)/,
    },
    {
      pattern: /mt-(1|2|3|4|5)/,
    },
    {
      pattern:
        /from-(gray|red|blue|green|yellow|indigo|purple|pink|amber|purple)-900/,
    },
    {
      pattern:
        /via-(gray|red|blue|green|yellow|indigo|purple|pink|amber|purple)-500/,
    },
    {
      pattern:
        /to-(gray|red|blue|green|yellow|indigo|purple|pink|amber|purple)-100/,
    },
  ],
  prefix: "",
  content: [
    "./components/**/*.{js,vue,ts}",
    "./layouts/**/*.vue",
    "./pages/**/*.vue",
    "./plugins/**/*.{js,ts}",
    "./app.vue",
    "./error.vue",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      fontFamily: {
        sans: ["EuclidCircularA", "sans-serif"],
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        xl: "calc(var(--radius) + 4px)",
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
        "collapsible-down": {
          from: { height: 0 },
          to: { height: "var(--radix-collapsible-content-height)" },
        },
        "collapsible-up": {
          from: { height: "var(--radix-collapsible-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "collapsible-down": "collapsible-down 0.2s ease-in-out",
        "collapsible-up": "collapsible-up 0.2s ease-in-out",
      },
    },
  },
  plugins: [animate],
};
