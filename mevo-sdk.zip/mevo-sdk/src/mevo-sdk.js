(function () {
  window.mevo = window.mevo || {};
  var target = "https://app.v3.usemevo.com";
  var botRoot = "https://bot.usemevo.com";

  var icons = {};

  var closeIcon =
    '<svg style="width:35px; height: 35px;" xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><style>svg{fill:#ffffff}</style><path d="M192 233.4L59.5 100.9 36.9 123.5 169.4 256 36.9 388.5l22.6 22.6L192 278.6 324.5 411.1l22.6-22.6L214.6 256 347.1 123.5l-22.6-22.6L192 233.4z"/></svg>';

  mevo.init = function (bid, t) {
    mevo.isChatboxOpen = false;
    mevo.bid = bid;
    mevo.t = t;
    // check is bot active or not
    _healthCheck(bid).then(function (botData) {
      if (botData) {
        mevo.bot = botData.bot;

        icons = {
          "message-smile": `<svg style="width:35px; height:28px; margin-top: 2px;" fill="${
            mevo.bot.appearance.theme
          }" xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><defs><style>.fa-secondary{opacity:1;fill:#ffffff;}.fa-primary{fill:transparent;}</style></defs><path class="fa-primary" d="M224 144a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm128 0a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM184.4 240c-8.8-9.9-24-10.7-33.9-1.9s-10.7 24-1.9 33.9c26.3 29.4 64.7 48 107.3 48s81-18.6 107.3-48c8.8-9.9 8-25-1.9-33.9s-25-8-33.9 1.9c-17.6 19.7-43.1 32-71.6 32s-53.9-12.3-71.6-32z"/><path class="fa-secondary" d="M0 64C0 28.7 28.7 0 64 0H448c35.3 0 64 28.7 64 64V352c0 35.3-28.7 64-64 64H309.3L185.6 508.8c-4.8 3.6-11.3 4.2-16.8 1.5s-8.8-8.2-8.8-14.3V416H64c-35.3 0-64-28.7-64-64V64zM192 176a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm128 0a32 32 0 1 0 0-64 32 32 0 1 0 0 64zM150.5 238.1c-9.9 8.8-10.7 24-1.9 33.9c26.3 29.4 64.7 48 107.3 48s81-18.6 107.3-48c8.8-9.9 8-25-1.9-33.9s-25-8-33.9 1.9c-17.6 19.7-43.1 32-71.6 32s-53.9-12.3-71.6-32c-8.8-9.9-24-10.7-33.9-1.9z"/></svg>`,
          message: `<svg xmlns="http://www.w3.org/2000/svg" height="1em" style="width:25px; height:20px; margin-top: 2px;" fill="${
            mevo.bot.appearance.theme
          }" viewBox="0 0 512 512"><!--!Font Awesome Pro 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc.--><path d="M512 0H0V416H160v96l144-96H512V0z"/></svg>`,
          comments: `<svg xmlns="http://www.w3.org/2000/svg" height="1em" style="width:25px; height:20px; margin-top: -2px;" fill="${
            mevo.bot.appearance.theme
          }" viewBox="0 0 640 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M208 352c114.9 0 208-78.8 208-176S322.9 0 208 0S0 78.8 0 176c0 38.6 14.7 74.3 39.6 103.4c-3.5 9.4-8.7 17.7-14.2 24.7c-4.8 6.2-9.7 11-13.3 14.3c-1.8 1.6-3.3 2.9-4.3 3.7c-.5 .4-.9 .7-1.1 .8l-.2 .2 0 0 0 0C1 327.2-1.4 334.4 .8 340.9S9.1 352 16 352c21.8 0 43.8-5.6 62.1-12.5c9.2-3.5 17.8-7.4 25.3-11.4C134.1 343.3 169.8 352 208 352zM448 176c0 112.3-99.1 196.9-216.5 207C255.8 457.4 336.4 512 432 512c38.2 0 73.9-8.7 104.7-23.9c7.5 4 16 7.9 25.2 11.4c18.3 6.9 40.3 12.5 62.1 12.5c6.9 0 13.1-4.5 15.2-11.1c2.1-6.6-.2-13.8-5.8-17.9l0 0 0 0-.2-.2c-.2-.2-.6-.4-1.1-.8c-1-.8-2.5-2-4.3-3.7c-3.6-3.3-8.5-8.1-13.3-14.3c-5.5-7-10.7-15.4-14.2-24.7c24.9-29 39.6-64.7 39.6-103.4c0-92.8-84.9-168.9-192.6-175.5c.4 5.1 .6 10.3 .6 15.5z"/></svg>`,
          "message-bot": `<svg xmlns="http://www.w3.org/2000/svg" height="1em" style="width:25px; height:20px; margin-top: 2px;" fill="${
            mevo.bot.appearance.theme
          }" viewBox="0 0 640 512"><!--!Font Awesome Pro 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc.--><path d="M160 0C124.7 0 96 28.7 96 64V176H59.7c-5.5-9.6-15.9-16-27.7-16c-17.7 0-32 14.3-32 32s14.3 32 32 32c11.8 0 22.2-6.4 27.7-16H96V352c0 35.3 28.7 64 64 64h64v80c0 6.1 3.4 11.6 8.8 14.3s11.9 2.1 16.8-1.5L373.3 416H480c35.3 0 64-28.7 64-64V208h36.3c5.5 9.6 15.9 16 27.7 16c17.7 0 32-14.3 32-32s-14.3-32-32-32c-11.8 0-22.2 6.4-27.7 16H544V64c0-35.3-28.7-64-64-64H160zm0 128c0-17.7 14.3-32 32-32H448c17.7 0 32 14.3 32 32V256c0 17.7-14.3 32-32 32H192c-17.7 0-32-14.3-32-32V128zm64 96a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm192 0a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"/></svg>`,
          "seal-question": `<svg xmlns="http://www.w3.org/2000/svg" height="1em" style="width:25px; height:25px;" fill="${
            mevo.bot.appearance.theme
          }" viewBox="0 0 512 512"><!--!Font Awesome Pro 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc.--><path d="M222.1 17.9c18.7-18.7 49.1-18.7 67.9 0L336 64l64 0c26.5 0 48 21.5 48 48l0 64 45.6 45.6c18.7 18.7 18.7 49.1 0 67.9L448 335.1l0 64.9c0 26.5-21.5 48-48 48l-64.9 0-45.1 45.1c-18.7 18.7-49.1 18.7-67.9 0L176.9 448 112 448c-26.5 0-48-21.5-48-48l0-64.9L18.4 289.5c-18.7-18.7-18.7-49.1 0-67.9L64 176l0-64c0-26.5 21.5-48 48-48l64 0 46.1-46.1zM169.8 165.3l-.4 1.2c-4.4 12.5 2.1 26.2 14.6 30.6s26.2-2.1 30.6-14.6l.4-1.2c1.1-3.2 4.2-5.3 7.5-5.3l58.3 0c8.4 0 15.1 6.8 15.1 15.1c0 5.4-2.9 10.4-7.6 13.1l-44.3 25.4c-7.5 4.3-12.1 12.2-12.1 20.8l0 13.5c0 13.3 10.7 24 24 24c13.1 0 23.8-10.5 24-23.6l32.3-18.5c19.6-11.3 31.7-32.2 31.7-54.8c0-34.9-28.3-63.1-63.1-63.1l-58.3 0c-23.7 0-44.8 14.9-52.8 37.3zM288 352a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"/></svg>`,
        };

        _injectChatbox();
        _injectEventListeners();
        _revokeLastState();
        _injectStyles();

        if (
          typeof mevo.bot.appearance.showAfterSeconds !== "undefined" &&
          mevo.bot.appearance.showAfterSeconds !== 0
        ) {
          setTimeout(() => {
            if (!mevo.isChatboxOpen) {
              _toggleChatbox();
            }
          }, mevo.bot.appearance.showAfterSeconds * 1000);
        }
      } else {
        console.info("MEVO: Your chatbot status set as disabled on dashboard.");
      }
    });
  };

  function _healthCheck(bid) {
    return new Promise((resolve) => {
      try {
        fetch(target + "/api/bots/v2/" + bid + "/public").then(function (
          response
        ) {
          response
            .json()
            .then((responseJson) => {
              if (response && response.ok) {
                resolve(responseJson);
              }
              resolve(false);
            })
            .catch((error) => {
              resolve(false);
            });
        });
      } catch (error) {
        resolve(false);
      }
    });
  }

  function _injectStyles() {
    var style = document.createElement("style");
    style.innerHTML =
      "#mevo_chatbox_opener { color: white; !important; background-color: " + mevo.bot.appearance.theme + " !important; " +
      (mevo.bot.appearance.position === "bottom-right"
        ? "right: 20px;"
        : "left: 20px;") +
      " box-shadow: 0 1px 6px 0 rgb(0 0 0 / 6%), 0 2px 32px 0 rgb(0 0 0 / 16%); display: flex; justify-content: center; align-items: center; width: 60px; height: 60px; background-color: " + mevo.bot.appearance.theme + "; border-radius: 100%; position: fixed; bottom: 20px; color: #e0e7ff; cursor: pointer; z-index:9000;}";
    style.innerHTML +=
      "#mevo_chatbox_opener.mevo_dot::after { width: 14px; height: 14px; border-radius: 50%; background-color: #6366f1; content: ''; position: absolute; right: 0px; bottom: 0px; }";
    style.innerHTML +=
      "#mevo_chatbox_iframe { " +
      (mevo.bot.appearance.position === "bottom-right"
        ? "right: 20px;"
        : "left: 20px;") +
      "  border:none !important; box-shadow: 0 1px 6px 0 rgb(0 0 0 / 6%), 0 2px 32px 0 rgb(0 0 0 / 16%); display:none; border-radius: 10px; height:600px;width:400px;position:fixed; bottom:30px;bottom:100px;z-index:502;}";
    style.innerHTML +=
      "@media screen and (max-height: 774px) { #mevo_chatbox_iframe { " +
      (mevo.bot.appearance.position === "bottom-right"
        ? "right: 20px;"
        : "left: 20px;") +
      "  border:none !important; box-shadow: 0 1px 6px 0 rgb(0 0 0 / 6%), 0 2px 32px 0 rgb(0 0 0 / 16%); display:none; border-radius: 10px; height:575px;width:400px;position:fixed; bottom:30px;bottom:100px;z-index:502;}}";
    style.innerHTML +=
      "@keyframes fadeInAnimation { 0% { opacity: 0; } 100% { opacity: 1; } }";
    style.innerHTML +=
      "@keyframes fadeOutAnimation { 0% { opacity: 1; } 100% { opacity: 0; } }";
    style.innerHTML +=
      "@keyframes chatbox-opener-intro { 0% { opacity: 0; transform: scale(0.5); } 100% { opacity: 1; transform: scale(1);} }";
    style.innerHTML +=
      "@keyframes fadeOutAnimation { 0% { opacity: 1; } 100% { opacity: 0; } }";
    style.innerHTML +=
      "#mevo_chatbox_iframe { animation-iteration-count: 1; animation-fill-mode: forwards; }";
    style.innerHTML +=
      "@media screen and (max-width: 768px) { #mevo_chatbox_opener { right: 16px; bottom: 16px; } #mevo_chatbox_opener.open { right: 16px; top: 10px; background: transparent; box-shadow: none; }}";
    style.innerHTML +=
      "@media screen and (max-width: 768px) { #mevo_chatbox_iframe { z-index: 9999; left: 0; right: 0; top: 0; bottom: 0; height: 100vh; height: -webkit-fill-available; width: 100vw; position: fixed; border: 0; border-radius: 0; }}";
    style.innerHTML +=
      ".mevo_animation_fade_in { animation: fadeInAnimation ease 0.25s; }";
    style.innerHTML +=
      ".mevo_animation_fade_out { animation: fadeOutAnimation ease 0.25s; }";
    // style.innerHTML += mevo.bot.design.popupCustomCSS;
    document.head.appendChild(style);
  }

  window.addEventListener(
    "message",
    (event) => {
      try {
        var data = JSON.parse(event.data);
        if (data.kind === "chatbox-closed") {
          _toggleChatbox();
        }
      } catch (e) {
        console.error("[MEVO] Unable to parse message", event.data);
      }
    },
    false
  );

  function _injectChatbox(botData) {
    var wrapper = document.createElement("div");
    wrapper.id = "mevo_wrapper";
    wrapper.style.display = "none";
    wrapper.innerHTML +=
      '<div id="mevo_chatbox_opener">' +
      icons["message-smile"] +
      "</div>" +
      '<iframe src="' +
      botRoot +
      "/" +
      mevo.bid +
      '?show_close=1" id="mevo_chatbox_iframe"></iframe>';
    document.body.appendChild(wrapper);
    wrapper.querySelector("#mevo_chatbox_iframe").onload = _iframeOnLoad;

    document.querySelector("#mevo_wrapper").style.display = "block";
  }

  function _injectEventListeners() {
    var chatboxOpener = document.querySelector("#mevo_chatbox_opener");

    chatboxOpener.addEventListener("click", function () {
      _toggleChatbox();
    });
  }

  function _toggleChatbox(botData) {
    var chatboxOpener = document.querySelector("#mevo_chatbox_opener");
    var chatbox = document.querySelector("#mevo_chatbox_iframe");

    if (mevo.isChatboxOpen) {
      chatbox.classList.add("mevo_animation_fade_out");
      chatbox.classList.remove("mevo_animation_fade_in");
      setTimeout(function () {
        chatbox.style.display = "none";
      }, 251);
      chatboxOpener.innerHTML = icons["message-smile"];
    } else {
      chatbox.classList.remove("mevo_animation_fade_out");
      chatbox.classList.add("mevo_animation_fade_in");
      chatboxOpener.classList.remove("mevo_dot");
      chatbox.style.display = "block";
      chatboxOpener.innerHTML = closeIcon;
    }

    // if (mevo.isChatboxOpen) {
    //   chatboxOpener.classList.remove('open');
    // }

    mevo.isChatboxOpen = !mevo.isChatboxOpen;
    sessionStorage.setItem(
      "_mevo_chatbox_state",
      mevo.isChatboxOpen ? "open" : "closed"
    );
  }

  function _revokeLastState() {
    if (sessionStorage.getItem("_mevo_chatbox_state") === "open") {
      _toggleChatbox();
      var chatboxOpener = document.querySelector("#mevo_chatbox_opener");
      chatboxOpener.innerHTML = closeIcon;
    }
  }

  function _iframeOnLoad() {
    var chatbox = document.querySelector("#mevo_chatbox_iframe");

    if (mevo.isChatboxOpen) {
      chatbox.style.display = "block";
      chatbox.classList.add("mevo_animation_fade_in");
    }
  }

  function _sendMessage(message) {
    if (!mevo.isChatboxOpen) _toggleChatbox();
    if (mevo_chatbox_iframe.src.indexOf("conversation") === -1) {
      mevo_chatbox_iframe.src =
        botRoot + "/" + mevo.bid + "/conversation?message=" + message;
    } else {
      mevo_chatbox_iframe.contentWindow.postMessage(
        JSON.stringify({ kind: "user-message", data: message }),
        "*"
      );
    }
  }

  var bid =
    document.currentScript && document.currentScript.getAttribute("bid");
  var t = document.currentScript && document.currentScript.getAttribute("t");
  if (bid) {
    window.addEventListener("load", function () {
      mevo.init(bid, t);
    });
  }

  window.mevo.sendMessage = _sendMessage;
  window.mevo.toggleChatbot = _toggleChatbox;
})();
