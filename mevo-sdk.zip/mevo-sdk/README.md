# Mevo - Web SDK - usemevo.com

This is the web sdk repository of Mevo.

[![MIT License](https://img.shields.io/apm/l/atomic-design-ui.svg?)](https://github.com/robogon/mevo-sdk/blob/master/LICENSE.md)

## Installation

Paste the integration snippet to your main html file.

```javascript
<script src="//cdn.usemevo.com/mevo-sdk.min.js" bid="{BOT_ID}" async></script>
```

You are ready to go.

## Feedback

Contact us by hi@usemevo.com if you have any feedback.

## Contribution

We're always open to contributions. Don't be shy to open a PR.
