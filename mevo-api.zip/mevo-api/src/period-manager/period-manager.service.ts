import mongoose, { Model } from "mongoose";
import { Injectable, Logger } from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { HttpService } from "@nestjs/axios";
import { Cron, CronExpression } from "@nestjs/schedule";
import { PlanType, SubscriptionType } from "../organizations/entities/plan";
import { SubscriptionsService } from "../subscriptions/subscriptions.service";
import { firstValueFrom } from "rxjs";
import { ApifyClient } from "apify-client";
import { ConfigService } from "@nestjs/config";
import {
  Secret,
  SecretDocument,
  SecretKey,
} from "src/organizations/entities/secret.schema";
import { Organization } from "src/organizations/entities/organization.schema";
import { send_telegram_notification } from "src/common/helpers/telegram-notifier";

@Injectable()
export class PeriodManagerService {
  private readonly logger = new Logger(PeriodManagerService.name);

  constructor(
    private subscriptionsService: SubscriptionsService,
    private configService: ConfigService,
    private readonly httpService: HttpService,
    @InjectModel(Secret.name)
    private secretModel: Model<SecretDocument>,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

  private formatDate(input: string | Date): string {
    const date = new Date(input);

    const pad = (num) => num.toString().padStart(2, '0');

    const day = pad(date.getDate());
    const month = pad(date.getMonth() + 1);
    const year = date.getFullYear();

    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());

    return `${day}.${month}.${year} - ${hours}:${minutes}`;
  }

  private async createAndAssignPeriod(organization: Organization, plan: PlanType) {
    // organization._id string'e çevrilmeli
    const newPeriod = await this.subscriptionsService.createPeriod(
      organization._id.toString(),
      plan
    );


    // old period info
    const oldPeriod = await this.connection
      .collection("periods")
      .findOne({ _id: organization.activePeriod });

    await this.connection.collection("organizations").updateOne(
      { _id: organization._id },
      {
        $set: {
          activePeriod: newPeriod._id,
          plan,
          subscriptionCancelled: false,
          monthlyTokenUsage: 0
        },
      }
    );

    this.logger.debug(
      `Created new period (${newPeriod._id}) and updated organization (${organization._id})`
    );

    return newPeriod;
  }

  @Cron(CronExpression.EVERY_10_SECONDS)
  async handleCron() {
    this.logger.debug(`Period manager started...`);

    /**
     * We should find all organizations that have expired periods and update their active period to a new one.
     *
     * We should only update period for the organizations have non-paid plans or paid plans with cancelled subscriptions. Because paid
     * subscriptsions will be updated by the payment service when the payment is made.
     */
    const expiredOrganizations = await this.connection
      .collection("organizations")
      .aggregate([
        {
          $match: {
            isRemoved: {
              $ne: true,
            },
            $or: [
              {
                plan: {
                  $nin: [
                    PlanType.PRO,
                    PlanType.PRO_NEW,
                    PlanType.LITE_NEW,
                    PlanType.MAX_NEW,
                  ],
                },
              },
              {
                $and: [
                  {
                    subscriptionCancelled: {
                      $ne: false,
                    },
                  },
                  {
                    subscriptionCancelled: {
                      $exists: true,
                    },
                  },
                ],
              },
            ],
          },
        },
        {
          $lookup: {
            from: "periods",
            localField: "activePeriod",
            foreignField: "_id",
            as: "period",
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "admins",
            foreignField: "_id",
            as: "admin_users",
          },
        },
        {
          $match: {
            "period.end": {
              $lt: new Date(),
            },
          },
        },
      ])
      .toArray();

    this.logger.debug(
      `Found ${expiredOrganizations.length} expired organizations.`
    );

    for (const organization of expiredOrganizations) {
      let plan;

      if (organization.subscriptionCancelled) {
        plan = PlanType.BASIC;
      } else {
        plan = organization.plan;
      }

      await this.createAndAssignPeriod(organization as Organization, plan);
    }


    // THIS IS NOT ABOUT PERIOD MANAGER, 
    // THIS IS ABOUT AVAILABILITY CHECKER FOR APIFY
    // WE SHOULD CREATE SEPARATE CRON SERVICE FOR THIS

    // check if there is any active run on Apify
    // if there is no active run, set the availability to 32768
    const apifyClient = new ApifyClient({
      token: this.configService.get<string>("APIFY_TOKEN"),
    });

    const runs = await apifyClient
      .actor("apify/website-content-crawler")
      .runs()
      .list();

    const activeRuns = runs.items.filter((run) => run.status === "RUNNING");

    if (!activeRuns.length) {
      await this.secretModel
        .findOneAndUpdate(
          {
            key: SecretKey.AVAILABILITY,
          },
          {
            value: 32768,
          }
        )
        .exec();
    }
  }
}
