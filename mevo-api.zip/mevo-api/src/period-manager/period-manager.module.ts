import { Module, forwardRef } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { PeriodManagerService } from "./period-manager.service";
import { OrganizationsModule } from "../organizations/organizations.module";
import { Period, PeriodSchema } from "../subscriptions/entities/period.schema";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { SubscriptionsModule } from "../subscriptions/subscriptions.module";
import { HttpModule } from "@nestjs/axios";
import { Secret, SecretSchema } from "src/organizations/entities/secret.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Organization.name, schema: OrganizationSchema },
      { name: Period.name, schema: PeriodSchema },
      { name: Secret.name, schema: SecretSchema },
    ]),
    forwardRef(() => OrganizationsModule),
    forwardRef(() => SubscriptionsModule),
    HttpModule,
  ],
  providers: [PeriodManagerService],
})
export class PeriodManagerModule {}
