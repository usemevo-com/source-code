import * as request from 'supertest'
import { Test } from '@nestjs/testing'
import { INestApplication, ValidationPipe } from '@nestjs/common'
import { Model } from 'mongoose'
import { getModelToken } from '@nestjs/mongoose'
import { AppModule } from '../../app.module'
import { Bot, BotDocument } from '../../bots/entities/bot.schema'
import { UserResponse, UserResponseDocument } from '../entities/user-response.schema'
import { getToken } from '../../common/helpers/get-token'
import { User, UserDocument } from '../../users/entities/user.schema'
import { Organization, OrganizationDocument } from '../../organizations/entities/organization.schema'

let app: INestApplication
let userResponseModel: Model<UserResponseDocument>
let botModel: Model<BotDocument>
let userModel: Model<UserDocument>
let organizationModel: Model<OrganizationDocument>
let createdUserResponse
let createdOrganization
let createdOrganization2
let createdOrganization3
let createdBot
let authToken
let authUser
let user1
let user2
let bot1
let bot2

beforeAll(async () => {
  const moduleRef = await Test.createTestingModule({
    providers: [
      {
        provide: getModelToken(UserResponse.name),
        useValue: Model,
      },
      {
        provide: getModelToken(Bot.name),
        useValue: Model,
      },
      {
        provide: getModelToken(User.name),
        useValue: Model,
      },
      {
        provide: getModelToken(Organization.name),
        useValue: Model,
      },
    ],
    imports: [AppModule],
  }).compile()

  // clear organizations collection
  userResponseModel = moduleRef.get<Model<UserResponseDocument>>(getModelToken(UserResponse.name))
  await userResponseModel.deleteMany({})

  // clear bots collection
  botModel = moduleRef.get<Model<BotDocument>>(getModelToken(Bot.name))
  await botModel.deleteMany({})

  // clear users collection
  userModel = moduleRef.get<Model<UserDocument>>(getModelToken(User.name))
  await userModel.deleteMany({})

  organizationModel = moduleRef.get<Model<OrganizationDocument>>(getModelToken(Organization.name))
  await organizationModel.deleteMany({})

  // start app instance
  app = moduleRef.createNestApplication()
  app.useGlobalPipes(new ValidationPipe())
  await app.init()

  const auth = await getToken(request(app.getHttpServer()), 'user@gmail.com')
  authToken = auth.token
  authUser = auth.user

  user1 = await getToken(request(app.getHttpServer()), 'user1_1@gmail.com')
  user2 = await getToken(request(app.getHttpServer()), 'user2_2@gmail.com')

  createdOrganization = await new organizationModel({
    name: 'Organization',
    admins: [authUser._id],
  }).save()

  createdOrganization2 = await new organizationModel({
    name: 'org2',
    admins: [user1.user._id],
    users: [user2.user._id],
  }).save()

  createdOrganization3 = await new organizationModel({
    name: 'org3',
    admins: [],
    users: [],
  }).save()

  // create a bot
  createdBot = await new botModel({
    name: 'Bot',
    design: {
      theme: 'red',
      position: 'left-mid',
      layout: 'chat-left',
      background: 'background-1.jpg',
    },
    script: {
      steps: [
        {
          type: 'text',
          message: 'wyn?',
          required: false,
          options: [],
        },
        {
          type: 'single-choice',
          message: 'r y mrd?',
          required: false,
          options: ['yes', 'no'],
        },
      ],
    },
    organization: createdOrganization._id,
  }).save()

  // create a bot
  bot1 = await new botModel({
    name: 'Bot1',
    design: {
      theme: 'red',
      position: 'left-mid',
      layout: 'chat-left',
      background: 'background-1.jpg',
    },
    script: {
      steps: [
        {
          type: 'text',
          message: 'wyn?',
          required: false,
          options: [],
        },
        {
          type: 'single-choice',
          message: 'r y mrd?',
          required: false,
          options: ['yes', 'no'],
        },
      ],
    },
    organization: createdOrganization2._id,
  }).save()

  // create a bot
  bot2 = await new botModel({
    name: 'Bot2',
    design: {
      theme: 'red',
      position: 'left-mid',
      layout: 'chat-left',
      background: 'background-1.jpg',
    },
    script: {
      steps: [
        {
          type: 'text',
          message: 'wyn?',
          required: false,
          options: [],
        },
        {
          type: 'single-choice',
          message: 'r y mrd?',
          required: false,
          options: ['yes', 'no'],
        },
      ],
    },
    organization: createdOrganization3._id,
  }).save()
})

describe('try to get all user responses for a bot', () => {
  test(`should get empty array`, () => {
    return request(app.getHttpServer()).get(`/user-responses?bot=${createdBot._id}`).expect(401)
  })

  test(`should get empty array`, () => {
    return request(app.getHttpServer())
      .get(`/user-responses?bot=${createdBot._id}`)
      .set('Cookie', `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(response.body.length).toEqual(0)
      })
  })
})

describe('try to create an user response for a bot', () => {
  test(`should return validation error while trying with incorrect body`, () => {
    return request(app.getHttpServer())
      .post(`/user-responses`)
      .set('Cookie', `Authentication=${authToken}`)
      .send({})
      .expect(400)
  })

  test(`should return bot not found error`, () => {
    return request(app.getHttpServer())
      .post('/user-responses')
      .set('Cookie', `Authentication=${authToken}`)
      .send({ bot: '111111111111111111111111', values: ['answer'] })
      .expect(404)
  })

  test(`should return bot id required error`, () => {
    return request(app.getHttpServer())
      .post('/bots')
      .set('Cookie', `Authentication=${authToken}`)
      .send({ values: ['answer'] })
      .expect(400)
  })

  test(`should return values required error`, () => {
    return request(app.getHttpServer())
      .post('/bots')
      .set('Cookie', `Authentication=${authToken}`)
      .send({ bot: createdBot._id })
      .expect(400)
  })

  test(`should create answer`, () => {
    return request(app.getHttpServer())
      .post(`/user-responses`)
      .set('Cookie', `Authentication=${authToken}`)
      .send({
        bot: createdBot._id,
        values: ['evet', 'hayir'],
      })
      .expect(201)
      .then((response) => {
        createdUserResponse = response.body
      })
  })

  test(`should return bot not found error`, () => {
    return request(app.getHttpServer())
      .get(`/user-responses?bot=111111111111111111111111`)
      .set('Cookie', `Authentication=${authToken}`)
      .expect(404)
  })

  test(`verify user response created for this bot`, () => {
    return request(app.getHttpServer())
      .get(`/user-responses?bot=${createdBot._id}`)
      .set('Cookie', `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(response.body.length).toEqual(1)
      })
  })
})

describe('test authorization', () => {
  it('should return 200 while try to access responses of bot 1 with user 1 as admin of organization', () => {
    return request(app.getHttpServer())
      .get(`/user-responses?bot=${bot1._id}`)
      .set('Cookie', `Authentication=${user1.token}`)
      .expect(200)
  })

  it('should return 200 while try to access responses of bot 1 with user 2 as user of organization', () => {
    return request(app.getHttpServer())
      .get(`/user-responses?bot=${bot1._id}`)
      .set('Cookie', `Authentication=${user2.token}`)
      .expect(200)
  })

  it('should return 403 while try to access responses of bot 2 from the out of organization', () => {
    return request(app.getHttpServer())
      .get(`/user-responses?bot=${bot2._id}`)
      .set('Cookie', `Authentication=${user1.token}`)
      .expect(403)
  })
})

afterAll(async () => {
  // clear collections
  await userResponseModel.deleteMany({})
  await botModel.deleteMany({})
  await userModel.deleteMany({})
  await organizationModel.deleteMany({})
  // close app
  await app.close()
})
