import { MongooseModule } from "@nestjs/mongoose";
import { Module, forwardRef } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { UserResponsesService } from "./user-responses.service";
import { UserResponsesController } from "./user-responses.controller";
import {
  UserResponse,
  UserResponseSchema,
} from "./entities/user-response.schema";
import { Bot, BotSchema } from "../bots/entities/bot.schema";
import { BotsModule } from "../bots/bots.module";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { Period, PeriodSchema } from "../subscriptions/entities/period.schema";
import { User, UserSchema } from "src/users/entities/user.schema";
import { NotificationReceiver, NotificationReceiverSchema } from "src/bots/entities/notification-receiver.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserResponse.name, schema: UserResponseSchema },
      { name: Bot.name, schema: BotSchema },
      { name: Organization.name, schema: OrganizationSchema },
      { name: Period.name, schema: PeriodSchema },
      { name: User.name, schema: UserSchema },
      { name: NotificationReceiver.name, schema: NotificationReceiverSchema },
    ]),
    forwardRef(() => BotsModule),
    HttpModule,
  ],
  controllers: [UserResponsesController],
  providers: [UserResponsesService],
  exports: [UserResponsesService],
})
export class UserResponsesModule {}
