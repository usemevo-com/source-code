import {
  Controller,
  Get,
  Post,
  Body,
  Query,
  Req,
  ForbiddenException,
  Res,
  Param,
  UseGuards,
} from "@nestjs/common";
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { UserResponsesService } from "./user-responses.service";
import { CreateUserResponseDto } from "./dto/create-user-response.dto";
import { isObjectIdPipe } from "../common/pipes/isObjectIdPipe";
import { Public } from "../auth/helpers/is-public";
import { Bot } from "../bots/entities/bot.schema";
import { UserResponse } from "./entities/user-response.schema";
import { hasAdminAccess, hasUserAccess } from "../auth/helpers/has-access";
import RequestWithUser from "../auth/interfaces/request-with-user";
import { BotsService } from "../bots/bots.service";
import { Throttle, minutes } from "@nestjs/throttler";

@ApiBearerAuth()
@ApiTags("user-responses")
@Controller("user-responses")
export class UserResponsesController {
  constructor(
    private readonly userResponsesService: UserResponsesService,
    private readonly botsService: BotsService
  ) {}

  // @Throttle({ default: { limit: 2, ttl: minutes(5) } })
  @Public()
  @Post()
  create(@Body() createUserResponseDto: CreateUserResponseDto, @Req() req) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const clientIp = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;
    return this.userResponsesService.create(
      createUserResponseDto,
      clientIp,
      req.headers["user-agent"]
    );
  }

  @Get()
  async findAll(
    @Query("bot", new isObjectIdPipe()) _id: string,
    @Query("csv") csv: boolean,
    @Query("p") page: number,
    @Req() request: RequestWithUser,
    @Res() response
  ) {
    const bot: Bot = await this.botsService.findOne({
      _id,
    });

    const pageNumber = csv ? 0 : page;
    const result = await this.userResponsesService.findAll(
      {
        bot: bot._id,
      },
      pageNumber
    );

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      if (csv) {
        let csvOutput = "";

        if (result.responses.length) {
          const headers = result.responses[0].values.map(({ id }) => {
            const {
              data: { message },
            } = bot.script.steps.find((step) => step.id === id);
            return message;
          });
          csvOutput = `${headers.join(",")}\n`;

          const lines = result.responses.map(({ values }) =>
            values.map(({ value }) => value).join(",")
          );
          csvOutput += `${lines.join("\n")}\n`;
        }

        response.setHeader("Content-Type", "text/csv");
        response.setHeader(
          "Content-Disposition",
          'attachment; filename="mevo-export.csv"'
        );
        response.send(csvOutput);
      } else {
        response.send(result);
      }
    }

    throw new ForbiddenException();
  }

  @Get("count/:organization")
  async count(@Param("organization", new isObjectIdPipe()) oid: string) {
    return this.userResponsesService.count(oid);
  }

  @Get("hidden-count/:organization")
  async hiddenCount(@Param("organization", new isObjectIdPipe()) oid: string) {
    return this.userResponsesService.count(oid, true);
  }

  @Get("hidden-count-by-bot/:bot")
  async hiddenCountByBot(@Param("bot", new isObjectIdPipe()) bid: string) {
    return this.userResponsesService.countHiddenResponsesByBot(bid);
  }

  @Get("response-stats/:bot")
  async responseStats(
    @Param("bot", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot: Bot = await this.botsService.findOne({
      _id,
    });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.userResponsesService.results(bot._id);
    }
  }
}
