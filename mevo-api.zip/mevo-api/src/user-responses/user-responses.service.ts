import { google, Auth } from "googleapis";
import mongoose, { Model } from "mongoose";
import { catchError, firstValueFrom } from "rxjs";
import * as geoip from "geoip-lite";
import * as UAParser from "ua-parser-js";
import { HttpService } from "@nestjs/axios";
import { AxiosError } from "axios";
import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { CreateUserResponseDto } from "./dto/create-user-response.dto";
import {
  BuilderStepType,
  UserResponse,
  UserResponseDocument,
} from "./entities/user-response.schema";
import { Bot, BotDocument } from "../bots/entities/bot.schema";
import { HttpResponseWithMessage } from "../common/helpers/response";
import { PlanType, Plans } from "../organizations/entities/plan";
import {
  Organization,
  OrganizationDocument,
} from "../organizations/entities/organization.schema";
import { NotificationReceiver, NotificationReceiverDocument, NotificationType } from "src/bots/entities/notification-receiver.schema";
import { sendTemplateMail } from "../common/helpers/send-mail";
import {
  Period,
  PeriodDocument,
} from "../subscriptions/entities/period.schema";
import { BotType } from "../bots/entities/bot-type";
import { User, UserDocument } from "src/users/entities/user.schema";
import { ConfigService } from "@nestjs/config";

@Injectable()
export class UserResponsesService {
  oauthClient: Auth.OAuth2Client;
  
  constructor(
    private readonly configService: ConfigService,
    private readonly httpService: HttpService,
    @InjectModel(UserResponse.name)
    private userResponseModel: Model<UserResponseDocument>,
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Period.name)
    private periodModel: Model<PeriodDocument>,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
    @InjectModel(User.name)
    private userModel: Model<UserDocument>,
    @InjectModel(NotificationReceiver.name)
    private notificationReceiverModel: Model<NotificationReceiverDocument>,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {
    const clientID = this.configService.get("GOOGLE_AUTH_CLIENT_ID");
    const clientSecret = this.configService.get("GOOGLE_AUTH_CLIENT_SECRET");
    const redirectURL = this.configService.get("GOOGLE_AUTH_REDIRECT_URL");
  
    this.oauthClient = new google.auth.OAuth2(clientID, clientSecret, redirectURL);
  }

  formatDate(input) {
    const date = new Date(input);

    const pad = (num) => num.toString().padStart(2, '0');

    const day = pad(date.getDate());
    const month = pad(date.getMonth() + 1);
    const year = date.getFullYear();

    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());

    return `${day}.${month}.${year} - ${hours}:${minutes}`;
  }

  async create(
    createUserResponseDto: CreateUserResponseDto,
    ip: string,
    userAgent: string
  ): Promise<Boolean> {
    // STEP 1: Check if the bot exists
    const bot = await this.botModel
      .findOne({
        $and: [
          { _id: createUserResponseDto.bot },
          { isRemoved: { $ne: true } },
        ],
      })
      .exec();

    // return 404 if bot not found
    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    // STEP 2: Get active period for the organization chatbot belongs to
    const organization = await this.organizationModel
      .findById(bot.organization._id)
      .exec();

    const period = await this.periodModel
      .findById(organization.activePeriod)
      .exec();

    // STEP 3: check the submissions count for the current ip address in the last hour
    const responsesCountFromThisIP = await this.userResponseModel
      .countDocuments({
        bot: createUserResponseDto.bot,
        ip,
        createdAt: { $gte: Date.now() - 3600000 },
      })
      .exec();

    // return 429 if the limit is reached (2 responses in 1 hour)
    if (responsesCountFromThisIP > 2) {
      throw new HttpException(
        "response.WAIT_1_HOUR_BEFORE_SENDING_ANOTHER_RESPONSE",
        HttpStatus.TOO_MANY_REQUESTS
      );
    }

    // STEP 4: check the plan limits for submissions, and set the submission hidden if the limit is reached
    if (period.submission_usage >= Plans[bot.organization.plan].limits.response)
      createUserResponseDto.isHidden = true;

    // STEP 5: build submission content for notification
    let responseContent = "";
    let responsesHookArr = [];

    bot.script.steps.forEach((question) => {
      // Check if the question has a response
      const response = createUserResponseDto.values.find(
        (resp) => resp.id === question.id
      );

      // If a response exists, create the Q&A string
      if (response) {
        responsesHookArr.push({
          question: question.data.message.replace(/<\/?[^>]+(>|$)/g, ""),
          answer: response.value,
        });
      }
    });

    // STEP 6: build recipients list for email notification
    let recipients = [];

    const hasNotificationPreferenceSet =
      typeof organization.sendEmailNotificationsToAdmins !== "undefined";

    // if organization admin notification preference is set
    // send organization admins into recipients list
    if (
      !hasNotificationPreferenceSet ||
      (hasNotificationPreferenceSet &&
        organization.sendEmailNotificationsToAdmins)
    ) {
      recipients = [...organization.admins];
    } else {
      console.log("No notification will be sent for this response.");
    }

    // This is a legacy feature, but we keep it for backward compatibility
    if (bot.emailReceivers) {
      const recipientUsers = await this.userModel.find({
        _id: {
          $in: bot.emailReceivers,
        },
      });

      recipientUsers.forEach((user) => {
        recipients.push({
          name: user.name,
          email: user.email,
        });
      });
    }

    // STEP 7: Get email notification receivers
    const emailNotificationReceivers = await this.notificationReceiverModel.find({
      bot: bot._id,
      type: NotificationType.EMAIL
    })

    emailNotificationReceivers.forEach((receiver: NotificationReceiver) => {
      recipients.push({
        name: receiver.payload.name,
        email: receiver.payload.email,
      });
    });

    recipients.forEach((user: { name: string, email: string }) => {
      sendTemplateMail("response-received", user.email, {
        name: user.name.split(" ")[0],
        organization: organization.name,
        bot: bot.name,
        content: responsesHookArr,
      });
    });

    // STEP 8: Update the organization's last notification sent date
    organization.lastNotificationSentAt = new Date();
    await organization.save();

    // STEP 9: Persist the user response
    createUserResponseDto.ip = ip;
    const ua = new UAParser(userAgent).getResult();

    // save response
    const createdUserResponse = new this.userResponseModel({
      ...createUserResponseDto,
      geo: geoip.lookup(ip),
      device: {
        os: ua.os.name,
        browser: ua.browser.name + " v" + ua.browser.version,
        device: ua.device.vendor,
      },
    });
    await createdUserResponse.save();

    // STEP 10: Set bot unread 
    bot.unread = true;
    await bot.save();

    // STEP 11: Send webhook notifications
    const webhookNotificationReceivers = await this.notificationReceiverModel.find({
      bot: bot._id,
      type: NotificationType.WEBHOOK
    })

    // build the payload for webhook notifications
    const payload = { content: JSON.stringify(responsesHookArr) };

    // if organization level webhook is set
    try {
      if (organization.webhookURL && organization.plan !== PlanType.BASIC) {
        await firstValueFrom(
          this.httpService.post(organization.webhookURL, payload).pipe(
            catchError((error: AxiosError) => {
              throw error;                                                    
            })
          )
        );
      }
    } catch (error) {
      console.log("Error sending webhook notification: ", error);
    }

    // send webhook notifications to all bot specific receivers
    // this is a legacy feature, but we keep it for backward compatibility
    try {
      if (
        bot.webhooks.length &&
        Plans[organization.plan].limits.chatbotSpecificWebhooks
      ) {
        for (const webhookUrl of bot.webhooks) {
          await firstValueFrom(
            this.httpService
              .post(webhookUrl, payload)
              .pipe(
                catchError((error: AxiosError) => {
                  throw error;
                })
              )
          );
        }
      }
    } catch (err) {
      console.log("Error sending webhook notification: ", err);
    }

    if (Plans[organization.plan].limits.chatbotSpecificWebhooks && webhookNotificationReceivers.length) {
      // send webhook notifications to all receivers
      webhookNotificationReceivers.forEach((receiver: NotificationReceiver) => {
        try {
          firstValueFrom(
            this.httpService
              .post(receiver.payload.url, payload)
              .pipe(
                catchError((error: AxiosError) => {
                  console.log("Error sending webhook notification: ", error.message);
                  throw error;
                })
              )
          );
        } catch (err) {
          console.log("Error sending webhook notification: ", err);
        }
      });
    }

    // STEP 12: increment usage submissions count for period
    await this.periodModel.findOneAndUpdate(
      { _id: organization.activePeriod._id },
      { $inc: { submission_usage: 1 } }
    );

    // STEP 13: add payload into spreadsheet as a row
    if (bot.googleSpreadsheetId) {
      this.oauthClient.setCredentials({ refresh_token: bot.googleRefreshToken });

      const { token: accessToken } = await this.oauthClient.getAccessToken();
      const sheets = google.sheets({ version: 'v4', auth: this.oauthClient });

      // add headers if the sheet is empty
      const sheetRows = await sheets.spreadsheets.values.get({
        spreadsheetId: bot.googleSpreadsheetId,
        range: 'Sheet1!A:A',
      });

      if (!sheetRows.data.values) {
        await sheets.spreadsheets.values.append({
          spreadsheetId: bot.googleSpreadsheetId,
          range: 'Sheet1!A1',
          valueInputOption: 'USER_ENTERED',
          insertDataOption: 'INSERT_ROWS',
          requestBody: {
            values: [
              [
                'Submission date', 
                ...JSON.parse(payload.content).map((item) => item.question),
                'Location',
                'Platform'
              ],
            ]
          },
        })
      }

      // add the response to the sheet
      await sheets.spreadsheets.values.append({
        spreadsheetId: bot.googleSpreadsheetId,
        range: 'Sheet1!A2',
        valueInputOption: 'USER_ENTERED',
        insertDataOption: 'INSERT_ROWS',
        requestBody: {
          values: [
            [
              this.formatDate(new Date().toISOString()),
              ...JSON.parse(payload.content).map((item) => item.answer),
              geoip.lookup(ip) ? geoip.lookup(ip).city + ' ' + geoip.lookup(ip).country : "N/A",
              ua ? (ua.browser.name + " v" + ua.browser.version + " on " + ua.os.name) : "N/A",
            ],
          ]
        },
      });
    }

    return true;
  }

  async findAll(
    condition: { [key: string]: any },
    page: number = 1
  ): Promise<{ count: number; responses: UserResponse[] }> {
    const pageSize = 5;

    if (typeof condition.bot !== "undefined") {
      const bot = await this.botModel
        .findOne({
          $and: [{ _id: condition.bot }, { isRemoved: { $ne: true } }],
        })
        .exec();

      if (!bot) {
        throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
      }
    }

    const count = await this.userResponseModel
      .countDocuments({
        $and: [
          condition,
          { isRemoved: { $ne: true } },
          { isHidden: { $ne: true } },
        ],
      })
      .exec();

    const responses = await this.userResponseModel
      .find({
        $and: [
          condition,
          { isRemoved: { $ne: true } },
          { isHidden: { $ne: true } },
        ],
      })
      .sort({ createdAt: -1 })
      .skip(page === 0 ? null : (page - 1) * pageSize)
      .limit(page === 0 ? null : pageSize)
      .exec();

    return { count, responses };
  }

  async results(bot: string) {
    // find the bot
    const botResult: Bot = await this.botModel.findById(bot).exec();

    const botResponses: UserResponse[] = await this.userResponseModel.find({
      bot,
    });

    if (botResult.type === BotType.GPT) {
      return "INVALID_BOT_TYPE";
    }

    if (typeof botResult.script.steps === "undefined") {
      return {
        stats: [],
      };
    }

    const steps = botResult.script.steps;
    const stats = [];

    steps.forEach((step) => {
      if (step.type === BuilderStepType.SINGLE_STEP) {
        const counts = [];

        for (let i = 0; i < step.data.options.length; i++) {
          counts.push(0);
        }

        stats.push({
          q: step.data.message,
          id: step.id,
          options: step.data.options,
          counts,
        });
      }
    });

    botResponses.forEach((response) => {
      response.values.forEach((value) => {
        const statIndex = stats.findIndex((stat) => stat.id === value.id);

        if (statIndex > -1) {
          const index = stats[statIndex].options.findIndex(
            (option) => option === value.value
          );

          if (index !== -1) {
            stats[statIndex].counts[index] += 1;
          }
        }
      });
    });

    return {
      stats,
    };
  }

  async remove(condition: { [key: string]: any }) {
    const userResponse = await this.userResponseModel
      .findOneAndUpdate(
        {
          $and: [
            condition,
            { isRemoved: { $ne: true }, isHidden: { $ne: true } },
          ],
        },
        { isRemoved: true },
        { new: true }
      )
      .exec();

    if (!userResponse) {
      throw new HttpException("response.NOT_FOUND", HttpStatus.NOT_FOUND);
    } else {
      return HttpResponseWithMessage("response.REMOVED", 200);
    }
  }

  async count(organization: string, isHidden: boolean = false) {
    const countResult = await this.connection
      .collection("bots")
      .aggregate([
        {
          $match: {
            $and: [
              {
                organization: new mongoose.Types.ObjectId(organization),
              },
              {
                isRemoved: {
                  $ne: true,
                },
              },
            ],
          },
        },
        {
          $lookup: {
            from: "userresponses",
            localField: "_id",
            foreignField: "bot",
            as: "matchedResponses",
          },
        },
        {
          $unwind: {
            path: "$matchedResponses",
          },
        },
        {
          $match: {
            "matchedResponses.isHidden": {
              $ne: !isHidden,
            },
            "matchedResponses.isRemoved": {
              $ne: true,
            },
          },
        },
        {
          $count: "count",
        },
      ])
      .toArray();

    if (!countResult.length) return 0;
    else return countResult[0].count;
  }

  async countHiddenResponsesByBot(bot: string) {
    const countResult = await this.connection
      .collection("bots")
      .aggregate([
        {
          $match: {
            $and: [
              {
                _id: new mongoose.Types.ObjectId(bot),
              },
              {
                isRemoved: {
                  $ne: true,
                },
              },
            ],
          },
        },
        {
          $lookup: {
            from: "userresponses",
            localField: "_id",
            foreignField: "bot",
            as: "matchedResponses",
          },
        },
        {
          $unwind: {
            path: "$matchedResponses",
          },
        },
        {
          $match: {
            "matchedResponses.isHidden": {
              $ne: false,
            },
          },
        },
        {
          $count: "count",
        },
      ])
      .toArray();

    if (!countResult.length) return 0;
    else return countResult[0].count;
  }

  async removeMany(
    condition: { [key: string]: any },
    session: mongoose.ClientSession | null = null
  ) {
    return this.userResponseModel
      .updateMany(condition, { isRemoved: true })
      .session(session)
      .exec();
  }
}
