import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "../../bots/entities/bot.schema";

export type UserResponseDocument = HydratedDocument<UserResponse>;

export enum BuilderStepType {
  SINGLE_STEP = "builder.SINGLE_SELECT_STEP_TYPE",
}
@Schema({
  timestamps: true,
})
export class UserResponse {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true })
  values: { value: string; id: string }[];

  @Prop({ default: false })
  isRemoved: boolean;

  @Prop({ default: false })
  isHidden: boolean;

  @Prop({ default: false, required: true })
  ip: string;

  @Prop({ required: false, type: Object })
  geo: Object;

  @Prop({ required: false, type: Object })
  device: Object;

  createdAt: number;
}

export const UserResponseSchema = SchemaFactory.createForClass(UserResponse);
