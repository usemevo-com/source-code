import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";
import { Bot } from "../../bots/entities/bot.schema";

export class CreateUserResponseDto {
  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  bot: Bot;

  @IsNotEmpty()
  @ApiProperty({ type: "array" })
  values: { value: string; id: string }[];

  isHidden?: boolean;

  ip?: string;
}
