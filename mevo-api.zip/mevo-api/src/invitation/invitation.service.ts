import { Injectable, NotFoundException } from "@nestjs/common";
import mongoose, { Model } from "mongoose";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { Invitation, InvitationDocument } from "./entities/invitation.schema";
import {
  Organization,
  OrganizationDocument,
} from "../organizations/entities/organization.schema";
import { User } from "../users/entities/user.schema";
import { sendTemplateMail } from "../common/helpers/send-mail";
import { AcceptInvitationDto } from "./dto/accept-invitation";

@Injectable()
export class InvitationService {
  constructor(
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Invitation.name)
    private invitationModel: Model<InvitationDocument>,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

  async acceptInvitation(acceptInvitationDto: AcceptInvitationDto, user: User) {
    // check if invitation exists by code and email
    const invitation = await this.invitationModel
      .findOne({
        $and: [{ code: acceptInvitationDto.code }, { email: user.email }],
      })
      .exec();

    if (!invitation) throw new NotFoundException("invitations.NOT_FOUND");

    // check if organization exists
    const organization = await this.organizationModel
      .findOne({
        $and: [{ _id: invitation.organization }, { isRemoved: { $ne: true } }],
      })
      .exec();

    if (!organization) throw new NotFoundException("organizations.NOT_FOUND");

    // check if user is already in organization
    const userCheck = organization.users.find((u) => u.email === user.email);
    if (userCheck)
      throw new NotFoundException("invitations.USER_ALREADY_IN_ORG");

    const adminCheck = organization.admins.find((a) => a.email === user.email);
    if (adminCheck)
      throw new NotFoundException("invitations.ADMIN_ALREADY_IN_ORG");

    // add user to organization
    const session = await this.connection.startSession();
    session.startTransaction();

    try {
      // add user to organization
      const pushObject = {};
      pushObject[invitation.role + "s"] = user._id;
      await this.organizationModel
        .findOneAndUpdate(
          {
            $and: [{ _id: organization._id }, { isRemoved: { $ne: true } }],
          },
          {
            $push: pushObject,
          },
          {
            new: true,
          }
        )
        .session(session)
        .exec();

      // delete invitation
      await this.invitationModel
        .findOneAndDelete({
          $and: [{ code: acceptInvitationDto.code }, { email: user.email }],
        })
        .session(session)
        .exec();

      await session.commitTransaction();
      session.endSession();

      organization.admins.forEach((admin) => {
        sendTemplateMail("invitation-accepted", admin.email, {
          organization: organization.name,
          name: user.name,
        });
      });

      return true;
    } catch (error) {
      await session.abortTransaction();
      session.endSession();

      throw error;
    }
  }
}
