import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Organization } from "../../organizations/entities/organization.schema";

export type InvitationDocument = HydratedDocument<Invitation>;
export enum Role {
  ADMIN = "admin",
  USER = "user",
  LISTENER = "listener",
}

@Schema({
  timestamps: true,
})
export class Invitation {
  _id: string;

  @Prop({ required: true })
  email: string;

  @Prop({ required: true })
  code: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
    autopopulate: {
      select: "name domain plan admins users",
    },
  })
  organization: Organization;

  @Prop({ required: false, enum: Role })
  role: string;
}

export const InvitationSchema = SchemaFactory.createForClass(Invitation);
