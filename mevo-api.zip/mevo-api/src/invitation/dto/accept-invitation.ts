import { ApiProperty } from '@nestjs/swagger'
import { IsNotEmpty } from 'class-validator'

export class AcceptInvitationDto {
  @IsNotEmpty()
  @ApiProperty({ type: 'string', required: true })
  code: string
}
