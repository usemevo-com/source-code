import { Module } from '@nestjs/common'
import { InvitationController } from './invitation.controller'
import { InvitationService } from './invitation.service'
import { MongooseModule } from '@nestjs/mongoose'
import { Invitation, InvitationSchema } from './entities/invitation.schema'
import { Organization, OrganizationSchema } from '../organizations/entities/organization.schema'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Invitation.name, schema: InvitationSchema },
      { name: Organization.name, schema: OrganizationSchema },
    ]),
  ],
  controllers: [InvitationController],
  providers: [InvitationService],
  exports: [InvitationService],
})
export class InvitationModule {}
