import { Body, Controller, Post, Req } from '@nestjs/common'
import RequestWithUser from '../auth/interfaces/request-with-user'
import { AcceptInvitationDto } from './dto/accept-invitation'
import { InvitationService } from './invitation.service'
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger'

@ApiBearerAuth()
@ApiTags('invitations')
@Controller('invitations')
export class InvitationController {
  constructor(private readonly invitationService: InvitationService) {}

  @Post('accept')
  async acceptInvitation(@Body() acceptInvitationDto: AcceptInvitationDto, @Req() request: RequestWithUser) {
    return this.invitationService.acceptInvitation(acceptInvitationDto, request.user)
  }
}
