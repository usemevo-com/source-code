import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";
import { AddOn } from "../../organizations/entities/plan";

export class BuyAddOnDto {
  @IsNotEmpty()
  @ApiProperty({ type: "string", enum: AddOn, required: true })
  addOn: AddOn;
}
