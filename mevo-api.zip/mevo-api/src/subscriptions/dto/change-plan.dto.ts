import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";
import { PlanType, SubscriptionType } from "../../organizations/entities/plan";

export class ChangePlanDto {
  @IsNotEmpty()
  @ApiProperty({ type: "string", enum: PlanType, required: true })
  plan: PlanType;

  @IsNotEmpty()
  @ApiProperty({ type: "string", enum: SubscriptionType, required: true })
  subscriptionType: SubscriptionType;

  @ApiProperty({ type: "string", required: false })
  affiliate_referrer: string;
}
