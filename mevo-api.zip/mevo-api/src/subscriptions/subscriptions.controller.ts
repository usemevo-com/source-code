import {
  Body,
  Controller,
  RawBodyRequest,
  Param,
  Post,
  Req,
  Get,
  Query,
  ForbiddenException,
} from "@nestjs/common";
import { SubscriptionsService } from "./subscriptions.service";
import { ChangePlanDto } from "./dto/change-plan.dto";
import RequestWithUser from "../auth/interfaces/request-with-user";
import { Public } from "../auth/helpers/is-public";
import { BuyAddOnDto } from "./dto/buy-add-on.dto";

@Controller("subscriptions")
export class SubscriptionsController {
  constructor(private readonly subscriptionsService: SubscriptionsService) {}

  @Post("plan/change/:organization")
  async changePlan(
    @Body() body: ChangePlanDto,
    @Param("organization") organizationId: string,
    @Req() request: RequestWithUser
  ) {
    const { plan, subscriptionType } = body;
    const result = await this.subscriptionsService.changePlan(
      plan,
      organizationId,
      request.user,
      subscriptionType,
      body.affiliate_referrer
    );
    return result;
  }

  @Post("buy-add-on/:organization")
  async buyAddOn(
    @Body() body: BuyAddOnDto,
    @Param("organization") organizationId: string,
    @Req() request: RequestWithUser
  ) {
    const { addOn } = body;
    const result = await this.subscriptionsService.buyAddOn(
      addOn,
      organizationId
    );
    return result;
  }

  @Post("cancel-add-on/:organization")
  async cancelAddOn(
    @Body() body: BuyAddOnDto,
    @Param("organization") organizationId: string,
    @Req() request: RequestWithUser
  ) {
    const { addOn } = body;
    const result = await this.subscriptionsService.cancelAddOn(
      addOn,
      organizationId
    );
    return result;
  }

  @Public()
  @Post("webhook")
  async webhook(@Req() request: RawBodyRequest<Request>, @Body() body) {
    console.log(body);
    const result = this.subscriptionsService.handleWebHook(
      request.rawBody,
      (request.headers as any)["stripe-signature"]
    );
    return result;
  }

  @Post("billing-management-url/:organization")
  async getBillingManagementUrl(@Param("organization") organizationId: string) {
    const result = await this.subscriptionsService.getBillingManagementUrl(
      organizationId
    );
    return result;
  }

  // @Public()
  // @Get("generate-product-keys")
  // async generateProductKeys(
  //   @Req() request: RequestWithUser,
  //   @Query("amount") amount: number,
  //   @Query("vendor") vendor: string = "appsumo"
  // ) {
  //   // const requestUser = request.user;

  //   // if (requestUser.email !== "frknbasaran@gmail.com") {
  //   //   throw new ForbiddenException();
  //   // }

  //   if (!amount) {
  //     return new ForbiddenException("Amount is required");
  //   }

  //   return this.subscriptionsService.generateProductKeys(amount, vendor);
  // }
}
