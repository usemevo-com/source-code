import { Module, forwardRef } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { SubscriptionsService } from "./subscriptions.service";
import { SubscriptionsController } from "./subscriptions.controller";
import { OrganizationsModule } from "../organizations/organizations.module";
import { MongooseModule } from "@nestjs/mongoose";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { Bot, BotSchema } from "../bots/entities/bot.schema";
import {
  UserResponse,
  UserResponseSchema,
} from "../user-responses/entities/user-response.schema";
import { Period, PeriodSchema } from "./entities/period.schema";
import { ProductKey, ProductKeySchema } from "./entities/product-key.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserResponse.name, schema: UserResponseSchema },
      { name: Organization.name, schema: OrganizationSchema },
      { name: Bot.name, schema: BotSchema },
      { name: Period.name, schema: PeriodSchema },
      { name: ProductKey.name, schema: ProductKeySchema },
    ]),
    forwardRef(() => OrganizationsModule),
    ConfigModule,
  ],
  providers: [SubscriptionsService],
  controllers: [SubscriptionsController],
  exports: [SubscriptionsService],
})
export class SubscriptionsModule {}
