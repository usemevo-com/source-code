import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { User } from "../../users/entities/user.schema";
import { Organization } from "src/organizations/entities/organization.schema";

export type ProductKeyDocument = HydratedDocument<ProductKey>;

@Schema({
  timestamps: true,
})
export class ProductKey {
  _id: string;

  @Prop({ required: true })
  key: string;

  @Prop({ required: true })
  vendor: string;

  @Prop({
    required: false,
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  })
  usedBy: User;

  @Prop({
    required: false,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
  })
  for: Organization;

  @Prop({ required: false, type: Boolean, default: false })
  isUsed: boolean;

  @Prop({ required: false, type: Date })
  usedAt: Date;
}

export const ProductKeySchema = SchemaFactory.createForClass(ProductKey);
