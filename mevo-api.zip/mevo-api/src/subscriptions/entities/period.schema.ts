import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Organization } from "../../organizations/entities/organization.schema";
import { PlanType, SubscriptionType } from "../../organizations/entities/plan";

export type PeriodDocument = HydratedDocument<Period>;

@Schema({
  timestamps: true,
})
export class Period {
  _id: string;

  @Prop({ required: true })
  start: Date;

  @Prop({ required: true })
  end: Date;

  @Prop({
    required: false,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
  })
  organization: Organization;

  @Prop({
    required: false,
    type: String,
    enum: PlanType,
    default: PlanType.BASIC,
  })
  plan: PlanType;

  @Prop({ required: false, type: Number })
  usage: number;

  @Prop({ required: false, type: Number })
  message_usage: number;

  @Prop({ required: false, type: Number })
  submission_usage: number;

  @Prop({ required: false, type: Number })
  email_usage: number;

  @Prop({ required: false, enum: SubscriptionType, type: String })
  subscriptionType: SubscriptionType;
}

export const PeriodSchema = SchemaFactory.createForClass(Period);
