/// <reference types="stripe-event-types" />

import Stripe from "stripe";
import mongoose, { Model } from "mongoose";
import { ConfigService } from "@nestjs/config";
import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import {
  Organization,
  OrganizationDocument,
} from "../organizations/entities/organization.schema";
import { User } from "../users/entities/user.schema";
import {
  AddOn,
  PlanType,
  SubscriptionType,
} from "../organizations/entities/plan";
import {
  UserResponse,
  UserResponseDocument,
} from "../user-responses/entities/user-response.schema";
import { sendTemplateMail } from "../common/helpers/send-mail";
import { Bot, BotDocument } from "../bots/entities/bot.schema";
import { Period, PeriodDocument } from "./entities/period.schema";
import { ProductKey } from "./entities/product-key.schema";

@Injectable()
export class SubscriptionsService {
  constructor(
    private configService: ConfigService,
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
    @InjectModel(UserResponse.name)
    private userResponseModel: Model<UserResponseDocument>,
    @InjectModel(Period.name)
    private periodModel: Model<PeriodDocument>,
    @InjectModel(ProductKey.name)
    private productKeyModel: Model<ProductKey>,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

  private stripe = new Stripe(this.configService.get<string>("STRIPE_SECRET"), {
    apiVersion: "2022-11-15",
  });

  private getRandomInt(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  private generateProductKey(): string {
    var tokens = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
      chars = 5,
      segments = 4,
      keyString = "";

    for (var i = 0; i < segments; i++) {
      var segment = "";

      for (var j = 0; j < chars; j++) {
        var k = this.getRandomInt(0, 35);
        segment += tokens[k];
      }

      keyString += segment;

      if (i < segments - 1) {
        keyString += "-";
      }
    }

    return keyString;
  }

  async buyAddOn(addOn: AddOn, organizationId: string) {
    const organization = await this.organizationModel
      .findOne({ _id: organizationId })
      .exec();

    if (!organization) {
      throw new NotFoundException("organizations.NOT_FOUND");
    }

    const addOnPrice = this.configService.get<string>(`STRIPE_PRICE_${addOn}`);

    if (!addOnPrice) {
      throw new NotFoundException("organizations.ADDON_NOT_FOUND");
    }

    if (addOn === AddOn.TRAINING_CHARACTERS && organization.extraCharacters) {
      return {
        status: "already-purchased",
      };
    }

    if (addOn === AddOn.BRAND_REMOVAL && organization.brandRemoval) {
      return {
        status: "already-purchased",
      };
    }

    const basePlanPrice = this.configService.get<string>(
      `STRIPE_PRICE_${organization.plan}`
    );

    if (!basePlanPrice) {
      throw new NotFoundException("organizations.PLAN_NOT_FOUND");
    }

    if (
      organization.plan === PlanType.BASIC ||
      organization.subscriptionCancelled
    ) {
      throw new ForbiddenException("organizations.NOT_ALLOWED_TO_BUY_ADDON");
    }

    const subscription = await this.stripe.subscriptions.retrieve(
      organization.subscriptionId
    );

    await this.stripe.subscriptions.update(organization.subscriptionId, {
      cancel_at_period_end: false,
      // proration_behavior: "create_prorations",
      items: [
        {
          id: subscription.items.data[0].id,
          price: basePlanPrice,
        },
        {
          price: addOnPrice,
          quantity: 1,
        },
      ],
    });

    if (addOn === AddOn.TRAINING_CHARACTERS) {
      organization.extraCharacters = true;
      await organization.save();
    }

    if (addOn === AddOn.BRAND_REMOVAL) {
      organization.brandRemoval = true;
      await organization.save();
    }

    return {
      status: "addon-purchased",
    };
  }

  async cancelAddOn(addOn: AddOn, organizationId: string) {
    const organization = await this.organizationModel
      .findOne({ _id: organizationId })
      .exec();

    if (!organization) {
      throw new NotFoundException("organizations.NOT_FOUND");
    }

    const addOnPrice = this.configService.get<string>(`STRIPE_PRICE_${addOn}`);

    if (!addOnPrice) {
      throw new NotFoundException("organizations.ADDON_NOT_FOUND");
    }

    const basePlanPrice = this.configService.get<string>(
      `STRIPE_PRICE_${organization.plan}`
    );

    if (!basePlanPrice) {
      throw new NotFoundException("organizations.PLAN_NOT_FOUND");
    }

    const subscription = await this.stripe.subscriptions.retrieve(
      organization.subscriptionId
    );

    const items = subscription.items.data
      .filter((item) => item.price.id !== addOnPrice)
      .map((item) => ({
        id: item.id,
        price: item.price.id,
      }));

    // Aboneliği güncelleyin
    await this.stripe.subscriptions.update(subscription.id, {
      cancel_at_period_end: false,
      items: items,
    });

    if (addOn === AddOn.TRAINING_CHARACTERS) {
      organization.extraCharacters = false;
      await organization.save();
    }

    if (addOn === AddOn.BRAND_REMOVAL) {
      organization.brandRemoval = false;
      await organization.save();
    }

    return {
      status: "addon-cancelled",
    };
  }

  async changePlan(
    plan: PlanType,
    organizationId: string,
    user: User,
    subscriptionType: SubscriptionType = SubscriptionType.MONTHLY,
    affiliate_referrer: string = ''
  ) {
    const planMap = {
      [PlanType.BASIC]: 0,
      [PlanType.LITE_NEW]: 1,
      [PlanType.PRO_NEW]: 2,
      [PlanType.MAX_NEW]: 3,
    };

    const organization = await this.organizationModel
      .findOne({ _id: organizationId, admins: user._id })
      .select("plan stripeCustomerId subscriptionId subscriptionCancelled")
      .exec();

    if (!organization) {
      throw new ForbiddenException("organizations.NOT_ALLOWED_TO_CHANGE_PLAN");
    }

    const requestedPlanCode = plan;
    const userPlan = organization.plan;

    if (!organization.stripeCustomerId) {
      const customer = await this.stripe.customers.create({
        description: organizationId,
      });

      organization.stripeCustomerId = customer.id;
      await organization.save();
    }

    if (requestedPlanCode === userPlan) {
      if (organization.subscriptionCancelled && organization.subscriptionId) {
        await this.continueSubscription({ _id: organization._id });

        return {
          status: "subscription-continued",
        };
      }

      return {
        status: "no-change",
      };
    }

    if (requestedPlanCode === PlanType.BASIC) {
      if (!organization.subscriptionCancelled) {
        await this.cancelSubscription({ _id: organization._id });

        return {
          status: "subscription-cancelled",
        };
      }

      return {
        status: "already-cancelled",
      };
    } else {
      if (organization.subscriptionId) {
        const newPriceId = this.configService.get<string>(
          subscriptionType === SubscriptionType.MONTHLY ? `STRIPE_PRICE_${requestedPlanCode}` : `STRIPE_PRICE_${requestedPlanCode}_YEARLY`
        );

        const subscription = await this.stripe.subscriptions.retrieve(
          organization.subscriptionId
        );

        await this.stripe.subscriptions.update(organization.subscriptionId, {
          cancel_at_period_end: false,
          proration_behavior: "create_prorations",
          items: [
            {
              id: subscription.items.data[0].id,
              price: newPriceId,
            },
          ],
        });

        if (planMap[requestedPlanCode] > planMap[userPlan]) {
          // create invoice
          const invoice = await this.stripe.invoices.create({
            customer: organization.stripeCustomerId,
            subscription: organization.subscriptionId,
            collection_method: "charge_automatically",
          });

          try {
            sendTemplateMail(
              "upgraded-paid-plan",
              organization.admins[0].email,
              {
                name: organization.admins[0].name,
                organization: organization.name,
              }
            );
          } catch (e) {
            console.log(e, "error");
          }

          if (invoice.total > 0) {
            try {
              // finalize invoice
              await this.stripe.invoices.finalizeInvoice(invoice.id);

              // charge manually
              const invoice_pay_result = await this.stripe.invoices.pay(
                invoice.id
              );

              if (invoice_pay_result.status === "paid") {
                organization.plan = requestedPlanCode;
                organization.subscriptionCancelled = false;
                await organization.save();

                return {
                  status: "plan-updated",
                };
              } else {
                return {
                  status: "payment-could-not-be-completed",
                };
              }
            } catch (e) {
              console.log(e, "error");
              return {
                status: "payment-could-not-be-completed",
              };
            }
          } else {
            organization.plan = requestedPlanCode;
            organization.subscriptionCancelled = false;
            await organization.save();

            return {
              status: "plan-updated",
            };
          }
        } else {
          organization.plan = requestedPlanCode;
          organization.subscriptionCancelled = false;
          await organization.save();

          try {
            sendTemplateMail(
              "downgraded-paid-plan",
              organization.admins[0].email,
              {
                name: organization.admins[0].name,
                organization: organization.name,
              }
            );
          } catch (e) {
            console.log(e, "error");
          }

          return {
            status: "plan-updated",
          };
        }
      } else {
        const session = await this.createStripeSession(
          organization.stripeCustomerId,
          requestedPlanCode,
          organizationId,
          subscriptionType,
          affiliate_referrer
        );

        if (!session) {
          return {
            status: "not-available",
          };
        }

        return {
          status: "payment-session",
          session: session,
        };
      }
    }
  }

  async fetchInvoices(customer: string) {
    const invoices = await this.stripe.invoices.list({
      customer,
      limit: 100,
    });

    return invoices.data;
  }

  async getBillingManagementUrl(oid: string) {
    const organization = await this.organizationModel
      .findOne({ _id: oid })
      .exec();

    if (!organization) {
      throw new NotFoundException("organizations.NOT_FOUND");
    }

    const billingPortal = await this.stripe.billingPortal.sessions.create({
      customer: organization.stripeCustomerId,
      return_url: `${this.configService.get<string>(
        "STRIPE_PORTAL_RETURN_URL"
      )}`,
    });

    return billingPortal;
  }

  async handleWebHook(payload: string | Buffer | undefined, signature: string) {
    try {
      if (!payload) return false;

      const data = (await this.stripe.webhooks.constructEventAsync(
        payload,
        signature,
        this.configService.get<string>("STRIPE_WEBHOOK_SECRET")
      )) as Stripe.DiscriminatedEvent;

      // console.log("[STRIPE] Webhook received!", JSON.stringify(data.type));
      if (data.type === "checkout.session.completed") {
        const subscriptionId = data.data.object.subscription as string;
        const metadata: any = data.data.object.metadata ?? {};
        const oid = metadata.oid;
        const planCode = metadata.planCode;
        const subscriptionType = metadata.subscriptionType;

        const organization = await this.organizationModel
          .findOne({ _id: oid })
          .select("plan stripeCustomerId subscriptionId subscriptionCancelled")
          .exec();

        if (organization) {
          organization.subscriptionId = subscriptionId;
          organization.subscriptionCancelled = false;
          organization.plan = planCode;
          organization.trainingCharacterExceeded = false;

          const period = await this.createPeriod(
            oid,
            planCode,
            null,
            subscriptionType
          );
          organization.activePeriod = period;

          if (planCode !== PlanType.BASIC) {
            organization.monthlyTokenUsage = 0;
          }

          await organization.save();

          // set all hidden responses to visible
          const bots = await this.botModel
            .find({ organization: oid, isRemoved: { $ne: true } })
            .exec();

          Promise.all(
            bots.map(async (bot) => {
              await this.userResponseModel
                .updateMany(
                  { bot: bot._id, isHidden: true },
                  { isHidden: false }
                )
                .exec();
            })
          );

          organization.admins.forEach((admin) => {
            sendTemplateMail("upgrade", admin.email, {
              organization: organization.name,
              plan: planCode,
              name: admin.name,
            });
          });
        } else {
          console.error("[STRIPE] handleWebHook, organization is null");
        }
      }

      if (data.type === "customer.subscription.updated") {
        if (data.data.object.canceled_at) {
          console.log("[MEVO] Subscription cancelled");
          await this.cancelSubscription({
            stripeCustomerId: data.data.object.customer as string,
          });
        } else {
          console.log("[MEVO] Subscription continued");
          await this.continueSubscription({
            stripeCustomerId: data.data.object.customer as string,
          });
        }
      }

      if (data.type === "invoice.paid") {
        console.log("[MEVO] Subscription extended");
        this.extendSubscription({
          stripeCustomerId: data.data.object.customer as string,
          // stripeCustomerId: data.data.object.metadata.customerId as string,
        });
      }

      if (data.type === "invoice.payment_failed") {
        console.log("[MEVO] Subscription extend attempt failed");
        this.handlePaymentFailed({
          stripeCustomerId: data.data.object.customer as string,
          // stripeCustomerId: data.data.object.metadata.customerId as string,
        });
      }

      // if (data.type === "invoice.created") {
      //   console.log("[MEVO] Invoice created");
      //   if (!data.data.object.status_transitions.finalized_at) {
      //     await this.finalizeInvoice(data.data.object.id);
      //   }
      // }

      return true;
    } catch (e) {
      console.error("[STRIPE] handleWebHook failed!", e);
      return '"[STRIPE] handleWebHook failed!"';
    }
  }

  async createStripeSession(
    customer: string,
    planCode: string,
    oid: string,
    subscriptionType: SubscriptionType,
    affiliate_referrer: string = ''
    // user: User
  ) {
    const price = this.configService.get<string>(subscriptionType === SubscriptionType.MONTHLY ? `STRIPE_PRICE_${planCode}` : `STRIPE_PRICE_${planCode}_YEARLY`);

    // if (subscriptionType === SubscriptionType.MONTHLY) {
    //   price = this.configService.get<string>("STRIPE_PRICE_PRO");
    // } else {
    //   price = this.configService.get<string>("STRIPE_PRICE_PRO_YEARLY");
    // }

    if (!price) {
      return null;
    }

    const payload = {
      mode: "subscription",
      success_url: `${this.configService.get<string>("STRIPE_SUCCESS_URL")}`,
      cancel_url: `${this.configService.get<string>("STRIPE_CANCEL_URL")}`,
      line_items: [{ price, quantity: 1 }],
      payment_method_types: ["card"],
      customer,
      // customer_email: user.email,
      billing_address_collection: "required",
      allow_promotion_codes: true,
      automatic_tax: { enabled: true },
      metadata: {
        oid,
        planCode,
        subscriptionType,
      },
      customer_update: {
        name: "auto",
        address: "auto",
      },
    };

    if (affiliate_referrer) {
      // @ts-ignore
      payload.client_reference_id = affiliate_referrer;
    }

    // @ts-ignore
    const session = await this.stripe.checkout.sessions.create(payload);

    return session;
  }

  async cancelStripeSubscription(subscription: string) {
    const session = await this.stripe.subscriptions.update(subscription, {
      cancel_at_period_end: true,
    });

    return session;
  }

  async continueStripeSubscription(subscription: string) {
    const session = await this.stripe.subscriptions.update(subscription, {
      cancel_at_period_end: false,
    });

    return session;
  }

  async createStripeCustomer(organization: Organization) {
    const customer = await this.stripe.customers.create({
      description: `${organization._id}:${organization.name}`,
      email: organization.admins[0].email,
    });

    return customer;
  }

  async createPeriod(
    oid: string,
    plan: PlanType = PlanType.BASIC,
    session: any = null,
    subscriptionType: SubscriptionType = SubscriptionType.MONTHLY
  ) {
    let periodEnd;

    if (subscriptionType === SubscriptionType.MONTHLY) {
      periodEnd = new Date(new Date().setMonth(new Date().getMonth() + 1));
    } else {
      periodEnd = new Date(
        new Date().setFullYear(new Date().getFullYear() + 1)
      );
    }

    const period = new this.periodModel({
      organization: oid,
      start: new Date(),
      end: periodEnd,
      usage: 0,
      message_usage: 0,
      submission_usage: 0,
      plan,
      subscriptionType,
    });

    if (session) {
      return period.save({ session });
    }

    return period.save();
  }

  async cancelSubscription(organizationSelector: { [key: string]: any }) {
    const organization = await this.organizationModel
      .findOne(organizationSelector)
      .exec();

    if (!organization) return;

    if (organization.subscriptionCancelled) {
      return;
    }

    const session = await this.cancelStripeSubscription(
      organization.subscriptionId
    );
    organization.subscriptionCancelled = true;
    organization.subscriptionEndAt = new Date((session.cancel_at || 0) * 1000);

    await organization.save();

    organization.admins.forEach((admin) => {
      sendTemplateMail("cancel", admin.email, {
        organization: organization.name,
        name: admin.name,
      });
    });
  }

  async continueSubscription(organizationSelector: { [key: string]: any }) {
    const organization = await this.organizationModel
      .findOne(organizationSelector)
      .exec();

    if (!organization) return;

    if (!organization.subscriptionCancelled) {
      return;
    }

    await this.continueStripeSubscription(organization.subscriptionId);
    organization.subscriptionEndAt = null;
    organization.subscriptionCancelled = false;

    await organization.save();

    organization.admins.forEach((admin) => {
      sendTemplateMail("continue", admin.email, {
        organization: organization.name,
        name: admin.name,
      });
    });
  }

  async extendSubscription(organizationSelector: { [key: string]: any }) {
    const organization = await this.organizationModel
      .findOne(organizationSelector)
      .populate("activePeriod")
      .exec();

    if (!organization) return;

    const period = await this.createPeriod(
      organization._id,
      organization.plan,
      null,
      organization.activePeriod.subscriptionType
    );
    organization.failedPaymentTry = 0;
    organization.activePeriod = period;
    organization.monthlyTokenUsage = 0;

    await organization.save();
  }

  async handlePaymentFailed(organizationSelector: { [key: string]: any }) {
    const organization = await this.organizationModel
      .findOne(organizationSelector)
      .exec();

    if (!organization) return;

    if (
      organization.plan !== PlanType.BASIC &&
      organization.failedPaymentTry < 2
    ) {
      organization.failedPaymentTry++;
      await organization.save();

      organization.admins.forEach((admin) => {
        sendTemplateMail("payment-failed", admin.email, {
          organization: organization.name,
          name: admin.name,
        });
      });
    } else {
      await this.downgradeToBasic(organizationSelector);

      organization.admins.forEach((admin) => {
        sendTemplateMail("downgraded", admin.email, {
          organization: organization.name,
          name: admin.name,
        });
      });
    }
  }

  async downgradeToBasic(organizationSelector: { [key: string]: any }) {
    const organization = await this.organizationModel
      .findOne(organizationSelector)
      .exec();

    if (!organization) return;
    if (organization.plan !== PlanType.BASIC) {
      const period = await this.createPeriod(organization._id, PlanType.BASIC);
      organization.failedPaymentTry = 0;
      organization.plan = PlanType.BASIC;
      organization.activePeriod = period;
      organization.monthlyTokenUsage = 0;

      await organization.save();
    }
  }

  async finalizeInvoice(invoiceId: string) {
    await this.stripe.invoices.finalizeInvoice(invoiceId);
  }

  async generateProductKeys(amount: number, vendor: string) {
    const keys = [];

    for (let i = 0; i < amount; i++) {
      keys.push(this.generateProductKey());
    }

    try {
      await this.productKeyModel.insertMany(
        keys.map((key) => {
          return {
            key,
            vendor,
          };
        })
      );

      return keys.join("\n");
    } catch (err) {
      console.log(err);
      return [];
    }
  }
}
