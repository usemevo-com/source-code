import { BadRequestException, Controller, Get, Res, Req } from "@nestjs/common";
import { Response } from "express";
import { ExportsService } from "./exports.service";
import * as archiver from "archiver";
import { ApiTags } from "@nestjs/swagger";
import RequestWithUser from "src/auth/interfaces/request-with-user";

@ApiTags("exports")
@Controller("exports")
export class ExportsController {
  constructor(
    private readonly exportsService: ExportsService
  ) {}

  @Get("by-email")
  async exportByEmail(@Req() req: RequestWithUser, @Res() res: Response) {
    const email = req.user?.email;
    if (!email) {
      throw new BadRequestException("Authenticated user must have an email");
    }

    const data = await this.exportsService.collectByEmail(email);

    const filename = `export-${email}-${Date.now()}.zip`;
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", (err) => {
      res.status(500).end(`Archive error: ${err.message}`);
    });

    archive.pipe(res);

    for (const [key, value] of Object.entries(data)) {
      archive.append(JSON.stringify(value ?? [], null, 0), {
        name: `${key}.json`,
      });
    }

    await archive.finalize();
  }
}


