import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";

import { User, UserDocument } from "src/users/entities/user.schema";
import { Organization, OrganizationDocument } from "src/organizations/entities/organization.schema";
import { Bot, BotDocument } from "src/bots/entities/bot.schema";
import { UserResponse, UserResponseDocument } from "src/user-responses/entities/user-response.schema";
import { Message, MessageDocument } from "src/bots/entities/message.schema";
import { File as BotFile, FileDocument } from "src/bots/entities/file.schema";
import { Text, TextDocument } from "src/bots/entities/text.schema";
import { Question, QuestionDocument } from "src/bots/entities/question.schema";
import { Product, ProductDocument } from "src/bots/entities/product.schema";
import { Link, LinkDocument } from "src/bots/entities/link.schema";
import { Lead, LeadDocument } from "src/leads/entities/lead.schema";

@Injectable()
export class ExportsService {
  constructor(
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
    @InjectModel(Organization.name) private readonly organizationModel: Model<OrganizationDocument>,
    @InjectModel(Bot.name) private readonly botModel: Model<BotDocument>,
    @InjectModel(UserResponse.name) private readonly userResponseModel: Model<UserResponseDocument>,
    @InjectModel(Message.name) private readonly messageModel: Model<MessageDocument>,
    @InjectModel(BotFile.name) private readonly fileModel: Model<FileDocument>,
    @InjectModel(Text.name) private readonly textModel: Model<TextDocument>,
    @InjectModel(Question.name) private readonly questionModel: Model<QuestionDocument>,
    @InjectModel(Product.name) private readonly productModel: Model<ProductDocument>,
    @InjectModel(Link.name) private readonly linkModel: Model<LinkDocument>,
    @InjectModel(Lead.name) private readonly leadModel: Model<LeadDocument>,
  ) {}

  async collectByEmail(email: string) {
    const user = await this.userModel.findOne({ email }).lean();
    if (!user) {
      throw new NotFoundException("User not found");
    }

    const organizations = await this.organizationModel
      .find({ admins: user._id })
      .lean();

    const orgIds = organizations.map((o: any) => o._id);
    const bots = await this.botModel
      .find({ organization: { $in: orgIds } })
      .lean();

    const botIds = bots.map((b: any) => b._id);

    const [
      userResponses,
      messages,
      files,
      texts,
      questions,
      products,
      links,
      leads,
    ] = await Promise.all([
      this.userResponseModel.find({ bot: { $in: botIds } }).lean(),
      this.messageModel.find({ bot: { $in: botIds } }).lean(),
      this.fileModel.find({ bot: { $in: botIds } }).lean(),
      this.textModel.find({ bot: { $in: botIds } }).lean(),
      this.questionModel.find({ bot: { $in: botIds } }).lean(),
      this.productModel.find({ bot: { $in: botIds } }).lean(),
      this.linkModel.find({ bot: { $in: botIds } }).lean(),
      this.leadModel.find({ organization: { $in: orgIds } }).lean(),
    ]);

    return {
      user,
      organizations,
      bots,
      "user-responses": userResponses,
      messages,
      files,
      texts,
      questions,
      products,
      leads,
      links,
    };
  }
}


