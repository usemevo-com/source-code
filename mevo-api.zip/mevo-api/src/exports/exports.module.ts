import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ConfigModule } from "@nestjs/config";
import { ExportsController } from "./exports.controller";
import { ExportsService } from "./exports.service";

import { User, UserSchema } from "src/users/entities/user.schema";
import { Organization, OrganizationSchema } from "src/organizations/entities/organization.schema";
import { Bot, BotSchema } from "src/bots/entities/bot.schema";
import { UserResponse, UserResponseSchema } from "src/user-responses/entities/user-response.schema";
import { Message, MessageSchema } from "src/bots/entities/message.schema";
import { File as BotFile, FileSchema } from "src/bots/entities/file.schema";
import { Text, TextSchema } from "src/bots/entities/text.schema";
import { Question, QuestionSchema } from "src/bots/entities/question.schema";
import { Product, ProductSchema } from "src/bots/entities/product.schema";
import { Link, LinkSchema } from "src/bots/entities/link.schema";
import { Lead, LeadSchema } from "src/leads/entities/lead.schema";

@Module({
  imports: [
    ConfigModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Organization.name, schema: OrganizationSchema },
      { name: Bot.name, schema: BotSchema },
      { name: UserResponse.name, schema: UserResponseSchema },
      { name: Message.name, schema: MessageSchema },
      { name: BotFile.name, schema: FileSchema },
      { name: Text.name, schema: TextSchema },
      { name: Question.name, schema: QuestionSchema },
      { name: Product.name, schema: ProductSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Lead.name, schema: LeadSchema },
    ]),
  ],
  controllers: [ExportsController],
  providers: [ExportsService],
})
export class ExportsModule {}


