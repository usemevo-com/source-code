import { Controller, Post, Body, Res, Req, Get, Query } from "@nestjs/common";
import { Response } from "express";
import TokenVerificationDto from "./dto/token-verification.dto";
import { GoogleService } from "./google.service";
import { Public } from "../auth/helpers/is-public";
import RequestWithUser from "src/auth/interfaces/request-with-user";
import { BotsService } from "src/bots/bots.service";
import { hasAdminAccess, hasUserAccess } from "src/auth/helpers/has-access";

@Controller("google")
export class GoogleController {
  constructor(
    private readonly googleService: GoogleService,
    private readonly botsService: BotsService) 
  {}

  @Public()
  @Post("authentication")
  async authenticate(
    @Body() tokenData: TokenVerificationDto,
    @Res() response: Response
  ) {
    const authenticationResult = await this.googleService.authenticate(
      tokenData.accessToken
    );
    response.setHeader("Set-Cookie", authenticationResult.cookie);
    return response.send(authenticationResult.user);
  }

  @Post("code-exchange")
  async codeExchange(
    @Body() codeExchangeBody: {
      code: string;
      bot_id: string;
    },
    @Req() request: RequestWithUser,
  ) {
    const bot = await this.botsService.findOne({ _id: codeExchangeBody.bot_id });
    
    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      const result = await this.googleService.exchangeAuthCode(codeExchangeBody.code, codeExchangeBody.bot_id);

      return {
        success: result,
      };
    }
  }

  @Get("spreadsheets")
  async getSpreadsheets(
    @Query() getSpreadsheetsBody: {
      bot_id: string;
    },
    @Req() request: RequestWithUser,
  ) {
    const bot = await this.botsService.findOne({ _id: getSpreadsheetsBody.bot_id });
    
    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.googleService.getSpreadsheets(bot.googleRefreshToken);
    }
  }
}
