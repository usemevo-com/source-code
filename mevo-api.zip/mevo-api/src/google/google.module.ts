import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { GoogleService } from "./google.service";
import { GoogleController } from "./google.controller";
import { MongooseModule } from "@nestjs/mongoose";
import { User, UserSchema } from "../users/entities/user.schema";
import { UsersModule } from "../users/users.module";
import { AuthModule } from "../auth/auth.module";
import { BotsModule } from "src/bots/bots.module";
import { Bot, BotSchema } from "src/bots/entities/bot.schema";

@Module({
  imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
    MongooseModule.forFeature([{ name: Bot.name, schema: BotSchema }]),
    ConfigModule,
    UsersModule,
    AuthModule,
    BotsModule,
  ],
  providers: [GoogleService],
  controllers: [GoogleController],
})
export class GoogleModule {}
