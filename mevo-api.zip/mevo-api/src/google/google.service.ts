import { Injectable } from "@nestjs/common";
import { decode } from 'jsonwebtoken';
import { UsersService } from "../users/users.service";
import { ConfigService } from "@nestjs/config";
import { google, Auth } from "googleapis";
import { AuthService } from "../auth/auth.service";
import { User } from "../users/entities/user.schema";
import { BotsService } from "src/bots/bots.service";
import { InjectModel } from "@nestjs/mongoose";
import { Bot, BotDocument } from "src/bots/entities/bot.schema";
import { Model } from "mongoose";

@Injectable()
export class GoogleService {
  oauthClient: Auth.OAuth2Client;
  constructor(
    private readonly usersService: UsersService,
    private readonly botsService: BotsService,
    private readonly configService: ConfigService,
    private readonly authService: AuthService,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
  ) {
    const clientID = this.configService.get("GOOGLE_AUTH_CLIENT_ID");
    const clientSecret = this.configService.get("GOOGLE_AUTH_CLIENT_SECRET");
    const redirectURL = this.configService.get("GOOGLE_AUTH_REDIRECT_URL");
  
    this.oauthClient = new google.auth.OAuth2(clientID, clientSecret, redirectURL);
  }

  async authenticate(
    accessToken: string
  ): Promise<{ cookie: string; user: User }> {
    const tokenInfo = await this.oauthClient.getTokenInfo(accessToken);

    const email = tokenInfo.email.toLowerCase();

    const user = await this.usersService.findOne({ email });

    if (user) {
      return {
        cookie: this.authService.getCookieWithJwtToken(user._id),
        user,
      };
    }
    return this.registerUser(accessToken);
  }

  async exchangeAuthCode(authCode: string, bot_id: string) {
    const bot = await this.botsService.findOne({ _id: bot_id });
    try {
      const { tokens } = await this.oauthClient.getToken(authCode);
      const decoded: any = decode(tokens.id_token);

      console.log(decoded, 'decoded');

      if (tokens.refresh_token) {
        bot.googleRefreshToken = tokens.refresh_token;
        bot.googleAccountOwner = decoded.email;
        
        await bot.save();

        return true;
      } else {
        throw new Error('Refresh token missing');
      }
    } catch (error) {
      console.error('Error exchanging auth code:', error);
      throw new Error('Failed to exchange auth code');
    }
  }

  async getSpreadsheets(refreshToken: string) {
    this.oauthClient.setCredentials({
      refresh_token: refreshToken,
    });

    const drive = google.drive({ version: 'v3', auth: this.oauthClient });

    const response = await drive.files.list({
      q: "mimeType='application/vnd.google-apps.spreadsheet'",
      fields: 'files(id, name)',
      pageSize: 100,
    });

    const sheets = response.data.files;

    return sheets;
  }

  async registerUser(
    accessToken: string
  ): Promise<{ cookie: string; user: User }> {
    const userData = await this.getUserData(accessToken);
    const user = await this.usersService.createWithGoogle(userData);

    return {
      cookie: this.authService.getCookieWithJwtToken(user._id),
      user,
    };
  }

  async getUserData(accessToken: string) {
    const userInfoClient = google.oauth2("v2").userinfo;

    this.oauthClient.setCredentials({
      access_token: accessToken,
    });

    const userInfoResponse = await userInfoClient.get({
      auth: this.oauthClient,
    });

    return userInfoResponse.data;
  }
}
