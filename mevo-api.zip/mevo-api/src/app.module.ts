import { APP_GUARD } from "@nestjs/core";
import { MulterModule } from "@nestjs/platform-express";
import { ScheduleModule } from "@nestjs/schedule";
import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { MongooseModule } from "@nestjs/mongoose";
import { UsersModule } from "./users/users.module";
import { BotsModule } from "./bots/bots.module";
import { OrganizationsModule } from "./organizations/organizations.module";
import { UserResponsesModule } from "./user-responses/user-responses.module";
import { getEnvPath } from "./common/helpers/env.helper";
import { getMongooseOptions } from "./common/helpers/mongoose-options";
import { AuthModule } from "./auth/auth.module";
import { InvitationModule } from "./invitation/invitation.module";
import { SubscriptionsModule } from "./subscriptions/subscriptions.module";
import { GoogleModule } from "./google/google.module";
import { PeriodManagerModule } from "./period-manager/period-manager.module";
import JwtAuthenticationGuard from "./auth/guards/jwt-authentication.guard";
import { uploadOptions } from "./common/middlewares/upload.middleware";
import { LeadsModule } from "./leads/leads.module";
import {
  ThrottlerGuard,
  ThrottlerModule,
  minutes,
  seconds,
} from "@nestjs/throttler";
import { NotificationManagerModule } from "./notification-manager/notification-manager.module";
import { ScrapeManagerModule } from "./scrape-manager/scrape-manager.module";
import { ExportsModule } from "./exports/exports.module";

const envFilePath: string = getEnvPath(`${__dirname}/common/envs`);

@Module({
  imports: [
    MulterModule.register(uploadOptions),
    ScheduleModule.forRoot(),
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath,
    }),
    MongooseModule.forRootAsync(getMongooseOptions()),
    UsersModule,
    BotsModule,
    OrganizationsModule,
    UserResponsesModule,
    AuthModule,
    InvitationModule,
    SubscriptionsModule,
    GoogleModule,
    PeriodManagerModule,
    NotificationManagerModule,
    ScrapeManagerModule,
    LeadsModule,
    ExportsModule,
    ThrottlerModule.forRoot([
      {
        ttl: seconds(1),
        limit: 20,
      },
    ]),
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtAuthenticationGuard,
    },
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}
