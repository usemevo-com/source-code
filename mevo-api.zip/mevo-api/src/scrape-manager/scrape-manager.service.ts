import mongoose, { Model } from "mongoose";
import { Injectable, Logger } from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { Cron, CronExpression } from "@nestjs/schedule";
import { send_telegram_notification } from "src/common/helpers/telegram-notifier";
// Link processing için gerekli importlar
import { Link, LinkDocument } from "src/bots/entities/link.schema";
import { Bot, BotDocument } from "src/bots/entities/bot.schema";
import { BotsService } from "src/bots/bots.service";

@Injectable()
export class ScrapeManagerService {
  private readonly logger = new Logger(ScrapeManagerService.name);
  private isLinkProcessingActive = false;
  private readonly MAX_CONCURRENT_SCRAPES = 5;

  constructor(
    private readonly botsService: BotsService,
    @InjectModel(Link.name)
    private linkModel: Model<LinkDocument>,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

    @Cron(CronExpression.EVERY_HOUR)
    async clearRedundantLinks() {
        const result = await this.linkModel.deleteMany({
            isProvisioned: true,
            createdAt: { $lt: new Date(Date.now() - 24*60*60*1000) },
          }).exec();
        this.logger.debug(`Removed ${result.deletedCount} redundant links`);
    }

    @Cron(CronExpression.EVERY_10_SECONDS)
    async handleLinkProcessing() {
        // check is link processing already active
        if (this.isLinkProcessingActive) {
            this.logger.debug('Link processing already active, skipping...');
            return;
        }

        try {
            this.isLinkProcessingActive = true;
            this.logger.debug('Starting link processing...');

            const linksToProcess = await this.getLinksToProcess();
            
            if (linksToProcess.length === 0) {
                this.logger.debug('No links to process');
                return;
            }

            this.logger.debug(`Found ${linksToProcess.length} links to process`);

            // process links 5 by 5
            await this.processLinksInBatches(linksToProcess);
            
            try {
                console.log('Syncing ' + linksToProcess.length + ' links with knowledge base');
                const groupLinksByBot = linksToProcess.reduce((acc, link) => {
                    acc[link.bot] = acc[link.bot] || [];
                    acc[link.bot].push(link);
                    return acc;
                }, {});

                for (const botId in groupLinksByBot) {
                    console.log('Syncing ' + groupLinksByBot[botId].length + ' links with knowledge base for bot ' + botId);
                    await this.botsService.add_links_in_queue_to_knowledge_base(botId);
                }
            } catch (error) {
                this.logger.error('Error adding links to knowledge base:', error);
            }
            
        } catch (error) {
            this.logger.error('Error in link processing:', error);
        } finally {
            this.isLinkProcessingActive = false;
        }
    }

    private async getLinksToProcess(): Promise<any[]> {
        return await this.connection
            .collection("links")
            .find({
                $and: [
                    { status: "onhold" },
                    {
                        $or: [
                            { isProvisioned: false },
                            { isProvisioned: { $exists: false } }
                        ]
                    }
                ]
            })
            .sort({ priority: -1 })
            .limit(this.MAX_CONCURRENT_SCRAPES)
            .toArray();
    }
    
    private async processLinksInBatches(links: any[]): Promise<void> {
        // process links 5 by 5 parallel
        const promises = links.map(link => this.processSingleLink(link));
        
        try {
            await Promise.allSettled(promises);

            this.logger.debug(`Successfully processed ${links.length} links`);
        } catch (error) {
            this.logger.error('Error processing links batch:', error);
        }
    }

    private async processSingleLink(link: any): Promise<void> {
        try {
            this.logger.debug(`Processing link: ${link.url} for bot: ${link.bot}`);

            // mark link as processing
            await this.markLinkAsProcessing(link._id);

            // get bot information
            const bot = await this.botModel.findById(link.bot).exec();
            if (!bot) {
                this.logger.warn(`Bot not found for link: ${link._id}`);
                await this.markLinkAsFailed(link._id, 'Bot not found');
                return;
            }

            // scrape the url, if the priority 10, it means this is root url and we should also generate starters
            const success = await this.botsService.scrape_url(link.url, bot._id.toString(), link.priority === 10);
            
            if (success) {
                // Link'i "trained" durumuna al
                await this.markLinkAsCompleted(link._id);
                this.logger.debug(`Successfully processed link: ${link.url}`);
            } else {
                await this.markLinkAsFailed(link._id, 'Scraping failed');
                this.logger.warn(`Failed to process link: ${link.url}`);
            }

        } catch (error) {
            this.logger.error(`Error processing link ${link._id}:`, error);
            await this.markLinkAsFailed(link._id, error.message);
        }
    }

    private async markLinkAsProcessing(linkId: string): Promise<void> {
        await this.connection
            .collection("links")
            .updateOne(
                { _id: new mongoose.Types.ObjectId(linkId) },
                {
                    $set: {
                        status: "processing",
                        processingStartedAt: new Date()
                    }
                }
            );
    }

    private async markLinkAsCompleted(linkId: string): Promise<void> {
        await this.connection
            .collection("links")
            .updateOne(
                { _id: new mongoose.Types.ObjectId(linkId) },
                {
                    $set: {
                        status: "in-queue",
                        processedAt: new Date()
                    },
                    $unset: {
                        processingStartedAt: 1
                    }
                }
            );
    }

    /**
     * Link'i failed durumuna al
     */
    private async markLinkAsFailed(linkId: string, errorMessage: string): Promise<void> {
        await this.connection
            .collection("links")
            .updateOne(
                { _id: new mongoose.Types.ObjectId(linkId) },
                {
                    $set: {
                        status: "failed",
                        errorMessage: errorMessage,
                        failedAt: new Date()
                    },
                    $unset: {
                        processingStartedAt: 1
                    }
                }
            );
    }

    @Cron(CronExpression.EVERY_5_MINUTES)
    async cleanupStuckLinks() {
        try {
            const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
            
            const result = await this.connection
            .collection("links")
            .updateMany(
                {
                    status: "processing",
                    processingStartedAt: { $lt: fiveMinutesAgo }
                },
                {
                    $set: {
                        status: "onhold",
                        errorMessage: "Processing timeout - reset to onhold"
                    },
                    $unset: {
                        processingStartedAt: 1
                    }
                }
            );

            if (result.modifiedCount > 0) {
                this.logger.warn(`Reset ${result.modifiedCount} stuck links back to onhold status`);
            }
        } catch (error) {
            this.logger.error('Error cleaning up stuck links:', error);
        }
    }
}
