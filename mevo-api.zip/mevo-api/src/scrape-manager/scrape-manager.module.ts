import { Module, forwardRef } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ScrapeManagerService } from "./scrape-manager.service";
import { OrganizationsModule } from "../organizations/organizations.module";
import { BotsModule } from "../bots/bots.module";
import { Period, PeriodSchema } from "../subscriptions/entities/period.schema";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { Link, LinkSchema } from "../bots/entities/link.schema";
import { Bot, BotSchema } from "../bots/entities/bot.schema";
import { SubscriptionsModule } from "../subscriptions/subscriptions.module";
import { HttpModule } from "@nestjs/axios";
import { Secret, SecretSchema } from "src/organizations/entities/secret.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Organization.name, schema: OrganizationSchema },
      { name: Period.name, schema: PeriodSchema },
      { name: Secret.name, schema: SecretSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Bot.name, schema: BotSchema },
    ]),
    forwardRef(() => OrganizationsModule),
    forwardRef(() => SubscriptionsModule),
    forwardRef(() => BotsModule),
    HttpModule,
  ],
  providers: [ScrapeManagerService],
})
export class ScrapeManagerModule {}