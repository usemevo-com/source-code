import { IsNotEmpty, IsUrl } from "class-validator";

export class ClarityTestDto {
  @IsNotEmpty()
  @IsUrl()
  url: string;
}