import { ApiProperty } from "@nestjs/swagger";

export class RemoveEmbeddingsDto {
  @ApiProperty({
    type: "string",
  })
  url: string;

  @ApiProperty({
    type: "string",
  })
  bot: string;
}
