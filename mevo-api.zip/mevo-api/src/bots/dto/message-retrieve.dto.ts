import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";

export class MessageRetrieveDto {
  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  sid: string;

  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  did: string;

  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  bid: string;

  @ApiProperty({
    type: "boolean",
  })
  is_demo: boolean;
}
