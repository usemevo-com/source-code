import { ApiProperty } from "@nestjs/swagger";
import { IsArray, IsNotEmpty } from "class-validator";

export class EmailReceiversDto {
  @IsArray()
  @IsNotEmpty()
  @ApiProperty({ type: Array })
  receivers: string[];
}
