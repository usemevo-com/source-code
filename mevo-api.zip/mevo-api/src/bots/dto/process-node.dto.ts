import { ApiProperty } from "@nestjs/swagger";
import { IsOptional } from "class-validator";

export class ProcessNodeDto {
  @ApiProperty({
    type: "string",
  })
  nodeId: string;

  @ApiProperty({
    type: "string",
  })
  sessionId: string;

  @ApiProperty({
    type: "string",
  })
  deviceId: string;

  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  message: string;

  @IsOptional()
  @ApiProperty({
    type: "boolean",
  })
  is_demo: boolean;
}
