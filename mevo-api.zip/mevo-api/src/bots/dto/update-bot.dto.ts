import { IsBoolean, IsOptional } from "class-validator";
import { Exclude, Type } from "class-transformer";
import { ApiProperty } from "@nestjs/swagger";
import {
  BotDesign,
  BotLayout,
  BotPosition,
  BotTheme,
} from "../entities/bot-design";
import { BotScript, BotStepType } from "../entities/bot-script";
import { GptSettings } from "../entities/bot-type";

export class UpdateBotDto {
  @IsOptional()
  @Exclude()
  _id?: string;

  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  name: String;

  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  inputText: String;

  @IsOptional()
  @Type(() => BotDesign)
  @ApiProperty({
    type: {
      theme: { type: "string", enum: BotTheme },
      position: { type: "string", enum: BotPosition },
      layout: { type: "string", enum: BotLayout },
      background: { type: "string" },
    },
  })
  design: BotDesign;

  @IsOptional()
  @Type(() => BotScript)
  @ApiProperty({
    type: {
      steps: {
        type: [
          {
            message: { type: "string" },
            options: { type: ["string"] },
            required: { type: "boolean", default: false },
            type: { type: "string", enum: BotStepType },
          },
        ],
      },
    },
  })
  script: BotScript;

  @IsOptional()
  @Type(() => GptSettings)
  gptSettings: GptSettings;

  @IsOptional()
  @IsBoolean()
  @ApiProperty({ type: "boolean" })
  isActive: boolean;
}
