import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsNotEmpty } from "class-validator";
import { BotEventType } from "../entities/bot-event-type";

export class ScrapeDto {
  @IsNotEmpty()
  @ApiProperty({
    type: "string",
    enum: BotEventType,
  })
  domain: string;

  @IsBoolean()
  @IsNotEmpty()
  @ApiProperty({
    type: "boolean",
  })
  isSinglePage: boolean;
}
