import { ApiProperty } from "@nestjs/swagger";

export class EditQuestionDto {
  @ApiProperty({
    type: "string",
  })
  question: string;

  @ApiProperty({
    type: "string",
  })
  answer: string;

  @ApiProperty({
    type: "boolean",
  })
  isChatStarter: boolean;

  @ApiProperty({
    type: "string",
  })
  bot: string;
}
