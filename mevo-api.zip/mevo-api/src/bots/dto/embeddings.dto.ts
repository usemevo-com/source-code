import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional } from "class-validator";
import { EmbeddingType } from "../entities/embedding.schema";

export class EmbeddingsDto {
  @IsNotEmpty()
  @ApiProperty({
    type: "string",
    enum: EmbeddingType,
  })
  type: EmbeddingType;

  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  content: string;

  @IsOptional()
  meta: {
    [key: string]: string;
  };
}
