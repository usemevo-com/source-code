import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional } from "class-validator";

export class BotInteractionDto {
  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  message: string;

  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  sid: string;

  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  did: string;

  @ApiProperty({
    type: "boolean",
  })
  is_demo: boolean;

  @IsOptional()
  @ApiProperty({
    type: "boolean",
  })
  human_communication_mode: boolean;
}
