import { ApiProperty } from "@nestjs/swagger";

export class ReplyViaEmailDto {
  @ApiProperty({
    type: "string",
  })
  bot: string;

  @ApiProperty({
    type: "string",
  })
  device_id: string;

  @ApiProperty({
    type: "string",
  })
  session_id: string;

  @ApiProperty({
    type: "string",
  })
  message: string;
}
