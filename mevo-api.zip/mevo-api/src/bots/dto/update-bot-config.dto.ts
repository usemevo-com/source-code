import { IsOptional } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";
import { BotFlow, Models } from "../entities/bot-type";

export class UpdateBotConfigDto {
  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  model?: Models;

  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  instructions?: string;

  @IsOptional()
  @ApiProperty({
    type: "object",
  })
  flow?: BotFlow;
}
