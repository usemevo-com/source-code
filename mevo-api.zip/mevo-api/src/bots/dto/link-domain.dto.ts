import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";
import { BotEventType } from "../entities/bot-event-type";

export class LinkDomainDto {
  @IsNotEmpty()
  @ApiProperty({
    type: "string",
    enum: BotEventType,
  })
  domain: string;
}
