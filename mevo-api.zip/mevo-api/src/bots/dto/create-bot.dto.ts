import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional } from "class-validator";
import { Type } from "class-transformer";
import { BotScript, BotStepType } from "../entities/bot-script";
import { User } from "../../users/entities/user.schema";
import { BotConfig, BotFlow, BotType } from "../entities/bot-type";

export class CreateBotDto {
  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  name: String;

  @IsNotEmpty()
  @ApiProperty({
    type: "string",
  })
  organization: string;

  // @IsNotEmpty()
  // @Type(() => BotDesign)
  // @ApiProperty({
  //   type: {
  //     theme: { type: "string", enum: BotTheme },
  //     position: { type: "string", enum: BotPosition },
  //     layout: { type: "string", enum: BotLayout },
  //     background: { type: "string" },
  //   },
  // })
  // design: BotDesign;

  @IsOptional()
  @Type(() => BotScript)
  @ApiProperty({
    type: {
      steps: {
        type: [
          {
            message: { type: "string" },
            options: { type: ["string"] },
            required: { type: "boolean", default: false },
            type: { type: "string", enum: BotStepType },
          },
        ],
      },
    },
  })
  script: BotScript;

  @IsNotEmpty()
  createdBy: User;

  @IsNotEmpty()
  config: BotConfig;

  @IsOptional()
  type: BotType;

  @IsOptional()
  flow: BotFlow;

  @IsOptional()
  fromTemplate: string;
}
