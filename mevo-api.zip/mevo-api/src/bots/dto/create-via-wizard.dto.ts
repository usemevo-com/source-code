export class CreateViaWizardDto {
  title: string;
  description: string;
  themeColor: string;
  callToAction: string;
  brandLogoUrl: string;
  organization: string;
  leadCaptureMode: string;
  notificationType: string;
  notificationReceiverName: string;
  notificationReceiverEmail: string;
  notificationReceiverUrl: string;
  createdBy?: string;
  trainingContent: string;
  chatbotType?: 'from_scratch' | 'customer_service' | 'from_website' | 'candidate_screening';
}
