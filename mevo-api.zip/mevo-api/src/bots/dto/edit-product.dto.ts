import { ApiProperty } from "@nestjs/swagger";

export class EditProductDto {
  @ApiProperty({
    type: "string",
  })
  name: string;

  @ApiProperty({
    type: "string",
  })
  description: string;

  @ApiProperty({
    type: "string",
  })
  price: string;

  @ApiProperty({
    type: "string",
  })
  bot: string;
}
