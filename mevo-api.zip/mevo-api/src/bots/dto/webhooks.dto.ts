import { ApiProperty } from "@nestjs/swagger";
import { IsArray, IsNotEmpty } from "class-validator";

export class WebhooksDto {
  @IsArray()
  @IsNotEmpty()
  @ApiProperty({ type: Array })
  webhooks: string[];
}
