import { ApiProperty } from "@nestjs/swagger";
import { IsOptional } from "class-validator";

export class AddProductDto {
  @ApiProperty({
    type: "string",
  })
  name: string;

  @ApiProperty({
    type: "string",
  })
  description: string;

  @ApiProperty({
    type: "string",
  })
  price: string;
}
