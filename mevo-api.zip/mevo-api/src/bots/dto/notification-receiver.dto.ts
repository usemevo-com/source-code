import { ApiProperty } from "@nestjs/swagger";
import { NotificationType } from "../entities/notification-receiver.schema";

export class NotificationReceiverDto {
  @ApiProperty({
    type: "string",
  })
  bot: string;

  @ApiProperty({
    type: "string",
    enum: [NotificationType.WEBHOOK, NotificationType.EMAIL],
  })
  type: string;

  @ApiProperty({
    type: "object",
  })
  payload: any;
}
