import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional } from "class-validator";
import { EmbeddingType } from "../entities/embedding.schema";

export class AddTextDto {
  @IsOptional()
  @ApiProperty({
    type: "string",
  })
  content: string;
}
