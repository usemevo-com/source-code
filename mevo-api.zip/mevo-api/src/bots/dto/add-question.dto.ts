import { ApiProperty } from "@nestjs/swagger";

export class AddQuestionDto {
  @ApiProperty({
    type: "string",
  })
  question: string;

  @ApiProperty({
    type: "string",
  })
  answer: string;

  @ApiProperty({
    type: "boolean",
  })
  isChatStarter: boolean;
}
