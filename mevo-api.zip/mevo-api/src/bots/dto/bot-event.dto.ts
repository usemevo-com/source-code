import { ApiProperty } from '@nestjs/swagger'
import { IsNotEmpty } from 'class-validator'
import { Bot } from '../entities/bot.schema'
import { BotEventType } from '../entities/bot-event-type'

export class BotEventDto {
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    enum: BotEventType,
  })
  type: String

  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
  })
  bot: Bot
}
