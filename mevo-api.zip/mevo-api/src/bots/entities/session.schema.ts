import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type SessionDocument = HydratedDocument<Session>;

@Schema({
  timestamps: true,
})
export class Session {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: false, type: String })
  session_id: string;

  @Prop({ required: false, type: String })
  active_node_id: string;
}

export const SessionSchema = SchemaFactory.createForClass(Session);
