import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type ClarityCacheDocument = ClarityCache & Document;

@Schema({ timestamps: true })
export class ClarityCache {
  @Prop({ required: true, unique: true })
  url: string;

  @Prop({ 
    required: true,
    type: Object,
    default: {}
  })
  result: {
    success: boolean;
    overall_score?: number;
    readability_score?: number;
    readability_improvement?: string;
    jargon_clarity_score?: number;
    jargon_clarity_improvement?: string;
    cta_clarity_score?: number;
    cta_clarity_improvement?: string;
    info_density_score?: number;
    info_density_improvement?: string;
    bot?: {
      botId: string;
      theme: string;
    };
    error?: string;
  };

  @Prop({ required: true })
  expiresAt: Date;
}

export const ClarityCacheSchema = SchemaFactory.createForClass(ClarityCache);

// TTL index - MongoDB will automatically delete expired documents
ClarityCacheSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });