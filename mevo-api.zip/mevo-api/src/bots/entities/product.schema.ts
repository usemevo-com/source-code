import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type ProductDocument = HydratedDocument<Product>;

@Schema({
  timestamps: true,
})
export class Product {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: false, type: String })
  name: string;

  @Prop({ required: false, type: String })
  description: string;

  @Prop({ required: false, type: String })
  price: string;

  @Prop({ required: false, type: String, default: "pending" })
  status: string;

  @Prop({ required: false, type: String })
  fileId: string;

  @Prop({ required: false, type: Boolean, default: false })
  isCustom: boolean;
}

export const ProductSchema = SchemaFactory.createForClass(Product);
