import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Secret } from "src/organizations/entities/secret.schema";
import { Organization } from "../../organizations/entities/organization.schema";
import { User } from "../../users/entities/user.schema";
import { Appearance, BotDesign } from "./bot-design";
import { BotScript } from "./bot-script";
import { BotConfig, BotFlow, BotType, GptSettings } from "./bot-type";

export type BotDocument = HydratedDocument<Bot>;

export enum ShowForm {
  NONE = "none",
  BEFORE_CHAT = "before_chat",
  IN_CHAT = "in_chat",
}

@Schema({
  timestamps: true,
})
export class Bot {
  _id: string;

  @Prop({ required: false, default: 0 })
  isTrainingProgress: boolean;

  @Prop({ required: false, default: 0 })
  viewCount: number;

  @Prop({ required: false, default: 0 })
  startCount: number;

  @Prop({ required: false, default: 0 })
  completedCount: number;

  @Prop({ required: true })
  name: string;

  @Prop({ required: false })
  design: BotDesign;

  @Prop({ required: false })
  appearance: Appearance;

  @Prop({ required: false })
  script: BotScript;

  @Prop({ required: false })
  config: BotConfig;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    autopopulate: {
      select: "name email",
    },
  })
  createdBy: User;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
    autopopulate: {
      select: "name domain plan admins users",
    },
  })
  organization: Organization;

  @Prop({ default: false })
  isRemoved: boolean;

  @Prop({ default: false })
  isProvisioning: boolean;

  @Prop({ default: true })
  isActive: boolean;

  @Prop({
    required: false,
    default: BotType.SCRIPTED,
    type: String,
    enum: BotType,
  })
  type: BotType;

  @Prop({ required: false, type: Object })
  gptSettings: GptSettings;

  @Prop({
    type: Object,
    required: false
  })
  flow: BotFlow;

  @Prop({ required: false, default: false, type: Boolean })
  isDraft: boolean;

  @Prop({ required: false, default: false, type: Boolean })
  unread: boolean;

  @Prop({ required: false, default: 0, type: Number })
  sessionCount: number;

  @Prop({ required: false, default: "", type: String })
  domain: string;

  @Prop({ required: false, default: "Type your message", type: String })
  inputText: string;

  @Prop({ required: false, default: "by", type: String })
  byText: string;

  @Prop({
    required: false,
    default: "Please fill the form to continue",
    type: String,
  })
  leadCaptureFormTitle: string;

  @Prop({
    required: false,
    default:
      "Our team will use this information to reach you after the conversation.",
    type: String,
  })
  leadCaptureFormDescription: string;

  @Prop({ required: false, default: "Name", type: String })
  nameLabel: string;

  @Prop({ required: false, default: "Email", type: String })
  emailLabel: string;

  @Prop({ required: false, default: "Organization", type: String })
  organizationLabel: string;

  @Prop({ required: false, default: "Bill Gates", type: String })
  namePlaceholder: string;

  @Prop({ required: false, default: "bill@microsoft.com", type: String })
  emailPlaceholder: string;

  @Prop({ required: false, default: "Microsoft", type: String })
  organizationPlaceholder: string;

  @Prop({ required: false, default: "Start conversation", type: String })
  formSubmitButton: string;

  @Prop({ required: false, default: "Please type your email", type: String })
  inChatEmailInputTitle: string;

  @Prop({ required: false, default: "Did that answer your question?", type: String })
  surveyMessage: string;

  @Prop({ required: false, default: "Yes, thanks.", type: String })
  surveyYes: string;

  @Prop({ required: false, default: "No, I want to continue talk with AI.", type: String })
  surveyNo: string;

  @Prop({ required: false, default: "I need to talk with a human", type: String })
  surveyHuman: string;

  @Prop({
    required: false,
    default: "Our team will reach out after your conversation with AI.",
    type: String,
  })
  inChatEmailInputDescription: string;

  @Prop({ required: false, default: "Submit", type: String })
  inChatEmailSubmitButtonLabel: string;

  @Prop({ required: false, default: "", type: String })
  domainUUID: string;

  @Prop({ required: false, default: 0, type: Number })
  charCount: number;

  @Prop({ required: false, default: false, type: Boolean })
  hideBranding: boolean;

  @Prop({ required: false, default: false, type: Boolean })
  hideCta: boolean;

  @Prop({
    type: [
      {
        required: false,
        type: mongoose.Schema.Types.ObjectId,
        ref: "Secret",
      },
    ],
  })
  secrets: Secret[];

  @Prop({ required: false, default: false, type: Boolean })
  apiKeySet: boolean;

  @Prop({ required: false, default: false, type: Boolean })
  hideOrganization: boolean;

  @Prop({
    required: false,
    default: ShowForm.NONE,
    type: String,
    enum: ShowForm,
  })
  showForm: ShowForm;

  @Prop({ required: false, default: "", type: String })
  hiddenFormFields: string;

  @Prop([{ required: false, type: String }])
  webhooks: string[];

  @Prop([{ required: false, type: String, default: [] }])
  tags: string[];

  @Prop([{ required: false, type: String }])
  emailReceivers: string[];

  @Prop({
    type: [
      {
        required: false,
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
  })
  notificationReceivers: User[];

  @Prop({ required: false, default: false, type: Number })
  showAfterSeconds: number;

  @Prop({ required: false, default: 1, type: Number })
  version: number;

  @Prop({ required: false })
  googleSpreadsheetId: string;

  @Prop({ required: false })
  googleSpreadsheetName: string;

  @Prop({
    type: String,
    required: false,
  })
  googleAccountOwner: string;

  @Prop({
    type: String,
    required: false,
  })
  googleRefreshToken: string;

  @Prop({
    type: String,
    required: false,
    default: 'from_scratch',
  })
  fromTemplate: string;

  @Prop({ required: false, default: false, type: Boolean })
  isTrainingFailed: boolean;

  @Prop({ required: false, default: '', type: String })
  previewUrl: string;

  @Prop({ required: false, default: '', type: String })
  previewRequestIp: string;
}

export const BotSchema = SchemaFactory.createForClass(Bot);
