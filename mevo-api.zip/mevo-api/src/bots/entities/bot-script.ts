export enum BotStepType {
  TEXT = "text",
}

export class BotScriptStep {
  id: string;
  type: string;
  data: {
    message: string;
    options: string[];
    jumps: string[];
  };
}

export class BotScript {
  steps: BotScriptStep[];
}
