export enum BotPosition {
  BOTTOM_RIGHT = "bottom-right",
  BOTTOM_LEFT = "bottom-left",
}

export enum BotLayout {
  CHAT_RIGHT = "chat-right",
  CHAT_MIDDLE = "chat-middle",
  CHAT_LEFT = "chat-left",
}

export enum BotTheme {
  BLUE = "blue",
  RED = "red",
  PURPLE = "purple",
  YELLOW = "yellow",
  PINK = "pink",
  INDIGO = "indigo",
}
export class BotDesign {
  theme: BotTheme;
  position: BotPosition;
  layout: BotLayout;
  background: string;
  backgroundColor: string;
  backgroundType: string;
  pageCustomCSS: string;
  popupCustomCSS: string;
  openerColor: string;
  bubbleColor: string;
  openerIcon: string;
}

export class Appearance {
  theme: BotTheme;
  position: BotPosition;
  hex: string;
  greeting: string;
  firstMessage: string;
  title: string;
  description: string;
  talkWithAgentMessage: string;
  hideBranding: boolean;
  skipWelcomePage: boolean;
  showAfterSeconds: number;
  placeholderText: string;
  brandImage: string;
}
