import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type QuestionDocument = HydratedDocument<Question>;

@Schema({
  timestamps: true,
})
export class Question {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true, type: String })
  question: string;

  @Prop({ required: true, type: String })
  answer: string;

  @Prop({ required: false, type: String })
  status: string;

  @Prop({ required: false, default: false, type: Boolean })
  isChatStarter: boolean;

  @Prop({ required: false, type: String })
  fileId: string;

  @Prop({ required: false, type: Boolean, default: false })
  isCustom: boolean;
}

export const QuestionSchema = SchemaFactory.createForClass(Question);
