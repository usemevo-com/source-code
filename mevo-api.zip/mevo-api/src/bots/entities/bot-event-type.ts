export enum BotEventType {
  START = 'start',
  COMPLETED = 'completed',
}
