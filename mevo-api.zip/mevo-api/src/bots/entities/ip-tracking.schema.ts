import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type IpTrackingDocument = HydratedDocument<IpTracking>;

@Schema({
  timestamps: true,
})
export class IpTracking {
  _id: string;

  @Prop({ required: true, type: String })
  ip: string;

  @Prop({ required: true, type: String })
  endpoint: string;

  @Prop({ required: true, type: Date })
  date: Date;

  @Prop({ required: true, type: Number, default: 1 })
  requestCount: number;
}

export const IpTrackingSchema = SchemaFactory.createForClass(IpTracking);

// IP + endpoint + date (günlük) kombinasyonu için unique index
IpTrackingSchema.index({ ip: 1, endpoint: 1, date: 1 }, { unique: true });