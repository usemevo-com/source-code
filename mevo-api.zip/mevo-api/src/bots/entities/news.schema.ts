import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type NewsDocument =
  HydratedDocument<News>;

@Schema({
  timestamps: true,
})
export class News {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  title: string;

  description: string;

  href: string;

  og_image: string;
}

export const NewsSchema =
  SchemaFactory.createForClass(News);
