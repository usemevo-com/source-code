import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type TextDocument = HydratedDocument<Text>;

@Schema({
  timestamps: true,
})
export class Text {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: false, type: Number })
  characterCount: number;

  @Prop({ required: false, type: String })
  status: string;

  @Prop({ required: false, type: String })
  content: string;

  @Prop({ required: false, type: String })
  fileId: string;

  @Prop({ required: false, type: Boolean, default: false })
  isCustom: boolean;
}

export const TextSchema = SchemaFactory.createForClass(Text);
