import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type FileDocument = HydratedDocument<File>;

@Schema({
  timestamps: true,
})
export class File {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: false, type: String })
  file_name: string;

  @Prop({ required: false, type: Number })
  characterCount: number;

  @Prop({ required: false, type: String })
  extension: string;

  @Prop({ required: false, type: String })
  size: string;

  @Prop({ required: false, type: String })
  status: string;

  @Prop({ required: false, type: String })
  fileId: string;

  @Prop({ required: false, type: Boolean, default: false })
  isCustom: boolean;
}

export const FileSchema = SchemaFactory.createForClass(File);
