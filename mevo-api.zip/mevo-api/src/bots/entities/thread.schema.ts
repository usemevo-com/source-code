import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type ThreadDocument = HydratedDocument<Thread>;

@Schema({
  timestamps: true,
})
export class Thread {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true, type: String })
  thread_id: string;

  @Prop({ required: true, type: String })
  session: string;

  @Prop({ required: false, type: String })
  run_id: string;

  @Prop({ required: false, type: String })
  assistant_id: string;
}

export const ThreadSchema = SchemaFactory.createForClass(Thread);
