import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type EmbeddingDocument = HydratedDocument<Embedding>;

export enum EmbeddingType {
  TEXT = "TEXT",
  QA = "QA",
  FILE = "FILE",
  PRODUCT = "PRODUCT",
  WEBPAGE = "WEBPAGE",
}
@Schema({
  timestamps: true,
})
export class Embedding {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true, type: Object })
  value: number[];

  @Prop({ required: true, type: String })
  ref: string;

  @Prop({ required: true, type: String, enum: EmbeddingType })
  type: string;

  @Prop({ required: false, type: Object })
  meta: object;
}

export const EmbeddingSchema = SchemaFactory.createForClass(Embedding);
