import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type ResponseFileDocument = HydratedDocument<ResponseFile>;

@Schema({ timestamps: true })
export class ResponseFile {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
  })
  organization: mongoose.Types.ObjectId;

  @Prop({ required: true, type: String })
  stepId: string;

  @Prop({ required: true, type: String })
  key: string;

  @Prop({ required: true, type: Number })
  size: number;

  @Prop({ required: false, type: String })
  contentType?: string;

  @Prop({ required: false, type: String })
  originalName?: string;

  @Prop({ required: false, type: String })
  uploadedByIp?: string;

  @Prop({ required: false, type: String })
  uploadedByUA?: string;

  @Prop({ required: false, type: String })
  uploadedByDeviceId?: string;

  createdAt: number;
}

export const ResponseFileSchema = SchemaFactory.createForClass(ResponseFile);

// indexes for rate limiting
ResponseFileSchema.index({ uploadedByDeviceId: 1, createdAt: -1 });
ResponseFileSchema.index({ uploadedByIp: 1, uploadedByUA: 1, createdAt: -1 });


