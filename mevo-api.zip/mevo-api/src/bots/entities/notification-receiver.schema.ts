import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type NotificationReceiverDocument =
  HydratedDocument<NotificationReceiver>;

export enum NotificationType {
  ALL = "all",
  EMAIL = "email",
  WEBHOOK = "webhook",
}

@Schema({
  timestamps: true,
})
export class NotificationReceiver {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true, type: String })
  type: NotificationType;

  @Prop({ required: true, type: Object })
  payload: any;
}

export const NotificationReceiverSchema =
  SchemaFactory.createForClass(NotificationReceiver);
