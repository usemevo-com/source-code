import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type MessageDocument = HydratedDocument<Message>;

export enum MessageSender {
  BOT = "BOT",
  USER = "USER",
  AGENT = "AGENT",
}

export enum SessionStatus {
  OPEN = "OPEN",
  CLOSED = "CLOSED",
}

export enum InboxFilter {
  HUMAN_YOURS = "human_yours",
  HUMAN_MENTIONS = "human_mentions",
  HUMAN_ALL = "human_all",
  AI_ALL = "ai_all",
  AI_RESOLVED = "ai_resolved",
  AI_ASSIGNED = "ai_assigned",
}

@Schema({
  timestamps: true,
})
export class Message {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true, type: String })
  content: string;

  @Prop({ required: true, type: String })
  session: string;

  @Prop({ required: true, type: String })
  did: string;

  @Prop({ required: true, type: String, enum: MessageSender })
  sender: MessageSender;

  @Prop({ required: false, type: Boolean, default: false })
  isEvent: boolean;

  @Prop({ required: false, type: Object })
  senderMeta: {
    _id: string;
    name: string;
    title: string;
    photo: string;
  };

  @Prop({ required: false, type: String, enum: SessionStatus, default: SessionStatus.OPEN })
  status: SessionStatus;

  @Prop({ required: true, type: String })
  ip: string;

  @Prop({ required: false, type: Object })
  geo: Object;

  @Prop({ required: false, type: Object })
  device: Object;

  @Prop({ required: false, type: Boolean, default: false })
  unread: Boolean;

  @Prop({ required: false, type: Boolean, default: false })
  notificationSent: Boolean;

  @Prop({ required: false, type: Number, default: 0 })
  credit_spending: number;
}

export const MessageSchema = SchemaFactory.createForClass(Message);
