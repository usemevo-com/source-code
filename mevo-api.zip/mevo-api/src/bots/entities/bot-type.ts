export enum BotType {
  SCRIPTED = "scripted",
  GPT = "gpt",
}

export interface GptFeed {
  type: string;
  data: [{ [key: string]: string }];
}

export enum BotResponseSubTypes {
  MESSAGE = 'message',
  RANDOMIZED_MESSAGE = 'randomized-message',
  IMAGE = 'image',
  GALLERY = 'gallery',
  WITH_BUTTONS = 'with-buttons',
  QUICK_REPLY = 'quick-reply',
}

export enum Models {
  GPT_3_5_TURBO_1106 = "gpt-3.5-turbo-1106",
  GPT_4_O = "gpt-4o",
  GPT_4_TURBO = "gpt-4-turbo",
  GPT_3_5_TURBO = "gpt-3.5-turbo",
  GPT_4_O_MINI = "gpt-4o-mini",
  GPT_4_1_NANO = 'gpt-4.1-nano-2025-04-14'
}

export enum ChatHistory {
  ENABLED = 1,
  DISABLED = 0,
}

export class BotConfig {
  assistant_id: string;
  model: Models;
  instructions: string;
  vector_store_id: string;
  fallback_message: string;
  is_custom_assistant_enabled: boolean;
  custom_assistant_id: string;
  custom_vector_store_id: string;
  show_ai_indicator: boolean;
  is_survey_disabled: boolean;
  meta: {
    title: string;
    description: string;
    og_image: string;
    keywords: string;
  };
}

export class GptSettings {
  represented: string;
  firstMessage: string;
  fallbackMessage: string;
  feed: GptFeed[];
  model: Models;
  withHistory: ChatHistory;
  showPredefinedQuestions: boolean;
  prompt: {
    systemMessage: "";
  };
  embeddings: {
    refs: string[];
    values: any[];
    rawText: string;
    hash: string;
    scraped: boolean;
    domain: string;
    lastScraped: Date;
  };
  qEmbeddings: {
    refs: string[];
    values: any[];
    rawText: string;
    hash: string;
    scraped: boolean;
    domain: string;
    lastScraped: Date;
  };
  fileSources: {
    refs?: string[];
    values?: any[];
    rawText?: string;
    hash?: string;
    fileName: string;
    fileId: string;
  }[];
  useAssistantAPI: boolean;
  assistantID: string;
  domainSources: string[];
}

export enum NodeType {
  BOT_RESPONSE = 'bot-response',
  USER_INPUT = 'user-input',
  QUESTION = 'question',
  GO_TO_STEP = 'go-to-block',
  START = 'start',
  AI_ASSIST = 'ai-assist',
  FALLBACK = 'fallback',
  WEBHOOK = 'webhook',
  END_CONVERSATION = 'end-conversation',
}


export class BotFlowChild {
  id: string;
  data: {
    label: string;
    id: string;
    type: NodeType;
    content: any;
  }
  type: NodeType;
  children: BotFlowChild[];
}

export type BotFlow = [BotFlowChild];

export enum FlowEventType {
  END_FLOW = 'END_FLOW',
  SHOW_OPTIONS = 'SHOW_OPTIONS',
  PROCESS_ON_SERVER = 'PROCESS_ON_SERVER',
  SET_ACTIVE_NODE = 'SET_ACTIVE_NODE', 
  PUSH_MESSAGE = 'PUSH_MESSAGE',
  SHOW_INPUT = 'SHOW_INPUT',
  HIDE_INPUT = 'HIDE_INPUT',
  SET_INPUT_VALIDATION_RULE = 'SET_INPUT_VALIDATION_RULE',
  SEND_TO_AI = 'SEND_TO_AI'
}

export interface IFlowEvent {
  type: FlowEventType;
  payload?: any;
}

/*
{
    type: FlowEventType.PROCESS_ON_SERVER,
    payload: {
        nodeId: "123-456-789",
        input?: 'Evet bence de öyle'
    }
}

{
    type: FlowEventType.SET_ACTIVE_NODE,
    payload: "123-456-789"
}

{
    type: FlowEventType.PUSH_MESSAGE,
    payload: "Size nasıl yardımcı olabilirim?"
}

{
    type: FlowEventType.SHOW_INPUT
}

{
    type: FlowEventType.SET_INPUT_VALIDATION_RULE,
    payload: "email"
}
*/