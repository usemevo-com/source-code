import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "./bot.schema";

export type LinkDocument = HydratedDocument<Link>;

@Schema({
  timestamps: true,
})
export class Link {
  _id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({ required: true, type: String })
  url: string;

  @Prop({ required: false, type: Number })
  characterCount: number;

  @Prop({ required: true, type: String, default: "pending" })
  status: string;

  @Prop({ required: false, type: String })
  content: string;

  @Prop({ required: false, type: String })
  fileId: string;

  @Prop({ required: false, type: Boolean, default: false })
  isCustom: boolean;

  @Prop({ required: false, type: Boolean, default: false })
  isProvisioned: boolean;

  @Prop({ required: false, type: Number, default: 0 })
  priority: number;

  @Prop({ required: false, type: Date })
  processedAt: Date;
}

export const LinkSchema = SchemaFactory.createForClass(Link);
