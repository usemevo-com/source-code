import { Module, forwardRef } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { ConfigModule } from "@nestjs/config";
import { HttpModule } from "@nestjs/axios";
import { BotsService } from "./bots.service";
import { BotsController } from "./bots.controller";
import { Bot, BotSchema } from "./entities/bot.schema";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { UserResponsesModule } from "../user-responses/user-responses.module";
import { OrganizationsModule } from "../organizations/organizations.module";
import { Message, MessageSchema } from "./entities/message.schema";
import { Secret, SecretSchema } from "../organizations/entities/secret.schema";
import { Thread, ThreadSchema } from "./entities/thread.schema";
import { Embedding, EmbeddingSchema } from "./entities/embedding.schema";
import { Lead, LeadSchema } from "src/leads/entities/lead.schema";
import { Link, LinkSchema } from "./entities/link.schema";
import { File, FileSchema } from "./entities/file.schema";
import { Text, TextSchema } from "./entities/text.schema";
import { Question, QuestionSchema } from "./entities/question.schema";
import {
  NotificationReceiver,
  NotificationReceiverSchema,
} from "./entities/notification-receiver.schema";
import { Product, ProductSchema } from "./entities/product.schema";
import { User, UserSchema } from "src/users/entities/user.schema";
import {
  UserResponse,
  UserResponseSchema,
} from "src/user-responses/entities/user-response.schema";
import { Period, PeriodSchema } from "src/subscriptions/entities/period.schema";
import { News, NewsSchema } from "./entities/news.schema";
import { SessionSchema, Session } from "./entities/session.schema";
import { IpTracking, IpTrackingSchema } from "./entities/ip-tracking.schema";
import { ClarityCache, ClarityCacheSchema } from "./entities/clarity-cache.schema";
import { ResponseFile, ResponseFileSchema } from "./entities/response-file.schema";
import { StorageService } from "../common/helpers/storage.service";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Bot.name, schema: BotSchema },
      { name: Organization.name, schema: OrganizationSchema },
      { name: Message.name, schema: MessageSchema },
      { name: Thread.name, schema: ThreadSchema },
      { name: Embedding.name, schema: EmbeddingSchema },
      { name: Secret.name, schema: SecretSchema },
      { name: Lead.name, schema: LeadSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Product.name, schema: ProductSchema },
      { name: File.name, schema: FileSchema },
      { name: Text.name, schema: TextSchema },
      { name: Question.name, schema: QuestionSchema },
      { name: Period.name, schema: PeriodSchema },
      { name: Session.name, schema: SessionSchema },
      {
        name: User.name,
        schema: UserSchema,
      },
      {
        name: NotificationReceiver.name,
        schema: NotificationReceiverSchema,
      },
      {
        name: UserResponse.name,
        schema: UserResponseSchema,
      },
      { name: News.name, schema: NewsSchema },
      { name: IpTracking.name, schema: IpTrackingSchema },
      { name: ClarityCache.name, schema: ClarityCacheSchema },
      { name: ResponseFile.name, schema: ResponseFileSchema },
    ]),
    forwardRef(() => UserResponsesModule),
    forwardRef(() => OrganizationsModule),
    HttpModule,
    ConfigModule,
  ],
  controllers: [BotsController],
  providers: [BotsService, StorageService],
  exports: [BotsService],
})
export class BotsModule {}
