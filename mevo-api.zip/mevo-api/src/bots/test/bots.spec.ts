import * as request from "supertest";
import { Test } from "@nestjs/testing";
import { INestApplication, ValidationPipe } from "@nestjs/common";
import { Model } from "mongoose";
import { getModelToken } from "@nestjs/mongoose";
import { AppModule } from "../../app.module";
import { Bot, BotDocument } from "../entities/bot.schema";
import {
  Organization,
  OrganizationDocument,
} from "../../organizations/entities/organization.schema";
import { getToken } from "../../common/helpers/get-token";
import { User, UserDocument } from "../../users/entities/user.schema";

let app: INestApplication;
let organizationModel: Model<OrganizationDocument>;
let botModel: Model<BotDocument>;
let userModel: Model<UserDocument>;
let createdOrganization;
let createdOrganization2;
let createdOrganization3;
let createdBot;
let createdBot2;
let createdBot3;
let createdBot4;
let authToken;
let authUser;
let user2;

beforeAll(async () => {
  const moduleRef = await Test.createTestingModule({
    providers: [
      {
        provide: getModelToken(Organization.name),
        useValue: Model,
      },
      {
        provide: getModelToken(Bot.name),
        useValue: Model,
      },
      {
        provide: getModelToken(User.name),
        useValue: Model,
      },
    ],
    imports: [AppModule],
  }).compile();

  // clear organizations collection
  organizationModel = moduleRef.get<Model<OrganizationDocument>>(
    getModelToken(Organization.name)
  );
  await organizationModel.deleteMany({});

  // clear bots collection
  botModel = moduleRef.get<Model<BotDocument>>(getModelToken(Bot.name));
  await botModel.deleteMany({});

  // clear users collection
  userModel = moduleRef.get<Model<UserDocument>>(getModelToken(User.name));
  await userModel.deleteMany({});

  // start app instance
  app = moduleRef.createNestApplication();
  app.useGlobalPipes(new ValidationPipe());
  await app.init();

  const auth = await getToken(
    request(app.getHttpServer()),
    "user_mevo_test@gmail.com"
  );
  authToken = auth.token;
  authUser = auth.user;

  // create an organization
  createdOrganization = await new organizationModel({
    name: "Unicef",
    admins: [authUser._id],
  }).save();

  createdOrganization2 = await new organizationModel({
    name: "org2",
    admins: [],
  }).save();

  user2 = await getToken(
    request(app.getHttpServer()),
    "user5_mevo_test@gmail.com"
  );

  createdOrganization3 = await new organizationModel({
    name: "org3",
    admins: [user2.user._id],
  }).save();

  createdBot2 = await new botModel({
    name: "Bot2",
    organization: createdOrganization3._id,
    script: [],
    design: {},
  }).save();

  createdBot3 = await new botModel({
    name: "Bot3",
    organization: createdOrganization3._id,
    script: [],
    design: {},
  }).save();

  createdBot4 = await new botModel({
    name: "Bot4",
    organization: createdOrganization2._id,
    script: [],
    design: {},
  }).save();
});

describe("try to get all bots for specific organization", () => {
  test(`should get authentication error`, () => {
    return request(app.getHttpServer())
      .get(`/bots?organization=111111111111111111111111`)
      .expect(401);
  });

  test(`should get empty array`, () => {
    return request(app.getHttpServer())
      .get(`/bots?organization=111111111111111111111111`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("organizations.NOT_FOUND");
      });
  });

  test(`should get empty array`, () => {
    return request(app.getHttpServer())
      .get(`/bots?organization=${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .expect([]);
  });
});

describe("try to create a bot for an organization", () => {
  test(`should return authentication error`, () => {
    return request(app.getHttpServer()).post(`/bots`).send({}).expect(401);
  });

  test(`should return validation error while trying with empty body`, () => {
    return request(app.getHttpServer())
      .post(`/bots`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({})
      .expect(400);
  });

  test(`should return organization not found error`, () => {
    return request(app.getHttpServer())
      .post("/bots")
      .set("Cookie", `Authentication=${authToken}`)
      .send({
        name: "Bot1",
        design: {},
        script: {},
        organization: "111111111111111111111111",
      })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("organizations.NOT_FOUND");
      });
  });

  test(`should return organization id required error`, () => {
    return request(app.getHttpServer())
      .post("/bots")
      .set("Cookie", `Authentication=${authToken}`)
      .send({ design: {}, script: {} })
      .expect(400);
  });

  test(`should create bot`, () => {
    return request(app.getHttpServer())
      .post(`/bots`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({
        name: "Bot1",
        organization: createdOrganization._id,
        design: {
          theme: "red",
          position: "left-mid",
          layout: "chat-left",
          background: "background-1",
        },
        script: {
          steps: [
            {
              type: "text",
              message: "wyn?",
              required: false,
              options: [],
            },
            {
              type: "single-choice",
              message: "r y mrd?",
              required: false,
              options: ["yes", "no"],
            },
          ],
        },
      })
      .expect(201)
      .then((response) => {
        createdBot = response.body;
      });
  });

  test(`verify bot created for this organization`, () => {
    return request(app.getHttpServer())
      .get(`/bots?organization=${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(response.body.length).toEqual(1);
      });
  });
});

describe("try to get single bot which just created", () => {
  test(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdOrganization._id}`)
      .expect(401);
  });

  test(`should return 404 while trying get non-existent bot detail`, () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });

  test(`should return bot detail`, () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(response.body.design.theme).toEqual("red");
        expect(response.body.design.position).toEqual("left-mid");
        expect(response.body.design.layout).toEqual("chat-left");
        expect(response.body.design.background).toEqual("background-1.jpg");
        expect(response.body.script.steps.length).toEqual(2);
        expect(response.body.script.steps[0].type).toEqual("text");
      });
  });
});

describe("try to update bot theme", () => {
  test(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .patch(`/bots/111111111111111111111111`)
      .expect(401);
  });

  test(`should return bot not found error with invalid bot id`, () => {
    return request(app.getHttpServer())
      .patch(`/bots/111111111111111111111111`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });

  test(`should update bot theme and return bot detail`, () => {
    return request(app.getHttpServer())
      .patch(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({
        design: {
          theme: "blue",
          position: "left-bot",
          layout: "chat-left",
          background: "background-1.jpg",
        },
      })
      .expect(200)
      .then((response) => {
        expect(response.body.design.theme).toEqual("blue");
        expect(response.body.design.position).toEqual("left-bot");
        expect(response.body.design.layout).toEqual("chat-left");
      });
  });
});

describe("try to update bot script", () => {
  test(`should add new step to bot and return bot detail, should remove all user responses`, () => {
    return request(app.getHttpServer())
      .patch(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({
        script: {
          steps: [
            { type: "text", message: "date?", required: true, options: [] },
          ],
        },
      })
      .expect(200)
      .then((response) => {
        expect(response.body.script.steps[0].type).toEqual("text");
        expect(response.body.script.steps[0].message).toEqual("date?");
        return request(app.getHttpServer())
          .get(`/user-responses?bot=${createdBot._id}`)
          .set("Cookie", `Authentication=${authToken}`)
          .expect(200)
          .then((response) => {
            expect(response.body.length).toEqual(0);
          });
      });
  });
});

describe("should bot detail service behave different for authorized and public mode", () => {
  it("should not return authorizatiion error from detail without permission if try to fetch with view flag and should not send forbidden fields", () => {
    return request(app.getHttpServer())
      .get(`/bots/public/${createdBot._id}`)
      .expect(200)
      .then((response) => {
        expect(response.body.viewCount).toBeUndefined();
        expect(response.body.completedCount).toBeUndefined();
        expect(response.body.startCount).toBeUndefined();
        expect(response.body.organization.admins).toBeUndefined();
        expect(response.body.organization.users).toBeUndefined();
        expect(response.body.organization.createdBy).toBeUndefined();
      });
  });

  it("should return bot detail and increased view count", () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .then((response) => {
        expect(response.body.viewCount).toEqual(1);
      });
  });

  it("should return bot detail and increase view count", () => {
    return request(app.getHttpServer())
      .get(`/bots/public/${createdBot._id}`)
      .expect(200);
  });

  it("should return bot detail and increased view count", () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .then((response) => {
        expect(response.body.viewCount).toEqual(2);
      });
  });
});

describe("test completedCount and startCount fields", () => {
  it("should increase startCount", () => {
    return request(app.getHttpServer())
      .post(`/bots/event`)
      .send({
        type: "start",
        bot: createdBot._id,
      })
      .expect(201);
  });

  it("should increase completedCount", () => {
    return request(app.getHttpServer())
      .post(`/bots/event`)
      .send({
        type: "completed",
        bot: createdBot._id,
      })
      .expect(201);
  });

  it("should be increased startCount and completedCount", () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(response.body.startCount).toBe(1);
        expect(response.body.completedCount).toBe(1);
      });
  });
});

describe("try to remove bot", () => {
  test(`should return bot not found error`, () => {
    return request(app.getHttpServer())
      .delete(`/bots/111111111111111111111111`)
      .expect(401);
  });

  test(`should return bot not found error`, () => {
    return request(app.getHttpServer())
      .delete(`/bots/111111111111111111111111`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });

  test(`should remove bot and all user responses related with it`, () => {
    return request(app.getHttpServer())
      .delete(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200);
  });

  test(`should verify remove process`, () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });

  test(`should verify removed user-responses`, () => {
    return request(app.getHttpServer())
      .get(`/user-responses/${createdBot._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });
});

describe("test authorization", () => {
  it("should return authorization error while try to create bot without permission", () => {
    return request(app.getHttpServer())
      .post(`/bots`)
      .set("Cookie", `Authentication=${user2.token}`)
      .send({
        name: "Bot1",
        organization: createdOrganization2._id,
        design: {
          theme: "red",
          position: "left-mid",
          layout: "chat-left",
          background: "background-1.jpg",
        },
        script: {
          steps: [
            {
              type: "text",
              message: "wyn?",
              required: false,
              options: [],
            },
            {
              type: "single-choice",
              message: "r y mrd?",
              required: false,
              options: ["yes", "no"],
            },
          ],
        },
      })
      .expect(403);
  });

  it("should return two bot with correct authroization", () => {
    return request(app.getHttpServer())
      .get(`/bots?organization=${createdOrganization3._id}`)
      .set("Cookie", `Authentication=${user2.token}`)
      .then((response) => {
        expect(response.body.length).toEqual(2);
      });
  });

  it("should return authorizatiion error from detail without permission", () => {
    return request(app.getHttpServer())
      .get(`/bots/${createdBot4._id}`)
      .set("Cookie", `Authentication=${user2.token}`)
      .expect(403);
  });

  it("should return authorixzaiton error when try to update bot without permission", () => {
    return request(app.getHttpServer())
      .patch(`/bots/${createdBot4._id}`)
      .set("Cookie", `Authentication=${user2.token}`)
      .send({
        design: {
          theme: "blue",
          position: "left-bot",
          layout: "chat-left",
          background: "background-1.jpg",
        },
      })
      .expect(403);
  });

  it("should return authorixzaiton error when try to delete bot without permission", () => {
    return request(app.getHttpServer())
      .delete(`/bots/${createdBot4._id}`)
      .set("Cookie", `Authentication=${user2.token}`)
      .expect(403);
  });
});

afterAll(async () => {
  // clear collections
  await organizationModel.deleteMany({});
  await botModel.deleteMany({});
  await userModel.deleteMany({});
  // close app
  await app.close();
});
