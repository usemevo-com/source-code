import {
  Body,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  HttpException,
  NotFoundException,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Req,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { Response } from 'express';
import { FileInterceptor } from "@nestjs/platform-express";
import { memoryStorage } from 'multer';
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { SkipThrottle, Throttle, minutes } from "@nestjs/throttler";
import * as pdf from "pdf-parse";
import { ThrottlerBehindProxyGuard } from "src/common/helpers/throttler-behind-proxy.guard";
import { AddSecretDto } from "src/organizations/dto/add-secret.dto";
import { BlogPostDto } from "src/organizations/dto/blog-post.dto";
import { RemoveSecretDto } from "src/organizations/dto/remove-secret.dto";
import { hasAdminAccess, hasUserAccess } from "../auth/helpers/has-access";
import { Public } from "../auth/helpers/is-public";
import RequestWithUser from "../auth/interfaces/request-with-user";
import { isObjectIdPipe } from "../common/pipes/isObjectIdPipe";
import { Organization } from "../organizations/entities/organization.schema";
import { OrganizationsService } from "../organizations/organizations.service";
import { BotsService } from "./bots.service";
import { AddProductDto } from "./dto/add-product.dto";
import { AddQuestionDto } from "./dto/add-question.dto";
import { AddTextDto } from "./dto/add-text.dto";
import { BotEventDto } from "./dto/bot-event.dto";
import { BotInteractionDto } from "./dto/bot-interaction.dto";
import { ClarityTestDto } from "./dto/clarity-test.dto";
import { CreateBotDto } from "./dto/create-bot.dto";
import { EditProductDto } from "./dto/edit-product.dto";
import { EditQuestionDto } from "./dto/edit-question.dto";
import { EmailReceiversDto } from "./dto/email-receivers.dto";
import { EmbeddingsDto } from "./dto/embeddings.dto";
import { LinkDomainDto } from "./dto/link-domain.dto";
import { MessageRetrieveDto } from "./dto/message-retrieve.dto";
import { NotificationReceiverDto } from "./dto/notification-receiver.dto";
import { ProcessNodeDto } from "./dto/process-node.dto";
import { RemoveEmbeddingsDto } from "./dto/remove-embeddings.dto";
import { RemovePdfDto } from "./dto/remove-pdf.dto";
import { ScrapeDto } from "./dto/scrape-dto";
import { UpdateBotConfigDto } from "./dto/update-bot-config.dto";
import { UpdateBotDto } from "./dto/update-bot.dto";
import { WebhooksDto } from "./dto/webhooks.dto";
import { Appearance } from "./entities/bot-design";
import { Models } from "./entities/bot-type";

import { Bot, ShowForm } from "./entities/bot.schema";
import { EmbeddingType } from "./entities/embedding.schema";
import { InboxFilter, SessionStatus } from "./entities/message.schema";
import { NotificationType } from "./entities/notification-receiver.schema";
import { ObjectId } from "bson";
import { CreateViaWizardDto } from "./dto/create-via-wizard.dto";
import { ReplyViaEmailDto } from "./dto/reply-via-email.dto";
import { EditTextDto } from "./dto/edit-text.dto";
import { sendTemplateMail } from "src/common/helpers/send-mail";

@ApiBearerAuth()
@ApiTags("bots")
@Controller("bots")
@UseGuards(ThrottlerBehindProxyGuard)
export class BotsController {
  constructor(
    private readonly botsService: BotsService,
    private readonly organizationsService: OrganizationsService
  ) {}

  @Public()
  @Get("/screenshot")
  @Throttle({ default: { limit: 10, ttl: minutes(10) } })
  async getScreenshot(
    @Query('url') url: string,
    @Res() res: Response,
    @Req() req: RequestWithUser,
  ) {
    if (!url) {
      throw new HttpException('URL parameter is required', 400);
    }

    // URL validation ve SSRF koruması
    if (!this.validateUrl(url)) {
      throw new HttpException('Invalid or blocked URL', 400);
    }

    // IP logging (şüpheli aktivite tespiti için)
    const clientIP = req.ip || req.connection?.remoteAddress || 'unknown';
    console.log(`Screenshot request from IP: ${clientIP}, URL: ${url}`);

    return this.botsService.getWebsiteScreenshot(url, res);
  }

  @Public()
  @Post("/get-customization")
  async getCustomization(@Body() getBrandColorHexDto: { url: string }) {
    return this.botsService.generate_data_from_url(getBrandColorHexDto.url);
  }

  private validateUrl(url: string): boolean {
    try {
      const fullUrl = url.startsWith('http') ? url : `https://${url}`;
      const parsed = new URL(fullUrl);
      
      // Internal IP ranges ve localhost engelle (SSRF koruması)
      const hostname = parsed.hostname;
      const blockedPatterns = [
        /^localhost$/i,
        /^127\./,           // 127.0.0.1 ve benzeri
        /^10\./,            // 10.0.0.0/8
        /^172\.(1[6-9]|2[0-9]|3[0-1])\./,  // 172.16.0.0/12
        /^192\.168\./,      // 192.168.0.0/16
        /^169\.254\./,      // AWS/Cloud metadata endpoint
        /^fe80::/,          // IPv6 link-local
        /^::1$/,            // IPv6 localhost
        /^0\.0\.0\.0$/,     // Invalid IP
      ];
      
      // Blocked patterns kontrolü
      if (blockedPatterns.some(pattern => pattern.test(hostname))) {
        return false;
      }

      // Port kontrolü (sadece standart HTTP/HTTPS portları)
      const port = parsed.port;
      if (port && !['80', '443', ''].includes(port)) {
        return false;
      }

      return true;
    } catch {
      return false;
    }
  }

  // @Public()
  // @Post("/add-flow-to-legacy-bots")
  // async addFlowToLegacyBots() {
  //   return this.botsService.add_flow_to_legacy_bots();
  // }

  @Post("notification-receivers/:id")
  async addNotificationReceiver(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() notificationReceiverDto: NotificationReceiverDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.add_notification_receiver(
        _id,
        notificationReceiverDto,
        bot.organization
      );
    }

    throw new ForbiddenException();
  }

  @Public()
  @Get("/active-node/:sid")
  async getActiveNodeForSession(
    @Param("sid") session_id: string,
  ) {
    return this.botsService.get_active_node_for_session(session_id);
  }

  @Public()
  @Get("/:id/news")
  async getNews(@Param("id", new isObjectIdPipe()) _id: string) {
    return this.botsService.get_news(_id);
  }

  @Throttle({ default: { limit: 10, ttl: minutes(1) } })
  @Public()
  @Post("/scan-website")
  async scanWebsite(@Body() scanWebsiteDto: { url: string, single_page: boolean }) {
    return this.botsService.scan_website(scanWebsiteDto.url, scanWebsiteDto.single_page);
  }

  @Throttle({ default: { limit: 10, ttl: minutes(1) } })
  @Public()
  @Post("/clarity-test")
  async clarityTest(@Body() clarityTestDto: ClarityTestDto) {
    return this.botsService.clarity_test(clarityTestDto.url);
  }

  @Public()
  @Post("/:id/train-with-urls-public")
  async trainWithUrlsPublic(
    @Body() trainWithUrlsDto: { urls: string[] },
    @Param("id", new isObjectIdPipe()) _id: string,
  ) {
    return this.botsService.scrape_urls(trainWithUrlsDto.urls, _id, true);
  }

  @Post("/:id/train-with-urls")
  async trainWithUrls(
    @Body() trainWithUrlsDto: { urls: string[] },
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.scrape_urls(trainWithUrlsDto.urls, _id, false);
    }

    throw new ForbiddenException();
  }

  @Post("/:id/retry-failed-links")
  async retryFailedLinks(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.retry_failed_links(_id);
    }

    throw new ForbiddenException();
  }

  @Post("reply-via-email")
  async replyViaEmail(
    @Body() replyViaEmailDto: ReplyViaEmailDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: replyViaEmailDto.bot });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.reply_via_email(replyViaEmailDto, request.user);
    }

    throw new ForbiddenException();
  }

  @Delete("notification-receivers/:id")
  async removeNotificationReceiver(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("receiver", new isObjectIdPipe()) receiverId: string,
    @Req() request: RequestWithUser
  ) {
    if (!receiverId)
      throw new HttpException("Must provide receiver query", 400);

    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.delete_notification_receiver(receiverId);
    }

    throw new ForbiddenException();
  }

  @Get("notification-receivers/:id")
  async getNotificationReceivers(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("type") type: NotificationType,
    @Query("p") page: number,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      if (!type) type = NotificationType.ALL;
      return this.botsService.get_notification_receiver(_id, page, type);
    }

    throw new ForbiddenException();
  }

  @Get("links/:id")
  async getLinks(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("p") page: number,
    @Query("status") status: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_links(_id, page, status);
    }

    throw new ForbiddenException();
  }

  @Post("sync-links/:id")
  async syncLinks(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.add_links_to_knowledge_base(_id);
    }

    throw new ForbiddenException();
  }

  @Delete("/links/:lid")
  async removeLink(
    @Param("lid", new isObjectIdPipe()) lid: string,
    @Query("bid", new isObjectIdPipe()) bid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bid });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_link(lid, bot._id);
    }

    throw new ForbiddenException();
  }

  @Delete("/all-links")
  async removeLinks(
    @Query("bid", new isObjectIdPipe()) bid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bid });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_links(bot._id);
    }

    throw new ForbiddenException();
  }

  @Post("embeddings/:id")
  async calculateEmbeddings(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser,
    @Body() embeddingsDto: EmbeddingsDto
  ) {
    if (embeddingsDto.type === EmbeddingType.FILE) {
      throw new HttpException("Unsupported embedding type", 400);
    }

    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.generateEmbeddings(
        embeddingsDto.content,
        embeddingsDto.type,
        bot,
        embeddingsDto.meta
      );
    }

    throw new ForbiddenException();
  }

  @Delete("embeddings")
  async removeEmbeddings(
    @Req() request: RequestWithUser,
    @Body() removeEmbeddingsDto: RemoveEmbeddingsDto
  ) {
    const bot = await this.botsService.findOne({
      _id: removeEmbeddingsDto.bot,
    });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.removeEmbeddings(bot, EmbeddingType.WEBPAGE, {
        domain: removeEmbeddingsDto.url,
      });
    }

    throw new ForbiddenException();
  }

  @Throttle({ default: { limit: 10, ttl: minutes(1) } })
  @Post("files/:id")
  @UseInterceptors(FileInterceptor("file"))
  async uploadFile(
    @Param("id", new isObjectIdPipe()) _id: string,
    @UploadedFile() file,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.create_file(bot._id, file);
    }

    throw new ForbiddenException();
  }

  @Public()
  @Throttle({ default: { limit: 20, ttl: minutes(1) } })
  @Post("response-files/:id")
  @UseInterceptors(
    FileInterceptor("file", {
      storage: memoryStorage(),
      limits: { fileSize: 10 * 1024 * 1024 },
    })
  )
  async uploadResponseFile(
    @Param("id", new isObjectIdPipe()) _id: string,
    @UploadedFile() file,
    @Body() body: { stepId: string; deviceId?: string },
    @Req() req: any
  ) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const ip = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;
    const ua = req.headers["user-agent"];

    return this.botsService.createResponseFileUpload({
      botId: _id,
      file,
      stepId: body.stepId,
      ip,
      ua,
      deviceId: body.deviceId,
    });
  }

  @Get("response-files/:rid/url")
  async getResponseFileSignedUrl(
    @Param("rid", new isObjectIdPipe()) rid: string,
    @Req() request: RequestWithUser
  ) {
    return this.botsService.getResponseFileSignedUrl(rid, request.user);
  }

  // @Throttle({ default: { limit: 10, ttl: minutes(1) } })
  @Post("shopify-products/:id")
  @UseInterceptors(FileInterceptor("file"))
  async uploadShopifyExport(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body()
    shopifyExportDto: {
      onlyInStock: boolean;
      onlyActive: boolean;
    },
    @UploadedFile() file,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.create_products_from_shopify_export(
        bot._id,
        file,
        {
          onlyInStock: shopifyExportDto.onlyInStock,
          onlyActive: shopifyExportDto.onlyActive,
        }
      );
    }

    throw new ForbiddenException();
  }

  @Delete("files/:id")
  async removeFile(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("bid", new isObjectIdPipe()) bid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bid });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_file(_id);
    }

    throw new ForbiddenException();
  }

  @Get("files/:id")
  async getFiles(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("p") page: number,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_files(_id, page);
    }

    throw new ForbiddenException();
  }

  @Post("texts/:id")
  async addText(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addTextDto: AddTextDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.add_text(addTextDto.content, _id);
    }

    throw new ForbiddenException();
  }

  @Post("products/:id")
  async addProduct(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addProductDto: AddProductDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.create_product(_id, addProductDto);
    }

    throw new ForbiddenException();
  }

  @Get("products/:id")
  async getProducts(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("p") page: number,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      if (!page) page = 1;
      return this.botsService.get_products(_id, page);
    }

    throw new ForbiddenException();
  }

  @Put("products/:id")
  async updateProduct(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("pid", new isObjectIdPipe()) pid: string,
    @Body() editProductDto: EditProductDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      editProductDto.bot = _id;
      return this.botsService.update_product(pid, editProductDto);
    }

    throw new ForbiddenException();
  }

  @Delete("products/:id")
  async removeProduct(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("pid", new isObjectIdPipe()) pid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_product(pid);
    }

    throw new ForbiddenException();
  }

  @Post("questions/:id")
  async addQuestion(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addQuestionDto: AddQuestionDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.add_question(addQuestionDto, _id);
    }

    throw new ForbiddenException();
  }

  @Put("questions/:id")
  async updateQuestion(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("qid", new isObjectIdPipe()) qid: string,
    @Body() editQuestionDto: EditQuestionDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      editQuestionDto.bot = _id;
      return this.botsService.update_question(qid, editQuestionDto);
    }

    throw new ForbiddenException();
  }

  @Put("texts/:id")
  async updateText(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("tid", new isObjectIdPipe()) tid: string,
    @Body() editTextDto: EditTextDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      editTextDto.bot = _id;
      return this.botsService.update_text(tid, editTextDto);
    }

    throw new ForbiddenException();
  }

  @Get("questions/:id")
  async getQuestions(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("p") page: number,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_questions(_id, page);
    }

    throw new ForbiddenException();
  }

  @Delete("questions/:id")
  async removeQuestions(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("bid", new isObjectIdPipe()) bid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bid });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_question(_id);
    }

    throw new ForbiddenException();
  }

  @Delete("texts/:id")
  async removeText(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("bid", new isObjectIdPipe()) bid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bid });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_text(_id);
    }

    throw new ForbiddenException();
  }

  @Get("texts/:id")
  async getTexts(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("p") page: number,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_texts(_id, page);
    }

    throw new ForbiddenException();
  }

  @Post("remove-domain/:id")
  async removeDomain(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("bid", new isObjectIdPipe()) bid: string,
    @Body() removePdfDto: RemovePdfDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bid });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      // remove file source with index

      return this.botsService.remove_file(removePdfDto._id);
    }

    throw new ForbiddenException();
  }

  private async parsePdf(buffer: Buffer): Promise<string> {
    const options = {
      // Set to true to preserve spaces between words
      // You can also adjust other options as needed
      // For example, encoding: 'ISO-8859-1' for specific encodings
      // Check the pdf-parse documentation for more options.
      normalizeWhitespace: false,
      combineTextItems: false,
    };

    const data = await pdf(buffer, options);
    return data.text;
  }

  @SkipThrottle()
  @Post()
  async create(
    @Body() createBotDto: CreateBotDto,
    @Req() request: RequestWithUser
  ) {
    const organization: Organization = await this.organizationsService.findOne({
      _id: createBotDto.organization,
    });

    if (!organization) throw new NotFoundException("organizations.not-found");

    if (
      hasUserAccess(organization, request.user) ||
      hasAdminAccess(organization, request.user)
    ) {
      createBotDto.createdBy = request.user;
      return this.botsService.create(createBotDto);
    }

    throw new ForbiddenException();
  }

  @Get()
  async findAll(
    @Query("organization", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (!organization) throw new NotFoundException("organizations.not-found");

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      const bots: Bot[] = await this.botsService.findAll({ organization: _id });
      return bots;
    }

    throw new ForbiddenException();
  }

  @Public()
  @Get("/public/:id")
  async findOnePublic(@Param("id", new isObjectIdPipe()) _id: string) {
    const bot = await this.botsService.findOne({ _id }, true);

    return bot;
  }

  @Public()
  @Get("/get-by-domain/:domain")
  async findOneByDomain(@Param("domain") domain: string) {
    const bot = await this.botsService.findOneByDomain(domain);

    return bot;
  }

  @Get(":id")
  async findOne(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser,
    @Query("sr") setReaded: boolean
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      if (setReaded) {
        await this.botsService.setReaded(_id);
      }

      return bot;
    }

    throw new ForbiddenException();
  }

  @Post("domain/:id")
  async linkDomain(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() linkDomainDto: LinkDomainDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.linkDomain(
        linkDomainDto,
        _id,
        request.user.email
      );
    }

    throw new ForbiddenException();
  }

  @Post("webhooks/:id")
  async webhooks(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() webhooksDto: WebhooksDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.updateWebhooks(_id, webhooksDto.webhooks);
    }
  }

  @Post("email-receivers/:id")
  async emailReceivers(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() emailReceiversDto: EmailReceiversDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.update_receivers(
        _id,
        emailReceiversDto.receivers
      );
    }
  }

  @Post("unlink-domain/:id")
  async unlinkDomain(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.unlinkDomain(_id);
    }

    throw new ForbiddenException();
  }

  @SkipThrottle()
  @Patch(":id")
  async update(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() updateBotDto: UpdateBotDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.update({ _id }, updateBotDto);
    }

    throw new ForbiddenException();
  }

  @Delete(":id")
  async remove(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (!bot) throw new NotFoundException("bots.not-found");

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.remove({ _id });
    }

    throw new ForbiddenException();
  }

  @Throttle({ default: { limit: 45, ttl: minutes(1) } })
  @Public()
  @Post("/event")
  async event(@Body() botEventDto: BotEventDto) {
    const bot: Bot = await this.botsService.findOne(
      {
        _id: botEventDto.bot,
      },
      true
    );

    if (!bot) throw new NotFoundException("bots.not-found");

    return this.botsService.processEvent(botEventDto);
  }

  // @Public()
  // @Post("/vector")
  // async vector(@Body() body: { text: string; prompt: string }) {
  //   return this.botsService.embedding(body.text, body.prompt);
  // }

  // @Public()
  // @Post("/scrape/:id")
  // async scrape(
  //   @Param("id", new isObjectIdPipe()) _id: string,
  //   @Body() scrapeDto: ScrapeDto
  // ) {
  //   return this.botsService.scrapeWebsite(scrapeDto.domain, _id);
  // }

  @Throttle({ default: { limit: 200, ttl: minutes(1) } })
  @Public()
  @Post("/interact-v2/:id")
  async interactV2(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() botInteraction: BotInteractionDto,
    @Req() req
  ) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const clientIp = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;
    return await this.botsService.interactWithAssistant(
      _id,
      botInteraction,
      clientIp,
      req.headers["user-agent"],
      botInteraction.human_communication_mode
    );
  }

  @Throttle({ default: { limit: 45, ttl: minutes(1) } })
  @Public()
  @Post("/retrieve")
  async retrieve(@Body() retrieveDto: MessageRetrieveDto, @Req() req) {
    return await this.botsService.retrieveMessage(
      retrieveDto.sid,
      retrieveDto.bid
    );
  }

  @Throttle({ default: { limit: 45, ttl: minutes(1) } })
  @Public()
  @Post("/interact/:id")
  async interact(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() botInteraction: BotInteractionDto,
    @Req() req
  ) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const clientIp = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;
    return await this.botsService.interact(
      _id,
      botInteraction,
      clientIp,
      req.headers["user-agent"]
    );
  }

  @Post(":id/add-secret")
  async addSecret(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addSecretDto: AddSecretDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.addSecret({ _id }, addSecretDto);
    }
  }

  @Post(":id/remove-secret")
  async removeSecret(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() removeSecretDto: RemoveSecretDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.removeSecret({ _id }, removeSecretDto);
    }
  }

  @Get("/sessions/:id")
  async sessions(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Query("p") page: number,
    @Query("sr") setReaded: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      // if set read flag is true, set this bot as readed
      if (setReaded === "true") {
        await this.botsService.setReaded(_id);
      }

      return this.botsService.getGroupedMessagesBySessionForBot(_id, page);
    }
  }

  @Delete(":id/remove-session/:sid")
  async removeSession(
    @Param("sid") sid: string,
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.removeSession(sid, _id);
    }
  }

  @Get(":id/messages/:sid")
  async messages(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Param("sid") sid: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.getMessages(sid);
    }
  }

  @Post("/scrape/:id")
  async scrape(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() scrapeDto: ScrapeDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (hasAdminAccess(bot.organization, request.user)) {
      return this.botsService.scrapeWebsite(
        scrapeDto.domain,
        bot,
        scrapeDto.isSinglePage
      );
    }

    throw new ForbiddenException();
  }

  @Throttle({ default: { limit: 3, ttl: minutes(1) } })
  @Public()
  @Post("generate-blog-post")
  async generateBlogPost(@Body() blogPostDto: BlogPostDto) {
    return this.botsService.generateBlogPost(blogPostDto.postTitle);
  }

  /**
   *
   * MEVO_V2 ENDPOINTS
   *
   */

  @Post("v2")
  async create_chatbot(
    @Body() createBotDto: CreateBotDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id: createBotDto.organization,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.botsService.create_bot(createBotDto);
    }

    throw new ForbiddenException();
  }

  @Public()
  @Post("v2/:id/stream")
  async streamInteract(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() botInteraction: BotInteractionDto,
    @Req() req,
    @Res({ passthrough: false }) res: Response // passthrough: false ekleyin
  ) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const clientIp = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;
    
    // Set headers for SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Cache-Control');
  
    console.log("stream controller - received request for bot:", _id);
  
    // Return olmadan direkt çağır
    await this.botsService.streamInteractWithAssistant(
      _id,
      botInteraction,
      clientIp,
      req.headers["user-agent"],
      res
    );
    
    // Response'u service handle ediyor, return etmeyin
  }

  @Delete("v2/:id")
  async remove_chatbot(
    @Param("id", new isObjectIdPipe()) bot_id: string, 
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_bot(bot_id);
    }

    throw new ForbiddenException();
  }

  @Patch("v2/:id")
  async update_chatbot(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Body() update_bot_config: UpdateBotConfigDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.update_bot(bot_id, update_bot_config);
    }

    throw new ForbiddenException();
  }

  @Put("v2/:id/tags")
  async update_tags(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Body() update_bot_config: { tags: string[] },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.update_tags(bot_id, update_bot_config.tags);
    }


    throw new ForbiddenException();
  }

  @Public()
  @Post("v2/:id/interact")
  async interact_with_chatbot(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Body() bot_interaction: BotInteractionDto,
    @Req() req
  ) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const ip = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;

    return this.botsService.chatbot_interaction(
      bot_id,
      bot_interaction,
      ip,
      req.headers["user-agent"]
    );
  }

  @Public()
  @Post("v2/retrieve")
  async check_response(@Body() message_retrieve: MessageRetrieveDto) {
    const bot = await this.botsService.findOne({ _id: message_retrieve.bid });
    if (!bot) throw new NotFoundException("bots.not-found");

    return this.botsService.retrieve_chatbot_response(
      message_retrieve.sid,
      message_retrieve.did,
      bot._id,
      message_retrieve.is_demo
    );
  }

  @Public()
  @Get("v2/:id/fetch-sessions")
  async sessions_by_device(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Query("device_id") device_id: string,
    @Query("sr") set_readed: string
  ) {
    if (!device_id) throw new HttpException("device_id is required", 400);

    const bot = await this.botsService.findOne({ _id: bot_id });
    if (!bot) throw new NotFoundException("bots.not-found");

    return this.botsService.get_sessions_by_device(
      device_id,
      bot_id,
      set_readed === "1"
    );
  }

  @Public()
  @Get("v2/:id/fetch-messages")
  async fetch_messages(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Query("session_id") session_id: string,
    @Query("sr") set_readed: string
  ) {
    if (!session_id) throw new HttpException("session_id is required", 400);

    const bot = await this.botsService.findOne({ _id: bot_id });
    if (!bot) throw new NotFoundException("bots.not-found");

    return this.botsService.get_messages_by_session(
      session_id,
      bot_id,
      set_readed === "1"
    );
  }

  @Post("v2/:id/appearance")
  async set_appearance(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() appearance: Appearance,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.set_appearance(_id, appearance);
    }

    throw new ForbiddenException();
  }

  @Post("v2/:id/settings")
  async set_ai_settings(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body()
    settings: {
      model: Models;
      instructions: string;
      fallback_message: string;
      show_ai_indicator: boolean;
      is_survey_disabled: boolean;
    },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.set_ai_settings(_id, settings);
    }

    throw new ForbiddenException();
  }

  @Post("v2/:id/lead-capture")
  async set_lead_capture(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body()
    settings: {
      lead_capture_mode: ShowForm;
    },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.set_lead_capture_mode(
        _id,
        settings.lead_capture_mode
      );
    }

    throw new ForbiddenException();
  }

  @Post("v2/:id/localization")
  async set_localization(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body()
    settings: {
      lead_capture_form_title: string;
      lead_capture_form_description: string;
      name_label: string;
      name_placeholder: string;
      email_label: string;
      email_placeholder: string;
      organization_label: string;
      organization_placeholder: string;
      form_submit_button: string;
      in_chat_email_input_title: string;
      in_chat_email_input_description: string;
      in_chat_email_submit_button_label: string;
      survey_message: string;
      survey_yes: string;
      survey_no: string;
      survey_human: string;
    },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.set_localization(_id, settings);
    }

    throw new ForbiddenException();
  }

  @Public()
  @Get("v2/:id/public")
  async get_public(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Query("do_not_increase_view_count") do_not_increase_view_count: string
  ) {
    // pass second param as true to increase view count
    return this.botsService.get_bot_public(
      {
        _id: bot_id,
      },
      do_not_increase_view_count !== "1"
    );
  }

  @Get("v2/:id/inbox")
  async get_inbox(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Query("p") page: number,
    @Query("s") status: SessionStatus = SessionStatus.OPEN,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_inbox(bot_id, page, status);
    }
  }

  @Post("v2/:id/sessions/:sid/status")
  async updateSessionStatus(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Param("sid") session_id: string,
    @Body() statusData: { status: SessionStatus },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.update_session_status(session_id, statusData.status);
    }
  }

  @Get("v2/:id/submissions")
  async get_submissions(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Query("p") page: number,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_submissions(bot_id, page);
    }
  }

  // @Public()
  // @Get("v2/migrate")
  // async migrate() {
  //   return this.botsService.sync_openai_with_mevo();
  // }

  @Post("/v2/:id/add-openai-key")
  async add_openai_key(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Body() addSecretDto: AddSecretDto,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.add_openai_key(bot_id, addSecretDto);
    }
  }

  @Post("/v2/:id/remove-openai-key")
  async remove_openai_key(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.remove_openai_key(bot_id);
    }
  }

  @Post("/v2/:id/link-assistant")
  async link_assistant(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Body() linkAssistantDto: { assistant_id: string },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.link_assistant(
        bot_id,
        linkAssistantDto.assistant_id
      );
    }
  }

  @Post("v3/create-via-wizard")
  async create_via_wizard_v3(
    @Body() createViaWizardDto: CreateViaWizardDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id: createViaWizardDto.organization,
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.botsService.create_via_wizard_v3(createViaWizardDto);
    }
  }

  @Public()
  @Post("v3/create-via-wizard-public")
  async create_via_wizard_public_v3(
    @Body() createViaWizardDto: CreateViaWizardDto,
  ) {
    return this.botsService.create_via_wizard_v3(createViaWizardDto);
  }

  @Post("v2/create-via-wizard")
  async create_via_wizard(
    @Body() createViaWizardDto: CreateViaWizardDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id: createViaWizardDto.organization,
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.botsService.create_via_wizard(createViaWizardDto);
    }
  }

  @Post("v2/link-google-sheet")
  async link_google_sheet(
    @Body() linkGoogleSheetDto: { spreadsheet_id: string, spreadsheet_name: string; bot_id: string },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: linkGoogleSheetDto.bot_id });
    if (!bot) throw new NotFoundException("bots.not-found");

    const organization = await this.organizationsService.findOne({
      _id: bot.organization
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.botsService.link_google_sheet(linkGoogleSheetDto.bot_id, linkGoogleSheetDto.spreadsheet_id, linkGoogleSheetDto.spreadsheet_name, request.user);
    }
  }

  @Post("v2/unlink-google-sheet")
  async unlink_google_sheet(
    @Body() linkGoogleSheetDto: { bot_id: string },
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: linkGoogleSheetDto.bot_id });
    if (!bot) throw new NotFoundException("bots.not-found");

    const organization = await this.organizationsService.findOne({
      _id: bot.organization
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.botsService.unlink_google_sheet(linkGoogleSheetDto.bot_id);
    }
  }

  // @Public()
  // @Get("/v2/experiment")
  // async experiment() {
  //   return this.botsService.inspect();
  // }

  // @Public()
  // @Post("v2/:id/create-file")
  // async create_file(@Param("id", new isObjectIdPipe()) _id: string) {
  //   return this.botsService.addContentToVectorStore(
  //     "6625a04bf752ba678346a222",
  //     "sürecek şampiyonluklar biz istedikçe",
  //     "vs_BlKc4FbRUp35f6ZvfPIuwCvt"
  //   );
  // }

  // @Public()
  // @Post("v2/:id/remove-file")
  // async remove_file(@Param("id", new isObjectIdPipe()) _id: string) {
  //   return this.botsService.deleteVectorStore(
  //     "6625a04bf752ba678346a222",
  //     "vs_BlKc4FbRUp35f6ZvfPIuwCvt"
  //   );

  //   // return this.botsService.deleteContentFromVectorStore(
  //   //   "6625a04bf752ba678346a222",
  //   //   "file-GwfNg86nX8Nke7UEgAWLprX6"
  //   // );
  // }

  @Get("v3/:id/inbox")
  async get_inbox_v3(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Query("p") page: number,
    @Query("f") filter: InboxFilter = InboxFilter.AI_ALL,
    @Req() request: RequestWithUser
  ) {
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.botsService.get_inbox_v3(bot_id, page, filter);
    }
  }

  @Public()
  @Post("v3/:id/process-node")
  async process_node(
    @Param("id", new isObjectIdPipe()) bot_id: string,
    @Body() processNodeDto: ProcessNodeDto,
    @Req() req
  ) {
    const xForwardedFor = req.headers["x-forwarded-for"];
    const ip = xForwardedFor ? xForwardedFor.split(",")[0] : req.ip;
    const bot = await this.botsService.findOne({ _id: bot_id });

    if (processNodeDto.message) {
      return this.botsService.process_node(
        bot,
        processNodeDto.nodeId,
        processNodeDto.sessionId,
        processNodeDto.deviceId,
        ip,
        req.headers["user-agent"],
        processNodeDto.message,
        processNodeDto.is_demo
      );
    }

    return this.botsService.process_node(bot, processNodeDto.nodeId, 
        processNodeDto.sessionId,
        processNodeDto.deviceId,
        ip,
        req.headers["user-agent"],
        undefined,
        processNodeDto.is_demo)
  }

  @Public()
  @Post("find-or-create-by-url")
  @SkipThrottle() // Custom IP-based daily limiting implemented in service
  async findOrCreateBotByUrl(
    @Body('url') url: string,
    @Req() req: any,
  ) {
    if (!url) {
      throw new HttpException('URL is required', 400);
    }

    // Get the client IP
    const clientIp = req.headers['x-forwarded-for'] || 
                     req.headers['x-real-ip'] || 
                     req.connection.remoteAddress || 
                     req.socket.remoteAddress ||
                     (req.connection.socket ? req.connection.socket.remoteAddress : null);

    try {
      const result = await this.botsService.findOrCreateBotByUrl(url, clientIp);
      return result;
    } catch (error) {
      // Rate limiting error'unu proper status code ile dön
      if (error instanceof HttpException && error.getStatus() === 429) {
        throw new HttpException(
          {
            success: false,
            error: 'RATE_LIMIT_EXCEEDED',
            message: error.message
          },
          429
        );
      }
      
      // Diğer hatalar
      if (error instanceof HttpException) {
        throw error;
      }
      
      // Unknown errors
      throw new HttpException(
        {
          success: false,
          error: 'BOT_CREATION_FAILED',
          message: 'Failed to find or create bot'
        },
        500
      );
    }
  }
}
