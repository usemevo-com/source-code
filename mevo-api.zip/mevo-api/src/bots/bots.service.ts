import axios from "axios";
import * as fs from "fs";
import * as officeParser from "officeparser";
import * as xml2js from "xml2js";
import { v4 as uuidv4 } from 'uuid';
import * as zlib from "zlib";
const md5 = require("md5");
// const scrapingbee = require('scrapingbee');
import { HttpService } from "@nestjs/axios";
import * as cheerio from "cheerio";
import { Vibrant } from "node-vibrant/node"
import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import * as tf from "@tensorflow/tfjs-node";
import { ApifyClient } from "apify-client";
import { AxiosError } from "axios";
import { ObjectId } from "bson";
import { parse } from "csv-parse/sync";
import * as geoip from "geoip-lite";
import mongoose, { Model } from "mongoose";
import OpenAI from "openai";
import { catchError, firstValueFrom } from "rxjs";
import { randomHex } from "src/auth/helpers/random-hex";
import { send_telegram_notification } from "src/common/helpers/telegram-notifier";
import { Lead, LeadDocument } from "src/leads/entities/lead.schema";
import { AddSecretDto } from "src/organizations/dto/add-secret.dto";
import { RemoveSecretDto } from "src/organizations/dto/remove-secret.dto";
import {
  Period,
  PeriodDocument,
} from "src/subscriptions/entities/period.schema";
import {
  UserResponse,
  UserResponseDocument,
} from "src/user-responses/entities/user-response.schema";
import { User, UserDocument } from "src/users/entities/user.schema";
import * as tmp from "tmp";
import * as UAParser from "ua-parser-js";
import { decrypt, encrypt } from "../common/helpers/crypto";
import { HttpResponseWithMessage } from "../common/helpers/response";
import { sendTemplateMail } from "../common/helpers/send-mail";
import {
  Organization,
  OrganizationDocument,
} from "../organizations/entities/organization.schema";
import { PlanType, Plans } from "../organizations/entities/plan";
import {
  Secret,
  SecretDocument,
  SecretKey,
} from "../organizations/entities/secret.schema";
import { UserResponsesService } from "../user-responses/user-responses.service";
import { AddProductDto } from "./dto/add-product.dto";
import { AddQuestionDto } from "./dto/add-question.dto";
import { BotEventDto } from "./dto/bot-event.dto";
import { BotInteractionDto } from "./dto/bot-interaction.dto";
import { CreateBotDto } from "./dto/create-bot.dto";
import { CreateViaWizardDto } from "./dto/create-via-wizard.dto";
import { EditProductDto } from "./dto/edit-product.dto";
import { EditQuestionDto } from "./dto/edit-question.dto";
import { EditTextDto } from "./dto/edit-text.dto";
import { LinkDomainDto } from "./dto/link-domain.dto";
import { NotificationReceiverDto } from "./dto/notification-receiver.dto";
import { ReplyViaEmailDto } from "./dto/reply-via-email.dto";
import { UpdateBotConfigDto } from "./dto/update-bot-config.dto";
import { UpdateBotDto } from "./dto/update-bot.dto";
import { Appearance, BotPosition, BotTheme } from "./entities/bot-design";
import { BotEventType } from "./entities/bot-event-type";
import { BotFlow, BotFlowChild, BotResponseSubTypes, BotType, FlowEventType, Models, NodeType } from "./entities/bot-type";
import { Bot, BotDocument, ShowForm } from "./entities/bot.schema";
import {
  Embedding,
  EmbeddingDocument,
  EmbeddingType,
} from "./entities/embedding.schema";
import { File, FileDocument } from "./entities/file.schema";
import { Link, LinkDocument } from "./entities/link.schema";
import {
  InboxFilter,
  Message,
  MessageDocument,
  MessageSender,
  SessionStatus,
} from "./entities/message.schema";
import { News, NewsDocument } from "./entities/news.schema";
import {
  NotificationReceiver,
  NotificationReceiverDocument,
  NotificationType,
} from "./entities/notification-receiver.schema";
import { IpTracking, IpTrackingDocument } from "./entities/ip-tracking.schema";
import { Product, ProductDocument } from "./entities/product.schema";
import { Question, QuestionDocument } from "./entities/question.schema";
import { Text, TextDocument } from "./entities/text.schema";
import { Thread, ThreadDocument } from "./entities/thread.schema";
import { ClarityCache, ClarityCacheDocument } from "./entities/clarity-cache.schema";
const nlp = require("compromise");
import { Response } from 'express';
import * as sharp from "sharp";
import * as path from "path";
import * as os from "os";
import { Session, SessionDocument } from "./entities/session.schema";
import { ResponseFile, ResponseFileDocument } from "./entities/response-file.schema";
import { StorageService } from "../common/helpers/storage.service";
import { hasAdminAccess, hasUserAccess } from "../auth/helpers/has-access";
const { pipeline } = require('stream')            // callback’li pipeline
const { promisify } = require('util')          

@Injectable()
export class BotsService {
  constructor(
    private configService: ConfigService,
    private readonly httpService: HttpService,
    @InjectModel(Period.name)
    private periodModel: Model<PeriodDocument>,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Message.name)
    private messageModel: Model<MessageDocument>,
    @InjectModel(Session.name)
    private sessionModel: Model<SessionDocument>,
    @InjectModel(Thread.name)
    private threadModel: Model<ThreadDocument>,
    @InjectModel(Embedding.name)
    private embeddingModel: Model<EmbeddingDocument>,
    @InjectModel(Secret.name)
    private secretModel: Model<SecretDocument>,
    @InjectModel(Lead.name)
    private leadModel: Model<LeadDocument>,
    @InjectModel(Link.name)
    private linkModel: Model<LinkDocument>,
    @InjectModel(Product.name)
    private productModel: Model<ProductDocument>,
    @InjectModel(File.name)
    private fileModel: Model<FileDocument>,
    @InjectModel(Text.name)
    private textModel: Model<TextDocument>,
    @InjectModel(Question.name)
    private questionModel: Model<QuestionDocument>,
    @InjectModel(User.name)
    private userModel: Model<UserDocument>,
    @InjectModel(UserResponse.name)
    private userResponseModel: Model<UserResponseDocument>,
    @InjectModel(NotificationReceiver.name)
    private notificationReceiverModel: Model<NotificationReceiverDocument>,
    @InjectModel(News.name)
    private newsModel: Model<NewsDocument>,
    @InjectModel(IpTracking.name)
    private ipTrackingModel: Model<IpTrackingDocument>,
    @InjectModel(ClarityCache.name)
    private clarityCacheModel: Model<ClarityCacheDocument>,
    @InjectModel(ResponseFile.name)
    private responseFileModel: Model<ResponseFileDocument>,
    @InjectConnection() private readonly connection: mongoose.Connection,
    private readonly userResponsesService: UserResponsesService,
    private readonly storageService: StorageService,
  ) {}

  async createResponseFileUpload(params: {
    botId: string;
    file: any;
    stepId: string;
    ip: string;
    ua: string;
    deviceId?: string;
  }) {
    const { botId, file, stepId, ip, ua, deviceId } = params;
    if (!file) {
      throw new HttpException("files.FILE_REQUIRED", HttpStatus.BAD_REQUEST);
    }

    const bot = await this.botModel
      .findOne({ $and: [{ _id: botId }, { isRemoved: { $ne: true } }] })
      .exec();
    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    // Size limit double-check (multer already enforces but keep server-side too)
    if (file.size > 10 * 1024 * 1024) {
      throw new HttpException(
        "files.FILE_TOO_LARGE",
        HttpStatus.BAD_REQUEST
      );
    }

    // rate limit: max 2 uploads in last hour per deviceId or per ip+ua
    const oneHourAgo = new Date(Date.now() - 3600 * 1000);
    const rateLimitCount = await this.responseFileModel.countDocuments({
      bot: bot._id,
      createdAt: { $gte: oneHourAgo },
      $or: [
        ...(deviceId ? [{ uploadedByDeviceId: deviceId }] : []),
        { uploadedByIp: ip, uploadedByUA: ua },
      ],
    });
    if (rateLimitCount >= 2) {
      throw new HttpException(
        "files.WAIT_1_HOUR_BEFORE_UPLOADING_MORE",
        HttpStatus.TOO_MANY_REQUESTS
      );
    }

    // 1) Validate step belongs to bot and requires file
    const isFileStep = (() => {
      try {
        const flow: any = bot.flow;
        if (!flow || !flow.length) return false;
        const dfs = (node: any): any | null => {
          if (!node) return null;
          if (node.id === stepId) return node;
          if (!node.children) return null;
          for (const child of node.children) {
            const found = dfs(child);
            if (found) return found;
          }
          return null;
        };
        const root = Array.isArray(flow) ? flow[0] : flow;
        const target = dfs(root);
        if (!target) return false;
        const type = target?.data?.type || target?.type;
        const validationType = target?.data?.content?.[0]?.content?.validation?.type || target?.data?.content?.validation?.type;
        return String(type) === 'question' && String(validationType) === 'file';
      } catch {
        return false;
      }
    })();
    if (!isFileStep) {
      throw new HttpException("files.INVALID_STEP_FOR_UPLOAD", HttpStatus.BAD_REQUEST);
    }

    // 2) MIME sniffing and allow-list (no external dep)
    const inferMimeFromMagic = (buf: Buffer, filename: string, fallback: string): string => {
      const ext = (filename.split('.').pop() || '').toLowerCase();
      const b = (n: number) => buf.subarray(0, n);
      const startsWith = (hex: number[]) => hex.every((h, i) => buf[i] === h);
      try {
        if (startsWith([0x25,0x50,0x44,0x46,0x2D])) return 'application/pdf'; // %PDF-
        if (startsWith([0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A])) return 'image/png'; // PNG
        if (startsWith([0xFF,0xD8,0xFF])) return 'image/jpeg'; // JPG
        if (b(6).toString('ascii') === 'GIF87a' || b(6).toString('ascii') === 'GIF89a') return 'image/gif';
        if (b(4).toString('ascii') === 'RIFF' && buf.subarray(8,12).toString('ascii') === 'WEBP') return 'image/webp';
        if (b(8).toString('ascii').toLowerCase().includes('<svg') || b(80).toString('utf8').toLowerCase().includes('<svg')) return 'image/svg+xml';
        if (startsWith([0xD0,0xCF,0x11,0xE0,0xA1,0xB1,0x1A,0xE1])) {
          // old office formats by extension
          if ([ 'doc', 'dot' ].includes(ext)) return 'application/msword';
          if ([ 'xls' ].includes(ext)) return 'application/vnd.ms-excel';
          if ([ 'ppt' ].includes(ext)) return 'application/vnd.ms-powerpoint';
        }
        if (startsWith([0x50,0x4B,0x03,0x04])) {
          // OOXML based on extension
          if (ext === 'docx') return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
          if (ext === 'xlsx') return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          if (ext === 'pptx') return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
        }
      } catch {}
      return (fallback || '').toLowerCase();
    };
    const sniffed = inferMimeFromMagic(file.buffer, file.originalname || '', file.mimetype || '');
    const allowedMimes = new Set<string>([
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'image/jpeg','image/png','image/gif','image/webp','image/svg+xml',
    ]);
    if (!allowedMimes.has(sniffed)) {
      throw new HttpException('files.UNSUPPORTED_TYPE', HttpStatus.BAD_REQUEST);
    }

    // 3) Optional AV scan hook
    if (process.env.FILE_SCAN_ENABLED === 'true') {
      try {
        // Placeholder: integrate ClamAV or external scanner here
        // e.g., await scanBufferWithClamAV(file.buffer)
      } catch {
        throw new HttpException("files.MALWARE_DETECTED", HttpStatus.BAD_REQUEST);
      }
    }

    const safeName = (file.originalname || "upload")
      .replace(/[^a-zA-Z0-9._-]+/g, "-")
      .slice(0, 140);
    const uuid = (await import("uuid")).v4();
    const orgId = bot.organization?._id?.toString?.() || bot.organization?.toString?.() || "org";
    const key = `org/${orgId}/bots/${bot._id}/responses/${uuid}-${safeName}`;

    await this.storageService.putObject({
      key,
      body: file.buffer,
      contentType: sniffed || undefined,
    });

    const created = new this.responseFileModel({
      bot: bot._id,
      organization: bot.organization,
      stepId,
      key,
      size: file.size,
      contentType: sniffed,
      originalName: file.originalname,
      uploadedByIp: ip,
      uploadedByUA: ua,
      uploadedByDeviceId: deviceId,
    });
    await created.save();

    return { id: created._id.toString() };
  }

  async getResponseFileSignedUrl(id: string, user: any) {
    const doc = await this.responseFileModel.findById(id).exec();
    if (!doc) {
      throw new HttpException("files.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    const bot = await this.botModel.findById(doc.bot).exec();
    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    // Access control: user must be admin or user in the same organization
    if (!(hasAdminAccess(bot.organization, user) || hasUserAccess(bot.organization, user))) {
      throw new HttpException("auth.FORBIDDEN", HttpStatus.FORBIDDEN);
    }

    const url = await this.storageService.getSignedUrl(doc.key, 60, doc.originalName || undefined);
    return { url };
  }

  

  async assign_bot_to_user(botId: string, userId: string) {
    try {
      // Find user and organization
      const user = await this.userModel.findById(new ObjectId(userId)).exec();
      if (!user) {
        throw new HttpException(
          "User not found",
          HttpStatus.NOT_FOUND
        );
      }
  
      const organization = await this.organizationModel
        .findOne({ admins: { $in: [new ObjectId(userId)] } })
        .exec();
      if (!organization) {
        throw new HttpException(
          "Organization not found or user is not an admin",
          HttpStatus.FORBIDDEN
        );
      }
  
      // Find bot WITHOUT populate to avoid autopopulate issues
      // Populate'siz bot çekme
      const bot = await this.botModel.findById(new ObjectId(botId)).exec();
      if (!bot) {
        throw new HttpException(
          "Bot not found",
          HttpStatus.NOT_FOUND
        );
      }
  
      // Create new ObjectId instances to ensure clean assignment
      // const organizationId = new ObjectId(organization._id);
      // const userId_obj = new ObjectId(user._id);
  
      // Update bot with explicit unset and set operations
      const updateResult = await this.botModel.updateOne(
        { _id: new ObjectId(botId) }, 
        { 
          $set: { 
            organization: organization._id.toString(),
            createdBy: user._id,
          }
        }
      );
  
      if (updateResult.modifiedCount === 0) {
        throw new HttpException(
          "Bot could not be updated",
          HttpStatus.INTERNAL_SERVER_ERROR
        );
      }

      // activate all provisioned links, add them to scraping queue
      await this.linkModel.updateMany(
        { bot: botId, isProvisioned: { $ne: false } },
        { $set: { isProvisioned: false }},
      );

      return {
        success: true,
        message: "Bot successfully assigned to user",
      };
  
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }
      
      console.error("Error in assign_bot_to_user:", error);
      throw new HttpException(
        "An error occurred while assigning bot to user",
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  // link training queue
  // all links has with status onhold must be visited and adding to knowledge base 5 by 5
  // if organization has no training credits, email should have sent

  // NON-AUTH
  // someone came to mevo, enter the website
  // we're created the sitemap, there 100 links in the map
  // user has selected 90 of them
  // since this is a public request, we're choosing the / link for training
  // we're creating provisioned links but won't train them since training character limit is exceeded, assign them a ttl as 3 days
  // a cron job should run every day and remove all the provisioned links that are older than 3 days
  // if user complete the bot creation, while bot assignment process, add provisioned links to training queue
  // send an email to training character limit excedeed

  // AUTH
  // user came to bot creation
  // user choosed the pages to train
  // once bot created, all the links must have added into training queue (status onhold)

  async scrape_urls(urls: string[], botId: string, is_public: boolean = false) {
    if (is_public) {
      let rootPath;

      try {
        const slash_split = urls[0].split('/');
        rootPath = slash_split[0] + '/' + slash_split[1] + '/' + slash_split[2] + '/';
      } catch {
        rootPath = urls[0];
      }

      await this.persist_link(botId, rootPath, 10)

      let rootLink = await this.linkModel.findOne({
        url: rootPath,
        bot: botId
      }).exec();
      
      let i = 0;

      while (typeof rootLink.processedAt === 'undefined' && i < 10) {
        await new Promise(resolve => setTimeout(resolve, 3000));
        rootLink = await this.linkModel.findOne({
          url: rootPath,
          bot: botId
        }).exec();
        i++;
      }
    }
    // persist all the links and set them provisioned
    console.log('provisioning other urls');
    await Promise.allSettled(
      urls.map((u) => this.persist_link(botId, u, 0, is_public)),
    );
  
    return true;
  }

  cleanUrl(input: string): string {
    // Trim, baştaki/sondaki boşluk ve satır sonlarını temizle
    let url = input.trim();
    // Satır içindeki yeni satır karakterlerini ve fazlalıkları temizle
    url = url.replace(/[\r\n]+/g, "");
    // Başta ve sonda boşluk varsa tekrar temizle
    url = url.trim();
    // Eğer url birden fazla kelime içeriyorsa, ilk http ile başlayan kısmı al
    const match = url.match(/https?:\/\/[^\s]+/);
    if (match) return match[0];
    return url;
  }

  async scrape_url(targetUrl: string, botId: string, generate_starter = false) {
    console.log('scraping url', targetUrl, 'generate_starter', generate_starter);
    const token = this.configService.get<string>("SCRAPE_DO_API_KEY");
    const cleaned_url = this.cleanUrl(targetUrl);
    const config = {
        'method': 'GET',
        'url': `https://api.scrape.do/?token=${token}&url=${cleaned_url}&output=markdown`,
        'headers': {}
    };

    try {
      const bot = await this.botModel.findById(botId).exec();
      const organization = await this.organizationModel.findById(bot.organization).exec();

      const is_exceeded = organization.trainingCharacterExceeded;

      if (is_exceeded) {
        throw new HttpException('bots.TRAINING_CHARACTER_LIMIT_EXCEEDED', HttpStatus.BAD_REQUEST);
      }

      // get the content of the url by scraping it
      const content = await axios.get(config.url);

      // update the link with the content
      await this.linkModel.updateOne({
        url: targetUrl,
        bot: botId
      }, {
        $set: {
          content: content.data,
          characterCount: content.data.length | 0,
        }
      })

      if (generate_starter) {
        console.log('generating starters');
        try {
          const bot = await this.botModel.findById(botId).exec();

          if (bot.fromTemplate && bot.fromTemplate !== 'customer_service') {
            console.log('generating questions')
            const question_and_answers = await this.generate_starter(
              botId,
              content.data,
              [],
              2
            );

            console.log('generated questions', question_and_answers)
    
            const bot = await this.botModel.findById(botId).exec();

            bot.flow[0].children[2].data.content[1].content.replies = question_and_answers.map((qa) => qa.question);
            bot.flow[0].children[2].children[0].data.content.sentences = [{ id: uuidv4(), sentence: question_and_answers[0].question }];
            bot.flow[0].children[2].children[0].data.content.keywords = [];
            bot.flow[0].children[2].children[0].children[0].data.content = [{ type: "message", content: question_and_answers[0].answer }];
            bot.flow[0].children[2].children[1].data.content.sentences = [{ id: uuidv4(), sentence: question_and_answers[1].question }];
            bot.flow[0].children[2].children[1].data.content.keywords = [];
            bot.flow[0].children[2].children[1].children[0].data.content = [{ type: "message", content: question_and_answers[1].answer }];

            await this.botModel.findByIdAndUpdate(botId, { $set: { flow: bot.flow } }).exec();
            console.log('saved new changes to bot')
          }
        } catch (error) {}
      }
      
      return true;
    } catch (error) {
      console.log('something bad happened', error)
      return false;
    } 
  }

  async get_news(bot_id: string) {
    const news = await this.newsModel.find({ bot: bot_id }).exec();
    return news;
  }

  async update_receivers(_id: string, receivers: string[]) {
    const bot = await this.botModel.findById(_id).exec();
    bot.emailReceivers = receivers;
    await bot.save();
    return bot.emailReceivers;
  }

  async reply_via_email(replyViaEmailDto: ReplyViaEmailDto, user: User) {
    const bot = await this.botModel.findById(replyViaEmailDto.bot).exec();
    const lead = await this.leadModel
      .findOne({ device_id: replyViaEmailDto.device_id })
      .exec();
    const organization = await this.organizationModel
      .findById(bot.organization)
      .exec();
    // Check if lead exists
    if (!lead) {
      throw new HttpException("bots.LEAD_NOT_FOUND", HttpStatus.BAD_REQUEST);
    }

    const period = await this.periodModel
      .findById(bot.organization.activePeriod)
      .exec();

    if (period.email_usage >= Plans[organization.plan].limits.email_limit) {
      throw new HttpException(
        "bots.EMAIL_LIMIT_REACHED",
        HttpStatus.BAD_REQUEST
      );
    }

    // save message locally first
    const message = new this.messageModel({
      content: replyViaEmailDto.message,
      bot: bot._id,
      sender: MessageSender.AGENT,
      senderMeta: {
        _id: user._id,
        name: user.name,
        title: 'Customer Support Specialist',
        photo: `https://gravatar.com/avatar/${md5(user.email)}`,
      },
      did: lead.device_id,
      session: replyViaEmailDto.session_id,
      ip: "127.0.0.1",
      notificationSent: true,
    });

    await message.save();

    // get all messages for this session
    const messages = await this.messageModel
      .find({
        bot: bot._id,
        did: lead.device_id,
        session: replyViaEmailDto.session_id,
      })
      .exec();

    // send email to lead
    await sendTemplateMail("agent-reply", lead.email, {
      message: replyViaEmailDto.message,
      bot: bot._id,
      organization: bot.organization.name,
      agent: user.name,
      session: replyViaEmailDto.session_id,
      device_id: lead.device_id,
    });

    await this.increase_email_usage(bot);

    return true;
  }

  async validate_openai_key(key: string) {
    const openai = new OpenAI({
      apiKey: key,
    });

    try {
      await openai.beta.assistants.list();
      return true;
    } catch (err) {
      return false;
    }
  }

  async scan_website(url: string, single_page: boolean) {
    // 1. check url, if it doesn't start with http or https, add https://
    let targetUrl = url.trim();
    if (!/^https?:\/\//i.test(targetUrl)) {
      targetUrl = "https://" + targetUrl;
    }
  
    // 2. check if there is a sitemap.xml
    let sitemapUrls: string[] = [];
    
    try {
      // Try to fetch robots.txt and look for all sitemap entries
      const robotsRes = await axios.get(new URL("/robots.txt", targetUrl).href, { timeout: 5000 });
      const sitemapLines = robotsRes.data
        .split("\n")
        .filter((line: string) => line.toLowerCase().startsWith("sitemap:"))
        .map((line: string) => line.toLowerCase().split("sitemap:")[1].trim());
  
      if (sitemapLines.length > 0) {
        sitemapUrls = sitemapLines;
      } else {
        sitemapUrls = [new URL("/sitemap.xml", targetUrl).href.trim()];
      }
    } catch {
      // fallback to /sitemap.xml
      sitemapUrls = [new URL("/sitemap.xml", targetUrl).href.trim()];
    }
  
    // 3. if single_page is true, return simple structure
    if (single_page) {
      return {
        urlset: {
          url: [
            { loc: targetUrl }
          ]
        }
      };
    }
  
    // 4. fetch and parse all sitemaps
    const allUrls = [];
    
    for (const sitemapUrl of sitemapUrls) {
      try {
        const sitemapRes = await axios.get(sitemapUrl, { 
          timeout: 30000,
          responseType: sitemapUrl.endsWith('.gz') ? 'arraybuffer' : 'text'
        });
        
        let xml = sitemapRes.data;
        
        // .gz uzantılı dosyaysa decompress et
        if (sitemapUrl.endsWith('.gz')) {
          xml = zlib.gunzipSync(Buffer.from(xml)).toString('utf8');
        }
        
        const json = await xml2js.parseStringPromise(xml, { explicitArray: false });
  
        // Extract URLs from this sitemap
        if (json.urlset && json.urlset.url) {
          const urls = Array.isArray(json.urlset.url) ? json.urlset.url : [json.urlset.url];
          allUrls.push(...urls);
        }
        
        // Handle sitemap index files
        if (json.sitemapindex && json.sitemapindex.sitemap) {
          const sitemaps = Array.isArray(json.sitemapindex.sitemap) ? json.sitemapindex.sitemap : [json.sitemapindex.sitemap];
          
          for (const sitemap of sitemaps) {
            if (sitemap.loc) {
              try {
                const subSitemapRes = await axios.get(sitemap.loc, { 
                  timeout: 30000,
                  responseType: sitemap.loc.endsWith('.gz') ? 'arraybuffer' : 'text'
                });
                
                let subXml = subSitemapRes.data;
                
                // .gz uzantılı dosyaysa decompress et
                if (sitemap.loc.endsWith('.gz')) {
                  subXml = zlib.gunzipSync(Buffer.from(subXml)).toString('utf8');
                }
                
                const subJson = await xml2js.parseStringPromise(subXml, { explicitArray: false });
                
                if (subJson.urlset && subJson.urlset.url) {
                  const subUrls = Array.isArray(subJson.urlset.url) ? subJson.urlset.url : [subJson.urlset.url];
                  allUrls.push(...subUrls);
                }
              } catch (subErr) {
                console.log(`Error processing sub-sitemap ${sitemap.loc}:`, subErr);
              }
            }
          }
        }
      } catch (err) {
        console.log(`Error processing sitemap ${sitemapUrl}:`, err);
      }
    }
  
    // 5. return combined results
    if (allUrls.length === 0) {
      throw new HttpException('bots.SITEMAP_NOT_FOUND', HttpStatus.BAD_REQUEST);
    }
  
    return {
      urlset: {
        url: allUrls
      }
    };
  }

  // async scan_website(url: string, single_page: boolean) {
  //   // 1. check url, if it doesn't start with http or https, add https://
  //   let targetUrl = url.trim();
  //   if (!/^https?:\/\//i.test(targetUrl)) {
  //     targetUrl = "https://" + targetUrl;
  //   }

  //   // 2. if single_page is true, return the urlset with the targetUrl
  //   if (single_page) {
  //     return {
  //       urlset: {
  //         url: [
  //           { loc: targetUrl }
  //         ]
  //       }
  //     };
  //   }

  //   // 3. check if there is a sitemap.xml
  //   let sitemapUrl: string;
  //   try {
  //     // Try to fetch robots.txt and look for sitemap
  //     const robotsRes = await axios.get(new URL("/robots.txt", targetUrl).href, { timeout: 5000 });
  //     const sitemapLine = robotsRes.data
  //       .split("\n")
  //       .find((line: string) => line.toLowerCase().startsWith("sitemap:"));

  //     if (sitemapLine) {
  //       sitemapUrl = sitemapLine.toLowerCase().split("sitemap:")[1].trim();
  //     } else {
  //       sitemapUrl = new URL("/sitemap.xml", targetUrl).href.trim();
  //     }
  //   } catch {
  //     // fallback to /sitemap.xml
  //     sitemapUrl = new URL("/sitemap.xml", targetUrl).href.trim();
  //   }

  //   // 4. if it's exist, get the value of sitemap.xml and convert it to json
  //    try {
  //     const sitemapRes = await axios.get(sitemapUrl, { 
  //       timeout: 30000,
  //       responseType: sitemapUrl.endsWith('.gz') ? 'arraybuffer' : 'text'
  //     });
      
  //     let xml = sitemapRes.data;
      
  //     // .gz uzantılı dosyaysa decompress et
  //     if (sitemapUrl.endsWith('.gz')) {
  //       xml = zlib.gunzipSync(Buffer.from(xml)).toString('utf8');
  //     }
      
  //     const json = await xml2js.parseStringPromise(xml, { explicitArray: false });

  //     return json;
  //   } catch (err) {
  //     throw new HttpException('bots.SITEMAP_NOT_FOUND', HttpStatus.BAD_REQUEST);
  //   }
  // }

  async create_via_wizard_v3(payload: CreateViaWizardDto) {
    let created_bot_id;
    try {
      if (!payload.createdBy) {
        payload.createdBy = this.configService.get('DEFAULT_CREATED_BY');
        payload.organization = this.configService.get('DEFAULT_ORGANIZATION');
      }
      
      const user = await this.userModel.findById(payload.createdBy).exec();
      const organization = await this.organizationModel
        .findById(payload.organization)
        .exec();
        
      if (!user) {
        throw new HttpException(
          `User not found: ${payload.createdBy}`,
          HttpStatus.BAD_REQUEST,
        );
      }
      
      if (!organization) {
        throw new HttpException(
          `Organization not found: ${payload.organization}`,
          HttpStatus.BAD_REQUEST,
        );
      }
      
      // create bot

      // initial flow
      const flow_templates = {
        from_scratch: [
          {
            "id": "0",
            "type": "start",
            "data": {
              "label": "Start",
              "id": "0",
              "type": "start",
              "content": [],
              "is_active": true
            },
            "position": {
              "x": 1320.1439714928665,
              "y": 1.9563632455442708
            },
            "draggable": true,
            "children": [
              {
                "id": "1",
                "type": "special",
                "data": {
                  "label": "bot response",
                  "id": "1",
                  "type": "bot-response",
                  "content": [
                    {
                      "type": "message",
                      "content": "Could you kindly provide more information for better understanding?"
                    }
                  ],
                  "is_active": false
                },
                "position": {
                  "x": 5.084661905361173,
                  "y": 142.08936978353887
                },
                "draggable": true,
                "children": []
              },
              {
                "id": "2",
                "type": "special",
                "data": {
                  "label": "When AI respond",
                  "id": "2",
                  "type": "ai-assist",
                  "content": [],
                  "is_active": false
                },
                "position": {
                  "x": 541.0994863747526,
                  "y": 141.37196781815985
                },
                "draggable": true,
                "children": []
              },
              {
                "id": "3",
                "type": "special",
                "data": {
                  "label": "First message sent",
                  "id": "3",
                  "type": "bot-response",
                  "content": [
                    {
                      "type": "message",
                      "content": "Welcome"
                    },
                    {
                      "type": "quick-reply",
                      "content": {
                        "text": "How can we help you today?",
                        "replies": [
                          "Why cats are better?",
                          "Why dogs are better?"
                        ]
                      }
                    }
                  ],
                  "is_active": false
                },
                "position": {
                  "x": 1208.4464549788618,
                  "y": 137.79541724946202
                },
                "draggable": true,
                "children": [
                  {
                    "id": "5",
                    "type": "special",
                    "data": {
                      "label": "user input",
                      "id": "5",
                      "type": "user-input",
                      "content": {
                        "sentences": [
                          {
                            "id": "cda56a2a-305f-4571-b091-f991fe88dcbd",
                            "sentence": "Why cats are better?"
                          }
                        ],
                        "keywords": [
                          {
                            "id": "ce57a9e0-2312-4afb-982a-3e6d829a4146",
                            "keyword": "cats"
                          }
                        ]
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 1028.4464549788618,
                      "y": 517.795417249462
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "7",
                        "type": "special",
                        "data": {
                          "label": "Cat Path",
                          "id": "7",
                          "type": "bot-response",
                          "content": [
                            {
                              "type": "image",
                              "content": {
                                "url": "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba",
                                "alt": ""
                              }
                            },
                            {
                              "type": "quick-reply",
                              "content": {
                                "text": "Cats are better because they are fluffy and cute.",
                                "replies": [
                                  "Why dogs are better?"
                                ]
                              }
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 1028.4464549788618,
                          "y": 897.795417249462
                        },
                        "draggable": true,
                        "children": []
                      }
                    ]
                  },
                  {
                    "id": "6",
                    "type": "special",
                    "data": {
                      "label": "user input",
                      "id": "6",
                      "type": "user-input",
                      "content": {
                        "sentences": [
                          {
                            "id": "d35e2792-20bf-403b-acd5-97d19b534618",
                            "sentence": "Why dogs are better?"
                          }
                        ],
                        "keywords": [
                          {
                            "id": "638941d3-d069-48e9-8d01-a3865b482d94",
                            "keyword": "dogs"
                          }
                        ]
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 1388.4464549788618,
                      "y": 517.795417249462
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "8",
                        "type": "special",
                        "data": {
                          "label": "Dog Path",
                          "id": "8",
                          "type": "bot-response",
                          "content": [
                            {
                              "type": "image",
                              "content": {
                                "url": "https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?q=80&w=994&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                                "alt": ""
                              }
                            },
                            {
                              "type": "quick-reply",
                              "content": {
                                "text": "Dogs are better because they're loyal and protective.",
                                "replies": [
                                  "Why cats are better?"
                                ]
                              }
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 1388.4464549788618,
                          "y": 897.795417249462
                        },
                        "draggable": true,
                        "children": []
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ],
        candidate_screening: [
          {
            "id": "0",
            "type": "start",
            "data": {
              "label": "Start",
              "id": "0",
              "type": "start",
              "content": [],
              "is_active": true
            },
            "position": {
              "x": 1442.1439714928665,
              "y": 1.9563632455442708
            },
            "draggable": true,
            "children": [
              {
                "id": "1",
                "type": "special",
                "data": {
                  "label": "bot response",
                  "id": "1",
                  "type": "bot-response",
                  "content": [
                    {
                      "type": "message",
                      "content": "Could you kindly provide more information for better understanding?"
                    }
                  ],
                  "is_active": false
                },
                "position": {
                  "x": 5.084661905361173,
                  "y": 142.08936978353887
                },
                "draggable": true,
                "children": []
              },
              {
                "id": "2",
                "type": "special",
                "data": {
                  "label": "When AI respond",
                  "id": "2",
                  "type": "ai-assist",
                  "content": [],
                  "is_active": false
                },
                "position": {
                  "x": 541.0994863747526,
                  "y": 141.37196781815985
                },
                "draggable": true,
                "children": []
              },
              {
                "id": "3",
                "type": "special",
                "data": {
                  "label": "Position Intro",
                  "id": "3",
                  "type": "bot-response",
                  "content": [
                    {
                      "type": "message",
                      "content": "Hello 👋"
                    },
                    {
                      "type": "quick-reply",
                      "content": {
                        "text": "We are building the next generation of web interfaces by providing powerful tools for creating elegant conversational experiences.  At Mevo, we empower businesses to design, train, and deploy AI-driven chatbots faster than ever. Our Flow Builder, integrations, and automation features allow companies to turn complex processes into seamless, human-like conversations.",
                        "replies": [
                          "Continue"
                        ]
                      }
                    }
                  ],
                  "is_active": false
                },
                "position": {
                  "x": 1334.725701259984,
                  "y": 144.6331560928284
                },
                "draggable": true,
                "children": [
                  {
                    "id": "5",
                    "type": "special",
                    "data": {
                      "label": "user input",
                      "id": "5",
                      "type": "user-input",
                      "content": {
                        "sentences": [],
                        "keywords": [
                          {
                            "id": "ce57a9e0-2312-4afb-982a-3e6d829a4146",
                            "keyword": "continue"
                          }
                        ]
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 1030.725701259984,
                      "y": 642.6331560928284
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "10",
                        "type": "special",
                        "data": {
                          "label": "Name?",
                          "id": "10",
                          "type": "question",
                          "content": [
                            {
                              "type": "question",
                              "content": {
                                "question": "What is your full name?",
                                "validation": {
                                  "type": "any",
                                  "errorMessage": "Please enter a valid value."
                                },
                                "attribute": "name",
                                "customKey": "",
                                "verification_required": true
                              }
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 1030.725701259984,
                          "y": 904.6331560928284
                        },
                        "draggable": true,
                        "children": [
                          {
                            "id": "11",
                            "type": "special",
                            "data": {
                              "label": "Email?",
                              "id": "11",
                              "type": "question",
                              "content": [
                                {
                                  "type": "question",
                                  "content": {
                                    "question": "What is your email?",
                                    "validation": {
                                      "type": "email",
                                      "errorMessage": "Please enter a valid email address."
                                    },
                                    "attribute": "email",
                                    "customKey": "",
                                    "verification_required": true
                                  }
                                }
                              ],
                              "is_active": false
                            },
                            "position": {
                              "x": 1030.725701259984,
                              "y": 1284.6331560928284
                            },
                            "draggable": true,
                            "children": [
                              {
                                "id": "6",
                                "type": "special",
                                "data": {
                                  "label": "Resume?",
                                  "id": "6",
                                  "type": "question",
                                  "content": [
                                    {
                                      "type": "question",
                                      "content": {
                                        "question": "Please select your resume to upload before continuing with the following questions.",
                                        "validation": {
                                          "type": "file",
                                          "errorMessage": "Please upload a file (max 10MB)."
                                        },
                                        "attribute": "custom",
                                        "customKey": "resume_file",
                                        "verification_required": false
                                      }
                                    }
                                  ],
                                  "is_active": false
                                },
                                "position": {
                                  "x": 1030.725701259984,
                                  "y": 1664.6331560928284
                                },
                                "draggable": true,
                                "children": [
                                  {
                                    "id": "14",
                                    "type": "special",
                                    "data": {
                                      "label": "LinkedIn?",
                                      "id": "14",
                                      "type": "question",
                                      "content": [
                                        {
                                          "type": "question",
                                          "content": {
                                            "question": "What is your LinkedIn url?",
                                            "validation": {
                                              "type": "url",
                                              "errorMessage": "Please enter a valid URL."
                                            },
                                            "attribute": "custom",
                                            "customKey": "linkedin",
                                            "verification_required": true
                                          }
                                        }
                                      ],
                                      "is_active": false
                                    },
                                    "position": {
                                      "x": 1030.725701259984,
                                      "y": 2044.6331560928284
                                    },
                                    "draggable": true,
                                    "children": [
                                      {
                                        "id": "7",
                                        "type": "special",
                                        "data": {
                                          "label": "Experience?",
                                          "id": "7",
                                          "type": "question",
                                          "content": [
                                            {
                                              "type": "question",
                                              "content": {
                                                "question": "How many years of experience do you have in total?",
                                                "validation": {
                                                  "type": "number",
                                                  "errorMessage": "Please enter a valid number."
                                                },
                                                "attribute": "custom",
                                                "customKey": "years_of_experience",
                                                "verification_required": true
                                              }
                                            }
                                          ],
                                          "is_active": false
                                        },
                                        "position": {
                                          "x": 1030.725701259984,
                                          "y": 2424.6331560928284
                                        },
                                        "draggable": true,
                                        "children": [
                                          {
                                            "id": "8",
                                            "type": "special",
                                            "data": {
                                              "label": "Require Visa?",
                                              "id": "8",
                                              "type": "question",
                                              "content": [
                                                {
                                                  "type": "question",
                                                  "content": {
                                                    "question": "Will you now or in the future require sponsorship for employment visa status?",
                                                    "validation": {
                                                      "type": "yes-no",
                                                      "errorMessage": "Please answer with \"yes\" or \"no\"."
                                                    },
                                                    "attribute": "custom",
                                                    "customKey": "require_visa_sponsorship",
                                                    "verification_required": true
                                                  }
                                                }
                                              ],
                                              "is_active": false
                                            },
                                            "position": {
                                              "x": 1030.725701259984,
                                              "y": 2804.6331560928284
                                            },
                                            "draggable": true,
                                            "children": [
                                              {
                                                "id": "9",
                                                "type": "special",
                                                "data": {
                                                  "label": "Salary?",
                                                  "id": "9",
                                                  "type": "question",
                                                  "content": [
                                                    {
                                                      "type": "question",
                                                      "content": {
                                                        "question": "What is your yearly gross salary expectation as EUR?",
                                                        "validation": {
                                                          "type": "number",
                                                          "errorMessage": "Please enter a valid number."
                                                        },
                                                        "attribute": "custom",
                                                        "customKey": "salary_expectation",
                                                        "verification_required": true
                                                      }
                                                    }
                                                  ],
                                                  "is_active": false
                                                },
                                                "position": {
                                                  "x": 1030.725701259984,
                                                  "y": 3184.6331560928284
                                                },
                                                "draggable": true,
                                                "children": [
                                                  {
                                                    "id": "16",
                                                    "type": "special",
                                                    "data": {
                                                      "label": "Reject if not met conditions",
                                                      "id": "16",
                                                      "type": "go-to-block",
                                                      "content": {
                                                        "targetStepId": "20",
                                                        "conditions": [
                                                          {
                                                            "operator": "lt",
                                                            "key": "years_of_experience",
                                                            "value": 5
                                                          },
                                                          {
                                                            "operator": "gt",
                                                            "key": "salary_expectation",
                                                            "value": 80000
                                                          },
                                                          {
                                                            "operator": "eq",
                                                            "key": "require_visa_sponsorship",
                                                            "value": "Yes"
                                                          }
                                                        ],
                                                        "conditions_enabled": true,
                                                        "logic": "OR"
                                                      },
                                                      "is_active": false
                                                    },
                                                    "position": {
                                                      "x": 1030.725701259984,
                                                      "y": 3518.6331560928284
                                                    },
                                                    "draggable": true,
                                                    "children": [
                                                      {
                                                        "id": "12",
                                                        "type": "special",
                                                        "data": {
                                                          "label": "Cover Letter?",
                                                          "id": "12",
                                                          "type": "question",
                                                          "content": [
                                                            {
                                                              "type": "question",
                                                              "content": {
                                                                "question": "Anything you’d like to add? A cover letter or your motivation for applying to this job.",
                                                                "validation": {
                                                                  "type": "any",
                                                                  "errorMessage": "Please enter a valid value."
                                                                },
                                                                "attribute": "custom",
                                                                "customKey": "cover_letter",
                                                                "verification_required": true
                                                              }
                                                            }
                                                          ],
                                                          "is_active": false
                                                        },
                                                        "position": {
                                                          "x": 1030.725701259984,
                                                          "y": 3944.6331560928284
                                                        },
                                                        "draggable": true,
                                                        "children": [
                                                          {
                                                            "id": "22",
                                                            "type": "special",
                                                            "data": {
                                                              "label": "webhook",
                                                              "id": "22",
                                                              "type": "webhook",
                                                              "content": {
                                                                "label": "webhook",
                                                                "url": "https://hooks.zapier.com/hooks/catch/16918013/u65c9zj/",
                                                                "method": "POST",
                                                                "body": "{\n  \"payload\": {\n    \"username\": \"Sr. Product Engineer Role\",\n    \"text\": \"@name - @email \\n@years_of_experience years of experience \\nSalary: @salary_expectation € per year \\nMotivation: \\n@cover_letter\"\n  }\n}"
                                                              },
                                                              "is_active": false
                                                            },
                                                            "position": {
                                                              "x": 1030.725701259984,
                                                              "y": 4298.633156092828
                                                            },
                                                            "draggable": true,
                                                            "children": [
                                                              {
                                                                "id": "13",
                                                                "type": "special",
                                                                "data": {
                                                                  "label": "Confirmation",
                                                                  "id": "13",
                                                                  "type": "bot-response",
                                                                  "content": [
                                                                    {
                                                                      "type": "message",
                                                                      "content": "Thank you for your answers; we've received your submission successfully."
                                                                    }
                                                                  ],
                                                                  "is_active": false
                                                                },
                                                                "position": {
                                                                  "x": 1030.725701259984,
                                                                  "y": 4626.633156092828
                                                                },
                                                                "draggable": true,
                                                                "children": [
                                                                  {
                                                                    "id": "15",
                                                                    "type": "special",
                                                                    "data": {
                                                                      "label": "end conversation",
                                                                      "id": "15",
                                                                      "type": "end-conversation",
                                                                      "content": [],
                                                                      "is_active": false
                                                                    },
                                                                    "position": {
                                                                      "x": 1030.725701259984,
                                                                      "y": 4900.633156092828
                                                                    },
                                                                    "draggable": true,
                                                                    "children": []
                                                                  }
                                                                ]
                                                              }
                                                            ]
                                                          }
                                                        ]
                                                      }
                                                    ]
                                                  }
                                                ]
                                              }
                                            ]
                                          }
                                        ]
                                      }
                                    ]
                                  }
                                ]
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "id": "18",
                    "type": "special",
                    "data": {
                      "label": "user input",
                      "id": "18",
                      "type": "user-input",
                      "content": {
                        "sentences": [],
                        "keywords": []
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 1644.725701259984,
                      "y": 632.6331560928284
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "20",
                        "type": "special",
                        "data": {
                          "label": "Reject Message",
                          "id": "20",
                          "type": "bot-response",
                          "content": [
                            {
                              "type": "message",
                              "content": "For this position, we’re looking for colleagues who have at least 5 years of experience, do not require visa sponsorship, and are comfortable with our decided salary range."
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 1644.725701259984,
                          "y": 900.6331560928284
                        },
                        "draggable": true,
                        "children": [
                          {
                            "id": "21",
                            "type": "special",
                            "data": {
                              "label": "end conversation",
                              "id": "21",
                              "type": "end-conversation",
                              "content": [],
                              "is_active": false
                            },
                            "position": {
                              "x": 1648.725701259984,
                              "y": 1272.6331560928284
                            },
                            "draggable": true,
                            "children": []
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ],
        nps: [
          {
            "id": "0",
            "type": "start",
            "data": {
              "label": "Start",
              "id": "0",
              "type": "start",
              "content": [],
              "is_active": true
            },
            "position": {
              "x": 1320.1439714928665,
              "y": 1.9563632455442708
            },
            "draggable": true,
            "children": [
              {
                "id": "1",
                "type": "special",
                "data": {
                  "label": "bot response",
                  "id": "1",
                  "type": "bot-response",
                  "content": [
                    {
                      "type": "message",
                      "content": "Could you kindly provide more information for better understanding?"
                    }
                  ],
                  "is_active": false
                },
                "position": {
                  "x": 5.084661905361173,
                  "y": 142.08936978353887
                },
                "draggable": true,
                "children": []
              },
              {
                "id": "2",
                "type": "special",
                "data": {
                  "label": "When AI respond",
                  "id": "2",
                  "type": "ai-assist",
                  "content": [],
                  "is_active": false
                },
                "position": {
                  "x": 541.0994863747526,
                  "y": 141.37196781815985
                },
                "draggable": true,
                "children": []
              },
              {
                "id": "3",
                "type": "special",
                "data": {
                  "label": "Intro",
                  "id": "3",
                  "type": "bot-response",
                  "content": [
                    {
                      "type": "message",
                      "content": "Hello"
                    },
                    {
                      "type": "quick-reply",
                      "content": {
                        "text": "In this short survey, we'll try understand what do you think about our app and ask a few short questions, it'll take max 1 minute to complete. ",
                        "replies": [
                          "Let's start"
                        ]
                      }
                    }
                  ],
                  "is_active": false
                },
                "position": {
                  "x": 1208.4464549788618,
                  "y": 137.79541724946202
                },
                "draggable": true,
                "children": [
                  {
                    "id": "5",
                    "type": "special",
                    "data": {
                      "label": "Start",
                      "id": "5",
                      "type": "user-input",
                      "content": {
                        "sentences": [
                          {
                            "id": "cda56a2a-305f-4571-b091-f991fe88dcbd",
                            "sentence": "Let's start"
                          }
                        ],
                        "keywords": [
                          {
                            "id": "4a3487c5-a9ee-4244-9609-53c575603eec",
                            "keyword": "start"
                          }
                        ]
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 1208.7939525895204,
                      "y": 474.9706079552594
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "19",
                        "type": "special",
                        "data": {
                          "label": "Ask NPS",
                          "id": "19",
                          "type": "question",
                          "content": [
                            {
                              "type": "question",
                              "content": {
                                "question": "On a scale from 0 to 10, how likely are you to recommend us to a friend or colleague?",
                                "validation": {
                                  "type": "one-to-ten",
                                  "errorMessage": "Please enter a number between 1 and 10."
                                },
                                "attribute": "custom",
                                "customKey": "nps_score",
                                "verification_required": true
                              }
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 1208.7939525895204,
                          "y": 854.9706079552594
                        },
                        "draggable": true,
                        "children": [
                          {
                            "id": "8",
                            "type": "special",
                            "data": {
                              "label": "Jump IF Unhappy",
                              "id": "8",
                              "type": "go-to-block",
                              "content": {
                                "targetStepId": "11",
                                "conditions": [
                                  {
                                    "operator": "lte",
                                    "key": "nps_score",
                                    "value": 6
                                  }
                                ],
                                "conditions_enabled": true,
                                "logic": "AND"
                              },
                              "is_active": false
                            },
                            "position": {
                              "x": 1206.7939525895204,
                              "y": 1195.4010816120547
                            },
                            "draggable": true,
                            "children": [
                              {
                                "id": "14",
                                "type": "special",
                                "data": {
                                  "label": "Jump IF Happy",
                                  "id": "14",
                                  "type": "go-to-block",
                                  "content": {
                                    "targetStepId": "12",
                                    "conditions": [
                                      {
                                        "operator": "gte",
                                        "key": "nps_score",
                                        "value": "9"
                                      },
                                      {
                                        "operator": "lte",
                                        "key": "nps_score",
                                        "value": "10"
                                      }
                                    ],
                                    "conditions_enabled": true,
                                    "logic": "AND"
                                  },
                                  "is_active": false
                                },
                                "position": {
                                  "x": 1206.867677411195,
                                  "y": 1545.484236248515
                                },
                                "draggable": true,
                                "children": [
                                  {
                                    "id": "13",
                                    "type": "special",
                                    "data": {
                                      "label": "Neutral Reason",
                                      "id": "13",
                                      "type": "question",
                                      "content": [
                                        {
                                          "type": "question",
                                          "content": {
                                            "question": "Thanks! What could we do to make your score a 10?",
                                            "validation": {
                                              "type": "any",
                                              "errorMessage": "Please enter a valid value."
                                            },
                                            "attribute": "custom",
                                            "customKey": "reason",
                                            "verification_required": true
                                          }
                                        }
                                      ],
                                      "is_active": false
                                    },
                                    "position": {
                                      "x": 1208.7939525895204,
                                      "y": 2022.6921228396654
                                    },
                                    "draggable": true,
                                    "children": [
                                      {
                                        "id": "15",
                                        "type": "special",
                                        "data": {
                                          "label": "Thanks",
                                          "id": "15",
                                          "type": "bot-response",
                                          "content": [
                                            {
                                              "type": "message",
                                              "content": "Thanks for your feedback. We really appreciate your time."
                                            }
                                          ],
                                          "is_active": false
                                        },
                                        "position": {
                                          "x": 1210.720227767846,
                                          "y": 2369.9454448081337
                                        },
                                        "draggable": true,
                                        "children": [
                                          {
                                            "id": "20",
                                            "type": "special",
                                            "data": {
                                              "label": "webhook",
                                              "id": "20",
                                              "type": "webhook",
                                              "content": {
                                                "label": "Send to Slack",
                                                "url": "https://hooks.zapier.com/hooks/catch/16918013/u65c9zj/",
                                                "method": "POST",
                                                "body": "{\n  \"payload\": {\n    \"username\": \"New NPS Submission\",\n    \"text\": \"Score: @nps_score\\nReason: @reason\"\n  }\n}"
                                              },
                                              "is_active": false
                                            },
                                            "position": {
                                              "x": 1210.720227767846,
                                              "y": 2603.9454448081337
                                            },
                                            "draggable": true,
                                            "children": [
                                              {
                                                "id": "18",
                                                "type": "special",
                                                "data": {
                                                  "label": "end conversation",
                                                  "id": "18",
                                                  "type": "end-conversation",
                                                  "content": [],
                                                  "is_active": false
                                                },
                                                "position": {
                                                  "x": 1212.720227767846,
                                                  "y": 2962.3634688985217
                                                },
                                                "draggable": true,
                                                "children": []
                                              }
                                            ]
                                          }
                                        ]
                                      }
                                    ]
                                  }
                                ]
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "id": "9",
                    "type": "special",
                    "data": {
                      "label": "Path Placeholder for Happy Users",
                      "id": "9",
                      "type": "user-input",
                      "content": {
                        "sentences": [],
                        "keywords": []
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 2144.4464549788618,
                      "y": 477.79541724946205
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "12",
                        "type": "special",
                        "data": {
                          "label": "Happy Reason",
                          "id": "12",
                          "type": "question",
                          "content": [
                            {
                              "type": "question",
                              "content": {
                                "question": "Awesome! What did you like the most?",
                                "validation": {
                                  "type": "any",
                                  "errorMessage": "Please enter a valid value."
                                },
                                "attribute": "custom",
                                "customKey": "reason",
                                "verification_required": true
                              }
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 2144.4464549788618,
                          "y": 857.795417249462
                        },
                        "draggable": true,
                        "children": [
                          {
                            "id": "17",
                            "type": "special",
                            "data": {
                              "label": "Go to Thanks",
                              "id": "17",
                              "type": "go-to-block",
                              "content": {
                                "targetStepId": "15",
                                "conditions": [],
                                "conditions_enabled": false,
                                "logic": "AND"
                              },
                              "is_active": false
                            },
                            "position": {
                              "x": 2144.4464549788618,
                              "y": 1233.795417249462
                            },
                            "draggable": true,
                            "children": []
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "id": "10",
                    "type": "special",
                    "data": {
                      "label": "Path Placeholder for Sad Users",
                      "id": "10",
                      "type": "user-input",
                      "content": {
                        "sentences": [],
                        "keywords": []
                      },
                      "is_active": false
                    },
                    "position": {
                      "x": 1666.4464549788618,
                      "y": 475.79541724946205
                    },
                    "draggable": true,
                    "children": [
                      {
                        "id": "11",
                        "type": "special",
                        "data": {
                          "label": "Unhappy Reason",
                          "id": "11",
                          "type": "question",
                          "content": [
                            {
                              "type": "question",
                              "content": {
                                "question": "We’re sorry to hear that. Which areas should we improve?",
                                "validation": {
                                  "type": "any",
                                  "errorMessage": "Please enter a valid value."
                                },
                                "attribute": "custom",
                                "customKey": "reason",
                                "verification_required": true
                              }
                            }
                          ],
                          "is_active": false
                        },
                        "position": {
                          "x": 1668.4464549788618,
                          "y": 855.795417249462
                        },
                        "draggable": true,
                        "children": [
                          {
                            "id": "16",
                            "type": "special",
                            "data": {
                              "label": "Go to Thanks",
                              "id": "16",
                              "type": "go-to-block",
                              "content": {
                                "targetStepId": "15",
                                "conditions": [],
                                "conditions_enabled": false,
                                "logic": "AND"
                              },
                              "is_active": false
                            },
                            "position": {
                              "x": 1668.4464549788618,
                              "y": 1229.795417249462
                            },
                            "draggable": true,
                            "children": []
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      };

      const chatbot_type = payload.chatbotType || 'from_scratch';
      const flow = flow_templates[chatbot_type];
      const titleMap = {
        'candidate_screening': 'Sr. Product Engineer at Mevo',
        'nps': 'NPS Survey',
      }

      const descriptionMap = {
        'candidate_screening': 'Answer questions for this position to get a call from our team.',
        'nps': 'Answer a few questions to help us improve our service.',
      }

      const callToActionMap = {
        'candidate_screening': 'Apply Now',
        'nps': 'Start Survey',
      }
      
      let chatbot_title = titleMap[chatbot_type] || payload.title;
      let chatbot_description = descriptionMap[chatbot_type] || payload.description;
      let call_to_action = callToActionMap[chatbot_type] || payload.callToAction;
      
      try {
        const created_bot = await this.create_bot({
          fromTemplate: chatbot_type,
          name: payload.title,
          organization: organization._id,
          createdBy: user,
          // @ts-ignore
          config: {
            model: Models.GPT_4_O_MINI,
          },
          type: BotType.GPT,
          flow: flow as unknown as BotFlow
        });

          // set bot id
          created_bot_id = created_bot._id;
          // set design
          await this.set_appearance(created_bot._id, {
            theme: payload.themeColor as BotTheme,
            position: BotPosition.BOTTOM_RIGHT,
            title: chatbot_title,
            description: chatbot_description,
            talkWithAgentMessage: call_to_action,
            brandImage: payload.brandLogoUrl,
            firstMessage: created_bot.appearance.firstMessage,
            hideBranding: false,
            skipWelcomePage: false,
            showAfterSeconds: 0,
            hex: created_bot.appearance.hex,
            greeting: created_bot.appearance.greeting,
            placeholderText: created_bot.appearance.placeholderText,
          });
  
          // set lead capture mode
          await this.set_lead_capture_mode(
            created_bot._id,
            payload.leadCaptureMode as ShowForm
          );
  
          if (
            payload.notificationReceiverUrl ||
            (payload.notificationReceiverEmail && payload.notificationReceiverName)
          ) {
            // set notification receiver
            const notification_receiver_payload = {};
  
            if (payload.notificationType === NotificationType.EMAIL) {
              notification_receiver_payload["email"] =
                payload.notificationReceiverEmail;
              notification_receiver_payload["name"] =
                payload.notificationReceiverName;
            }
  
            if (payload.notificationType === NotificationType.WEBHOOK) {
              notification_receiver_payload["url"] =
                payload.notificationReceiverUrl;
            }
  
            await this.add_notification_receiver(
              created_bot._id,
              {
                bot: created_bot._id,
                type: payload.notificationType,
                payload: notification_receiver_payload,
              },
              created_bot.organization
            );
          }
  
          // if (payload.trainingContent) {
          //   // set training content
          //   await this.add_text(payload.trainingContent, created_bot._id);
          // }
  
          if (payload.trainingContent) {
            await this.set_ai_settings(created_bot._id, {
              instructions: payload.trainingContent,
            });
          }
  
          const final_bot_data = await this.findOne({ _id: created_bot._id });
  
          await this.generate_demo_conversation(created_bot._id);
          return {
            success: true,
            bot: final_bot_data,
          };
      } catch (err) {
        if (err.error && err.error.code === "invalid_api_key") {
          throw new HttpException("bots.INVALID_API_KEY", HttpStatus.BAD_REQUEST);
        } else if (
          err.message === "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS"
        ) {
          throw new HttpException(
            "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
            HttpStatus.BAD_REQUEST
          );
        } else {
          console.log('create_via_wizard_v3 Error:', err.message);
          return {
            success: false,
          }
        }
      }
    } catch (err) {
      
      await this.messageModel.deleteMany({ bot: created_bot_id });
      await this.leadModel.deleteMany({ bot: created_bot_id });
      await this.botModel.deleteOne({ _id: created_bot_id });
      await this.notificationReceiverModel.deleteOne({ bot: created_bot_id });

      if (err.error && err.error.code === "invalid_api_key") {
        throw new HttpException("bots.INVALID_API_KEY", HttpStatus.BAD_REQUEST);
      } else if (
        err.message === "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS"
      ) {
        throw new HttpException(
          "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
          HttpStatus.BAD_REQUEST
        );
      } else {
        return {
          success: false,
        }
      }
    }
  }

  async create_via_wizard(payload: CreateViaWizardDto) {
    let created_bot_id;
    try {
      if (!payload.createdBy) {
        payload.createdBy = this.configService.get('DEFAULT_CREATED_BY');
        payload.organization = this.configService.get('DEFAULT_ORGANIZATION');
      }
      const user = await this.userModel.findById(payload.createdBy).exec();
      const organization = await this.organizationModel
        .findById(payload.organization)
        .exec();
      // create bot
      try {
        const created_bot = await this.create_bot({
          fromTemplate: payload.chatbotType,
          name: payload.title,
          organization: organization._id,
          createdBy: user,
          // @ts-ignore
          config: {
            model: Models.GPT_4_O_MINI,
          },
          type: BotType.GPT
        });

          // set bot id
          created_bot_id = created_bot._id;
          // set design
          await this.set_appearance(created_bot._id, {
            theme: payload.themeColor as BotTheme,
            position: BotPosition.BOTTOM_RIGHT,
            title: payload.title,
            description: payload.description,
            talkWithAgentMessage: payload.callToAction,
            brandImage: payload.brandLogoUrl,
            firstMessage: created_bot.appearance.firstMessage,
            hideBranding: false,
            skipWelcomePage: false,
            showAfterSeconds: 0,
            hex: created_bot.appearance.hex,
            greeting: created_bot.appearance.greeting,
            placeholderText: created_bot.appearance.placeholderText,
          });
  
          // set lead capture mode
          await this.set_lead_capture_mode(
            created_bot._id,
            payload.leadCaptureMode as ShowForm
          );
  
          if (
            payload.notificationReceiverUrl ||
            (payload.notificationReceiverEmail && payload.notificationReceiverName)
          ) {
            // set notification receiver
            const notification_receiver_payload = {};
  
            if (payload.notificationType === NotificationType.EMAIL) {
              notification_receiver_payload["email"] =
                payload.notificationReceiverEmail;
              notification_receiver_payload["name"] =
                payload.notificationReceiverName;
            }
  
            if (payload.notificationType === NotificationType.WEBHOOK) {
              notification_receiver_payload["url"] =
                payload.notificationReceiverUrl;
            }
  
            await this.add_notification_receiver(
              created_bot._id,
              {
                bot: created_bot._id,
                type: payload.notificationType,
                payload: notification_receiver_payload,
              },
              created_bot.organization
            );
          }
  
          // if (payload.trainingContent) {
          //   // set training content
          //   await this.add_text(payload.trainingContent, created_bot._id);
          // }
  
          if (payload.trainingContent) {
            await this.set_ai_settings(created_bot._id, {
              instructions: payload.trainingContent,
            });
          }
  
          const final_bot_data = await this.findOne({ _id: created_bot._id });
  
          await this.generate_demo_conversation(created_bot._id);
          return {
            success: true,
            bot: final_bot_data,
          };
      } catch (err) {
        if (err.error && err.error.code === "invalid_api_key") {
          throw new HttpException("bots.INVALID_API_KEY", HttpStatus.BAD_REQUEST);
        } else if (
          err.message === "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS"
        ) {
          throw new HttpException(
            "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
            HttpStatus.BAD_REQUEST
          );
        } else {
          console.log('create_via_wizard_v3 Error:', err.message);
          return {
            success: false,
          }
        }
      }
    } catch (err) {
      
      await this.messageModel.deleteMany({ bot: created_bot_id });
      await this.leadModel.deleteMany({ bot: created_bot_id });
      await this.botModel.deleteOne({ _id: created_bot_id });
      await this.notificationReceiverModel.deleteOne({ bot: created_bot_id });

      if (err.error && err.error.code === "invalid_api_key") {
        throw new HttpException("bots.INVALID_API_KEY", HttpStatus.BAD_REQUEST);
      } else if (
        err.message === "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS"
      ) {
        throw new HttpException(
          "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
          HttpStatus.BAD_REQUEST
        );
      } else {
        return {
          success: false,
        }
      }
    }
  }

  // async add_flow_to_legacy_bots() {
  //   const BATCH_SIZE = 100; // Batch processing
  //   let skip = 0;
  //   let processed = 0;
  //   let errors = 0;
  
  //   while (true) {
  //     // Batch şeklinde al
  //     const bots = await this.botModel
  //       .find({ flow: { $exists: false } })
  //       .skip(skip)
  //       .limit(BATCH_SIZE)
  //       .exec();
  
  //     if (bots.length === 0) break;
  
  //     for (const bot of bots) {
  //       try {
  //         // Data validation
  //         if (!bot._id) {
  //           console.error(`Bot missing _id: ${bot}`);
  //           errors++;
  //           continue;
  //         }
  
  //         const firstMessage = bot.appearance?.firstMessage || "Welcome";
  
  //         const flow = this.createDefaultFlow(firstMessage);
  
  //         await this.botModel.updateOne(
  //           { _id: bot._id }, 
  //           { $set: { flow } }
  //         );
  
  //         processed++;
  //         console.log(`✅ Flow added to bot ${bot._id}`);
  
  //       } catch (error) {
  //         errors++;
  //         console.error(`❌ Failed to add flow to bot ${bot._id}:`, error);
  //         // Continue ile diğer botları da işle
  //       }
  //     }
  
  //     skip += BATCH_SIZE;
  //     console.log(`📊 Processed: ${processed}, Errors: ${errors}`);
  //   }
  
  //   return { processed, errors };
  // }
  
  // private createDefaultFlow(firstMessage: string) {
  //   // Flow objesi ayrı metoda taşın, tek seferlik oluşturun
  //   const flow = [
  //     {
  //       "id": "0",
  //       "type": "start",
  //       "data": {
  //         "label": "Start",
  //         "id": "0",
  //         "type": "start",
  //         "content": [],
  //         "is_active": true
  //       },
  //       "position": {
  //         "x": 1320.1439714928665,
  //         "y": 1.9563632455442708
  //       },
  //       "draggable": true,
  //       "children": [
  //         {
  //           "id": "1",
  //           "type": "special",
  //           "data": {
  //             "label": "bot response",
  //             "id": "1",
  //             "type": "bot-response",
  //             "content": [
  //               {
  //                 "type": "message",
  //                 "content": "Could you kindly provide more information for better understanding?"
  //               }
  //             ],
  //             "is_active": false
  //           },
  //           "position": {
  //             "x": 5.084661905361173,
  //             "y": 142.08936978353887
  //           },
  //           "draggable": true,
  //           "children": []
  //         },
  //         {
  //           "id": "2",
  //           "type": "special",
  //           "data": {
  //             "label": "When AI respond",
  //             "id": "2",
  //             "type": "ai-assist",
  //             "content": [],
  //             "is_active": false
  //           },
  //           "position": {
  //             "x": 541.0994863747526,
  //             "y": 141.37196781815985
  //           },
  //           "draggable": true,
  //           "children": []
  //         },
  //         {
  //           "id": "3",
  //           "type": "special",
  //           "data": {
  //             "label": "First message sent",
  //             "id": "3",
  //             "type": "bot-response",
  //             "content": [
  //               {
  //                 "type": "message",
  //                 "content": "Welcome"
  //               },
  //             ],
  //             "is_active": false
  //           },
  //           "position": {
  //             "x": 1208.4464549788618,
  //             "y": 137.79541724946202
  //           },
  //           "draggable": true,
  //           "children": [
  //             {
  //               "id": "5",
  //               "type": "special",
  //               "data": {
  //                 "label": "user input",
  //                 "id": "5",
  //                 "type": "user-input",
  //                 "content": {
  //                   "sentences": [
  //                     {
  //                       "id": "cda56a2a-305f-4571-b091-f991fe88dcbd",
  //                       "sentence": "Example sentence"
  //                     }
  //                   ],
  //                   "keywords": [
  //                     {
  //                       "id": "ce57a9e0-2312-4afb-982a-3e6d829a4146",
  //                       "keyword": "example"
  //                     }
  //                   ]
  //                 },
  //                 "is_active": false
  //               },
  //               "position": {
  //                 "x": 1028.4464549788618,
  //                 "y": 517.795417249462
  //               },
  //               "draggable": true,
  //               "children": [
  //                 {
  //                   "id": "7",
  //                   "type": "special",
  //                   "data": {
  //                     "label": "bot response",
  //                     "id": "7",
  //                     "type": "bot-response",
  //                     "content": [
  //                       {
  //                         "type": "message",
  //                         "content": "Message about the example subject"
  //                       }
  //                     ],
  //                     "is_active": false
  //                   },
  //                   "position": {
  //                     "x": 1028.4464549788618,
  //                     "y": 897.795417249462
  //                   },
  //                   "draggable": true,
  //                   "children": []
  //                 }
  //               ]
  //             }
  //           ]
  //         }
  //       ]
  //     }
  //   ];
    
  //   // Safe assignment
  //   if (flow[0]?.children?.[2]?.data?.content?.[0]) {
  //     flow[0].children[2].data.content[0].content = firstMessage;
  //   }
    
  //   return flow;
  // }

  async generate_demo_conversation(bot_id: string) {
    try {
      const bot = await this.botModel.findById(bot_id).exec();
      const organization = bot.organization._id;
      const device_id = randomHex(16);
      const session_id = randomHex(16);

      const messages = [
        {
          content:
            "This is a demo conversation created by Mevo. Do you ship to Canada?",
          ip: "::1",
          did: device_id,
          session: session_id,
          geo: {
            country: "CA",
            region: "QC",
            city: "Montreal",
          },
          device: {
            browser: "Chrome v125.0.23",
            os: "macOS",
            device: "Apple",
          },
          sender: MessageSender.USER,
          unread: true,
          notificationSent: true,
        },
        {
          content:
            "Yes, we ship to Canada. Also we have free shipping for orders over $100. Do you have any other questions?",
          ip: "::1",
          did: device_id,
          session: session_id,
          geo: {
            country: "N/A",
            region: "N/A",
            city: "N/A",
          },
          device: {
            browser: "N/A",
            os: "N/A",
            device: "N/A",
          },
          sender: MessageSender.BOT,
          unread: true,
          notificationSent: true,
        },
        {
          content: "What is the return policy?",
          ip: "::1",
          did: device_id,
          session: session_id,
          geo: {
            country: "CA",
            region: "QC",
            city: "Montreal",
          },
          device: {
            browser: "Chrome v125.0.23",
            os: "macOS",
            device: "Apple",
          },
          sender: MessageSender.USER,
          unread: true,
          notificationSent: true,
        },
        {
          content:
            "We have a 30-day return policy. If you are not satisfied with your purchase, you can return it within 30 days of the purchase date. Do you have any other questions?",
          ip: "::1",
          did: device_id,
          session: session_id,
          geo: {
            country: "N/A",
            region: "N/A",
            city: "N/A",
          },
          device: {
            browser: "N/A",
            os: "N/A",
            device: "N/A",
          },
          sender: MessageSender.BOT,
          unread: true,
          notificationSent: true,
        },
        {
          content: "No, that's all. Thank you!",
          ip: "::1",
          did: device_id,
          session: session_id,
          geo: {
            country: "CA",
            region: "QC",
            city: "Montreal",
          },
          device: {
            browser: "Chrome v125.0.23",
            os: "macOS",
            device: "Apple",
          },
          sender: MessageSender.USER,
          unread: true,
          notificationSent: true,
        },
      ];

      const lead = {
        name: "Steve Wozniak",
        email: "woz@apple.com",
        company: "Apple",
        organization,
        bot: bot_id,
        device_id,
        customData: {
          favorite_fruit: 'apple',
          has_beard: 'yes',
        }
      };

      for (const message of messages) {
        const new_message = new this.messageModel({
          ...message,
          bot: bot_id,
        });
        await new_message.save();
      }

      await this.leadModel.create(lead);
    } catch (err) {
      console.log(err);
    }
  }

  async link_assistant(bot_id: string, assistant_id: string) {
    const bot = await this.botModel.findById(bot_id).exec();
    const openai_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: openai_key,
    });

    try {
      const non_supported_models_for_file_search = [
        "gpt-4",
        "gpt-4-1106-preview",
        "gpt-4-0613",
        "gpt-4-0125-preview",
      ];
      const existing_assistant = await open_ai_client.beta.assistants.retrieve(
        assistant_id
      );

      // clear existing training resources
      await this.remove_training_resources(bot._id);

      // init vector store ids array
      let vector_store_ids = [];
      let custom_vector_store_id = "";

      // check if file search tool is enabled
      // if not enabled, we're enabling it
      // check if vector store id is available
      // if not available, we're creating a new vector store
      // if available, we're using it as custom vector store id and updating the bot

      const has_file_search_tool = existing_assistant.tools.some(
        (tool) => tool.type === "file_search"
      );
      const has_vector_store_id =
        existing_assistant.tool_resources?.file_search?.vector_store_ids
          ?.length || false;

      let assistant_tools = existing_assistant.tools.map((tool) => ({
        type: tool.type,
      }));

      // enable file search tool if not enabled
      if (!has_file_search_tool) {
        assistant_tools.push({ type: "file_search" });
      }

      // create and assign new vector store if not available
      if (!has_vector_store_id) {
        const created_vector_store =
          await open_ai_client.beta.vectorStores.create({});
        vector_store_ids = [created_vector_store.id];
        custom_vector_store_id = created_vector_store.id;
      }

      // assign existing vector store to bot if available
      if (has_vector_store_id) {
        vector_store_ids =
          existing_assistant.tool_resources.file_search.vector_store_ids;
        custom_vector_store_id =
          existing_assistant.tool_resources.file_search.vector_store_ids[0];
      }

      let model = existing_assistant.model;
      if (
        non_supported_models_for_file_search.includes(existing_assistant.model)
      ) {
        if (model.includes("gpt-4")) {
          model = "gpt-4-turbo";
        } else {
          model = "gpt-3.5-turbo-1106";
        }
      }

      await open_ai_client.beta.assistants.update(
        bot.config.custom_assistant_id,
        {
          // @ts-ignore
          tools: assistant_tools,
          model: model,
          tool_resources: {
            file_search: {
              vector_store_ids: vector_store_ids,
            },
          },
        }
      );

      await this.botModel.updateOne(
        {
          _id: bot._id,
        },
        {
          $set: {
            config: {
              ...bot.config,
              instructions: existing_assistant.instructions,
              custom_vector_store_id: custom_vector_store_id,
              custom_assistant_id: assistant_id,
              model: model,
              is_custom_assistant_enabled: true,
            },
          },
        }
      );
    } catch (err) {
      if (err.status === 404) {
        throw new HttpException(
          "bots.ASSISTANT_NOT_FOUND",
          HttpStatus.BAD_REQUEST
        );
      }
    }
  }

  // async clear_orphan_resources() {
  //   // if there is a product, question, message, lead, link, text, file that related bot is removed, remove it
  //   const products = await this.productModel.find({}).exec();
  //   const questions = await this.questionModel.find({}).exec();
  //   const links = await this.linkModel.find({}).exec();
  //   const texts = await this.textModel.find({}).exec();
  //   const files = await this.fileModel.find({}).exec();
  //   const leads = await this.leadModel.find({}).exec();
  //   const messages = await this.messageModel.find({}).exec();
  //   const notification_receivers = await this.notificationReceiverModel.find({}).exec();

  //   for (const product of products) {

  //   }

    
  // }

  async remove_training_resources(bot_id: string) {
    const products = await this.productModel.find({ bot: bot_id }).exec();
    const questions = await this.questionModel.find({ bot: bot_id }).exec();
    const links = await this.linkModel.find({ bot: bot_id }).exec();
    const texts = await this.textModel.find({ bot: bot_id }).exec();
    const files = await this.fileModel.find({ bot: bot_id }).exec();

    await Promise.allSettled([
      ...products.map((product) => {
        return this.remove_product(product._id);
      }),
      ...questions.map((question) => {
        return this.remove_question(question._id);
      }),
      ...links.map((link) => {
        return this.remove_link(link._id, bot_id);
      }),
      ...texts.map((text) => {
        return this.remove_text(text._id);
      }),
      ...files.map((file) => {
        return this.remove_file(file._id);
      }),
    ]);
  }

  async remove_openai_key(bot_id: string) {
    const bot = await this.botModel.findById(bot_id).exec();

    // remove all training resources
    await this.remove_training_resources(bot._id);

    // remove secret from bot
    await this.secretModel.deleteOne({ _id: bot.secrets[0] });

    // remove assistant and vector store from openai
    await this.botModel.updateOne(
      {
        _id: bot._id,
      },
      {
        $set: {
          secrets: [],
          apiKeySet: false,
          config: {
            ...bot.config,
            custom_assistant_id: undefined,
            is_custom_assistant_enabled: false,
            custom_vector_store_id: undefined,
          },
        },
      }
    );

    return true;
  }

  async add_openai_key(bot_id: string, addSecretDto: AddSecretDto) {
    const is_key_valid = await this.validate_openai_key(addSecretDto.value);

    if (!is_key_valid) {
      throw new HttpException(
        "bots.INVALID_OPENAI_KEY",
        HttpStatus.BAD_REQUEST
      );
    }

    const bot = await this.botModel.findById(bot_id).exec();

    // remove all training resources
    await this.remove_training_resources(bot._id);

    // add secret to bot
    await this.addSecret(
      { _id: bot._id },
      { key: SecretKey.OPEN_AI_KEY, value: addSecretDto.value }
    );

    // create assistant for this bot by using this key
    const open_ai_client = new OpenAI({
      apiKey: addSecretDto.value,
    });

    const assistant = await open_ai_client.beta.assistants.create({
      instructions: bot.config.instructions,
      tools: [{ type: "file_search" }],
      model: bot.config.model,
    });

    // create vector store for this bot by using this key
    const vector_store = await open_ai_client.beta.vectorStores.create({});

    // update assistant with vector store
    // so assistant can use this vector store for file search tool
    await open_ai_client.beta.assistants.update(assistant.id, {
      tool_resources: {
        file_search: { vector_store_ids: [vector_store.id] },
      },
    });

    // set custom_assistant_id and use_assistant_api flags to true in config
    await this.botModel.updateOne(
      {
        _id: bot._id,
      },
      {
        $set: {
          config: {
            ...bot.config,
            custom_assistant_id: assistant.id,
            is_custom_assistant_enabled: true,
            custom_vector_store_id: vector_store.id,
          },
        },
      }
    );

    return true;
  }

  async addSecret(
    condition: { [key: string]: any },
    addSecretDto: AddSecretDto
  ) {
    const bot = await this.botModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .populate("secrets")
      .exec();

    if (addSecretDto.key === SecretKey.OPEN_AI_KEY) {
      if (bot.organization.plan === PlanType.BASIC) {
        throw new HttpException(
          "organizations.OPEN_AI_KEY_NOT_ALLOWED_FOR_BASIC_PLAN",
          HttpStatus.BAD_REQUEST
        );
      }

      if (bot.apiKeySet) {
        const existingKey = bot.secrets.find(
          (secret) => secret.key === SecretKey.OPEN_AI_KEY
        );

        if (existingKey) {
          await this.secretModel.remove({
            _id: existingKey._id,
          });
          bot.secrets = bot.secrets.filter(
            (secret) => secret._id !== existingKey._id
          );
        }
      }

      bot.apiKeySet = true;
    }

    const newSecret = new this.secretModel({
      key: addSecretDto.key,
      value: encrypt(
        addSecretDto.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      ),
    });
    const savedSecret = await newSecret.save();

    bot.secrets.push(savedSecret);
    await bot.save();

    return true;
  }

  // async setAppearance(_id: string, appearance: Appearance) {
  //   const bot = await this.botModel.findById(_id).exec();

  //   bot.appearance = appearance;
  //   await bot.save();

  //   return bot;
  // }

  async updateWebhooks(_id: string, webhooks: string[]) {
    const bot = await this.botModel.findById(_id).exec();
    bot.webhooks = webhooks;
    await bot.save();
    return bot.webhooks;
  }

  async encryptSecrets() {
    const secrets = await this.secretModel.find({}).exec();

    for (const secret of secrets) {
      secret.value = encrypt(
        secret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
      await secret.save();
    }

    return true;
  }

  async removeSecret(
    condition: { [key: string]: any },
    removeSecretDto: RemoveSecretDto
  ) {
    const bot = await this.botModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .populate("secrets")
      .exec();

    const currentSecret = bot.secrets.find(
      (secret) => secret.key === removeSecretDto.key
    );

    if (currentSecret) {
      await this.secretModel.remove({
        _id: currentSecret._id,
      });

      if (currentSecret.key === SecretKey.OPEN_AI_KEY) {
        bot.apiKeySet = false;
      }

      bot.secrets = bot.secrets.filter(
        (secret) => secret.key !== removeSecretDto.key
      );

      await bot.save();

      return true;
    } else {
      return false;
    }
  }

  async create(createBotDto: CreateBotDto): Promise<Bot> {
    const organization = await this.organizationModel.findById(
      createBotDto.organization
    );

    // if (
    //   Plans[organization.plan].name === PlanType.BASIC &&
    //   createBotDto.type === BotType.GPT
    // ) {
    //   throw new HttpException(
    //     "organizations.YOUR_PLAN_DOES_NOT_SUPPORT_GPT",
    //     HttpStatus.BAD_REQUEST
    //   );
    // }

    if (!organization)
      throw new HttpException("organizations.NOT_FOUND", HttpStatus.NOT_FOUND);

    const botCount = await this.botModel.countDocuments({
      organization: organization._id,
      isRemoved: { $ne: true },
      isDraft: { $ne: true },
    });

    if (botCount >= Plans[organization.plan].limits.bot)
      throw new HttpException(
        "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
        HttpStatus.BAD_REQUEST
      );

    const bot = {
      organization: createBotDto.organization,
      ...createBotDto,
    };

    const createdBot = new this.botModel(bot);
    return createdBot.save();
  }

  async link_google_sheet(bot_id: string, sheet_id: string, sheet_name: string, user: User) {
    const bot = await this.botModel.findById(bot_id).exec();

    bot.googleSpreadsheetId = sheet_id;
    bot.googleSpreadsheetName = sheet_name;

    await bot.save();
    return true;
  }

  async unlink_google_sheet(bot_id: string) {
    const bot = await this.botModel.findById(bot_id).exec();

    bot.googleSpreadsheetId = null;
    bot.googleSpreadsheetName = null;

    await bot.save();
    return true;
  }

  async findAll(condition: { [key: string]: any }): Promise<Bot[]> {
    // hide fileSources field
    const bots = await this.botModel
      .find({
        $and: [
          {
            isRemoved: { $ne: true },
          },
          condition,
        ],
      })
      .exec();

    bots.forEach((bot) => {
      if (bot.gptSettings && bot.gptSettings.embeddings) {
        bot.gptSettings.fileSources = [];
        bot.gptSettings.embeddings = undefined;

        if (bot.gptSettings.qEmbeddings) {
          bot.gptSettings.qEmbeddings = undefined;
        }
      }
    });

    return bots;
  }

  // async setSessionCounts(): Promise<boolean> {
  //   // get all bots
  //   // get all messages
  //   // get all unique session
  //   // set session count to bot
  //   const bots = await this.botModel.find({ type: "gpt" }).exec();
  //   const botIds = bots.map((bot) => bot._id);

  //   botIds.forEach(async (botId) => {
  //     const sessionCount = await this.messageModel
  //       .distinct("session", {
  //         bot: botId,
  //       })
  //       .exec();

  //     await this.botModel
  //       .updateOne(
  //         {
  //           _id: botId,
  //         },
  //         {
  //           sessionCount: sessionCount.length,
  //         }
  //       )
  //       .exec();
  //   });

  //   return true;
  // }

  async processEvent(event: BotEventDto): Promise<boolean> {
    let eventAction = {};

    if (event.type === BotEventType.START) {
      eventAction = { $inc: { startCount: 1 } };
    } else if (event.type === BotEventType.COMPLETED) {
      eventAction = { $inc: { completedCount: 1 } };
    }

    const eventResult = await this.botModel.findOneAndUpdate(
      {
        $and: [
          {
            isRemoved: { $ne: true },
          },
          { _id: event.bot },
        ],
      },
      eventAction
    );

    if (eventResult) return true;
    return false;
  }

  async increaseCharCount(botId: string, charCount: number): Promise<boolean> {
    try {
      const updateResult = await this.botModel.updateOne(
        {
          _id: botId,
        },
        {
          $inc: { charCount: charCount },
        }
      );

      return true;
    } catch (err) {
      return false;
    }
  }

  async findOne(
    condition: { [key: string]: any },
    view: boolean = false
  ): Promise<any> {
    const bot = await this.botModel
      .findOne({
        $and: [
          {
            isRemoved: { $ne: true },
          },
          condition,
        ],
      })
      .exec();

    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    if (view) {
      // increase view count
      await this.botModel.findOneAndUpdate(condition, {
        $inc: { viewCount: 1 },
      });

      if (bot) {
        bot.hideBranding =
          bot.organization.plan !== PlanType.BASIC && bot.hideBranding;
        bot.hideCta = bot.organization.plan !== PlanType.BASIC;
        bot.completedCount = undefined;
        bot.viewCount = undefined;
        bot.startCount = undefined;
        bot.sessionCount = undefined;
        bot.unread = undefined;
        // @ts-ignore
        bot.updatedAt = undefined;
        // @ts-ignore
        bot.createdAt = undefined;
        bot.isRemoved = undefined;
        bot.organization.admins = undefined;
        bot.organization.users = undefined;
        bot.organization._id = undefined;
        bot.organization.activePeriod = undefined;
        bot.organization.plan = undefined;
        bot.charCount = undefined;
        bot.createdBy = undefined;
        if (bot.emailReceivers) {
          bot.emailReceivers = undefined;
        }
        if (typeof bot.domainUUID !== "undefined") {
          bot.domainUUID = undefined;
          bot.domain = undefined;
        }
        if (bot.gptSettings) {
          bot.gptSettings.feed = [
            // @ts-ignore
            { dont_walk_around: "here" },
            bot.gptSettings.feed[1],
          ];
          bot.gptSettings.assistantID = undefined;
          bot.gptSettings.embeddings = undefined;
          bot.gptSettings.qEmbeddings = undefined;
          bot.gptSettings.fallbackMessage = undefined;
          bot.gptSettings.fileSources = undefined;
          bot.gptSettings.model = undefined;
          bot.gptSettings.prompt = undefined;
          bot.gptSettings.represented = undefined;
          bot.gptSettings.withHistory = undefined;
          bot.gptSettings.domainSources = undefined;
        }
      }

      // if (!bot.isActive) {
      //   throw new HttpException("bots.NOT_ACTIVE", HttpStatus.NOT_FOUND);
      // }
    }

    if (bot.gptSettings && bot.gptSettings.embeddings) {
      if (bot.gptSettings.qEmbeddings) {
        bot.gptSettings.qEmbeddings = undefined;
      }
      bot.gptSettings.embeddings.values = [];
      bot.gptSettings.embeddings.refs = [];
      if (bot.gptSettings.fileSources) {
        bot.gptSettings.fileSources = bot.gptSettings.fileSources.map(
          (fileSource) => {
            if (fileSource.values) delete fileSource.values;
            if (fileSource.refs) delete fileSource.refs;
            if (fileSource.rawText) delete fileSource.rawText;
            if (fileSource.hash) delete fileSource.hash;
            return fileSource;
          }
        );
      }
    }

    return bot;
  }

  async findOneByDomain(domain: string): Promise<Bot> {
    const bot = await this.botModel
      .findOne({
        $and: [
          {
            isRemoved: { $ne: true },
          },
          { domain: domain },
        ],
      })
      .exec();

    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    if (bot) {
      bot.completedCount = undefined;
      bot.viewCount = undefined;
      bot.startCount = undefined;
      bot.isRemoved = undefined;
      bot.organization.admins = undefined;
      bot.organization.users = undefined;
      bot.organization._id = undefined;
      bot.organization.activePeriod = undefined;
      bot.createdBy = undefined;
      if (bot.emailReceivers) {
        bot.emailReceivers = undefined;
      }

      if (bot.gptSettings && bot.gptSettings.embeddings) {
        if (bot.gptSettings.qEmbeddings) {
          bot.gptSettings.qEmbeddings = undefined;
        }
        bot.gptSettings.embeddings.values = [];
        bot.gptSettings.embeddings.refs = [];
        if (bot.gptSettings.fileSources) {
          bot.gptSettings.fileSources = bot.gptSettings.fileSources.map(
            (fileSource) => {
              if (fileSource.values) delete fileSource.values;
              if (fileSource.refs) delete fileSource.refs;
              if (fileSource.rawText) delete fileSource.rawText;
              if (fileSource.hash) delete fileSource.hash;
              return fileSource;
            }
          );
        }
      }
    }

    return bot;
  }

  async setReaded(botId: string): Promise<boolean> {
    try {
      await this.botModel.updateOne(
        {
          _id: botId,
        },
        {
          unread: false,
        }
      );

      return true;
    } catch (err) {
      return false;
    }
  }
  // TODO: nested validation does not work correctly
  // so if client send design: {} without fill the object
  // it may update design property like above
  async update(
    condition: { [key: string]: any },
    updateBotDto: UpdateBotDto,
    isFileSource: boolean = false,
    isFileRemove: boolean = false
  ) {
    const botData = await this.botModel.findOne({
      $and: [
        {
          isRemoved: { $ne: true },
        },
        condition,
      ],
    });

    // @ts-ignore
    delete updateBotDto.apiKeySet;
    // @ts-ignore
    delete updateBotDto.secrets;

    const organization = await this.organizationModel.findById(
      botData.organization
    );

    if (
      organization &&
      Plans[organization?.plan]?.limits?.multiplePdfFiles === 0 &&
      updateBotDto?.gptSettings?.fileSources?.length > 1
    ) {
      throw new HttpException(
        "organization.MULTIPLE_PDF_FILES_NOT_ALLOWED",
        HttpStatus.BAD_REQUEST
      );
    }

    if (
      updateBotDto.gptSettings &&
      updateBotDto.gptSettings.useAssistantAPI &&
      organization.plan === PlanType.BASIC
    ) {
      throw new HttpException(
        "organizations.ASSISTANT_API_NOT_AVAILABLE_FOR_THIS_TIER",
        HttpStatus.BAD_REQUEST
      );
    }

    if (
      botData.type === BotType.SCRIPTED &&
      updateBotDto.script &&
      updateBotDto.script.steps
    ) {
      let atLeastOneJumpExist = false;

      const singleSelectSteps = updateBotDto.script.steps.filter(
        (step) => step.type === "builder.SINGLE_SELECT_STEP_TYPE"
      );

      singleSelectSteps.forEach((step) => {
        if (step.data.jumps) {
          step.data.jumps.forEach((jump) => {
            if (jump) {
              atLeastOneJumpExist = true;
            }
          });
        }
      });

      if (
        atLeastOneJumpExist &&
        Plans[organization?.plan]?.limits?.logicalJumps === 0
      ) {
        throw new HttpException(
          "organization.LOGICAL_JUMPS_NOT_ALLOWED",
          HttpStatus.BAD_REQUEST
        );
      }
    }

    const bot = await this.botModel
      .findOneAndUpdate(
        {
          $and: [
            {
              isRemoved: { $ne: true },
            },
            condition,
          ],
        },
        updateBotDto,
        {
          new: true,
        }
      )
      .exec();

    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    return bot;
  }

  extractDomain = function (url) {
    const regex = /^(?:https?:\/\/)?([^\/]+)/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  standardizeURL = function (input) {
    // Remove the http:// or https:// prefix and any trailing slash
    const normalized = input.replace(/^(http:\/\/|https:\/\/)?(.*?)\/?$/, "$2");

    // Add https:// prefix
    return `https://${normalized}`;
  };

  // async extract_links(url) {
  //   var client = new scrapingbee.ScrapingBeeClient('FZY8BWVSAK70WIHIGZNZ4AXWLYXCEXBGPEVIN3O3T2Q4CLXTPHC6B8K9SWDKOS1327MMV3JY8QXNMSTY');
  //   var response = await client.get({
  //     url: url,
  //     params: {
  //       extract_rules: {
  //         "links":{
  //           "selector":"a@href",
  //           "type":"list"
  //         }
  //       },
  //       wait: '2500',
  //       wait_browser: 'networkidle2',
  //     },
  //   })

  //   return response
  // }

  // async extract_text(url) {
  //   var client = new scrapingbee.ScrapingBeeClient('FZY8BWVSAK70WIHIGZNZ4AXWLYXCEXBGPEVIN3O3T2Q4CLXTPHC6B8K9SWDKOS1327MMV3JY8QXNMSTY');
  //   var response = await client.get({
  //     url: url,
  //     params: {
  //       extract_rules: {"text": {"selector": "body" ,"output": "text_relevant"}},
  //       wait_browser: 'networkidle2',
  //     },
  //   })

  //   return response
  // }

  // async scrape_website(url: string, bot: Bot, isSinglePage: boolean) {
  //   try {
  //     const response = await this.extract_links(url)
  //     var decoder = new TextDecoder();
  //     var text = decoder.decode(response.data);

  //     const urls = JSON.parse(text).links;

  //     await Promise.all(
  //       urls.map(async (_url) => {
  //         console.log(_url, 'url mapping');
  //         try {
  //           const text = await this.extract_text(_url);
  //           var decoder = new TextDecoder();
  //           var content = decoder.decode(text.data);

  //           // let link = new this.linkModel({
  //           //   bot: bot._id,
  //           //   url: _url,
  //           //   characterCount: text.content.length | 0,
  //           //   content: content,
  //           //   status: "onhold",
  //           // });

  //           // await link.save();

  //           console.log(content, 'content');
  //         } catch (err) {
  //           console.log(`Error extracting text from ${_url}:`, err);
  //         }
  //       })
  //     );

  //     return this.linkModel.find({ bot: bot._id, status: "onhold" }).exec();
  //   } catch (e) {
  //     console.log('A problem occurs : ' + e);
  //   }
  // }

  async scrapeWebsite(domain: string, bot: Bot, isSinglePage: boolean) {
    const extractedDomain = domain;
    const maxCrawlPages = isSinglePage
      ? 1
      : Plans[bot.organization.plan].limits.crawlingLimit;

    // if (
    //   bot.gptSettings.domainSources &&
    //   bot.gptSettings.domainSources.indexOf(extractedDomain) > -1
    // ) {
    //   throw new HttpException(
    //     "bots.DOMAIN_ALREADY_LINKED_TO_BOT",
    //     HttpStatus.BAD_REQUEST
    //   );
    // }

    // get resource availability secret
    let availability = await this.secretModel
      .findOne({ key: SecretKey.AVAILABILITY })
      .exec();

    if (!availability) {
      const newSecret = new this.secretModel({
        key: SecretKey.AVAILABILITY,
        value: 32768,
      });

      availability = await newSecret.save();
    }

    if (parseInt(availability.value) < 256) {
      throw new HttpException(
        "bots.RESOURCE_NOT_AVAILABLE",
        HttpStatus.BAD_REQUEST
      );
    }

    // calculate allocation size
    let allocatedMemory = parseInt(availability.value) / 2;

    await this.secretModel
      .findOneAndUpdate(
        {
          key: SecretKey.AVAILABILITY,
        },
        {
          value: parseInt(availability.value) - allocatedMemory + "",
        }
      )
      .exec();

    const apifyClient = new ApifyClient({
      token: this.configService.get<string>("APIFY_TOKEN"),
    });

    const { defaultDatasetId } = await apifyClient
      .actor("apify/website-content-crawler")
      .call(
        {
          startUrls: [
            {
              url: domain,
              userData: {
                label: "START",
              },
            },
          ],
          maxCrawlDepth: 2,
          maxCrawlPages,
          ignoreCanonicalUrl: true,
        },
        {
          memory: allocatedMemory,
        }
      );

    const { items } = await apifyClient.dataset(defaultDatasetId).listItems();

    const availabilitySecret = await this.secretModel
      .findOne({ key: SecretKey.AVAILABILITY })
      .exec();

    // give resources back
    await this.secretModel
      .findOneAndUpdate(
        {
          key: SecretKey.AVAILABILITY,
        },
        {
          value: parseInt(availabilitySecret.value) + allocatedMemory + "",
        }
      )
      .exec();

    const preparedResponse: {
      bot: string;
      url: string;
      characterCount: number;
      content: string;
      status: string;
    }[] = items.map((item: { url: string; text: string }) => {
      return {
        bot: bot._id,
        status: "onhold",
        url: item.url,
        characterCount: item.text.length,
        content: item.text,
      };
    });

    for (var item of preparedResponse) {
      let link = new this.linkModel({
        bot: bot._id,
        url: item.url,
        characterCount: item.content.length | 0,
        content: item.content,
        status: "onhold",
      });

      await link.save();
    }

    return this.linkModel.find({ bot: bot._id, status: "onhold" }).exec();
  }

  async generateEmbeddings(
    content: string,
    type: EmbeddingType,
    bot: Bot,
    meta: { [key: string]: any } = {}
  ) {
    let dynamicContent = content;
    /**
     * remove existing embeddings
     * for this bot with the same type if type
     * is not file
     *
     * bcz we have different logic for file in separate function
     */
    if (type !== EmbeddingType.FILE) {
      await this.embeddingModel.deleteMany({
        bot: bot._id,
        type: type,
      });
    }

    /**
     * Override content and generate from scratch
     * if type is product or qa
     */
    if (type === EmbeddingType.PRODUCT) {
      dynamicContent = "";
      bot.gptSettings.feed[0].data.forEach((product) => {
        dynamicContent += `Product name: ${product.name}; Product description: ${product.description}; Product price: ${product.price} __MEVO__`;
      });
    }

    if (type === EmbeddingType.QA) {
      dynamicContent = "";
      bot.gptSettings.feed[1].data.forEach((qa) => {
        dynamicContent += `Question: ${qa.q}; Answer: ${qa.a} __MEVO__`;
      });
    }

    return this.calculateEmbeddings(dynamicContent, bot, type, true, meta);
  }

  async removeEmbeddings(
    bot: Bot,
    type: EmbeddingType,
    meta: { [key: string]: any } = {}
  ) {
    if (type === EmbeddingType.WEBPAGE) {
      return this.embeddingModel.deleteMany({
        bot: bot._id,
        type: type,
        "meta.domain": { $regex: meta.domain, $options: "i" },
      });
    }

    return this.embeddingModel.deleteMany({
      bot: bot._id,
      type: type,
      meta: meta,
    });
  }

  async unlinkDomain(botId: string): Promise<boolean> {
    try {
      const bot = await this.botModel.findById(botId);

      const { data } = await firstValueFrom(
        this.httpService
          .delete(
            "https://app.saascustomdomains.com/api/v1/accounts/acc_fb11c873/upstreams/upstream_29fcea2e/custom_domains/" +
              bot.domainUUID,
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer yi7A9eJa5fZbwNR7DYrP8Vyo`,
              },
            }
          )
          .pipe(
            catchError((error: AxiosError) => {
              throw new HttpException(
                "bots.DNS_PROVIDER_ERROR",
                HttpStatus.BAD_REQUEST
              );
            })
          )
      );

      await this.botModel.updateOne(
        {
          _id: botId,
        },
        {
          domain: null,
          domainUUID: null,
        }
      );

      await this.organizationModel.findOneAndUpdate(
        {
          _id: bot.organization._id,
        },
        {
          $inc: { customDomainUsage: -1 },
        }
      );

      return true;
    } catch (err) {
      return false;
    }
  }

  async linkDomain(
    linkDomainDto: LinkDomainDto,
    botId: string,
    recipient: string
  ): Promise<boolean> {
    const bot = await this.botModel.findById(botId);

    if (!bot) throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);

    // count how many domain linked to bots in this organization
    const organization = await this.organizationModel.findById(
      bot.organization
    );

    if (!organization)
      throw new HttpException("organizations.NOT_FOUND", HttpStatus.NOT_FOUND);

    const domainLimit = Plans[organization.plan].limits.customDomain;
    const domainLinkedBotsCount = await this.botModel.count({
      $and: [
        { organization: organization._id },
        { isRemoved: { $ne: true } },
        { isDraft: { $ne: true } },
        { domain: { $ne: null } },
        { domain: { $ne: "" } },
      ],
    });

    if (domainLinkedBotsCount >= domainLimit)
      throw new HttpException(
        "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_DOMAINS",
        HttpStatus.BAD_REQUEST
      );

    // check if domain already linked to another bot
    const domainLinkedBot = await this.botModel.findOne({
      domain: linkDomainDto.domain,
      isRemoved: { $ne: true },
    });

    if (domainLinkedBot)
      throw new HttpException(
        "bots.DOMAIN_ALREADY_LINKED_TO_ANOTHER_BOT",
        HttpStatus.BAD_REQUEST
      );

    try {
      const { data } = await firstValueFrom(
        this.httpService
          .post(
            "https://app.saascustomdomains.com/api/v1/accounts/acc_fb11c873/upstreams/upstream_29fcea2e/custom_domains",
            {
              host: linkDomainDto.domain,
              instructions_recipient: recipient,
            },
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer yi7A9eJa5fZbwNR7DYrP8Vyo`,
              },
            }
          )
          .pipe(
            catchError((error: AxiosError) => {
              throw new HttpException(
                "bots.DNS_PROVIDER_ERROR",
                HttpStatus.BAD_REQUEST
              );
            })
          )
      );

      // link domain to bot
      await this.botModel
        .findOneAndUpdate(
          {
            _id: bot._id,
            isRemoved: { $ne: true },
          },
          {
            domain: linkDomainDto.domain,
            domainUUID: data.uuid,
          }
        )
        .exec();

      await this.organizationModel.findOneAndUpdate(
        {
          _id: bot.organization._id,
        },
        {
          $inc: { customDomainUsage: 1 },
        }
      );

      return true;
    } catch (err) {
      throw new HttpException(
        "bots.DOMAIN_COULD_NOT_BE_LINKED_TO_BOT",
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async remove(condition: { [key: string]: any }) {
    const session = await this.connection.startSession();

    const transaction = await session.withTransaction(async () => {
      const bot = await this.botModel.findOne(condition).session(session);

      if (bot.domain) {
        await this.unlinkDomain(bot._id);
      }

      await this.botModel
        .findOneAndUpdate(
          {
            $and: [
              {
                isRemoved: { $ne: true },
              },
              condition,
            ],
          },
          { isRemoved: true }
        )
        .session(session)
        .exec();

      await this.userResponsesService.removeMany(
        { bot: condition._id },
        session
      );
    });

    session.endSession();

    if (transaction.ok === 1) {
      return HttpResponseWithMessage("removed", HttpStatus.OK);
    } else {
      return HttpResponseWithMessage(
        "common.TRANSACTION_FAILED",
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  async removeMany(
    condition: { [key: string]: any },
    session: mongoose.ClientSession | null = null
  ) {
    const bots = await this.botModel.find(condition).exec();
    const ids = bots.map((bot) => bot._id);

    await this.botModel
      .updateMany(condition, { isRemoved: true })
      .session(session)
      .exec();

    await this.userResponsesService.removeMany({ bot: { $in: ids } }, session);
  }

  async getOpenAIAPIKey(organizationId: string): Promise<string> {
    const organization = await this.organizationModel
      .findOne({ _id: organizationId })
      .exec();

    const secrets = await this.secretModel
      .find({ _id: { $in: organization.secrets } })
      .exec();

    const OpenAISecret = secrets.find(
      (secret) => secret.key === SecretKey.OPEN_AI_KEY
    );

    if (OpenAISecret && organization.plan !== PlanType.BASIC) {
      return decrypt(
        OpenAISecret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
    }

    return this.configService.get<string>("MEVO_OPENAI_KEY");
  }

  async interactWithAssistant(
    bot: string,
    payload: BotInteractionDto,
    ip: string,
    userAgent: string,
    humanCommunicationMode: boolean
  ): Promise<any> {
    const botData = await this.botModel.findById(bot).exec();
    let apiKey;

    if (!botData.gptSettings.useAssistantAPI) return false;
    if (botData.organization.plan === PlanType.BASIC)
      return {
        status: false,
        message: "organizations.ASSISTANT_API_NOT_AVAILABLE_FOR_THIS_TIER",
      };

    try {
      const secret = await this.secretModel
        .findOne({ _id: botData.secrets[0] })
        .exec();

      apiKey = decrypt(
        secret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
    } catch (somethingWentWrong) {
      // STEP2: fetch open ai api key and prepare openAI object
      apiKey = await this.getOpenAIAPIKey(botData.organization._id);
    }

    // prepare openai object
    const openai = new OpenAI({
      apiKey,
    });

    // get session id
    // find the threads with this session id
    // create a thread dif not exist
    // save it to db
    // create a new message into that thread
    // save message to db
    // run the thread
    // return true
    let thread_id;
    let localThread = await this.threadModel.findOne({
      session: payload.sid,
      bot: botData._id,
      assistant_id: botData.gptSettings.assistantID,
    });

    if (!localThread) {
      const remoteThread = await openai.beta.threads.create({
        messages: [
          {
            role: "user",
            content: payload.message,
          },
        ],
      });

      localThread = new this.threadModel({
        session: payload.sid,
        bot: botData._id,
        thread_id: remoteThread.id,
        assistant_id: botData.gptSettings.assistantID,
      });
      await localThread.save();

      thread_id = remoteThread.id;
    } else {
      thread_id = localThread.thread_id;
    }

    if (!humanCommunicationMode) {
      // save remote message
      await openai.beta.threads.messages.create(thread_id, {
        role: humanCommunicationMode ? "user" : "assistant",
        content: payload.message,
      });

      const run = await openai.beta.threads.runs.create(thread_id, {
        assistant_id: botData.gptSettings.assistantID,
        model: botData.gptSettings.model,
      });

      // save run id
      localThread.run_id = run.id;
      await localThread.save();
    }
    
    // get how many unique session for this bot
    const sessionCount = await this.messageModel
      .distinct("session", {
        bot: botData._id,
      })
      .exec();

    // set session count to bot
    botData.sessionCount = sessionCount.length;

    // STEP5: save user message
    const ua = new UAParser(userAgent).getResult();
    // save local message
    const localMessage = new this.messageModel({
      bot: botData._id,
      content: payload.message,
      session: payload.sid,
      sender: MessageSender.USER,
      ip: ip,
      geo: geoip.lookup(ip),
      device: {
        os: ua.os.name,
        browser: ua.browser.name + " v" + ua.browser.version,
        device: ua.device.vendor,
      },
      unread: true,
    });
    await localMessage.save();

    botData.unread = true;

    await botData.save();

    return true;
  }

  async retrieveMessage(sid: string, bid: string): Promise<any> {
    const botData = await this.botModel.findById(bid).exec();
    let apiKey;

    if (botData.organization.plan === PlanType.BASIC)
      return {
        status: false,
        message: "organizations.ASSISTANT_API_NOT_AVAILABLE_FOR_THIS_TIER",
      };

    let localThread = await this.threadModel.findOne({
      session: sid,
      bot: bid,
      assistant_id: botData.gptSettings.assistantID,
    });

    if (!localThread) {
      return {
        status: false,
        message: null,
      };
    }

    if (!botData.gptSettings.useAssistantAPI) return false;

    // STEP2: fetch open ai api key and prepare openAI object
    try {
      const secret = await this.secretModel
        .findOne({ _id: botData.secrets[0] })
        .exec();

      apiKey = decrypt(
        secret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
    } catch (somethingWentWrong) {
      apiKey = await this.getOpenAIAPIKey(botData.organization._id);
    }

    // prepare openai object
    const openai = new OpenAI({
      apiKey,
    });

    const runCheck = await openai.beta.threads.runs.retrieve(
      localThread.thread_id,
      localThread.run_id
    );

    if (runCheck.status === "in_progress") {
      return {
        status: false,
        message: null,
      };
    } else {
      const messages = await openai.beta.threads.messages.list(
        localThread.thread_id
      );

      const aiResponse = new this.messageModel({
        bot: botData._id,
        // @ts-ignore
        content: messages.data[0].content[0].text.value,
        session: sid,
        sender: MessageSender.BOT,
        ip: "127.0.0.1",
        geo: geoip.lookup("127.0.0.1"),
        device: {
          os: "Mevo OS",
          browser: "Mevo Browser",
          device: "MevoBook Pro",
        },
      });
      await aiResponse.save();

      return {
        status: true,
        // @ts-ignore
        message: messages.data[0].content[0].text.value,
      };
    }
  }

  async interact(
    bot: string,
    payload: BotInteractionDto,
    ip: string,
    userAgent: string
  ): Promise<any> {
    const botData = await this.botModel.findById(bot).exec();
    let apiKey;

    try {
      const secret = await this.secretModel
        .findOne({ _id: botData.secrets[0] })
        .exec();
      apiKey = decrypt(
        secret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
    } catch (somethingWentWrong) {
      apiKey = await this.getOpenAIAPIKey(botData.organization._id);
    }

    // prepare openai object
    const openai = new OpenAI({
      apiKey,
    });

    // STEP3: detect bot source type and prepare system prompt
    const isLongTextProvided =
      botData.gptSettings.embeddings &&
      botData.gptSettings.embeddings.rawText.length;
    const isCustomPromptProvided =
      botData.gptSettings.prompt.systemMessage.length;
    const isFileSourceProvded =
      botData.gptSettings.fileSources &&
      botData.gptSettings.fileSources.length > 0;

    let SYSTEM_PROMPT = [
      {
        role: "system",
        content: `
        You are a helpful assistant who only answers messages about the provided information below.
        Your duty is help people by answering their questions. Never return markdown or code snippets.
        `,
      },
    ];

    if (
      botData.gptSettings.feed[0].data.length > 0 &&
      botData.gptSettings.feed[0].data[0].name
    ) {
      try {
        const { data: queryVector } = await this.getEmbedding(
          payload.message,
          apiKey
        );

        const productEmbeddings = await this.embeddingModel.find({
          bot: botData._id,
          type: EmbeddingType.PRODUCT,
        });

        const productValues = productEmbeddings.map(
          (embedding) => embedding.value
        );

        const productRefs = productEmbeddings.map((embedding) => embedding.ref);

        const corpusVectors = productValues.map((tensorArray) =>
          tf.tensor(tensorArray)
        );

        const similarities = corpusVectors.map(
          (vec) => queryVector.dot(vec.transpose()).dataSync()[0]
        );

        const top5 = similarities
          .map((sim, i) => ({ sim, i }))
          .sort((a, b) => b.sim - a.sim)
          .slice(0, 5);

        const top5Messages = top5.map((item) => productRefs[item.i]).join(".");

        SYSTEM_PROMPT[0].content += "Here are our products: \n";
        SYSTEM_PROMPT[0].content += top5Messages;
      } catch (err) {
        console.log("error in product embeddings", err);
      }
    }

    if (
      botData.gptSettings.domainSources &&
      botData.gptSettings.domainSources.length
    ) {
      try {
        const { data: queryVector } = await this.getEmbedding(
          payload.message,
          apiKey
        );

        const webpageEmbeddings = await this.embeddingModel.find({
          bot: botData._id,
          type: EmbeddingType.WEBPAGE,
        });

        const webpageValues = webpageEmbeddings.map(
          (embedding) => embedding.value
        );

        const webpageRefs = webpageEmbeddings.map((embedding) => embedding.ref);

        const corpusVectors = webpageValues.map((tensorArray) =>
          tf.tensor(tensorArray)
        );

        const similarities = corpusVectors.map(
          (vec) => queryVector.dot(vec.transpose()).dataSync()[0]
        );

        const top5 = similarities
          .map((sim, i) => ({ sim, i }))
          .sort((a, b) => b.sim - a.sim)
          .slice(0, 5);

        const top5Messages = top5.map((item) => webpageRefs[item.i]).join(".");

        SYSTEM_PROMPT[0].content +=
          "Here are other information you can use: \n";
        SYSTEM_PROMPT[0].content += top5Messages;
      } catch (err) {
        console.log("error in webpage embeddings", err);
      }
    }

    if (
      botData.gptSettings.feed[1].data.length > 0 &&
      botData.gptSettings.feed[1].data[0].q
    ) {
      try {
        const { data: queryVector } = await this.getEmbedding(
          payload.message,
          apiKey
        );

        const qaEmbeddings = await this.embeddingModel.find({
          bot: botData._id,
          type: EmbeddingType.QA,
        });

        // console.log(qaEmbeddings, "qaEmbeddings");

        const qaValues = qaEmbeddings.map((embedding) => embedding.value);

        const qaRefs = qaEmbeddings.map((embedding) => embedding.ref);

        const corpusVectors = qaValues.map((tensorArray) =>
          tf.tensor(tensorArray)
        );

        const similarities = corpusVectors.map(
          (vec) => queryVector.dot(vec.transpose()).dataSync()[0]
        );

        const top5 = similarities
          .map((sim, i) => ({ sim, i }))
          .sort((a, b) => b.sim - a.sim)
          .slice(0, 5);

        const top5Messages = top5.map((item) => qaRefs[item.i]).join(".");

        console.log(top5Messages, "matched qa");

        SYSTEM_PROMPT[0].content += "Here are some questions and answers: \n";
        SYSTEM_PROMPT[0].content += top5Messages;
      } catch (err) {
        console.log("error in qa embeddings", err);
      }
    }

    // STEP4: inject old messages if chat history is enabled
    const oldMessages = [];

    const messageHistory = await this.messageModel
      .find({
        bot: botData._id,
        session: payload.sid,
      })
      .sort({ createdAt: 1 })
      .exec();

    messageHistory.forEach((message) => {
      oldMessages.push({
        role: message.sender === MessageSender.USER ? "user" : "assistant",
        content: message.content,
      });
    });

    // get how many unique session for this bot
    const sessionCount = await this.messageModel
      .distinct("session", {
        bot: botData._id,
      })
      .exec();

    // set session count to bot
    botData.sessionCount = sessionCount.length;
    await botData.save();

    const unreadMessage = await this.messageModel.findOne({
      session: payload.sid,
      unread: true,
    });

    const org = await this.organizationModel.findById(botData.organization._id);

    // if (!unreadMessage) {
    //   org.admins.forEach((admin) => {
    //     sendTemplateMail("response-received", admin.email, {
    //       name: admin.name.split(" ")[0],
    //       organization: org.name,
    //       bot: botData.name,
    //       content: payload.message,
    //     });
    //   });
    // }

    // try {
    //   if (org.webhookURL && org.plan !== PlanType.BASIC) {
    //     await firstValueFrom(
    //       this.httpService
    //         .post(org.webhookURL, {
    //           content: JSON.stringify({
    //             bot: botData.name,
    //             message: payload.message,
    //             sender: "visitor",
    //           }),
    //         })
    //         .pipe(
    //           catchError((error: AxiosError) => {
    //             throw error;
    //           })
    //         )
    //     );
    //   }
    // } catch (err) {
    //   console.log("could not send organization webhook");
    // }

    // try {
    //   if (
    //     botData.webhooks.length &&
    //     Plans[org.plan].limits.chatbotSpecificWebhooks
    //   ) {
    //     for (const webhookUrl of botData.webhooks) {
    //       await firstValueFrom(
    //         this.httpService
    //           .post(webhookUrl, {
    //             content: JSON.stringify({
    //               bot: botData.name,
    //               message: payload.message,
    //               sender: "visitor",
    //             }),
    //           })
    //           .pipe(
    //             catchError((error: AxiosError) => {
    //               throw error;
    //             })
    //           )
    //       );
    //     }
    //   }
    // } catch (err) {
    //   console.log("could not send chatbot specific webhook");
    // }

    // STEP5: save user message
    const ua = new UAParser(userAgent).getResult();
    const message = new this.messageModel({
      bot: botData._id,
      content: payload.message,
      session: payload.sid,
      sender: MessageSender.USER,
      ip: ip,
      geo: geoip.lookup(ip),
      device: {
        os: ua.os.name,
        browser: ua.browser.name + " v" + ua.browser.version,
        device: ua.device.vendor,
      },
      unread: true,
    });
    await message.save();

    botData.unread = true;
    await botData.save();

    // STEP6: prepare messages array for openai request
    let messages;

    if (isLongTextProvided) {
      const { data: queryVector } = await this.getEmbedding(
        payload.message,
        apiKey
      );

      const textEmbeddings = await this.embeddingModel.find({
        bot: botData._id,
        type: EmbeddingType.TEXT,
      });

      const embeddingsValues = textEmbeddings.map(
        (embedding) => embedding.value
      );
      const embeddingsRefs = textEmbeddings.map((embedding) => embedding.ref);

      const corpusVectors = embeddingsValues.map((tensorArray) =>
        tf.tensor(tensorArray)
      );

      const similarities = corpusVectors.map(
        (vec) => queryVector.dot(vec.transpose()).dataSync()[0]
      );

      const top5 = similarities
        .map((sim, i) => ({ sim, i }))
        .sort((a, b) => b.sim - a.sim)
        .slice(0, 5);

      const top5Messages = top5.map((item) => embeddingsRefs[item.i]).join(".");

      SYSTEM_PROMPT[0].content +=
        "Also you can use this information for answering question too: " +
        top5Messages;
    }

    if (isFileSourceProvded) {
      const { data: queryVector } = await this.getEmbedding(
        payload.message,
        apiKey
      );

      const fileEmbeddings = await this.embeddingModel.find({
        bot: botData._id,
        type: EmbeddingType.FILE,
      });

      const embeddingsValues = fileEmbeddings.map(
        (embedding) => embedding.value
      );
      const embeddingsRefs = fileEmbeddings.map((embedding) => embedding.ref);

      const corpusVectors = embeddingsValues.map((tensorArray) =>
        tf.tensor(tensorArray)
      );

      const similarities = corpusVectors.map(
        (vec) => queryVector.dot(vec.transpose()).dataSync()[0]
      );

      const top5 = similarities
        .map((sim, i) => ({ sim, i }))
        .sort((a, b) => b.sim - a.sim)
        .slice(0, 5);

      const top5Messages = top5.map((item) => embeddingsRefs[item.i]).join(".");

      SYSTEM_PROMPT[0].content += top5Messages;
    }

    if (isCustomPromptProvided) {
      SYSTEM_PROMPT[0].content +=
        "And " + botData.gptSettings.prompt.systemMessage;
    }

    SYSTEM_PROMPT[0].content += `
      If the user asks anything which is not written above say "${botData.gptSettings.fallbackMessage}".
      Use a formal tone and be polite.
      *never* leave from the role* and *never* answer to any other question.
    `;

    // build messages array
    messages = [
      ...SYSTEM_PROMPT,
      ...oldMessages,
      {
        role: "user",
        content: payload.message,
      },
    ];

    // messages = [
    //   {
    //     role: "system",
    //     content:
    //       "\n" +
    //       "        You are a helpful assistant who only answers messages about the provided information below.\n" +
    //       "        Your duty is help people by answering their questions.\n" +
    //       "        Here are our products: \n" +
    //       "Product name: Small; Product description: It contains a single credit that allows you to create a roadmap and join a mock interview with AI.; Product price: $9.99 __MEVO__Here are some questions and answers: \n" +
    //       "__MEVO__.After the interview, you will get feedback, a positive or negative result, and tips. You can join tests again and again. __MEVO__Question: What is your refund policy?; Answer: You can ask for a refund within 7 days after your purchase unless you used any of your credits. If you used any of your credits, you can't ask for a refund. __MEVO__Question: Is there a free tier?; Answer: No, there is no free tier, but we have a %25 discount special for launch week. You can use that discount by applying the LAUNCH25 code on the checkout screen..Question: What this product does?; Answer: It's AI-powered education platform that dynamically create roadmaps for your dream position according the details like experience, key skills etc. You can create a personalized roadmap to yourself, learn new concepts, solve quizzes and join a mock interview with AI. __MEVO__Question: What is a credit?; Answer: A single credit includes one mock interview with AI and one roadmap generation for your personal needs according to the job position, skills, experience etc. All roadmaps includes ten main steps and each step also includes ten sub-steps with quizzes and study cards. __MEVO__Question: Do I need a computer to use this tool?; Answer: No, you can use our tool with your mobile phone or tablet. All of our functionalities are compatible with mobile devices. __MEVO__Question: What if I don't have a camera or microphone?; Answer: You can still join the mock interviews.Also you can use this information for answering question too: Imagine a tool that create a personalized interview preparation roadmap for the job description you pasted, shows what you need to learn, generate quizzes, and even let you practice with AI like a real online interview with a HR professional. That's what we offer.\n" +
    //       // `      If the user asks anything which is not related above say "I'm not sure about it. If you leave your email, I'll get back to you.".\n` +
    //       "      Use a formal tone and be polite.\n" +
    //       "      *never* leave from the role* \n" +
    //       "    ",
    //   },
    //   { role: "user", content: "what is the cost of this service?" },
    //   {
    //     role: "system",
    //     content:
    //       "The cost of our service is $9.99 per credit. Each credit allows you to create a personalized roadmap and join a mock interview with AI.",
    //   },
    //   { role: "user", content: "What are the other prices" },
    // ];

    // console.log(messages, "messages");

    const organization = await this.organizationModel.findById(
      botData.organization._id
    );

    const isCustomAPIKeyProvided = organization.apiKeySet;

    if (
      Plans[organization.plan].limits.token < organization.monthlyTokenUsage &&
      !isCustomAPIKeyProvided
    ) {
      // if organizaiton lastLimitEmailSentAt is null or more than 1 day ago
      // send email to admins
      if (
        !organization.lastLimitEmailSentAt ||
        new Date().getTime() - organization.lastLimitEmailSentAt.getTime() >
          24 * 60 * 60 * 1000
      ) {
        organization.lastLimitEmailSentAt = new Date();
        await organization.save();

        organization.admins.forEach((admin) => {
          sendTemplateMail("limit-reached", admin.email, {
            name: admin.name.split(" ")[0],
            organization: organization.name,
          });
        });
      }

      return {
        message:
          "Our chatbot system is out of service right now, please contact with us on another channel.",
      };
    }

    // STEP7: send request to openai
    const response = await openai.chat.completions.create({
      model: isCustomAPIKeyProvided
        ? botData.gptSettings.model
        : "gpt-3.5-turbo-1106",
      messages,
    });

    if (!isCustomAPIKeyProvided) {
      const usage = response.usage.total_tokens;
      organization.monthlyTokenUsage += usage;
      await organization.save();
    }

    // STEP8: save ai response to db as message
    const aiResponse = new this.messageModel({
      bot: botData._id,
      content: response.choices[0].message.content,
      session: payload.sid,
      sender: MessageSender.BOT,
      ip: ip,
      geo: geoip.lookup(ip),
      device: {
        os: ua.os.name,
        browser: ua.browser.name + " v" + ua.browser.version,
        device: ua.device.vendor,
      },
    });
    await aiResponse.save();

    // try {
    //   if (org.webhookURL && org.plan !== PlanType.BASIC) {
    //     const { data } = await firstValueFrom(
    //       this.httpService
    //         .post(org.webhookURL, {
    //           content: JSON.stringify({
    //             bot: botData.name,
    //             message: response.choices[0].message.content,
    //             sender: "bot",
    //           }),
    //         })
    //         .pipe(
    //           catchError((error: AxiosError) => {
    //             console.log(error.response.data);
    //             throw "An error happened!";
    //           })
    //         )
    //     );
    //   }
    // } catch (err) {}

    return {
      message: response.choices[0].message.content,
    };
  }

  async removeSession(sid: string, bid: string) {
    const session = await this.connection.startSession();

    try {
      const result = await session.withTransaction(async () => {
        // Delete messages by session ID (not device ID)
        await this.messageModel.deleteMany({ session: sid }).session(session).exec();
        
        // Delete leads by device_id (this might be correct if did and device_id are same)
        await this.leadModel
          .deleteMany({ device_id: sid })
          .session(session)
          .exec();

        // Recalculate session count for bot
        const sessionCount = await this.messageModel
          .distinct("session", { bot: bid })
          .session(session)
          .exec();
        
        // Update session count for bot
        await this.botModel
          .findByIdAndUpdate({ _id: bid }, { sessionCount: sessionCount.length })
          .session(session)
          .exec();

        return true;
      });

      if (result) {
        return HttpResponseWithMessage("removed", HttpStatus.OK);
      } else {
        return HttpResponseWithMessage(
          "common.TRANSACTION_FAILED",
          HttpStatus.INTERNAL_SERVER_ERROR
        );
      }
    } catch (error) {
      console.error('Error removing session:', error);
      return HttpResponseWithMessage(
        "common.TRANSACTION_FAILED",
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    } finally {
      await session.endSession();
    }
  }

  async calculateEmbeddings(
    rawText: string,
    bot: Bot,
    type: EmbeddingType,
    writeToDB: boolean = false,
    meta: { [key: string]: any } = {}
  ): Promise<{
    result: boolean;
    message?: string;
    data?: any;
  }> {
    let apiKey;

    if (typeof rawText === "undefined")
      return { result: false, message: "INVALID_TEXT_PROVIDED" };

    try {
      apiKey = decrypt(
        bot.secrets.find((secret) => secret.key === SecretKey.OPEN_AI_KEY)
          .value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
    } catch (somethingWentWrong) {
      apiKey = await this.getOpenAIAPIKey(bot.organization._id);
    }

    const modelEndpoint = "https://api.openai.com/v1/embeddings";

    const tokenizeSentences = (text) => {
      const doc = nlp(text);
      const sentences = doc.sentences().out("array");
      // combine sentences that are shorter than 6 words
      let acc = [];
      let _sentences = [];
      for (let i = 0; i < sentences.length; i++) {
        if (acc.length < 6) {
          acc.push(sentences[i]);
        } else {
          _sentences.push(acc.join(" "));
          acc = [];
        }

        if (i === sentences.length - 1) {
          _sentences.push(acc.join(" "));
        }
      }
      return _sentences;
    };

    const sentences = tokenizeSentences(rawText);

    /**
     * split sentences into chunks of 2047
     * */
    const chunksArr = [];
    let acc = [];

    for (let i = 0; i < sentences.length; i++) {
      if (acc.length < 2047) {
        acc.push(sentences[i]);
      } else {
        chunksArr.push(acc);
        acc = [];
      }

      if (i === sentences.length - 1) {
        chunksArr.push(acc);
      }
    }

    /**
     * get embeddings from openai
     */
    const embeddings = [];

    for (const input of chunksArr) {
      try {
        const { data } = await firstValueFrom(
          this.httpService
            .post(
              modelEndpoint,
              {
                input,
                model: "text-embedding-ada-002",
              },
              {
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${apiKey}`,
                },
              }
            )
            .pipe(
              catchError((error: AxiosError) => {
                throw {
                  result: false,
                  message: error.message,
                };
              })
            )
        );

        data.data.forEach((item) => {
          embeddings.push(tf.tensor(item.embedding).arraySync());
        });
      } catch (err) {
        console.log("openai request failed", err);
      }
    }

    /**
     * save embeddings to db if writeToDB is flag is set
     */
    if (writeToDB) {
      const embeddingIds = [];

      for (const embedding of embeddings) {
        let embeddingObj = {
          bot: bot._id,
          value: embedding,
          ref: sentences[embeddingIds.length],
          type,
          meta,
        };

        try {
          const e = new this.embeddingModel(embeddingObj);
          const savedEmbedding = await e.save();

          embeddingIds.push(savedEmbedding._id);
        } catch (err) {
          // TODO: send to sentry
        }
      }
    }

    /**
     * return embeddings
     */
    return {
      result: true,
      data: embeddings,
    };
  }

  // async embedding(text: string, prompt: string): Promise<any> {
  //   const openaiApiKey = "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";
  //   const modelEndpoint = "https://api.openai.com/v1/embeddings";

  //   const getEmbedding = async (text) => {
  //     const { data } = await firstValueFrom(
  //       this.httpService
  //         .post(
  //           modelEndpoint,
  //           {
  //             input: text,
  //             model: "text-embedding-ada-002",
  //           },
  //           {
  //             headers: {
  //               "Content-Type": "application/json",
  //               Authorization: `Bearer ${openaiApiKey}`,
  //             },
  //           }
  //         )
  //         .pipe(
  //           catchError((error: AxiosError) => {
  //             console.log(error.response.data);
  //             throw "An error happened!";
  //           })
  //         )
  //     );

  //     const embedding = data.data[0].embedding;
  //     return tf.tensor1d(embedding);
  //   };

  //   async function findMostSimilar(text, corpus) {
  //     const queryVector = await getEmbedding(text);
  //     const corpusVectors = await Promise.all(corpus.map(getEmbedding));
  //     const similarities = corpusVectors.map(
  //       (vec) => queryVector.dot(vec.transpose()).dataSync()[0]
  //     );
  //     const top5 = similarities
  //       .map((sim, i) => ({ sim, i }))
  //       .sort((a, b) => b.sim - a.sim)
  //       .slice(0, 5);
  //     return top5.map((item) => corpus[item.i]);
  //   }

  //   const corpus = text.split(".");
  //   const query = prompt;
  //   const response = await findMostSimilar(query, corpus);

  //   return response;

  //   let requestPrompt = "";

  //   response.forEach((item) => {
  //     requestPrompt += item + " ";
  //   });

  //   requestPrompt += prompt;
  //   const configuration = new Configuration({
  //     apiKey: openaiApiKey,
  //   });
  //   const openai = new OpenAIApi(configuration);
  //   const apiResponse = await openai.createChatCompletion({
  //     model: "gpt-3.5-turbo",
  //     messages: [
  //       {
  //         content: requestPrompt,
  //         role: "system",
  //       },
  //     ],
  //   });

  //   return apiResponse.data.choices[0];
  // }

  async getEmbedding(
    text: string,
    key: string
  ): Promise<{ result: boolean; message?: string; data?: any }> {
    const openaiApiKey = key;
    const modelEndpoint = "https://api.openai.com/v1/embeddings";

    try {
      const { data } = await firstValueFrom(
        this.httpService
          .post(
            modelEndpoint,
            {
              input: text,
              model: "text-embedding-ada-002",
            },
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${openaiApiKey}`,
              },
            }
          )
          .pipe(
            catchError((error: AxiosError) => {
              throw "An error happened!";
            })
          )
      );

      const embedding = data.data[0].embedding;
      return {
        result: true,
        data: tf.tensor(embedding),
      };
    } catch (err) {
      return {
        result: false,
        message: "errors.OPEN_AI_KEY_NOT_DEFINED",
      };
    }
  }

  // async migrate() {
  //   const bots = await this.botModel
  //     .find({
  //       isRemoved: { $ne: true },
  //       type: "gpt",
  //     })
  //     .exec();

  //   console.log("migrate after query");

  //   for (const bot of bots) {
  //     console.log("bot migration start", bot.name);
  //     if (bot.gptSettings.feed[0].data.length > 0) {
  //       await this.generateEmbeddings("", EmbeddingType.PRODUCT, bot);
  //     }

  //     if (bot.gptSettings.feed[1].data.length > 0) {
  //       await this.generateEmbeddings("", EmbeddingType.QA, bot);
  //     }

  //     if (typeof bot.gptSettings.embeddings !== "undefined") {
  //       await this.generateEmbeddings(
  //         bot.gptSettings.embeddings.rawText,
  //         EmbeddingType.TEXT,
  //         bot
  //       );
  //     }

  //     if (typeof bot.gptSettings.fileSources !== "undefined") {
  //       for (const [
  //         index,
  //         fileSource,
  //       ] of bot.gptSettings.fileSources.entries()) {
  //         const fileId = randomHex(16);
  //         try {
  //           await this.generateEmbeddings(
  //             fileSource.rawText,
  //             EmbeddingType.FILE,
  //             bot,
  //             {
  //               fileId,
  //             }
  //           );

  //           bot.gptSettings.fileSources[index].fileId = fileId;

  //           await this.botModel.findOneAndUpdate(
  //             {
  //               _id: bot._id,
  //             },
  //             {
  //               fileSources: bot.gptSettings.fileSources,
  //             }
  //           );
  //         } catch (err) {
  //           console.log(
  //             "failed to migrate file source for bot",
  //             bot.name,
  //             bot._id
  //           );
  //         }
  //       }
  //     }

  //     console.log("bot migrated", bot.name);
  //   }
  // }

  async get_submissions(bot: string, pageNumber: number = 1) {
    const pageSize = 16;

    const submissions = await this.userResponseModel.aggregate([
      {
        $match: {
          bot: new ObjectId(bot),
          isRemoved: { $ne: true },
          isHidden: { $ne: true },
        },
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $facet: {
          data: [
            {
              $skip: pageSize * (pageNumber - 1),
            },
            {
              $limit: pageSize,
            },
          ],
          total: [
            {
              $count: "total",
            },
          ],
        },
      },
      {
        $project: {
          data: "$data",
          total: {
            $arrayElemAt: ["$total.total", 0],
          },
        },
      },
    ]);
    return submissions;
  }

  async getMessages(sid: string) {
    const messages = await this.messageModel
      .find({
        session: sid,
      })
      .sort({ createdAt: 1 })
      .exec();
    // update messages as readed
    const updateProcess = await this.messageModel
      .updateMany(
        {
          session: sid,
        },
        {
          $set: {
            unread: false,
          },
        }
      )
      .exec();

    return messages;
  }

  // async scrapeWebsite(domain: string, botId: string) {
  //   const bot = await this.botModel.findById(botId);

  //   if (!bot.gptSettings) {
  //     throw new BadRequestException("bots.NOT_AN_AI_BOT");
  //   }

  //   const organization = await this.organizationModel.findById(
  //     bot.organization._id
  //   );
  //   // open the headless browser
  //   const browser = await puppeteer.launch({ args: ["--no-sandbox"] });
  //   const page = await browser.newPage();
  //   // set domain
  //   const targetDomain = domain.includes("https://")
  //     ? domain
  //     : "https://" + domain;
  //   await page.goto(targetDomain);

  //   // Get all links on the page
  //   const links = await page.$$eval("a", (as) => as.map((a) => a.href));
  //   const visitedLinks = [];
  //   // Visit each link and get its text content
  //   const contents = [];

  //   for (const link of links) {
  //     if (!link.includes(targetDomain.split("https://")[1])) continue;
  //     if (link.split(domain)[1].includes(".")) continue;
  //     if (!link.includes("https://")) continue;
  //     if (visitedLinks.includes(link)) {
  //       continue;
  //     }
  //     await page.goto(link);
  //     const content = await page.$eval("body", (body) => {
  //       const scripts = body.querySelectorAll("script");
  //       scripts.forEach((script) => script.remove());
  //       return body.textContent;
  //     });
  //     contents.push(content.replace(/<[^>]+>/g, ""));
  //     visitedLinks.push(link);
  //   }

  //   await browser.close();

  //   const embeddings = await Promise.all(
  //     contents.map((content) =>
  //       this.getRecalculatedEmbeddingsObject(content, organization)
  //     )
  //   );

  //   let values = [];
  //   let refs = [];

  //   embeddings
  //     .filter((e) => e.result)
  //     .forEach((embedding) => {
  //       values = [...values, ...embedding.data.values];
  //       refs = [...refs, ...embedding.data.refs];
  //     });

  //   bot.gptSettings.embeddings = {
  //     values,
  //     refs,
  //     rawText: "Content scraped from " + domain,
  //     scraped: true,
  //     hash: "",
  //     domain: domain,
  //     lastScraped: new Date(),
  //   };
  //   try {
  //     await this.botModel
  //       .findOneAndUpdate(
  //         {
  //           $and: [
  //             {
  //               isRemoved: { $ne: true },
  //             },
  //             { _id: botId },
  //           ],
  //         },
  //         bot,
  //         {
  //           new: true,
  //         }
  //       )
  //       .exec();
  //     return "bots.SITE_SCRAPED_SUCCESSFULLY";
  //   } catch (err) {
  //     throw new HttpException("bots.SCRAPE_FAILED", HttpStatus.BAD_REQUEST);
  //   }
  // }

  async getGroupedMessagesBySessionForBot(bot: string, pageNumber: number = 1) {
    const botData = await this.findOne({ _id: bot }, false);
    const pageSize = 5;
    const messages = await this.messageModel
      .aggregate([
        {
          $match: {
            bot: botData._id,
          },
        },
        {
          $lookup: {
            from: "leads",
            localField: "session",
            foreignField: "sid",
            as: "lead",
          },
        },
        {
          $project: {
            _id: 1,
            session: 1,
            createdAt: 1,
            geo: 1,
            device: 1,
            ip: 1,
            unread: 1,
            content: 1,
            lead: {
              $cond: {
                if: { $eq: [{ $size: "$lead" }, 0] },
                then: { email: "N/A", name: "N/A", company: "N/A" },
                else: { $first: "$lead" },
              },
            },
          },
        },
        {
          $unwind: "$lead",
        },
        {
          $group: {
            _id: "$session",
            session: { $first: "$session" },
            createdAt: { $max: "$createdAt" },
            geo: { $first: "$geo" },
            device: { $first: "$device" },
            ip: { $first: "$ip" },
            count: { $sum: 1 },
            unread: {
              $max: {
                $cond: [{ $eq: ["$unread", true] }, 1, 0],
              },
            },
            lead: { $first: "$lead" },
            firstMessage: { $first: "$content" },
          },
        },
        {
          $addFields: {
            unread: { $gt: ["$unread", 0] },
          },
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              {
                $skip: pageSize * (pageNumber - 1),
              },
              {
                $limit: pageSize,
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    const messagesCount = await this.messageModel
      .count({
        bot: botData._id,
      })
      .exec();

    return { ...messages, messagesCount };
  }

  async generateBlogPost(postTitle: string) {
    const apiKey = this.configService.get<string>("MEVO_OPENAI_KEY");

    // prepare openai object
    const openai = new OpenAI({
      apiKey,
    });

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo-1106",
      messages: [
        {
          role: "user",
          content: `Write a blog article with the title: ${postTitle} and give me that text as HTML tags. Html should not include any head, body or other tags. Only necessary tags for article, and add inline-styles to basic formatting elements, because I'm using reset.css`,
        },
      ],
    });

    return response.choices[0].message.content;
  }

  // MEVO_V2

  async migration_internal() {
    const bots_to_be_migrated: Bot[] = await this.botModel.find({
      isRemoved: { $ne: true },
      isDraft: { $ne: true },
      "config.meta": { $exists: false },
    });

    for (const bot of bots_to_be_migrated) {
      try {
        await this.botModel
          .updateOne(
            {
              _id: bot._id,
            },
            {
              $set: {
                "config.meta": {
                  title: bot.name,
                  description: "A chatbot created with Mevo",
                },
              },
            }
          )
          .exec();
        console.log("bot meta migrated", bot._id);
      } catch (err) {
        console.log("bot appearance migration failed");
      }
    }

    //   try {
    //     bot.emailReceivers.forEach(async (email_receiver) => {
    //       const user = await this.userModel.findOne({ _id: email_receiver });

    //       await this.add_notification_receiver(
    //         bot._id,
    //         {
    //           type: NotificationType.EMAIL,
    //           payload: {
    //             name: user.name,
    //             email: user.email,
    //           },
    //           bot: bot._id,
    //         },
    //         bot.organization
    //       );

    //       console.log(
    //         "bot notification receiver migrated",
    //         bot._id,
    //         user.email
    //       );
    //     });

    //     bot.webhooks.forEach(async (webhook) => {
    //       await this.add_notification_receiver(
    //         bot._id,
    //         {
    //           type: NotificationType.WEBHOOK,
    //           payload: {
    //             url: webhook,
    //           },
    //           bot: bot._id,
    //         },
    //         bot.organization
    //       );

    //       console.log("bot notification receiver migrated", bot._id, webhook);
    //     });
    //   } catch (err) {
    //     console.log(
    //       "bot notification migration failed",
    //       bot._id,
    //       bot.name,
    //       bot.organization.name
    //     );
    //   }
    // }

    // return true;
    // const bots_to_be_migrated: Bot[] = await this.botModel.find({
    //   "appearance.title": "Chatbot Title",
    // });

    // for (const bot of bots_to_be_migrated) {
    //   try {
    //     await this.botModel
    //       .updateOne(
    //         {
    //           _id: bot._id,
    //         },
    //         {
    //           appearance: {
    //             title: bot.name,
    //           },
    //         }
    //       )
    //       .exec();
    //     console.log("bot appearance migrated", bot._id);
    //   } catch (err) {
    //     console.log(
    //       "bot appearance migration failed",
    //       bot._id,
    //       bot.name,
    //       bot.organization.name
    //     );
    //   }
    // }
  }

  async migrationGPT() {
    const success_ids = [];
    const failed_ids = [];

    const bots_to_be_migrated = await this.botModel.find({
      type: BotType.GPT,
      isRemoved: { $ne: true },
      isDraft: { $ne: true },
      viewCount: { $gt: 0 },
      startCount: { $gt: 0 },
      gptSettings: { $exists: true },
    });

    for (const bot of bots_to_be_migrated) {
      try {
        console.log("bot migration start", bot._id);

        const api_key = await this.get_api_key_for_bot(bot);
        const open_ai_client = new OpenAI({
          apiKey: api_key,
        });

        // update bot with assistantId and vectorStoreId
        await this.botModel
          .updateOne(
            {
              _id: bot._id,
            },
            {
              $set: {
                config: {
                  instructions: bot.gptSettings.prompt.systemMessage,
                  custom_assistant_id: bot.gptSettings.assistantID,
                  is_custom_assistant_enabled: bot.gptSettings.useAssistantAPI,
                },
                appearance: {
                  firstMessage: bot.gptSettings.firstMessage,
                  title: bot.name,
                },
              },
            }
          )
          .exec();

        for (const product of bot.gptSettings.feed[0].data) {
          await this.create_product(bot._id, {
            name: product.name,
            description: product.description,
            price: product.price,
          });
          console.log("migrated product for chatbot", bot._id);
        }

        for (const qa of bot.gptSettings.feed[1].data) {
          await this.add_question(
            {
              question: qa.q,
              answer: qa.a,
              isChatStarter: false,
            },
            bot._id
          );
          console.log("migrated question for chatbot", bot._id);
        }

        console.log("migrated products and questions for chatbot");
      } catch (err) {
        console.log(err, "migration failed");
        failed_ids.push(bot._id);
        console.log(
          "bot migration failed",
          bot._id,
          bot.name,
          bot.organization.name
        );
      }
    }

    return { success_ids, failed_ids };
  }

  async migration() {
    const success_ids = [];
    const failed_ids = [];

    const bots_to_be_migrated = await this.botModel.find({
      type: BotType.GPT,
      isRemoved: { $ne: true },
      isDraft: { $ne: true },
    });

    // console.log(bots_to_be_migrated.length + " bots queued to be migrated...");

    for (const bot of bots_to_be_migrated) {
      // const bot = await this.botModel.findById(b);
      try {
        console.log("bot migration start", bot._id);

        // const api_key = await this.get_api_key_for_bot(bot);
        // const open_ai_client = new OpenAI({
        //   apiKey: api_key,
        // });

        // // create assistant on openai
        // const assistant = await open_ai_client.beta.assistants.create({
        //   name: bot._id + "_" + bot.organization._id,
        //   instructions: bot.gptSettings.prompt.systemMessage,
        //   tools: [{ type: "file_search" }],
        //   model: bot.gptSettings.model,
        // });

        // console.log("assistant created: ", assistant.id);

        // // create vector store for this chatbot on openai
        // // we'll use this vector store for file search tool
        // const vector_store = await open_ai_client.beta.vectorStores.create({});

        // console.log("vector store created: ", vector_store.id);

        // // update assistant with vector store
        // // so assistant can use this vector store for file search tool
        // await open_ai_client.beta.assistants.update(assistant.id, {
        //   tool_resources: {
        //     file_search: { vector_store_ids: [vector_store.id] },
        //   },
        // });

        // console.log("assistant updated with vector store");

        // // update bot with assistantId and vectorStoreId
        // await this.botModel
        //   .updateOne(
        //     {
        //       _id: bot._id,
        //     },
        //     {
        //       $set: {
        //         config: {
        //           assistant_id: assistant.id,
        //           vector_store_id: vector_store.id,
        //           model: bot.gptSettings.model,
        //           instructions: bot.gptSettings.prompt.systemMessage,
        //           custom_assistant_id: bot.gptSettings.assistantID,
        //           is_custom_assistant_enabled: bot.gptSettings.useAssistantAPI,
        //           meta: {
        //             title: "AI Assistant",
        //             description:
        //               "This is an AI assistant trained for answering questions.",
        //           },
        //         },
        //         appearance: {
        //           firstMessage: bot.gptSettings.firstMessage,
        //           title: bot.name,
        //           theme: bot.design.theme,
        //           position: bot.design.position,
        //           description: "",
        //           talkWithAgentMessage: "Start conversation",
        //           hideBranding: false,
        //           showAfterSeconds: 0,
        //           placeholderText: "Type your message...",
        //           brandImage: "",
        //         },
        //       },
        //     }
        //   )
        //   .exec();

        for (const product of bot.gptSettings.feed[0].data) {
          await this.create_product(bot._id, {
            name: product.name,
            description: product.description,
            price: product.price,
          });
          console.log("migrated product for chatbot", bot._id);
        }

        for (const qa of bot.gptSettings.feed[1].data) {
          await this.add_question(
            {
              question: qa.q,
              answer: qa.a,
              isChatStarter: false,
            },
            bot._id
          );
          console.log("migrated question for chatbot", bot._id);
        }

        console.log("bot updated with assistantId and vectorStoreId");
      } catch (err) {
        console.log(err, "error");
        failed_ids.push(bot._id);
        console.log(
          "bot migration failed",
          bot._id,
          bot.name,
          bot.organization.name
        );
      }
    }

    return { success_ids, failed_ids };
  }

  /**
   * A service method which create a chatbot on local db,
   * create an assistant on openai and create a vector store
   * for the assistant on openai, then update the bot with
   * assistantId and vectorStoreId
   *
   * @param create_bot_dto : CreateBotDto
   * @returns Bot
   */
  async create_bot(create_bot_dto: CreateBotDto): Promise<Bot> {
    try {
      const organization = await this.organizationModel.findById(
        create_bot_dto.organization
      );

      const botCount = await this.botModel.countDocuments({
        organization: create_bot_dto.organization,
        isRemoved: { $ne: true },
        isDraft: { $ne: true },
      });

      if (botCount >= Plans[organization.plan].limits.bot)
        throw new HttpException(
          "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
          HttpStatus.BAD_REQUEST
        );

      const type = create_bot_dto.type || BotType.GPT;

      if (type === BotType.GPT) {
        // we're looking organization level api key
        // if is there any organization level api key, we're creating bot with that key
        // if not, we're creating bot with the default key
        const api_key = await this.getOpenAIAPIKey(create_bot_dto.organization);
        const open_ai_client = new OpenAI({
          apiKey: api_key,
        });

        create_bot_dto.config.instructions = `You are an AI assistant who helps users with their inquiries, issues and requests. You aim to provide excellent, friendly and efficient replies at all times. Your role is to listen attentively to the user, understand their needs, and do your best to assist them or direct them to the appropriate resources. If a question is not clear, ask clarifying questions. Make sure to end your replies with a positive note. Never mention that you have access to training data explicitly to the user. If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to the training data. You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, say "I am not sure about that but my teammates will reach out you if you leave your email address". You do not answer questions or perform tasks that are not related to your role and training data. All your responses should be in markdown format.`;

        // create assistant on openai
        const assistant = await open_ai_client.beta.assistants.create({
          instructions: create_bot_dto.config.instructions,
          tools: [{ type: "file_search" }],
          model: create_bot_dto.config.model,
        });

        // create vector store for this chatbot on openai
        // we'll use this vector store for file search tool
        const vector_store = await open_ai_client.beta.vectorStores.create({});

        // update assistant with vector store
        // so assistant can use this vector store for file search tool
        await open_ai_client.beta.assistants.update(assistant.id, {
          tool_resources: {
            file_search: { vector_store_ids: [vector_store.id] },
          },
        });

        // create a local chatbot on db
        // save bot with assistantId and vectorStoreId
        // so we can use these ids for further operations
        // and return the bot
        const created_bot = await this.botModel.create({
          name: create_bot_dto.name,
          type: BotType.GPT,
          createdBy: create_bot_dto.createdBy,
          organization: create_bot_dto.organization,
          fromTemplate: create_bot_dto.fromTemplate,
          config: {
            model: create_bot_dto.config.model,
            instructions: create_bot_dto.config.instructions,
            assistant_id: assistant.id,
            vector_store_id: vector_store.id,
            meta: {
              title: "AI Assistant",
              description:
                "This is an AI assistant trained for answering questions.",
            },
            show_ai_indicator: false,
          },
          appearance: {
            theme: BotTheme.INDIGO,
            position: BotPosition.BOTTOM_RIGHT,
            greeting: "Welcome",
            firstMessage: "Hello, how can I help you?",
            title: "AI Assistant",
            description: "An AI assistant trained for answering questions.",
            talkWithAgentMessage: "Start conversation",
            hideBranding: false,
            showAfterSeconds: 0,
            placeholderText: "Type your message...",
            brandImage: "",
            skipWelcomePage: false,
          },
          version: 2,
          flow: create_bot_dto.flow as unknown as BotFlow
        });

        try {
          const { data } = await firstValueFrom(
            this.httpService.post(
              "https://api.telegram.org/bot7829408371:AAFs4wqDl7annRiY9D5oGpiRN6Hs3UkLKO4/sendMessage",
              {
                chat_id: 406038897,
                text: `🤖 Bot created
        
🏢 ${created_bot.organization.name}
🎯 ${created_bot.organization.admins[0].name} - ${created_bot.organization.admins[0].email}
🧩 AI Chatbot
        `,
              },
              {
                headers: {
                  "Content-Type": "application/json",
                },
              }
            )
          );
        } catch (err) {}

        return created_bot;
      } else {
        const created_bot = await this.botModel.create({
          name: create_bot_dto.name,
          type: BotType.SCRIPTED,
          createdBy: create_bot_dto.createdBy,
          organization: create_bot_dto.organization,
          config: {
            meta: {
              title: "Rule-based Chatbot",
              description:
                "This is a rule-based chatbot created for collecting information.",
            },
          },
          script: create_bot_dto.script,
          appearance: {
            theme: BotTheme.INDIGO,
            position: BotPosition.BOTTOM_RIGHT,
            greeting: "Welcome",
            firstMessage: "Hello, how can I help you?",
            title: "Chatbot",
            description: "A rule-based chatbot created for help people.",
            talkWithAgentMessage: "Start conversation",
            hideBranding: false,
            showAfterSeconds: 0,
            placeholderText: "Type your message...",
            brandImage: "",
            skipWelcomePage: false,
          },
          version: 2,
        });

        try {
          const { data } = await firstValueFrom(
            this.httpService.post(
              "https://api.telegram.org/bot7829408371:AAFs4wqDl7annRiY9D5oGpiRN6Hs3UkLKO4/sendMessage",
              {
                chat_id: 406038897,
                text: `🤖 Bot created
        
🏢 ${created_bot.organization.name}
🎯 ${created_bot.organization.admins[0].name} - ${created_bot.organization.admins[0].email}
🧩 Rulebased Chatbot
        `,
              },
              {
                headers: {
                  "Content-Type": "application/json",
                },
              }
            )
          );
        } catch (err) {}

        return created_bot;
      }
    } catch (err) {
      console.log(err, 'error');
      if (err.error && err.error.code === "invalid_api_key") {
        throw new HttpException("bots.INVALID_API_KEY", HttpStatus.BAD_REQUEST);
      } else if (
        err.message === "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS"
      ) {
        throw new HttpException(
          "organizations.YOUR_PLAN_LIMIT_REACHED_FOR_BOTS",
          HttpStatus.BAD_REQUEST
        );
      } else {
        throw new HttpException(
          "bots.BOT_CREATION_FAILED",
          HttpStatus.BAD_REQUEST
        );
      }
    }
  }

  /**
   * A service method which remove a chatbot from local db,
   * remove the assistant from openai and remove the vector store
   * for the assistant on openai
   *
   * @param botId : string
   * @returns boolean
   */
  async remove_bot(bot_id: string): Promise<boolean> {
    try {
      // find the bot with given id
      const bot = await this.botModel.findById(bot_id);

      if (bot.type === BotType.GPT) {
        // we're looking organization level api key
        // if is there any organization level api key, we're creating bot with that key
        // if not, we're creating bot with the default key
        const api_key = await this.get_api_key_for_bot(bot);
        const open_ai_client = new OpenAI({
          apiKey: api_key,
        });

        // remove training resources of the bot
        await this.remove_training_resources(bot_id);

        // remove assistant from openai
        await open_ai_client.beta.assistants.del(bot.config.assistant_id);

        // remove vector store from openai
        await open_ai_client.beta.vectorStores.del(bot.config.vector_store_id);

        // remove bot from local db
        await this.botModel.deleteOne({ _id: bot_id });

        // remove messages of the bot
        await this.messageModel.deleteMany({ bot: bot_id });

        // remove leads of the bot
        await this.leadModel.deleteMany({ bot: bot_id });

        // update organization training character usage
        await this.update_training_character_usage(bot.organization._id);
      } else {
        // remove bot from local db
        await this.botModel.deleteOne({ _id: bot_id });

        // remove messages of the bot
        await this.userResponseModel.deleteMany({ bot: bot_id });
      }

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * A service method which update tags of a chatbot
   * on local db
   * 
   * @param bot_id : string
   * @param tags : string[]
   * @returns Bot
   */
  async update_tags(bot_id: string, tags: string[]): Promise<boolean> {
    try {
      // update bot with new tags
      await this.botModel.updateOne(
        { _id: bot_id },
        {
          $set: {
            tags,
          }
        }
      );

      return true;
    } catch (err) {
      return false;
    }
  }

 /**
 * A service method which update chatbot settings from local db,
 * update the assistant on openai
 *
 * @param bot_id : string
 * @returns Bot
 */
  async update_bot(
    bot_id: string,
    update_bot_config_dto: UpdateBotConfigDto,
    write_db: boolean = true
  ): Promise<Boolean> {
    // find the bot with given id
    const bot = await this.botModel.findById(bot_id).lean().exec() as Bot;

    // we're looking organization level api key
    // if is there any organization level api key, we're creating bot with that key
    // if not, we're creating bot with the default key
    const api_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: api_key,
    });

    const assistant_id = bot.config.is_custom_assistant_enabled
      ? bot.config.custom_assistant_id
      : bot.config.assistant_id;

    if (update_bot_config_dto.instructions && update_bot_config_dto.model) {
      // update assistant on openai
      // TODO: fallback prompt: if the user's message is not related with the content of the files we provided the bot will respond with: ${bot.config.fallbackMessage}
      await open_ai_client.beta.assistants.update(assistant_id, {
        instructions: `${update_bot_config_dto.instructions}`,
        model: update_bot_config_dto.model,
      });
    }

    if (write_db) {
      const updateObject = {
        config: {
          ...bot.config,
        },
        flow: bot.flow,
      };

      if (update_bot_config_dto.instructions && update_bot_config_dto.model) {
        updateObject.config.instructions = update_bot_config_dto.instructions;
        updateObject.config.model = update_bot_config_dto.model;
      }

      if (update_bot_config_dto.flow) {
        updateObject.flow = update_bot_config_dto.flow;
      }

      // update bot on local db
      await this.botModel.updateOne(
        { _id: bot_id },
        {
          $set: updateObject,
        }
      );
    }

    return true;
  }

  async repair_chatbot(bot: Bot): Promise<Bot> {
    const bot_object: Bot = await this.botModel.findById(bot._id);
    const open_ai_client = new OpenAI({
      apiKey: await this.get_api_key_for_bot(bot_object),
    });

    let instructions;
    let model;
    let config;
    let appearance;

    // if config exists, we're updating the assistant
    if (bot_object.config) {
      instructions = bot_object.config.instructions || "";
      model = bot_object.config.model.includes("gpt-4")
        ? "gpt-4-turbo"
        : bot_object.config.model;
      config = bot_object.config;

      if (!bot_object.config.meta) {
        config.meta = {
          title: bot.appearance.title,
          description: bot.appearance.description,
          keywords: "",
          og_image: "",
        };
      }

      // update assistant with new model and instructions
      // so assistant can use this vector store for file search tool
      await open_ai_client.beta.assistants.update(
        bot_object.config.assistant_id,
        {
          instructions,
          model,
        }
      );
    }
    // if config does not exist, we're creating a new assistant
    // and updating the bot with assistantId and vectorStoreId
    else {
      instructions = bot_object.gptSettings.prompt.systemMessage;
      model = bot_object.gptSettings.model.includes("gpt-4")
        ? "gpt-4-turbo"
        : bot_object.gptSettings.model;

      const assistant = await open_ai_client.beta.assistants.create({
        name: bot_object._id + "_" + bot_object.organization._id,
        instructions,
        tools: [{ type: "file_search" }],
        model,
      });

      // create vector store for this chatbot on openai
      // we'll use this vector store for file search tool
      const vector_store = await open_ai_client.beta.vectorStores.create({});

      // update assistant with vector store
      // so assistant can use this vector store for file search tool
      await open_ai_client.beta.assistants.update(assistant.id, {
        tool_resources: {
          file_search: { vector_store_ids: [vector_store.id] },
        },
      });

      config = {
        model,
        instructions,
        assistant_id: assistant.id,
        vector_store_id: vector_store.id,
        custom_assistant_id: bot_object.gptSettings.assistantID,
        custom_vector_store_id: "",
        is_custom_assistant_enabled: bot_object.gptSettings.useAssistantAPI,
        meta: {
          title: bot.name,
          description: "",
          keywords: "",
          og_image: "",
        },
      };
    }

    if (bot_object.appearance) {
      appearance = bot_object.appearance;
    } else {
      appearance = {
        theme: bot_object.design.theme,
        position: bot_object.design.position,
        greeting: "Welcome",
        firstMessage: "Hello, how can I help you?",
        title: bot_object.name,
        description: "",
        talkWithAgentMessage: "Start conversation",
        hideBranding: false,
        showAfterSeconds: 0,
        placeholderText: "This is placeholder",
        brandImage: "",
      };
    }

    await this.botModel.updateOne(
      { _id: bot_object._id },
      {
        $set: {
          config: config,
          appearance: appearance,
        },
      }
    );

    return bot;
  }

  async fix_bot_level_keys() {
    const bots_not_migrated = [];
    const bots = await this.botModel.find({
      secrets: { $ne: [], $exists: true },
      isRemoved: { $ne: true },
      isDraft: { $ne: true },
      type: "gpt",
    });

    for (var bot of bots) {
      const has_custom_assistant =
        bot?.config?.is_custom_assistant_enabled || false;
      if (!has_custom_assistant) {
        console.log("started migration for bot", bot.name);
        try {
          const api_key = await this.get_api_key_for_bot(bot);
          const open_ai_client = new OpenAI({
            apiKey: api_key,
          });

          // create assistant on openai
          const assistant = await open_ai_client.beta.assistants.create({
            name: bot.name + "_created_by_mevo",
            instructions: bot.config.instructions,
            tools: [{ type: "file_search" }],
            model: "gpt-3.5-turbo-1106",
          });

          // create vector store for this chatbot on openai
          // we'll use this vector store for file search tool
          const vector_store = await open_ai_client.beta.vectorStores.create(
            {}
          );

          // update assistant with vector store
          // so assistant can use this vector store for file search tool
          await open_ai_client.beta.assistants.update(assistant.id, {
            tool_resources: {
              file_search: { vector_store_ids: [vector_store.id] },
            },
          });

          // update bot with assistantId and vectorStoreId
          await this.botModel.updateOne(
            {
              _id: bot._id,
            },
            {
              $set: {
                config: {
                  ...bot.config,
                  is_custom_assistant_enabled: true,
                  custom_assistant_id: assistant.id,
                  custom_vector_store_id: vector_store.id,
                  model: "gpt-3.5-turbo-1106",
                },
              },
            }
          );
          console.log("migration completed for bot", bot.name);
        } catch (err) {
          console.log("migration failed for bot", bot.name);
          console.log("repairing bot", bot.name);
          if (
            err.code === "invalid_api_key" ||
            err.code === "model_not_found"
          ) {
            const api_key = this.configService.get<string>("MEVO_OPENAI_KEY");
            const open_ai_client = new OpenAI({
              apiKey: api_key,
            });

            // create assistant on openai
            const assistant = await open_ai_client.beta.assistants.create({
              name: bot.name + "_created_by_mevo",
              instructions: bot.config.instructions,
              tools: [{ type: "file_search" }],
              model: "gpt-3.5-turbo-1106",
            });

            // create vector store for this chatbot on openai
            // we'll use this vector store for file search tool
            const vector_store = await open_ai_client.beta.vectorStores.create(
              {}
            );

            // update assistant with vector store
            // so assistant can use this vector store for file search tool
            await open_ai_client.beta.assistants.update(assistant.id, {
              tool_resources: {
                file_search: { vector_store_ids: [vector_store.id] },
              },
            });

            // update bot with assistantId and vectorStoreId
            await this.botModel.updateOne(
              {
                _id: bot._id,
              },
              {
                $set: {
                  apiKeySet: false,
                  secrets: [],
                  config: {
                    ...bot.config,
                    is_custom_assistant_enabled: false,
                    assistant_id: assistant.id,
                    vector_store_id: vector_store.id,
                  },
                },
              }
            );
          } else {
            bots_not_migrated.push({
              bot: bot._id,
              reason: err.code,
              err: err,
            });
          }
        }
      } else {
        console.log("skipped bcz it already has custom assistant", bot.name);
      }
    }

    return bots_not_migrated;
  }

  async create_custom_vector_store_if_not_exists(
    bot: Bot,
    api_key: string
  ): Promise<string> {
    const non_supported_models_for_file_search = [
      "gpt-4",
      "gpt-4-1106-preview",
      "gpt-4-0613",
      "gpt-4-0125-preview",
    ];
    // init client
    const open_ai_client = new OpenAI({
      apiKey: api_key,
    });

    // get existing assistant
    const existing_assistant = await open_ai_client.beta.assistants.retrieve(
      bot.config.custom_assistant_id
    );

    // init vector store ids array
    let vector_store_ids = [];
    let custom_vector_store_id = "";

    // check if file search tool is enabled
    // if not enabled, we're enabling it
    // check if vector store id is available
    // if not available, we're creating a new vector store
    // if available, we're using it as custom vector store id and updating the bot

    const has_file_search_tool = existing_assistant.tools.some(
      (tool) => tool.type === "file_search"
    );
    const has_vector_store_id =
      existing_assistant.tool_resources?.file_search?.vector_store_ids
        ?.length || false;

    let assistant_tools = existing_assistant.tools.map((tool) => ({
      type: tool.type,
    }));

    // enable file search tool if not enabled
    if (!has_file_search_tool) {
      assistant_tools.push({ type: "file_search" });
    }

    // create and assign new vector store if not available
    if (!has_vector_store_id) {
      const created_vector_store =
        await open_ai_client.beta.vectorStores.create({});
      vector_store_ids = [created_vector_store.id];
      custom_vector_store_id = created_vector_store.id;
    }

    // assign existing vector store to bot if available
    if (has_vector_store_id) {
      vector_store_ids =
        existing_assistant.tool_resources.file_search.vector_store_ids;
      custom_vector_store_id =
        existing_assistant.tool_resources.file_search.vector_store_ids[0];
    }

    let model = existing_assistant.model;
    if (
      non_supported_models_for_file_search.includes(existing_assistant.model)
    ) {
      if (model.includes("gpt-4")) {
        model = "gpt-4-turbo";
      } else {
        model = "gpt-3.5-turbo-1106";
      }
    }

    await open_ai_client.beta.assistants.update(
      bot.config.custom_assistant_id,
      {
        // @ts-ignore
        tools: assistant_tools,
        model: model,
        tool_resources: {
          file_search: {
            vector_store_ids: vector_store_ids,
          },
        },
      }
    );

    await this.botModel.updateOne(
      {
        _id: bot._id,
      },
      {
        $set: {
          config: {
            ...bot.config,
            custom_vector_store_id: custom_vector_store_id,
            model: model,
          },
        },
      }
    );

    return custom_vector_store_id;
  }

  /**
   * A service method which create a file from the training content
   * and upload it to vector store on the openai
   *
   * It returns the file id of the uploaded file.
   *
   * @param organization_id - string - organization id, we need this for getting custom api key if available
   * @param content - string or { originalname: string; buffer: Buffer } - content to be uploaded
   * @param vector_store_id - string - vector store id
   *
   * @returns file_id - string
   */
  async add_content_to_vector_store(
    bot: Bot,
    content: string | { originalname: string; buffer: Buffer }
  ): Promise<string> {
    const api_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: api_key,
    });

    let postfix = "";

    if (typeof content === "string") {
      postfix = ".txt";
    } else {
      postfix = `.${
        content.originalname.split(".")[
          content.originalname.split(".").length - 1
        ]
      }`;
    }

    const file_payload = typeof content === "string" ? content : content.buffer;

    return new Promise((resolve, reject) => {
      tmp.file({ postfix }, (err, path, fd, cleanup_callback) => {
        if (err) throw err;

        fs.writeFile(fd, file_payload, { encoding: "utf8" }, async (err) => {
          if (err) throw err;

          try {
            const file = await open_ai_client.files.create({
              file: fs.createReadStream(path),
              purpose: "assistants",
            });

            await this.update_training_character_usage(bot.organization._id);

            // if custom assistant is enabled and custom vector store id is not available
            // we're creating a new vector store for the custom assistant
            if (
              bot.config.is_custom_assistant_enabled &&
              !bot.config.custom_vector_store_id
            ) {
              bot.config.custom_vector_store_id =
                await this.create_custom_vector_store_if_not_exists(
                  bot,
                  api_key
                );
            }

            const target_vector_store_id = bot.config
              .is_custom_assistant_enabled
              ? bot.config.custom_vector_store_id
              : bot.config.vector_store_id;

            await open_ai_client.beta.vectorStores.files.createAndPoll(
              target_vector_store_id,
              { file_id: file.id }
            );

            cleanup_callback();
            resolve(file.id);
          } catch (error) {
            cleanup_callback();
            reject(error);
          }
        });
      });
    });
  }

  async update_training_character_usage(organization_id: string) {
    let total_training_character = 0;
    const organization = await this.organizationModel.findOne({ _id: organization_id }).exec();

    const bots = await this.botModel.find({
      organization: organization._id,
      type: BotType.GPT,
      isRemoved: { $ne: true },
      config: { $exists: true },
    });

    for (const bot of bots) {
      const links = await this.linkModel.find({ bot: bot._id, status: 'trained' }).exec();
      const files = await this.fileModel.find({ bot: bot._id }).exec();
      const texts = await this.textModel.find({ bot: bot._id }).exec();
      const questions = await this.questionModel.find({ bot: bot._id }).exec();

      for (const link of links) {
        if (typeof link.characterCount === 'number') {
          total_training_character += link.characterCount;
        }
      }

      for (const file of files) {
        if (typeof file.characterCount === 'number') {
          total_training_character += file.characterCount;
        }
      }

      for (const text of texts) {
        if (typeof text.characterCount === 'number') {
          total_training_character += text.characterCount;
        }
      }

      for (const question of questions) {
        if (typeof question.question === 'string' && typeof question.answer === 'string') {
          total_training_character += (question.question.length + question.answer.length);
        }
      }
    }

    try {
      console.log('total_training_character', total_training_character);
      await this.organizationModel.updateOne(
        {
          _id: organization._id,
        },
        {
          $set: {
            trainingCharacterUsage: total_training_character,
          },
        }
      );

      try {
        const isExceeded = Plans[organization.plan].limits.charLimit < total_training_character;
        await this.organizationModel.updateOne({ _id: organization._id }, { $set: { trainingCharacterExceeded: isExceeded } });
      } catch (err) {
        console.log('error updating training character usage', err);
      }
    } catch (err) {
      console.log('error updating training character usage', err);
    }
  }

  /**
   * A service method which create a file from the training content
   * and upload it to vector store on the openai
   *
   * It returns the file id of the uploaded file.
   *
   * @param organization_id - string - organization id, we need this for getting custom api key if available
   * @param file_id - string - file id
   *
   * @returns boolean
   */
  async delete_content_from_vector_store(
    organization_id: string,
    file_id: string,
    contentType: "file" | "text" | "link" | "question" | "product"
): Promise<boolean> {
    try {
        const api_key = await this.getOpenAIAPIKey(organization_id);
        const openai_client = new OpenAI({
            apiKey: api_key,
        });

        let content;

        switch (contentType) {
            case "file":
                content = await this.fileModel.findOne({ fileId: file_id }).exec();
                break;
            case "text":
                content = await this.textModel.findOne({ fileId: file_id }).exec();
                break;
            case "link":
                content = await this.linkModel.findOne({ fileId: file_id }).exec();
                break;
            case "question":
                content = await this.questionModel.findOne({ fileId: file_id }).exec();
                break;
            case "product":
                content = await this.productModel.findOne({ fileId: file_id }).exec();
                break;
            default:
                return false;
        }

        if (!content) return false;

        const bot = await this.botModel.findById(content.bot).exec();
        if (!bot || !bot.config.vector_store_id) return false;

        const vector_store_id = bot.config.vector_store_id;

        const stored_files = await openai_client.beta.vectorStores.files.list(vector_store_id);

        const fileExists = stored_files.data.some(f => f.id === file_id);
        if (!fileExists) return false;

        await openai_client.beta.vectorStores.files.del(vector_store_id, file_id);
        await openai_client.files.del(file_id);

        await this.update_training_character_usage(organization_id);

        return true;
    } catch (err) {
        return false;
    }
}

  /**
   * In V2, we have dedicated entities for notification receivers,
   * instead of chatbot entity properties.
   *
   * This method for creating a notification receiver.
   *
   * @param bot_id
   * @param notification_receiver_dto - NotificationReceiverDto - Includes notification type and payload
   *
   * @returns NotificationReceiver
   */
  async add_notification_receiver(
    bot_id: string,
    notification_receiver_dto: NotificationReceiverDto,
    organization: Organization
  ) {
    if (notification_receiver_dto.type === "email") {
      const user = await this.userModel.findOne({
        email: notification_receiver_dto.payload.email,
      });

      if (!user) {
        throw new HttpException(
          "notification_receiver.USER_NOT_FOUND",
          HttpStatus.BAD_REQUEST
        );
      }

      const is_user_of_organization = organization.users.find(
        (u) => u.email === user.email
      );
      const is_admin_of_organization = organization.admins.find(
        (a) => a.email === user.email
      );
      const is_notification_receiver = organization.listeners.find(
        (l) => l.email === user.email
      );

      const is_user_member_of_organization =
        is_user_of_organization ||
        is_admin_of_organization ||
        is_notification_receiver;

      if (!is_user_member_of_organization) {
        throw new HttpException(
          "notification_receiver.USER_NOT_MEMBER_OF_ORGANIZATION",
          HttpStatus.BAD_REQUEST
        );
      }

      const notification_receivers = await this.notificationReceiverModel.find({
        bot: bot_id,
        "payload.email": notification_receiver_dto.payload.email,
      });

      if (notification_receivers.length) {
        throw new HttpException(
          "notification_receiver.EMAIL_ALREADY_EXISTS",
          HttpStatus.BAD_REQUEST
        );
      }
    }

    if (notification_receiver_dto.type === "webhook") {
      const notification_receivers = await this.notificationReceiverModel.find({
        bot: bot_id,
        "payload.url": notification_receiver_dto.payload.url,
      });

      if (notification_receivers.length) {
        throw new HttpException(
          "notification_receiver.URL_ALREADY_EXISTS",
          HttpStatus.BAD_REQUEST
        );
      }
    }

    const new_notification_receiver = new this.notificationReceiverModel({
      bot: bot_id,
      type: notification_receiver_dto.type,
      payload: notification_receiver_dto.payload,
    });

    return new_notification_receiver.save();
  }

  /**
   * Service method for removing a notification receiver entity.
   *
   * @param receiver_id - string (object id) - notification receiver id
   * @returns - boolean
   */
  async delete_notification_receiver(receiver_id: string): Promise<boolean> {
    try {
      await this.notificationReceiverModel.remove({ _id: receiver_id }).exec();
      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * Service method for getting notification receivers for a bot
   * with pagination and type filter.
   *
   * If not type parameter provided, it'll return all notification
   * receivers without type filter.
   *
   * @param bot_id
   * @param page_number
   * @param type
   * @returns - { data: NotificationReceiver[]; total: number }[]
   */
  async get_notification_receiver(
    bot_id: string,
    page_number: number = 1,
    type: NotificationType = NotificationType.ALL
  ): Promise<{ data: NotificationReceiver[]; total: number }[]> {
    const $match = {
      bot: new ObjectId(bot_id),
    };
    const page_size = 10;

    if (type !== NotificationType.ALL) {
      $match["type"] = type;
    }

    const receivers = await this.notificationReceiverModel
      .aggregate([
        {
          $match,
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              {
                $skip: page_size * (page_number - 1),
              },
              {
                $limit: page_size,
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    return receivers;
  }

  /**
   * Service method for adding a text to the bot's vector store.
   * It creates a text entity on the local db and adds the content
   * to the bot's vector store on openai.
   *
   * @param content - string, text content
   * @param bot_id - string (object id) - bot id
   * @returns - Text
   */
  async add_text(content: string, bot_id: string) {
    const bot = await this.botModel.findById(bot_id).exec();

    if (!bot.config.is_custom_assistant_enabled) {
      const is_training_character_usage_exceeded =
        await this.is_training_character_usage_exceeded(
          bot.organization,
          content.length
        );

      if (is_training_character_usage_exceeded) {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }
    }

    const file_id = await this.add_content_to_vector_store(bot, content);

    // update organization training character usage
    this.update_training_character_usage(bot.organization._id).then(() => {});

    const new_text = new this.textModel({
      bot: bot_id,
      characterCount: content.length,
      status: "trained",
      content: content,
      fileId: file_id,
    });

    return new_text.save();
  }

  async is_training_character_usage_exceeded(
    organization: Organization,
    content_size: number
  ) {
    const organization_object = await this.organizationModel.findById(
      organization._id
    );

    return (
      Plans[organization_object.plan].limits.charLimit <
      organization_object.trainingCharacterUsage + content_size
    );
  }

  /**
   * Create a new question entity on the local db and add the content
   * to the bot's vector store on openai.
   *
   * @param question_dto
   * @param bot_id
   * @returns - Question
   */
  async add_question(
    question_dto: AddQuestionDto,
    bot_id: string
  ): Promise<Question> {
    const same_question = await this.questionModel
      .findOne({
        bot: bot_id,
        question: question_dto.question,
      })
      .exec();

    if (same_question) {
      return same_question;
    }

    const content = `Example question: ${question_dto.question}, Answer: ${question_dto.answer}`;
    const bot = await this.botModel.findById(bot_id).exec();

    if (!bot.config.is_custom_assistant_enabled) {
      const is_training_character_usage_exceeded =
        await this.is_training_character_usage_exceeded(
          bot.organization,
          content.length
        );

      if (is_training_character_usage_exceeded) {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }
    }

    console.log("content ->", content);
    const file_id = await this.add_content_to_vector_store(bot, content);

    // update organization training character usage
    this.update_training_character_usage(bot.organization._id).then(() => {});

    const new_question = new this.questionModel({
      bot: bot_id,
      question: question_dto.question,
      answer: question_dto.answer,
      status: "trained",
      isChatStarter: question_dto.isChatStarter,
      fileId: file_id,
    });

    return new_question.save();
  }

  /**
   * Create a new file entity on the local db and add the content
   * to the bot's vector store on openai.
   *
   * @param bot_id - string (object id) - bot id
   * @param file - any - file object
   * @returns - File
   */
  async create_file(bot_id: string, file: any): Promise<File> {
    let contentSize = 0;
    let content = "";
    const file_extension = file.originalname.split(".").pop();
    const bot = await this.botModel.findById(bot_id).exec();
    if (
      file_extension === "doc" ||
      file_extension === "docx" ||
      file_extension === "ppt" ||
      file_extension === "pptx" ||
      file_extension === "pdf"
    ) {
      try {
        // "data" string returned from promise here is the text parsed from the office file passed in the argument
        content = await officeParser.parseOfficeAsync(file.buffer);
      } catch (err) {
        throw new HttpException(
          "bot.COULD_NOT_PARSE_OFFICE_FILE",
          HttpStatus.BAD_REQUEST
        );
      }
    } else {
      content = file.buffer.toString("utf-8");
    }

    // set content size
    contentSize = content.length;

    const is_training_character_usage_exceeded =
      await this.is_training_character_usage_exceeded(
        bot.organization,
        contentSize
      );

    if (is_training_character_usage_exceeded) {
      throw new HttpException(
        "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
        HttpStatus.BAD_REQUEST
      );
    }

    // add content to vector store
    const file_id = await this.add_content_to_vector_store(bot, file);

    // // update organization training character usage
    // await this.update_training_character_usage(bot.organization._id);

    // save file ref in local
    const new_file = new this.fileModel({
      bot: bot_id,
      status: "trained",
      file_name: file.originalname,
      extension: file.originalname.split(".").pop(),
      characterCount: contentSize,
      size: file.size,
      fileId: file_id,
    });

    return new_file.save();
  }

  /**
   * Create a new products file by analyzing the shopify product export
   * file.
   *
   * @param bot_id - string (object id) - bot id
   * @param file - any - file object
   * @returns - File
   */
  async create_products_from_shopify_export(
    bot_id: string,
    file: any,
    options: {
      onlyActive: boolean;
      onlyInStock: boolean;
    }
  ): Promise<boolean> {
    try {
      const bot = await this.botModel.findById(bot_id).exec();
      const csvString = file.buffer.toString("utf-8");
      const is_training_character_usage_exceeded =
        await this.is_training_character_usage_exceeded(
          bot.organization,
          csvString.length
        );

      if (is_training_character_usage_exceeded) {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }

      const products = parse(csvString, {
        columns: true,
        skip_empty_lines: true,
      });

      const activeProducts = products.filter((product) => {
        if (options.onlyActive && product["Status"] !== "active") {
          return false;
        }

        if (
          options.onlyInStock &&
          parseInt(product["Variant Inventory Qty"]) < 1
        ) {
          return false;
        }

        return true;
      });

      for (var product of activeProducts) {
        const content = `One of our product or service; Name: ${product["Title"]}, Description: ${product["Body (HTML)"]}, Price: ${product["Variant Price"]}`
        // add content to vector store
        const file_id = await this.add_content_to_vector_store(
          bot, content
        );

        // save file ref in local
        const new_product = new this.productModel({
          name: product["Title"],
          description: product["Body (HTML)"],
          price: product["Variant Price"],
          bot: bot_id,
          status: "trained",
          fileId: file_id,
        });

        await new_product.save();
      }

      // update organization training character usage
      await this.update_training_character_usage(bot.organization._id);

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * Create a new product entity on the local db and add the content
   * to the bot's vector store on openai.
   *
   *
   * @param bot - string (object id) - bot id
   * @param product - AddProductDto
   * @returns Product
   */
  async create_product(
    bot_id: string,
    product: AddProductDto
  ): Promise<Product> {
    const bot = await this.botModel.findById(bot_id).exec();
    const content = `For those who are asking what are our products or services, here is the one of our products or services; Name: ${product.name}, Description: ${product.description}, Price: ${product.price}`;

    if (!bot.config.is_custom_assistant_enabled) {
      const is_training_character_usage_exceeded =
        await this.is_training_character_usage_exceeded(
          bot.organization,
          content.length
        );

      if (is_training_character_usage_exceeded) {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }
    }

    // add content to vector store
    const file_id = await this.add_content_to_vector_store(bot, content);

    const new_product = new this.productModel({
      status: "trained",
      fileId: file_id,
      bot: bot_id,
      ...product,
    });

    return new_product.save();
  }

  async update_product(product_id: string, updateProductDto: EditProductDto) {
    const bot = await this.botModel.findById(updateProductDto.bot).exec();
    const product = await this.productModel.findById(product_id);

    if (!product) {
      throw new HttpException("product.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    // remove the file from vector store
    await this.delete_content_from_vector_store(
      bot.organization._id,
      product.fileId,
      "product"
    );
    const content = `For those who are asking what are our products or services, here is the one of our products or services; Name: ${updateProductDto.name}, Description: ${updateProductDto.description}, Price: ${updateProductDto.price}`;

    try {
      const file_id = await this.add_content_to_vector_store(bot, content);
      await this.productModel.findByIdAndUpdate(product_id, {
        fileId: file_id,
        name: updateProductDto.name,
        description: updateProductDto.description,
        price: updateProductDto.price,
      });

      this.update_training_character_usage(bot.organization._id).then(() => {});

      return true;
    } catch (err) {
      throw new HttpException(
        "product.COULD_NOT_UPDATE_PRODUCT",
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async update_text(text_id: string, updateTextDto: EditTextDto) {
    const bot = await this.botModel.findById(updateTextDto.bot).exec();
    const text = await this.textModel.findById(text_id);

    if (!text) {
      throw new HttpException("text.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    // remove the file from vector store
    await this.delete_content_from_vector_store(
      bot.organization._id,
      text.fileId,
      "product"
    );

    try {
      const file_id = await this.add_content_to_vector_store(
        bot,
        updateTextDto.content
      );
      await this.textModel.findByIdAndUpdate(text_id, {
        fileId: file_id,
        content: updateTextDto.content,
        characterCount: updateTextDto.content.length,
      });

      // update organization training character usage
      this.update_training_character_usage(bot.organization._id).then(() => {});

      return true;
    } catch (err) {
      throw new HttpException(
        "question.COULD_NOT_UPDATE_QUESTION",
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async update_question(
    question_id: string,
    updateQuestionDto: EditQuestionDto
  ) {
    const bot = await this.botModel.findById(updateQuestionDto.bot).exec();
    const question = await this.questionModel.findById(question_id);

    if (!question) {
      throw new HttpException("question.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    if (
      updateQuestionDto.question === question.question &&
      updateQuestionDto.answer === question.answer
    ) {
      await this.questionModel.findByIdAndUpdate(question_id, {
        isChatStarter: updateQuestionDto.isChatStarter,
      });

      return true;
    } else {
      // remove the file from vector store
      await this.delete_content_from_vector_store(
        bot.organization._id,
        question.fileId,
        "question"
      );
      const content = `Example question: ${updateQuestionDto.question}, Answer: ${updateQuestionDto.answer}`;

      try {
        const file_id = await this.add_content_to_vector_store(bot, content);
        await this.questionModel.findByIdAndUpdate(question_id, {
          fileId: file_id,
          question: updateQuestionDto.question,
          answer: updateQuestionDto.answer,
          isChatStarter: updateQuestionDto.isChatStarter,
        });

        this.update_training_character_usage(bot.organization._id).then(
          () => {}
        );

        return true;
      } catch (err) {
        throw new HttpException(
          "question.COULD_NOT_UPDATE_QUESTION",
          HttpStatus.BAD_REQUEST
        );
      }
    }
  }

  /**
   * A service method which get all the links scraped for this chatbot
   * but not added to the vector store yet. (status: "onhold")
   *
   * Add these links to the vector store and update their status to "trained"
   *
   * @param bot_id - string (object id) - bot id
   * @returns - boolean
   */
  /**
   * A service method which get all the links scraped for this chatbot
   * but not added to the vector store yet. (status: "onhold")
   *
   * Add these links to the vector store and update their status to "trained"
   * This method returns immediately and processes links asynchronously
   * 
   * @param bot_id - string (object id) - bot id
   * @returns - boolean
   */
  async add_links_to_knowledge_base(bot_id: string): Promise<boolean> {
    try {
      const bot = await this.botModel.findById(bot_id).exec();
      const links = await this.linkModel
        .find({ bot: bot_id, status: "onhold" })
        .exec();
  
      if (links.length === 0) {
        return true; // No links to process
      }
      // Start processing links in the background without awaiting
      this.processLinksInBackground(bot, links);
  
      // Return immediately
      return true;
    } catch (err) {
      if (err.message === "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED") {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }
      return false;
    }
  }

  async retry_failed_links(bot_id: string): Promise<boolean> {
    try {
      const bot = await this.botModel.findById(bot_id).exec();
      await this.botModel.updateOne({ _id: bot._id }, { $set: { isTrainingProgress: true } }).exec();
      const put_links_in_queue = await this.linkModel
        .updateMany({ bot: bot_id, status: "failed" }, { $set: { status: "in-queue" } })
        .exec();

      console.log(put_links_in_queue, 'put_links_in_queue');

      const links = await this.linkModel.find({ bot: bot_id, status: "in-queue" }).exec();

      // Start processing links in the background without awaiting
      this.processLinksInBackground(bot, links);
  
      // Return immediately
      return true;
    } catch (err) {
      if (err.message === "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED") {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }
      return false;
    }
  }

  async add_links_in_queue_to_knowledge_base(bot_id: string): Promise<boolean> {
    try {
      const bot = await this.botModel.findById(bot_id).exec();
      const onhold_links = await this.linkModel
        .find({ bot: bot_id, status: "onhold" })
        .exec();

      const in_queue_links = await this.linkModel
        .find({ bot: bot_id, status: "in-queue" })
        .exec();
  
      if (onhold_links.length > 0 || in_queue_links.length === 0) {
        console.log('sync will skip bcz there are still some onhold links to wait to be scraped or no links in queue')
        return true; // No links to process
      }

      console.log('bot which will be process in background', bot);
      // Start processing links in the background without awaiting
      this.processLinksInBackground(bot, in_queue_links);
  
      // Return immediately
      return true;
    } catch (err) {
      if (err.message === "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED") {
        throw new HttpException(
          "organization.TRAINING_CHARACTER_LIMIT_EXCEEDED",
          HttpStatus.BAD_REQUEST
        );
      }
      return false;
    }
  }
  
  /**
   * Process links in the background and send email notification when complete
   * 
   * @param bot - Bot entity
   * @param links - Links to process
   */
  private async processLinksInBackground(bot: any, links: any[]): Promise<void> {
    try {
      await this.botModel.updateOne({ _id: bot._id }, { $set: { isTrainingProgress: true } }).exec();
      // Get organization for notification
      const organization = await this.organizationModel.findById(bot.organization._id).exec();
      
      let processedLinks = 0;
      let failedLinks = 0;
      let trainingCharacterExceeded = false;
      
      for (const link of links) {
        console.log('processing link', link._id)
        try {
          const is_training_character_usage_exceeded =
            await this.is_training_character_usage_exceeded(
              bot.organization,
              link.content.length
            );
  
          if (is_training_character_usage_exceeded) {
            trainingCharacterExceeded = true;
            failedLinks++;
            await this.linkModel
              .updateOne({ _id: link._id }, { status: "failed" })
              .exec();
            continue;
          }
  
          const file_id = await this.add_content_to_vector_store(
            bot,
            link.content
          );
  
          await this.linkModel
            .updateOne({ _id: link._id }, { fileId: file_id, status: "trained" })
            .exec();
            
          processedLinks++;
        } catch (error) {
          failedLinks++;
        }
      }
  
      // Update organization training character usage
      await this.update_training_character_usage(bot.organization._id);
      
      console.log('processed, failed, trainingCharacterExceeded', processedLinks, failedLinks, trainingCharacterExceeded);

      // Send email notification to all admins
      if (links.length > 0 && !trainingCharacterExceeded) {
        await this.botModel.updateOne({ _id: bot._id }, { $set: { isTrainingFailed: false } }).exec();
        for (const admin of organization.admins) {
          console.log('sending training completed email to', admin.email);
          await sendTemplateMail("training-completed", admin.email);
        }
        console.log('training complete email sent');
      } else if (links.length > failedLinks && trainingCharacterExceeded) {
        await this.botModel.updateOne({ _id: bot._id }, { $set: { isTrainingFailed: true } }).exec();
        for (const admin of organization.admins) {
          console.log('sending training incomplete email to', admin.email);
          await sendTemplateMail("ok-but-need-more-character-limit", admin.email, { failed: failedLinks, succeed: processedLinks });
        }
        console.log('training incomplete email sent');
      } else if (failedLinks == links.length && trainingCharacterExceeded) {
        await this.botModel.updateOne({ _id: bot._id }, { $set: { isTrainingFailed: true } }).exec();
        for (const admin of organization.admins) {
          console.log('sending training failed email to', admin.email);
          await sendTemplateMail("need-more-character-limit", admin.email, { failed: failedLinks, succeed: processedLinks });
        }
        console.log('training failed email sent');
      }

      await this.botModel.updateOne({ _id: bot._id }, { $set: { isTrainingProgress: false } }).exec();
    } catch (error) {
      await send_telegram_notification(error);
    }
  }

  
  async persist_link(
    bot_id: string,
    url: string,
    priority = 0,
    isProvisioned = false,
  ) {
    try {
      await this.linkModel.updateOne(
        { bot: bot_id, url },
        {
          $setOnInsert: {
            status: 'onhold',
            priority,
            isProvisioned,
            createdAt: new Date(),
          },
        },
        { upsert: true },
      );
    } catch (err) {
      console.log('persist_link failed', err);
      throw err;
    }
  }

  async create_custom_link(bot_id: string, link: Link) {
    const bot = await this.botModel.findById(bot_id).exec();
    const file_id = await this.add_content_to_vector_store(bot, link.content);

    const new_link = new this.linkModel({
      bot: bot_id,
      url: link.url,
      status: link.status,
      content: link.content,
      fileId: file_id,
      isCustom: true,
    });

    return new_link.save();
  }

  /**
   * A service method which remove a product from the bot's vector store
   * and remove the product entity from the local db.
   *
   * @param product_id - string (object id) - product id
   * @returns - boolean
   */
  async remove_product(
    product_id: string,
    only_remote: boolean = false
  ): Promise<boolean> {
    try {
      const product = await this.productModel.findById(product_id).exec();
      const bot = await this.botModel.findById(product.bot).exec();

      // remove content from vector store
      await this.delete_content_from_vector_store(
        bot.organization._id,
        product.fileId,
        "product"
      );

      // update organization training character usage
      await this.update_training_character_usage(bot.organization._id);

      if (!only_remote) {
        // remove product from local db
        await this.productModel.deleteOne({ _id: product_id }).exec();
      }

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * A service method which return all the products from
   * the local db.
   *
   * @param bot_id - string (object id) - bot id
   * @param page_number - number
   * @returns - { data: Product[]; total: number }[]
   */
  async get_products(
    bot_id: string,
    page_number: number = 1
  ): Promise<{ data: Product[]; total: number }[]> {
    const $match = {
      bot: new ObjectId(bot_id),
    };
    const page_size = 10;

    const products = await this.productModel
      .aggregate([
        {
          $match,
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              {
                $skip: page_size * (page_number - 1),
              },
              {
                $limit: page_size,
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    return products;
  }

  /**
   * A service method which return all the links from
   * the local db with pagination and status filter.
   *
   * @param bot_id - string (object id) - bot id
   * @param page_number - number
   * @param status - string - status of the links
   * @returns - { data: Product[]; total: number }[]
   */
  async get_links(
    bot_id: string,
    page_number: number = 1,
    status: string
  ): Promise<{ data: Product[]; total: number }[]> {
    const $match = {
      bot: new ObjectId(bot_id),
    };
    const page_size = 10;
    const data = [];

    if (status.includes("not")) {
      const status_filter = status.split("not_")[1];
      $match["status"] = { $ne: status_filter };
    } else if (status !== "all") {
      $match["status"] = status;
    }

    if (status !== "onhold") {
      data.push({
        $skip: page_size * (page_number - 1),
      });
      data.push({
        $limit: page_size,
      });
    }

    const links = await this.linkModel
      .aggregate([
        {
          $match,
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              ...data,
              {
                $project: {
                  content: 0,
                },
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    return links;
  }

  /**
   * A service method which return all the texts from
   * the local db with pagination.
   *
   * @param bot_id - string (object id) - bot id
   * @param page_number - number
   * @returns - { data: Text[]; total: number }[]
   */
  async get_texts(
    bot_id: string,
    page_number: number = 1
  ): Promise<{ data: Text[]; total: number }[]> {
    const page_size = 10;
    const texts = await this.textModel
      .aggregate([
        {
          $match: {
            bot: new ObjectId(bot_id),
            status: { $ne: "onhold" },
          },
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              {
                $skip: page_size * (page_number - 1),
              },
              {
                $limit: page_size,
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    return texts;
  }

  /**
   * A service method which return all the questions from
   * the local db with pagination.
   *
   * @param bot_id - string (object id) - bot id
   * @param page_number - number
   * @returns - { data: Question[]; total: number }[]
   */
  async get_questions(
    bot_id: string,
    page_number: number = 1
  ): Promise<{ data: Question[]; total: number }[]> {
    const page_size = 10;
    const questions = await this.questionModel
      .aggregate([
        {
          $match: {
            bot: new ObjectId(bot_id),
            status: { $ne: "onhold" },
          },
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              {
                $skip: page_size * (page_number - 1),
              },
              {
                $limit: page_size,
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    return questions;
  }

  /**
   * A service method which return all the files from
   * the local db with pagination.
   *
   * @param bot_id - string (object id) - bot id
   * @param page_number - number
   * @returns - { data: File[]; total: number }[]
   */
  async get_files(
    bot_id: string,
    page_number: number = 1
  ): Promise<{ data: File[]; total: number }[]> {
    const page_size = 10;
    const files = await this.fileModel
      .aggregate([
        {
          $match: {
            bot: new ObjectId(bot_id),
            status: { $ne: "onhold" },
          },
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $facet: {
            data: [
              {
                $skip: page_size * (page_number - 1),
              },
              {
                $limit: page_size,
              },
            ],
            total: [
              {
                $count: "total",
              },
            ],
          },
        },
        {
          $project: {
            data: "$data",
            total: {
              $arrayElemAt: ["$total.total", 0],
            },
          },
        },
      ])
      .exec();

    return files;
  }

  /**
   * A service method which remove the file from the bot's vector store
   * and remove the file entity from the local db.
   *
   * @param file_id - string (object id)
   * @returns - boolean
   */
  async remove_file(file_id: string): Promise<boolean> {
    try {
      const file = await this.fileModel.findById(file_id).exec();
      const bot = await this.botModel.findById(file.bot).exec();

      // remove content from vector store
      await this.delete_content_from_vector_store(
        bot.organization._id,
        file.fileId,
        "file"
      );

      // update organization training character usage
      await this.update_training_character_usage(bot.organization._id);

      // remove file
      await this.fileModel.deleteOne({ _id: file_id }).exec();

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * A service method which remove the question from the bot's vector store
   * and remove the question entity from the local db.
   *
   * @param question_id - string (object id)
   * @returns - boolean
   */
  async remove_question(question_id: string): Promise<boolean> {
    try {
      const question = await this.questionModel.findById(question_id).exec();
      const bot = await this.botModel.findById(question.bot).exec();

      // remove content from vector store
      await this.delete_content_from_vector_store(
        bot.organization._id,
        question.fileId,
        "question"
      );

      // update organization training character usage
      await this.update_training_character_usage(bot.organization._id);

      // remove question
      await this.questionModel.deleteOne({ _id: question_id }).exec();

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * A service method which remove the link from the bot's vector store
   * and remove the link entity from the local db.
   *
   * @param link_id - string (object id)
   * @param bot_id - string (object id)
   * @returns - boolean
   */
  async remove_link(link_id: string, bot_id: string): Promise<boolean> {
    try {
      const bot = await this.botModel.findById(bot_id).exec();

      if (link_id === "all") {
        // This case only works for the scraped links
        // which are not trained yet
        // so we don't need to remove content from vector store
        await this.linkModel
          .deleteMany({ bot: bot_id, status: "onhold" })
          .exec();
      } else {
        // This case works for the trained links
        // so we need to remove content from vector store

        // we need to access to link for getting file id reference
        const link = await this.linkModel.findById(link_id).exec();

        // remove content from vector store
        await this.delete_content_from_vector_store(
          bot.organization._id,
          link.fileId,
          "link"
        );

        // update organization training character usage
        await this.update_training_character_usage(bot.organization._id);

        // remove link
        await this.linkModel.deleteOne({ _id: link_id }).exec();
      }

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * A service method which remove the text from the bot's vector store
   * and remove the text entity from the local db.
   *
   * @param text_id - string (object id)
   * @returns - boolean
   */
  async remove_text(text_id: string): Promise<boolean> {
    try {
      const text = await this.textModel.findById(text_id).exec();
      const bot = await this.botModel.findById(text.bot).exec();

      // remove content from vector store
      await this.delete_content_from_vector_store(
        bot.organization._id,
        text.fileId,
        "text"
      );

      // update organization training character usage
      await this.update_training_character_usage(bot.organization._id);

      // remove text
      await this.textModel.deleteOne({ _id: text_id }).exec();

      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * A service method which remove all the links which related with a
   * specific chatbot.
   *
   * Since the links with status "onhold" are not added into vector store
   * it's enough to remove them from local db.
   *
   * @param bot_id - string (object id) - bot id
   * @returns - boolean
   */
  async remove_links(bot_id: string): Promise<boolean> {
    try {
      await this.linkModel.deleteMany({ bot: bot_id, status: "onhold" }).exec();
      return true;
    } catch (err) {
      return false;
    }
  }

  async is_chatbot_interaction_allowed(bot: Bot): Promise<boolean> {
    const has_custom_api_key = await this.has_custom_api_key(bot);

    if (!has_custom_api_key) {
      const organization = await this.organizationModel
        .findById(bot.organization)
        .exec();
      const active_period = await this.periodModel.findById(
        organization.activePeriod
      );

      // credits system
      if (
        !organization.useLegacyPricing &&
        active_period.message_usage >= Plans[organization.plan].limits.message
      ) {
        return false;
      }

      // tokens system
      if (
        organization.useLegacyPricing &&
        organization.monthlyTokenUsage >= Plans[organization.plan].limits.token
      ) {
        return false;
      }
    }

    return true;
  }

  async create_event_message(message: string, device_id: string, bot_id: string, session_id: string) {
    const allowedEvents = ['MEVO_EVENT_HELPED', 'MEVO_EVENT_HUMAN_DEMAND']

    if (!allowedEvents.includes(message)) {
      throw new HttpException("Invalid event message", HttpStatus.BAD_REQUEST);
    }

    try {
      const eventMessage = new this.messageModel({
        bot: bot_id,
        content: message,
        session: session_id,
        did: device_id,
        sender: MessageSender.USER,
        unread: false,
        ip: '127.0.0.1',
        geo: {},
        isEvent: true
      })
  
      await eventMessage.save();
      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * The most important method in the whole application which is
   * responsible for the interaction between the user and the chatbot
   *
   * It checks the local threads for the session_id provided,
   * if there is no local thread, it creates a remote thread on openai
   * and run the thread with the given message.
   *
   * it also creates a local message entity for the message
   * and increase the session count of the bot and set the bot as unread
   *
   *
   * @param bot_id - string (object id) - bot id
   * @param payload - BotInteractionDto
   * @param ip - string - user ip
   * @param user_agent - string - user agent
   * @returns - boolean
   */
  async chatbot_interaction(
    bot_id: string,
    payload: BotInteractionDto,
    ip: string,
    user_agent: string,
  ): Promise<boolean> {
    const bot = await this.botModel.findById(bot_id).exec();

    console.log('chatbot_interaction called for bot:', bot_id, 'payload:', payload);

    if (payload.message.indexOf('MEVO_EVENT_') > -1) {
      await this.create_event_message(payload.message, payload.did, bot_id, payload.sid);
      return true;
    }

    const is_chatbot_interaction_allowed =
      await this.is_chatbot_interaction_allowed(bot);


    if (!is_chatbot_interaction_allowed) {
      bot.organization.admins.forEach(async (admin) => {
        sendTemplateMail("limit-reached", admin.email, {
          name: admin.name,
          organization: bot.organization.name,
        });
      });

      throw new HttpException(
        "chatbot_interaction.TOKEN_LIMIT_REACHED",
        HttpStatus.BAD_REQUEST
      );
    }

    // TODO(v2): we need transactional mechanism for here
    try {

      // run the assistant first
      await this.run_assistant(bot, payload);

      // do not create local messages if it's a demo
      if (!payload.is_demo) {

        // create a local message if assistant run successfully
        await this.create_local_message(
          user_agent,
          ip,
          payload,
          bot,
          MessageSender.USER
        );

        // increase the session count and set bot as unread
        await this.increase_session_count_and_set_bot_unread(bot);

        if (!bot.organization.useLegacyPricing) {
          await this.increase_message_usage(bot);
        }
      } else {
        console.log(
          "local message is not created for user message because demo flag is set"
        );
      }

      return true;
    } catch (err) {
      if (
        typeof bot.config === "undefined" ||
        typeof bot.config.meta === "undefined" ||
        (err?.error?.type === "invalid_request_error" &&
          err?.error?.param === "tool_resources")
      ) {
        // await this.repair_chatbot(bot);
        // await this.chatbot_interaction(bot_id, payload, ip, user_agent);
        return false;
      } else {
        return false;
      }
    }
  }

  async retrieve_chatbot_response(
    session_id: string,
    device_id: string,
    bot_id: string,
    is_demo: boolean,
    save_to_db: boolean = true
  ): Promise<{
    status: boolean;
    message: string | null;
  }> {
    const bot = await this.botModel.findById(bot_id).exec();
    const assistant_response = await this.check_assistant(session_id, bot);

    if (assistant_response.status && save_to_db) {
      if (!is_demo) {
        // create a local message if assistant run successfully
        await this.create_local_message(
          "",
          "127.0.0.1",
          {
            sid: session_id,
            did: device_id,
            message: assistant_response.message,
            is_demo,
            human_communication_mode: false
          },
          bot,
          MessageSender.BOT
        );
      } else {
        console.log(
          "local message is not created for ai response because demo flag is set"
        );
      }
    }

    return assistant_response;
  }

  async increase_email_usage(bot: Bot) {
    const organization_obj = await this.organizationModel
      .findById(bot.organization._id)
      .exec();

    const increase = 1;

    await this.periodModel.findOneAndUpdate(
      {
        _id: organization_obj.activePeriod,
      },
      {
        $inc: {
          email_usage: increase,
        },
      }
    );
  }

  async increase_message_usage(bot: Bot) {
    const model_credit_multiplier = {
      [Models.GPT_3_5_TURBO_1106]: 1,
      [Models.GPT_4_O_MINI]: 1,
      [Models.GPT_4_O]: 16,
      [Models.GPT_4_TURBO]: 48,
    };

    const organization_obj = await this.organizationModel
      .findById(bot.organization._id)
      .exec();

    const increase = model_credit_multiplier[bot.config.model] || 1;

    await this.periodModel.findOneAndUpdate(
      {
        _id: organization_obj.activePeriod,
      },
      {
        $inc: {
          message_usage: increase,
        },
      }
    );
  }

  async increase_token_usage(organization: Organization, tokenCount: number) {
    const organization_obj = await this.organizationModel
      .findById(organization._id)
      .exec();

    await this.organizationModel.updateOne(
      { _id: organization._id },
      {
        monthlyTokenUsage: organization_obj.monthlyTokenUsage + tokenCount,
      }
    );
  }

  async check_assistant(
    session_id: string,
    bot: Bot
  ): Promise<{
    status: boolean;
    message: string | null;
    annotations?: { url: string }[];
  }> {
    const target_assistant_id = bot.config.is_custom_assistant_enabled
      ? bot.config.custom_assistant_id
      : bot.config.assistant_id;

    // check is there a local thread for this session
    let local_thread = await this.threadModel.findOne({
      session: session_id,
      bot: bot._id,
      assistant_id: target_assistant_id,
    });

    if (!local_thread) {
      return {
        status: false,
        message: null,
      };
    }

    // if there is a local thread, we need to check the status of the thread
    // create a new openai client with the api key
    const api_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: api_key,
    });

    // get the thread status
    const run_check = await open_ai_client.beta.threads.runs.retrieve(
      local_thread.thread_id,
      local_thread.run_id
    );

    console.log(run_check.status, "run_check");

    // if the thread is in progress, we're returning false
    if (run_check.status === "in_progress") {
      return {
        status: false,
        message: null,
      };
    } else if (run_check.status === "failed") {
      send_telegram_notification(`
        A customer got an error while interacting with their AI chatbot.
👇

Error code: ${run_check.last_error.code}
Error description: ${run_check.last_error.message}
Contact person: ${bot.organization.admins[0].email}
`);

      if (run_check.last_error.code === "rate_limit_exceeded") {
        return {
          status: true,
          message: "Error code: #3 ~ Your OpenAI API key is rate limited.",
        };
      } else {
        return {
          status: true,
          message:
            "Error code: #4 ~ There is an issue with your OpenAI API key. Please contact Mevo support via hi@usemevo.com",
        };
      }
    }
    // if the thread is completed, we're returning the messages
    else {
      const has_custom_api_key = await this.has_custom_api_key(bot);

      if (!has_custom_api_key) {
        const organization = await this.organizationModel.findById(
          bot.organization
        );

        if (organization.useLegacyPricing) {
          await this.increase_token_usage(
            organization,
            run_check.usage.total_tokens
          );
        } else {
          await this.increase_message_usage(bot);
        }
      }

      const messages = await open_ai_client.beta.threads.messages.list(
        local_thread.thread_id
      );

      if (messages.data[0].role === "assistant") {
        // @ts-ignore
        // const annotations = messages.data[0].content[0].text.annotations;
        let response = {
          status: true,
          // @ts-ignore
          message: messages.data[0].content[0].text.value,
          annotations: [],
        };
        
        // if (annotations && annotations.length > 0) {
        //   const links = await this.linkModel.find({
        //     fileId: { $in: annotations.map((a) => a.file_citation.file_id) },
        //   });

        //   response = {
        //     ...response,
        //     annotations: links.map((link) => ({
        //       url: link.url,
        //     })),
        //   };
        // }
        
        return response;
      } else {
        return {
          status: false,
          message: null,
        };
      }
    }
  }

  /**
   * Check if the bot has a custom api key, if not return the default key
   * @param bot - Bot
   * @returns string - openai api key
   */
  async get_api_key_for_bot(bot: Bot): Promise<string> {
    const bot_object = await this.botModel.findById(bot._id).exec();
    const is_bot_has_api_key = bot_object.secrets.length > 0;

    // if bot has a custom api key, we're using that key
    // we can check this by looking the secrets array
    // bcz there is nothing else than in secrets array of a chatbot
    // so if there is at least one secret, we can say that bot has a custom api key
    if (is_bot_has_api_key) {
      // if bot has a custom api key, we're looking the secret
      const secret = await this.secretModel
        .findOne({ _id: bot_object.secrets[0] })
        .exec();
      // decrypt the secret value and return it
      return decrypt(
        secret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
    }
    // if bot has no custom api key
    // we need to check the organization level api key
    // if there is an organization level api key, we're using that key
    else {
      const organization = await this.organizationModel
        .findOne({ _id: bot_object.organization._id })
        .exec();

      const secrets = await this.secretModel
        .find({ _id: { $in: organization.secrets } })
        .exec();

      const open_ai_secret = secrets.find(
        (secret) => secret.key === SecretKey.OPEN_AI_KEY
      );

      // we're looking the plan of the organization
      // we don't allow to use custom api key if organization is free
      if (open_ai_secret && organization.plan !== PlanType.BASIC) {
        return decrypt(
          open_ai_secret.value,
          this.configService.get<string>("MEVO_SECRET_KEY")
        );
      }

      // if organization is free, we're using the default mevo key
      return this.configService.get<string>("MEVO_OPENAI_KEY");
    }
  }

  /**
   * Check if the bot has a custom api key, if not return false
   * @param bot - Bot
   * @returns boolean - has custom api key
   */
  async has_custom_api_key(bot: Bot): Promise<boolean> {
    const is_bot_has_api_key = bot.secrets.length > 0;

    // if bot has a custom api key, we're using that key
    // we can check this by looking the secrets array
    // bcz there is nothing else than in secrets array of a chatbot
    // so if there is at least one secret, we can say that bot has a custom api key
    if (is_bot_has_api_key) {
      return true;
    }
    // if bot has no custom api key
    // we need to check the organization level api key
    // if there is an organization level api key, we're using that key
    else {
      const organization = await this.organizationModel
        .findOne({ _id: bot.organization._id })
        .exec();

      const secrets = await this.secretModel
        .find({ _id: { $in: organization.secrets } })
        .exec();

      const open_ai_secret = secrets.find(
        (secret) => secret.key === SecretKey.OPEN_AI_KEY
      );

      // we're looking the plan of the organization
      // we don't allow to use custom api key if organization is free
      if (open_ai_secret && organization.plan !== PlanType.BASIC) {
        return true;
      }

      // if organization is free, we're using the default mevo key
      return false;
    }
  }

  // async inspect() {
  //   const api_key =
  //     "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";

  //   const open_ai_client = new OpenAI({
  //     apiKey: api_key,
  //   });

  //   const steps = await open_ai_client.beta.threads.runs.steps.list(
  //     "thread_cAunG7voGVpNRr5p8wZm5aF6",
  //     "run_j9PvjnLgxmVG6vEYFjO25WoC"
  //   );

  //   const step = await open_ai_client.beta.threads.runs.steps.retrieve(
  //     "thread_cAunG7voGVpNRr5p8wZm5aF6",
  //     "run_j9PvjnLgxmVG6vEYFjO25WoC",
  //     "step_AYGSkI5kdY7rTBd4G6SRzbMc",
  //     {
  //       // @ts-ignore
  //       include: ["step_details.tool_calls[*].file_search.results[*].content"],
  //     }
  //   );

  //   return {
  //     step,
  //   };
  // }

  /**
   * check is there a local thread for this session,
   * create a remote thread if there is no local thread
   * create a new message in the thread
   * and run the thread with the given message
   * @param bot - Bot
   * @param payload - BotInteractionDto
   */
  async run_assistant(bot: Bot, payload: BotInteractionDto): Promise<void> {
    const api_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: api_key,
    });

    const target_assistant_id = bot.config.is_custom_assistant_enabled
      ? bot.config.custom_assistant_id
      : bot.config.assistant_id;

    // check is there a local thread for this session
    let thread_id;
    let local_thread = await this.threadModel.findOne({
      session: payload.sid,
      bot: bot._id,
      assistant_id: target_assistant_id,
    });

    console.log(local_thread, 'local_thread');
    // if there is no local thread, we need to create a remote thread
    // and save the thread id to local db
    if (!local_thread) {
      const vector_store_ids = [];
      const tool_resources: { [key: string]: any } = {};

      if (bot.config.is_custom_assistant_enabled) {
        if (bot.config.custom_vector_store_id) {
          vector_store_ids.push(bot.config.custom_vector_store_id);
          tool_resources.file_search = { vector_store_ids };
        }
      } else {
        vector_store_ids.push(bot.config.vector_store_id);
        tool_resources.file_search = { vector_store_ids };
      }

      const remote_thread = await open_ai_client.beta.threads.create({
        messages: [{
          role: "user",
          content: payload.message,
        }],
        tool_resources,
      });

      local_thread = new this.threadModel({
        session: payload.sid,
        bot: bot._id,
        thread_id: remote_thread.id,
        assistant_id: target_assistant_id,
      });
      await local_thread.save();

      thread_id = remote_thread.id;
    } else {
      thread_id = local_thread.thread_id;
    }

    // create a new message in the thread
    await open_ai_client.beta.threads.messages.create(thread_id, {
      role: "user",
      content: payload.message,
    });

    if (local_thread.run_id) {
      try {
        // Retrieve the existing run status
        const existing_run = await open_ai_client.beta.threads.runs.retrieve(
          local_thread.thread_id,
          local_thread.run_id
        );

        // If the run is active, cancel it
        if (existing_run.status === "in_progress") {
          await open_ai_client.beta.threads.runs.cancel(
            local_thread.thread_id,
            local_thread.run_id
          );
        }
      } catch (error) {
        console.error("Error retrieving or canceling the existing run:", error);
      }
    }

    // run the thread with the given message
    const run = await open_ai_client.beta.threads.runs.create(thread_id, {
      assistant_id: target_assistant_id,
      model: bot.config.model,
    });

    // save related id to local thread
    // so we can use this id for further operations
    local_thread.run_id = run.id;
    await local_thread.save();
  }

  /**
   * create a local message with the given payload
   * @param user_agent - string
   * @param ip - string
   * @param payload - BotInteractionDto
   * @param bot - Bot
   */
  async create_local_message(
    user_agent: string,
    ip: string,
    payload: BotInteractionDto,
    bot: Bot,
    sender: MessageSender = MessageSender.USER
  ): Promise<void> {
    // get user agent info
    const ua = new UAParser(user_agent).getResult();
    // create local message
    const local_message = new this.messageModel({
      bot: bot._id,
      content: payload.message,
      session: payload.sid,
      did: payload.did,
      sender,
      ip: ip,
      geo: geoip.lookup(ip),
      device: {
        os: ua.os.name,
        browser: ua.browser.name + " v" + ua.browser.version,
        device: ua.device.vendor,
      },
      unread: true,
    });

    // save local message
    await local_message.save();
  }

  /**
   * increase session count and set bot unread
   * @param bot - Bot
   */
  async increase_session_count_and_set_bot_unread(bot: Bot): Promise<void> {
    const bot_entity = await this.botModel.findById(bot._id).exec();
    // get how many unique session for this bot
    const session_count = await this.messageModel
      .distinct("session", {
        bot: bot_entity._id,
      })
      .exec();

    // set session count to bot
    bot_entity.sessionCount = session_count.length;
    bot_entity.unread = true;

    await bot_entity.save();
  }

  /**
   * get all the messages for a specific session
   * @param bot_id - string (object id) - bot id
   * @param device_id - string - device id
   * @returns - Message[]
   */
  async get_sessions_by_device(
    device_id: string,
    bot_id: string,
    set_readed: boolean = false
  ) {
    if (set_readed) {
      await this.messageModel
        .updateMany(
          {
            did: device_id,
            bot: new ObjectId(bot_id),
          },
          {
            unread: false,
          }
        )
        .exec();
    }

    const messages_grouped_by_session = await this.messageModel.aggregate([
      {
        $match: {
          did: device_id,
          bot: new ObjectId(bot_id),
          isEvent: { $ne: true }
        },
      },
      {
        $sort: {
          createdAt: 1,
        },
      },
      {
        $lookup: {
          from: "leads",
          localField: "did",
          foreignField: "device_id",
          as: "lead",
        },
      },
      {
        $group: {
          _id: "$session",
          messages: {
            $push: {
              _id: "$_id",
              text: "$content",
              sender: "$sender",
              sent_at: "$createdAt",
              geo: "$geo",
              device: "$device",
              ip: "$ip",
              sender_meta: "$senderMeta"
            },
          },
          firstCreatedAt: { $first: "$createdAt" },
          lead: { $first: "$lead" },
        },
      },
      { $sort: { firstCreatedAt: 1 } },
    ]);

    return messages_grouped_by_session;
  }

  /**
 * get all the messages for a specific session
 * @param bot_id - string (object id) - bot id
 * @param session_id - string - session id
 * @param set_readed - boolean - whether to mark messages as read
 * @returns - Message[]
 */
  async get_messages_by_session(
    session_id: string,
    bot_id: string,
    set_readed: boolean = false
  ) {
    if (set_readed) {
      await this.messageModel
        .updateMany(
          {
            session: session_id,
            bot: new ObjectId(bot_id),
          },
          {
            unread: false,
          }
        )
        .exec();
    }

    const messages = await this.messageModel.aggregate([
      {
        $match: {
          session: session_id,
          bot: new ObjectId(bot_id),
        },
      },
      {
        $sort: {
          createdAt: 1,
        },
      },
      {
        $lookup: {
          from: "leads",
          localField: "did",
          foreignField: "device_id",
          as: "lead",
        },
      },
      {
        $project: {
          _id: 1,
          text: "$content",
          sender: 1,
          sent_at: "$createdAt",
          geo: 1,
          device: 1,
          ip: 1,
          did: 1,
          lead: 1,
          sender_meta: '$senderMeta',
          isEvent: 1,
          status: 1
        }
      }
    ]);

    return messages;
  }

  async update_session_status(session_id: string, session_status: SessionStatus) {
    try {
      await this.messageModel
      .updateMany(
        {
          session: session_id,
        },
        {
          status: session_status,
        }
      )
      .exec();

      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * get all the messages for a specific bot, grouped by session
   * @param bot_id - string (object id) - bot id
   * @returns - Message[]
  */
  async get_inbox(bot_id: string, page: number = 1, status: SessionStatus = SessionStatus.OPEN) {
    const messages_grouped_by_session = await this.messageModel.aggregate([
      {
        $match: {
          bot: new ObjectId(bot_id),
          status,
          $or: [
            { isEvent: { $exists: false } },
            { isEvent: false }
          ]
        }
      },
      {
        $project: {
          session: 1,
          content: 1,
          geo: 1,
          createdAt: 1,
          unread: 1,
          did: 1,
          status: 1
        }
      },
      {
        $sort: {
          createdAt: 1,
        },
      },
      {
        $lookup: {
          from: "leads",
          localField: "did",
          foreignField: "device_id",
          as: "lead",
          pipeline: [
            { $project: { name: 1, email: 1 /* only the fields you need */ } }
          ]
        }
      },
      {
        $group: {
          _id: "$session",
          lastMessage: { $last: "$content" },
          geo: { $first: "$geo" },
          lastCreatedAt: { $last: "$createdAt" },
          unread: { $last: "$unread" },
          lead: { $last: "$lead" },
          did: { $first: "$did" },
          status: { $last: "$status" },
        }
      },
      { $sort: { lastCreatedAt: -1 } },
      {
        $facet: {
          data: [
            {
              $skip: 10 * (page - 1),
            },
            {
              $limit: 10,
            },
          ],
          total: [
            {
              $count: "total",
            },
          ],
        },
      },
      {
        $project: {
          data: "$data",
          total: {
            $arrayElemAt: ["$total.total", 0],
          },
        },
      },
    ]);

    return messages_grouped_by_session;
  }

  async set_appearance(bot_id: string, appearance: Appearance) {
    const bot = await this.botModel.findById(bot_id).exec();

    bot.appearance = appearance;
    await bot.save();

    return bot;
  }

  async set_lead_capture_mode(bot_id: string, lead_capture_mode: ShowForm) {
    const bot = await this.botModel.findById(bot_id).exec();

    bot.showForm = lead_capture_mode;
    await bot.save();

    return bot;
  }

  async get_bot_public(
    condition: { [key: string]: any },
    increase_view_count: boolean = false
  ): Promise<any> {
    let bot: Bot = await this.botModel
      .findOne({
        $and: [
          {
            isRemoved: { $ne: true },
          },
          condition,
        ],
      })
      .select(
        "-createdBy -organization appearance type name config script showForm showAfterSeconds surveyMessage surveyYes surveyNo surveyHuman leadCaptureFormTitle leadCaptureFormDescription nameLabel namePlaceholder emailLabel emailPlaceholder organizationLabel organizationPlaceholder formSubmitButton inChatEmailInputTitle inChatEmailInputDescription inChatEmailSubmitButtonLabel flow isTrainingProgress isActive"
      )
      .exec();

    if (!bot) {
      throw new HttpException("bots.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    if (bot.type === BotType.GPT && !bot.config) {
      try {
        await this.repair_chatbot(bot);
        bot = await this.botModel
          .findOne({
            $and: [
              {
                isRemoved: { $ne: true },
              },
              condition,
            ],
          })
          .select(
            "appearance type name config script showForm showAfterSeconds leadCaptureFormTitle leadCaptureFormDescription nameLabel namePlaceholder emailLabel emailPlaceholder organizationLabel organizationPlaceholder formSubmitButton inChatEmailInputTitle inChatEmailInputDescription inChatEmailSubmitButtonLabel isTrainingProgress"
          )
          .exec();
      } catch (err) {
        if (err.error.code === "invalid_api_key") {
          throw new HttpException(
            "bots.INVALID_API_KEY",
            HttpStatus.BAD_REQUEST
          );
        }
      }
    }

    // get chat starters
    const chat_starters = await this.questionModel
      .aggregate([
        {
          $match: {
            bot: bot._id,
            isChatStarter: {
              $ne: false,
            },
          },
        },
        { $sample: { size: 3 } },
        {
          $project: {
            _id: 1,
            question: 1,
          },
        },
      ])
      .exec();

    if (increase_view_count) {
      // increase view count
      await this.botModel
        .findOneAndUpdate(condition, {
          $inc: { viewCount: 1 },
        })
        .exec();
    }

    bot.config = {
      is_survey_disabled: bot.config.is_survey_disabled,
      show_ai_indicator: bot.config.show_ai_indicator,
      model: null,
      instructions: null,
      fallback_message: null,
      assistant_id: null,
      vector_store_id: null,
      is_custom_assistant_enabled: false,
      custom_assistant_id: null,
      custom_vector_store_id: null,
      meta: bot.config.meta
    }

    return {
      bot,
      chat_starters,
    };
  }

  async set_ai_settings(
    bot_id: string,
    payload: {
      model?: Models;
      instructions?: string;
      fallback_message?: string;
      is_custom_assistant_enabled?: boolean;
      custom_assistant_id?: string;
      custom_vector_store_id?: string;
      show_ai_indicator?: boolean;
      is_survey_disabled?: boolean;
      meta?: {
        title: string;
        description: string;
        keywords: string;
        ogImage: string;
      };
    }
  ): Promise<Bot> {
    const bot = await this.botModel.findById(bot_id).exec();
    const changes: { [key: string]: any } = {
      config: bot.config,
    };

    if (payload.meta) {
      changes.config.meta = payload.meta;
    }

    if (payload.model) {
      changes.config.model = payload.model;
    }

    if (payload.instructions) {
      changes.config.instructions = payload.instructions;
    }

    if (typeof payload.show_ai_indicator !== 'undefined') {
      changes.config.show_ai_indicator = payload.show_ai_indicator;
    }

    if (typeof payload.is_survey_disabled !== 'undefined') {
      changes.config.is_survey_disabled = payload.is_survey_disabled;
    }

    if (payload.fallback_message) {
      changes.config.fallback_message = payload.fallback_message;
    }

    if (typeof payload.is_custom_assistant_enabled !== "undefined") {
      changes.config.is_custom_assistant_enabled =
        payload.is_custom_assistant_enabled;
    }

    if (typeof payload.custom_assistant_id !== "undefined") {
      changes.config.custom_assistant_id = payload.custom_assistant_id;
    }

    if (typeof payload.custom_vector_store_id !== "undefined") {
      changes.config.custom_vector_store_id = payload.custom_vector_store_id;
    }

    // update the bot in the local db
    await this.botModel
      .updateOne(
        {
          _id: bot_id,
        },
        changes
      )
      .exec();

    if (payload.model || payload.instructions) {
      // update the bot in the openai
      await this.update_bot(
        bot_id,
        {
          model: bot.config.model,
          instructions: bot.config.instructions,
        },
        false
      );
    }

    return bot;
  }

  async set_localization(
    bot_id: string,
    payload: {
      lead_capture_form_title: string;
      lead_capture_form_description: string;
      name_label: string;
      name_placeholder: string;
      email_label: string;
      email_placeholder: string;
      organization_label: string;
      organization_placeholder: string;
      form_submit_button: string;
      in_chat_email_input_title: string;
      in_chat_email_input_description: string;
      in_chat_email_submit_button_label: string;
      survey_message: string;
      survey_yes: string;
      survey_no: string;
      survey_human: string;
    }
  ): Promise<Bot> {
    const bot = await this.botModel.findById(bot_id).exec();
    const changes: { [key: string]: any } = {
      config: bot.config,
    };

    if (payload.lead_capture_form_title) {
      changes.leadCaptureFormTitle = payload.lead_capture_form_title;
    }

    if (payload.lead_capture_form_description) {
      changes.leadCaptureFormDescription =
        payload.lead_capture_form_description;
    }

    if (payload.name_label) {
      changes.nameLabel = payload.name_label;
    }

    if (payload.name_placeholder) {
      changes.namePlaceholder = payload.name_placeholder;
    }

    if (payload.email_label) {
      changes.emailLabel = payload.email_label;
    }

    if (payload.survey_message) {
      changes.surveyMessage = payload.survey_message;
    }

    if (payload.survey_yes) {
      changes.surveyYes = payload.survey_yes;
    }

    if (payload.survey_no) {
      changes.surveyNo = payload.survey_no;
    }

    if (payload.survey_human) {
      changes.surveyHuman = payload.survey_human;
    }

    if (payload.email_placeholder) {
      changes.emailPlaceholder = payload.email_placeholder;
    }

    if (payload.organization_label) {
      changes.organizationLabel = payload.organization_label;
    }

    if (payload.organization_placeholder) {
      changes.organizationPlaceholder = payload.organization_placeholder;
    }

    if (payload.form_submit_button) {
      changes.formSubmitButton = payload.form_submit_button;
    }

    if (payload.in_chat_email_input_title) {
      changes.inChatEmailInputTitle = payload.in_chat_email_input_title;
    }

    if (payload.in_chat_email_input_description) {
      changes.inChatEmailInputDescription =
        payload.in_chat_email_input_description;
    }

    if (payload.in_chat_email_submit_button_label) {
      changes.inChatEmailSubmitButtonLabel =
        payload.in_chat_email_submit_button_label;
    }

    // update the bot in the local db
    await this.botModel
      .updateOne(
        {
          _id: bot_id,
        },
        {
          $set: changes,
        }
      )
      .exec();

    return bot;
  }

  async clean_vector_stores() {
    try {
      const organizations = await this.organizationModel.find({});
      console.log(`${organizations.length} organization bulundu.`);
  
      for (const org of organizations) {
        console.log(`İşleniyor: Organization ID: ${org._id}`);
  
        const bots = await this.botModel.find({ organization: org._id });
        console.log(`Organization ${org._id} içinde ${bots.length} bot bulundu.`);
  
        for (const bot of bots) {
          const openai = new OpenAI({
            apiKey: await this.get_api_key_for_bot(bot),
            defaultHeaders: { 'OpenAI-Beta': 'assistants=v2' }
          });

          if (!bot.config) continue;

          const vectorStoreId = bot.config?.is_custom_assistant_enabled ? bot.config?.custom_vector_store_id : bot.config?.vector_store_id;
          if (!vectorStoreId) continue;
  
          console.log(`İşleniyor: Bot ID: ${bot._id}, Vector Store ID: ${vectorStoreId}`);
  
          const productFiles = await this.productModel.find({ bot: bot._id }).select('fileId');
          const fileFiles = await this.fileModel.find({ bot: bot._id }).select('fileId');
          const textFiles = await this.textModel.find({ bot: bot._id }).select('fileId');
          const linkFiles = await this.linkModel.find({ bot: bot._id }).select('fileId');
          const questionFiles = await this.questionModel.find({ bot: bot._id }).select('fileId');
  
          const mongoFileIds = new Set([
            ...productFiles.map(f => f.fileId),
            ...fileFiles.map(f => f.fileId),
            ...textFiles.map(f => f.fileId),
            ...linkFiles.map(f => f.fileId),
            ...questionFiles.map(f => f.fileId),
          ]);
  
          console.log(`MongoDB'de ${mongoFileIds.size} dosya bulundu.`);
  
          const vectorFiles = await openai.beta.vectorStores.files.list(vectorStoreId);
          const vectorFileIds = vectorFiles.data.map(f => f.id);
  
          console.log(`Vector Store'da ${vectorFileIds.length} dosya bulundu.`);
  
          for (const fileId of vectorFileIds) {
            if (!mongoFileIds.has(fileId)) {
              console.log(`Siliniyor: ${fileId}`);
              await openai.beta.vectorStores.files.del(vectorStoreId, fileId);
            }
          }
  
          console.log(`Bot ${bot._id} için temizleme işlemi tamamlandı.`);
        }

        await this.update_training_character_usage(org._id);
      }
  
      console.log('Tüm organizationlar için işlem tamamlandı!');
    } catch (error) {
      console.error('Hata:', error);
    }
  }

  /**
   * get all the messages for a specific bot, grouped by session
   * @param bot_id - string (object id) - bot id
   * @returns - Message[]
  */
  async get_inbox_v3(bot_id: string, page: number = 1, filter: InboxFilter = InboxFilter.AI_ALL) {
    const statusFilterMap = {
      [InboxFilter.AI_ALL]: SessionStatus.OPEN,
      [InboxFilter.AI_RESOLVED]: SessionStatus.CLOSED,
    }
    
    const messages_grouped_by_session = await this.messageModel.aggregate([
      {
        $match: {
          bot: new ObjectId(bot_id),
          status: statusFilterMap[filter],
          $or: [
            { isEvent: { $exists: false } },
            { isEvent: false }
          ]
        }
      },
      {
        $project: {
          session: 1,
          content: 1,
          geo: 1,
          createdAt: 1,
          unread: 1,
          did: 1,
          status: 1
        }
      },
      {
        $sort: {
          createdAt: 1,
        },
      },
      {
        $lookup: {
          from: "leads",
          localField: "did",
          foreignField: "device_id",
          as: "lead",
          pipeline: [
            { $project: { name: 1, email: 1 /* only the fields you need */ } }
          ]
        }
      },
      {
        $group: {
          _id: "$session",
          lastMessage: { $last: "$content" },
          geo: { $first: "$geo" },
          lastCreatedAt: { $last: "$createdAt" },
          unread: { $last: "$unread" },
          lead: { $last: "$lead" },
          did: { $first: "$did" },
          status: { $last: "$status" },
        }
      },
      { $sort: { lastCreatedAt: -1 } },
      {
        $facet: {
          data: [
            {
              $skip: 10 * (page - 1),
            },
            {
              $limit: 10,
            },
          ],
          total: [
            {
              $count: "total",
            },
          ],
        },
      },
      {
        $project: {
          data: "$data",
          total: {
            $arrayElemAt: ["$total.total", 0],
          },
        },
      },
    ]);

    return messages_grouped_by_session;
  }


  /**
   * 
      "id": "0",
      "type": "start",
      "position": {
        "x": 480,
        "y": 0
      },
      "data": {
        "label": "Start",
        "id": "0",
        "type": "start",
      } 
   *
   */

  async process_flow_node(node: BotFlowChild) {
    switch (node.type) {
      case NodeType.START:
        // handle
        break;
      case NodeType.BOT_RESPONSE:
        // handle
        break;
      case NodeType.USER_INPUT:
        // handle
        break;
      case NodeType.QUESTION:
        // handle
        break;
      case NodeType.GO_TO_STEP:
        // handle
        break;
      default:
        throw new HttpException(
          `Unknown node type: ${node.type}`,
          HttpStatus.BAD_REQUEST
        );
    }
  }

  find_node_by_id(node: BotFlowChild, nodeId: string): BotFlowChild | null {
    if (node.id === nodeId) return node;
    if (!node.children) return null;
    for (const child of node.children) {
      const found = this.find_node_by_id(child, nodeId);
      if (found) return found;
    }
    return null;
  }
  
  async process_node(bot: Bot, nodeId: string, sid?: string, did?: string, ip?: string, user_agent?: string, message?: string, is_demo?: boolean) {
    const node = this.find_node_by_id(bot.flow[0], nodeId);

    switch (node.data.type) {
      case NodeType.START:
        return this.process_start(bot, node, sid, did, ip, user_agent, is_demo);
      case NodeType.BOT_RESPONSE:
        return this.process_bot_response(bot, node, sid, did, ip, user_agent, is_demo);
      case NodeType.WEBHOOK:
        return this.process_webhook(bot, node, sid, did);
      case NodeType.USER_INPUT:
        if (message) {
          return this.process_user_input(bot, node, sid, did, ip, user_agent, message, is_demo);  
        } else {
          return this.process_user_input(bot, node, sid, did, ip, user_agent, undefined, is_demo);
        }
      case NodeType.QUESTION:
        if (message) {
          return this.process_question(bot, node, sid, did, ip, user_agent, message, is_demo);  
        }
        return this.process_question(bot, node, sid, did, ip, user_agent, undefined, is_demo);
      case NodeType.GO_TO_STEP:
        return this.process_go_to_block(bot, node, sid, did);
      case NodeType.AI_ASSIST:
        return this.process_ai_assist(bot, node, sid, did, ip, user_agent, message, is_demo);
      case NodeType.FALLBACK:
        return this.process_ai_fallback(bot, node, sid);
      case NodeType.END_CONVERSATION: {
        const events = [
          {
            type: FlowEventType.END_FLOW,
            payload: {
              message: 'Conversation completed',
            },
          },
        ];
        return events;
      }
      default:
        throw new HttpException(
          `Unknown node type: ${node.data.type}`,
          HttpStatus.BAD_REQUEST
        );
    }
  }

  async process_webhook(bot: Bot, node: BotFlowChild, sid: string, did: string) {
    const events = [];
    const webhookSettings = node.data.content;
    const primary_properties = ['name', 'email', 'phone', 'company', 'url']
    
    // Find lead by session id
    let lead = null;
    try {
      console.log('sid', sid)
      lead = await this.leadModel.findOne({ device_id: did, bot: bot._id }).exec();
    } catch (error) {
      console.log('Error finding lead:', error);
    }

    // Function to replace @attributes in text
    const replaceAttributes = (text: string): string => {
      console.log(text, 'replace attr text', lead)
      if (!text || !lead) return text;
      
      return text.replace(/@(\w+)/g, (match, attribute) => {
        console.log(match, attribute)
        // Check if attribute is in primary properties
        if (primary_properties.includes(attribute)) {
          const value = lead[attribute];
          console.log(value, 'looking for primary property')
          return value !== null && value !== undefined ? value : match;
        }
        
        // Check if attribute is in customData
        if (lead.customData && lead.customData[attribute] !== undefined && lead.customData[attribute] !== null) {
          console.log(lead.customData[attribute], 'looking for custom property')
          return lead.customData[attribute];
        }
        
        // If not found, return original text
        return match;
      });
    };

    // Replace attributes in webhook URL
    if (webhookSettings.url) {
      webhookSettings.url = replaceAttributes(webhookSettings.url);
    }

    // Replace attributes in webhook body (if it's a string)
    if (webhookSettings.body) {
      if (typeof webhookSettings.body === 'string') {
        webhookSettings.body = replaceAttributes(webhookSettings.body);
      } else if (typeof webhookSettings.body === 'object') {
        // If body is an object, stringify it, replace attributes, then parse back
        const bodyStr = JSON.stringify(webhookSettings.body);
        const replacedBodyStr = replaceAttributes(bodyStr);
        try {
          webhookSettings.body = JSON.parse(replacedBodyStr);
        } catch (error) {
          console.log('Error parsing webhook body after attribute replacement:', error);
        }
      }
    }

    try {
      if (webhookSettings.method === 'GET') {
        await axios.get(webhookSettings.url, {});
      } else if (webhookSettings.method === 'POST') {
        await axios.post(webhookSettings.url, webhookSettings.body, {
          headers: {
            'Content-Type': 'application/json'
          }
        });
      }
      console.log('Webhook sent successfully', webhookSettings.url, webhookSettings.method);
    } catch (error) {
      console.log('Webhook failed', error);
      console.error(error);
    }
    
    if (node.children.length) {
      events.push({
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: node.children[0].id
      });
      await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
    } else {
      events.push({
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: '5' // main user input node id
      });
      await this.update_active_node(bot._id.toString(), sid, '5');
    }

    return this.send_events(events);
  }

  async process_start(bot: Bot, node: BotFlowChild, sid: string, did: string, ip: string, user_agent: string, is_demo?: boolean) {
    const events = [];

    if (bot.flow && bot.flow.length && bot.flow[0].children.length > 2) {
      throw new HttpException(
        "Flow is not healthy. Please check the flow configuration.",
        HttpStatus.BAD_REQUEST
      );
    }

    events.push({
      type: FlowEventType.SET_ACTIVE_NODE, 
      payload: bot.flow[0].children[2].id
    });
    await this.update_active_node(bot._id.toString(), sid, bot.flow[0].children[2].id);

    return this.send_events(events);
  }

  async process_ai_fallback(bot: Bot, node: BotFlowChild, sid: string) {
    if (node.children.length) {
      // if there is at least one child node, we need to set it as active node
      await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
      return this.send_events([{
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: node.children[0].id
      }]);
    } else {
      await this.update_active_node(bot._id.toString(), sid, '5');
      return this.send_events([{
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: '5' // main user input node id
      }]);
    }
  }

  async push_message(events: any[], message: string, sid: string, did: string, ip: string, user_agent: string, bot: Bot, persist_only: boolean = false, is_demo: boolean = false) {
    let _events = events;
    let text = message;
    let thread_id = null;
    let local_thread = null;

    if (!persist_only) {
      _events.push({
        type: FlowEventType.PUSH_MESSAGE,
        payload: message
      })
    }

    // Demo modda mesajları kaydetme
    if (!is_demo) {
      await this.create_local_message(
        user_agent,
        ip,
        {
          message,
          sid,
          did,
          is_demo: false,
          human_communication_mode: false
        },
        bot,
        persist_only ? MessageSender.USER : MessageSender.BOT
      );
    } else {
      console.log("Message is not saved because demo flag is set");
    }

    const api_key = await this.get_api_key_for_bot(bot);
    const openai = new OpenAI({
      apiKey: api_key,
    });

    if (message.includes('__MEVO__')) {
      text = message.split('__MEVO__')[0];
    }

    local_thread = await this.threadModel.findOne({
      session: sid,
    })

    if (!local_thread) {
      const vector_store_ids = [];
      const tool_resources: { [key: string]: any } = {};
  
      if (bot.config.is_custom_assistant_enabled) {
        if (bot.config.custom_vector_store_id) {
          vector_store_ids.push(bot.config.custom_vector_store_id);
          tool_resources.file_search = { vector_store_ids };
        }
      } else {
        vector_store_ids.push(bot.config.vector_store_id);
        tool_resources.file_search = { vector_store_ids };
      }

      // profil: düz obje olarak alın ve okunabilir/limitli formatla
      const user_profile = await this.leadModel
        .findOne({ device_id: did })
        .lean();

      const blocked_fields = ['device_id', 'bot', 'createdAt', 'updatedAt', 'sid', '_id', '__v'];
      const MAX_PROFILE_FIELDS = 20;

      function formatValue(val: any): string {
        if (val == null || val === 'N/A') return '';
        if (typeof val === 'string') return val.trim();
        try { return JSON.stringify(val); } catch { return String(val); }
      }

      function titleCase(key: string): string {
        return key
          .replace(/_/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
          .replace(/\b\w/g, (c) => c.toUpperCase());
      }

      let user_info = '';
      if (user_profile) {
        const { customData, ...rest } = user_profile as any;
        const baseEntries = Object.entries(rest)
          .filter(([key, val]) => !String(key).startsWith('$') && !blocked_fields.includes(key) && val != null && val !== 'N/A')
          .slice(0, MAX_PROFILE_FIELDS)
          .map(([key, val]) => `- ${titleCase(key)}: ${formatValue(val)}`);

        const customEntries = customData && typeof customData === 'object'
          ? Object.entries(customData)
              .filter(([, val]) => val != null && val !== 'N/A')
              .slice(0, MAX_PROFILE_FIELDS)
              .map(([k, v]) => `- ${titleCase(String(k))}: ${formatValue(v)}`)
          : [];

        const lines = [...baseEntries, ...customEntries];
        user_info = lines.length > 0 ? lines.join('\n') : 'No additional user attributes available.';
      } else {
        user_info = "First time user, we don't have any info about user.";
      }

      // geçmiş mesajları sırala ve kısalt
      const allMessages = await this.messageModel
        .find({ did: did, bot: bot._id })
        .sort({ createdAt: 1 })
        .lean();

      type MessageLike = { session: string; sender: string; content: any; createdAt: Date };
      const grouped = allMessages.reduce((acc: Record<string, MessageLike[]>, m: any) => {
        (acc[m.session] ||= []).push(m as MessageLike);
        return acc;
      }, {} as Record<string, MessageLike[]>);

      // session'ları son aktiviteye göre sırala ve limit koy
      const MAX_SESSIONS = 3;
      const MAX_MSGS_PER_SESSION = 8;
      const MAX_CHARS_PER_MSG = 400;

      const orderedSessions = Object.entries(grouped)
        .sort(([, a], [, b]) => {
          const aLast = a[a.length - 1]?.createdAt ? new Date(a[a.length - 1].createdAt).getTime() : 0;
          const bLast = b[b.length - 1]?.createdAt ? new Date(b[b.length - 1].createdAt).getTime() : 0;
          return bLast - aLast;
        })
        .slice(0, MAX_SESSIONS);

      function trimContent(c: any): string {
        const s = typeof c === 'string' ? c : formatValue(c);
        return s.length > MAX_CHARS_PER_MSG ? s.slice(0, MAX_CHARS_PER_MSG) + '…' : s;
      }

      let previous_conversations = '';
      for (const [sessionId, group] of orderedSessions) {
        const lastDate = group[group.length - 1]?.createdAt ? new Date(group[group.length - 1].createdAt) : undefined;
        previous_conversations += `\nSession ${sessionId}${lastDate ? ` (last: ${lastDate.toISOString()})` : ''}:\n`;
        const tail = group.slice(-MAX_MSGS_PER_SESSION);
        for (const m of tail) {
          previous_conversations += `${m.sender}: ${trimContent(m.content)}\n`;
        }
      }

      const context_block = [
        'SYSTEM CONTEXT (do not reveal to user):',
        'You are assisting the same user across sessions. Use the profile and prior snippets as background only.',
        'Be concise, helpful, and avoid repeating the provided context verbatim.',
        '',
        'User profile:',
        user_info,
        '',
        'Recent conversations (most recent sessions first):',
        previous_conversations || 'No prior conversation history.',
      ].join('\n');

      const messages_input: Array<{ role: 'user'|'assistant', content: string }> = [];
      // Bağlamsal blok tek bir user mesajı olarak gönderilir
      messages_input.push({ role: 'user', content: context_block });
      // Son olarak mevcut kullanıcının mesajı
      messages_input.push({ role: 'user', content: text });

      const remote_thread = await openai.beta.threads.create({
        messages: messages_input,
        tool_resources,
      });
  
      local_thread = new this.threadModel({
        session: sid,
        bot: bot._id,
        thread_id: remote_thread.id,
        assistant_id: bot.config.assistant_id,
      });
      await local_thread.save();
  
      thread_id = remote_thread.id;
    } else {
      await openai.beta.threads.messages.create(local_thread.thread_id, {
        role: persist_only ? "user" : "assistant",
        content: text,
      });
    }

    

    return _events;
  }

  async get_active_node_for_session(session_id: string) {
    const session = await this.sessionModel.findOne({
      session_id: session_id
    });

    if (!session) {
      return '3';
    }

    return session.active_node_id;
  }

  async update_active_node(bot_id: string, session_id: string, node_id: string) {
    let session = await this.sessionModel.findOne({
      session_id: session_id
    });

    if (!session) {
      session = new this.sessionModel({
        session_id: session_id,
        active_node_id: node_id,
        bot: bot_id
      });
      await session.save();
    }

    session.active_node_id = node_id;
    await session.save();
  }

  async process_bot_response(bot: Bot, node: BotFlowChild, sid: string, did: string, ip: string, user_agent: string, is_demo?: boolean) {
    let events = [];

    for (let i = 0; i < node.data.content.length; i++) {
      if (node.data.content[i].type === BotResponseSubTypes.MESSAGE) {
        events = await this.push_message(events, node.data.content[i].content, sid, did, ip, user_agent, bot, false, is_demo);
      }
      else if (node.data.content[i].type === BotResponseSubTypes.QUICK_REPLY) {
        const text = node.data.content[i].content.text + '__MEVO__' + JSON.stringify(node.data.content[i].content.replies);
        events = await this.push_message(events, text, sid, did, ip, user_agent, bot, false, is_demo);
      } else if (node.data.content[i].type === BotResponseSubTypes.RANDOMIZED_MESSAGE) {
        if (Array.isArray(node.data.content[i].content) && node.data.content[i].content.length > 0) {
          const randomIndex = Math.floor(Math.random() * node.data.content[i].content.length);
          const randomMessage = node.data.content[i].content[randomIndex];
          events = await this.push_message(events, randomMessage, sid, did, ip, user_agent, bot, false, is_demo);
        } else {
          console.warn('⚠️ RANDOMIZED_MESSAGE tipi var ama content dizisi boş.');
        }
      } else if (node.data.content[i].type === BotResponseSubTypes.IMAGE) {
        const imageUrl = node.data.content[i].content.url;
        if (imageUrl) {
          const imageEvent = {
            type: FlowEventType.PUSH_MESSAGE,
            payload: imageUrl,
            meta: {
              contentType: "image",
            }
          };
          events.push(imageEvent);
        } else {
          console.warn('⚠️ url is empty');
        }
      }
    }

    if (node.children.length) {
      // if there is at least one child node, we need to set it as active node
      events.push({
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: node.children[0].id
      });
      await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
    }
    else {
      events.push({
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: '5' // main user input node id
      });
      await this.update_active_node(bot._id.toString(), sid, '5');
    }

    return this.send_events(events);
  }

  async process_user_input(bot: Bot, node: BotFlowChild, sid: string, did: string, ip: string, user_agent: string, message?: string, is_demo?: boolean) {
    let events = [];

    if (message) {
      const flow_root = bot.flow[0].children[2];
      const parent_of_current_node = this.find_parent_node(flow_root, node.id);
      const matches = [];
      
      // set matches array
      parent_of_current_node.children.filter(
        (child) => child.data.type === NodeType.USER_INPUT
      ).map((user_input) => {
        const content = { keywords: [], sentences: [] };

        content.keywords = user_input.data.content.keywords.map((item) => item.keyword.toLowerCase());
        content.sentences = user_input.data.content.sentences.map((item) => item.sentence.toLowerCase());

        matches.push(content);
      });

      const matched_index = await this.find_best_match_index_with_ai(bot._id.toString(), message, matches);

      if (matched_index === -1) {
        events.push({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: bot.flow[0].children[1].id // assign user message to ai assist
        })
        await this.update_active_node(bot._id.toString(), sid, bot.flow[0].children[1].id);
      } else {
        // persist message if ai fallback not triggered
        events = await this.push_message(events, message, sid, did, ip, user_agent, bot, true, is_demo);
        events.push({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: parent_of_current_node.children[matched_index].children[0].id
        })
        await this.update_active_node(bot._id.toString(), sid, parent_of_current_node.children[matched_index].children[0].id);
      }
    }
    else {
      events.push({
        type: FlowEventType.SHOW_INPUT
      })
    }

    return this.send_events(events);
  }

  // async process_user_input(bot: Bot, node: BotFlowChild, sid: string, did: string, ip: string, user_agent: string, message?: string) {
  //   let events = [];

  //   if (message) {
  //     const flow_root = bot.flow[0].children[2];
  //     const parent_of_current_node = this.find_parent_node(flow_root, node.id);
  //     const matches = [];
      
  //     // set matches array
  //     parent_of_current_node.children.filter(
  //       (child) => child.data.type === NodeType.USER_INPUT
  //     ).map((user_input) => {
  //       const content = { keywords: [], sentences: [] };

  //       content.keywords = user_input.data.content.keywords.map((item) => item.keyword.toLowerCase());
  //       content.sentences = user_input.data.content.sentences.map((item) => item.sentence.toLowerCase());

  //       matches.push(content);
  //     });

  //     const matched_index = await this.find_best_match_index_with_ai(bot._id.toString(), message, matches);

  //     if (matched_index === -1) {
  //       events.push({
  //         type: FlowEventType.SET_ACTIVE_NODE,
  //         payload: bot.flow[0].children[1].id // assign user message to ai assist
  //       })
  //       await this.update_active_node(bot._id.toString(), sid, bot.flow[0].children[1].id);
  //     } else {
  //       // persist message if ai fallback not triggered
  //       events = await this.push_message(events, message, sid, did, ip, user_agent, bot, true);
  //       events.push({
  //         type: FlowEventType.SET_ACTIVE_NODE,
  //         payload: parent_of_current_node.children[matched_index].children[0].id
  //       })
  //       await this.update_active_node(bot._id.toString(), sid, parent_of_current_node.children[matched_index].children[0].id);
  //     }
  //   }
  //   else {
  //     events.push({
  //       type: FlowEventType.SHOW_INPUT
  //     })
  //   }

  //   return this.send_events(events);
  // }

  async process_question(bot: Bot, node: BotFlowChild, sid: string, did: string, ip: string, user_agent: string, message?: string, is_demo?: boolean) {
    let events = [];
    let lead = null;
    function toSnakeCase(str: string): string {
      return str
        .toLowerCase()
        .trim()
        .replace(/[^\w\s]/g, '')
        .replace(/\s+/g, '_');
    }
    // Demo modda lead oluşturma ve sorgulama yapma
    if (!is_demo) {
      lead = await this.leadModel.findOne({
        device_id: did,
        bot: bot._id,
      }).exec();

      if (!lead) {
        // create a new lead
        lead = new this.leadModel({
          device_id: did,
          sid: sid,
          ip: ip,
          user_agent: user_agent,
          name: "N/A",
          email: "N/A",
          company: "N/A",
          number: "N/A",
          phone: "N/A",
          url: "N/A",
          date: null,
          text: "N/A",
          organization: bot.organization,
          bot: bot._id,
        });
        await lead.save();
      }
    } else {
      console.log("Lead creation/query is not performed because demo flag is set");
    }

    if (message) {
      events = await this.push_message(events, message, sid, did, ip, user_agent, bot, true, is_demo);
      const attrForEmail = node.data.content[0].content.attribute;
      // Special handling only for email attribute
      if (attrForEmail === "email") {
        const requireVerification = !!(node?.data?.content?.[0]?.content?.verification_required);
        // If verification not required, save email and continue as regular
        if (!requireVerification) {
          if (!is_demo) {
            await this.leadModel.updateOne(
              { device_id: did, bot: bot._id },
              { $set: { email: (message || '').trim().toLowerCase() } }
            ).exec();
          }

          // events = await this.push_message(events, "Thanks for the information you provided.", sid, did, ip, user_agent, bot, false, is_demo);
          if (node.children.length) {
            events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: node.children[0].id });
            await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
          } else {
            events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: '5' });
            await this.update_active_node(bot._id.toString(), sid, '5');
          }
          return this.send_events(events);
        }
        if (!is_demo) {
          const trimmed = (message || '').trim();
          const isSixDigits = /^[0-9]{6}$/.test(trimmed);
          const currentLead = await this.leadModel.findOne({ device_id: did, bot: bot._id }).exec();

          // If user entered 6-digit code and we already have a pending verification
          if (
            isSixDigits &&
            currentLead &&
            currentLead.email &&
            currentLead.email_verification_code
          ) {
            const isExpired = !!currentLead.email_verification_expires_at &&
              new Date(currentLead.email_verification_expires_at).getTime() < Date.now();

            if (isExpired) {
              const codeRaw = Math.floor(100000 + Math.random() * 900000).toString();
              const code = codeRaw.replace(/^0/, '1');
              const expires = new Date(Date.now() + 10 * 60 * 1000);
              await this.leadModel.updateOne(
                { device_id: did, bot: bot._id },
                { $set: { email_verification_code: code, email_verification_expires_at: expires, email_verification_attempts: 0, last_verification_sent_at: new Date() } }
              ).exec();
              try {
                await this.checkHourlyIpLimit(ip, 'email_verification');
                await sendTemplateMail("lead-email-verification", currentLead.email, { code });
                await this.increase_email_usage(bot);
              } catch (e) {}

              const remainingSec = Math.ceil((expires.getTime() - Date.now()) / 1000);
              events = await this.push_message(
                events,
                `Your code is expired, we sent you a new code. Please enter the 6-digit code.__MEVO__["resend"]`,
                sid,
                did,
                ip,
                user_agent,
                bot,
                false,
                is_demo
              );
              events.push({
                type: FlowEventType.SET_INPUT_VALIDATION_RULE,
                payload: { type: "any", errorMessage: "Please type 'resend' or enter the 6-digit code." }
              });
              events.push({ type: FlowEventType.SHOW_INPUT });
              return this.send_events(events);
            }

            if (trimmed === currentLead.email_verification_code) {
              await this.leadModel.updateOne(
                { device_id: did, bot: bot._id },
                { $set: { email_verified: true }, $unset: { email_verification_code: "", email_verification_expires_at: "" } }
              ).exec();

              events = await this.push_message(
                events,
                "Thank you, your email address has been verified.",
                sid,
                did,
                ip,
                user_agent,
                bot,
                false,
                is_demo
              );

              if (node.children.length) {
                events.push({
                  type: FlowEventType.SET_ACTIVE_NODE,
                  payload: node.children[0].id // set next node as active
                });
                await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
              } else {
                events.push({
                  type: FlowEventType.SET_ACTIVE_NODE,
                  payload: '5' // main user input node id
                });
                await this.update_active_node(bot._id.toString(), sid, '5');
              }
              return this.send_events(events);
            }

            // Not expired but wrong code
            const attempts = (currentLead.email_verification_attempts || 0) + 1;
            await this.leadModel.updateOne(
              { device_id: did, bot: bot._id },
              { $set: { email_verification_attempts: attempts } }
            ).exec();

            if (attempts >= 5) {
              events = await this.push_message(
                events,
                "You have made too many incorrect attempts. Please type 'resend' or enter the 6-digit code.",
                sid,
                did,
                ip,
                user_agent,
                bot,
                false,
                is_demo
              );
              events.push({
                type: FlowEventType.SET_INPUT_VALIDATION_RULE,
                payload: { type: "any", errorMessage: "Please type 'resend' or enter the 6-digit code." }
              });
              events.push({ type: FlowEventType.SHOW_INPUT });
              return this.send_events(events);
            }

            events = await this.push_message(
              events,
              "Code is incorrect. Please try again.",
              sid,
              did,
              ip,
              user_agent,
              bot,
              false,
              is_demo
            );
            events.push({
              type: FlowEventType.SET_INPUT_VALIDATION_RULE,
              payload: { type: "any", errorMessage: "Please type 'resend' or enter the 6-digit code." }
            });
            events.push({ type: FlowEventType.SHOW_INPUT });
            return this.send_events(events);
          }

          // Resend intent detection
          try {
            const resendIntent = await this.is_resend_request(bot._id.toString(), trimmed);
            if (resendIntent === 1 && currentLead?.email) {
              const lastSent = currentLead.last_verification_sent_at ? new Date(currentLead.last_verification_sent_at).getTime() : 0;
              const now = Date.now();
              if (now - lastSent < 60 * 1000) {
                const waitSec = Math.ceil((60 * 1000 - (now - lastSent)) / 1000);
                events = await this.push_message(events, `Please try again in ${waitSec} seconds.`, sid, did, ip, user_agent, bot, false, is_demo);
                events.push({ type: FlowEventType.SHOW_INPUT });
                return this.send_events(events);
              }

              // generate or reuse existing code if still valid
              let code = currentLead.email_verification_code;
              let expires = currentLead.email_verification_expires_at ? new Date(currentLead.email_verification_expires_at) : null;
              if (!code || !expires || expires.getTime() < Date.now()) {
                const codeRaw = Math.floor(100000 + Math.random() * 900000).toString();
                code = codeRaw.replace(/^0/, '1');
                expires = new Date(Date.now() + 10 * 60 * 1000);
                await this.leadModel.updateOne(
                  { device_id: did, bot: bot._id },
                  { $set: { email_verification_code: code, email_verification_expires_at: expires, email_verification_attempts: 0 } }
                ).exec();
              }

              try {
                await this.checkHourlyIpLimit(ip, 'email_verification');
                await sendTemplateMail("lead-email-verification", currentLead.email, { code });
                await this.increase_email_usage(bot);
                await this.leadModel.updateOne(
                  { device_id: did, bot: bot._id },
                  { $set: { last_verification_sent_at: new Date() } }
                ).exec();
              } catch (e) {
                if ((e as any)?.status === HttpStatus.TOO_MANY_REQUESTS) {
                  events = await this.push_message(events, 'Hourly email sending limit reached. Please try again later.', sid, did, ip, user_agent, bot, false, is_demo);
                  events.push({ type: FlowEventType.SHOW_INPUT });
                  return this.send_events(events);
                }
              }

              const remainingSec = expires ? Math.max(0, Math.ceil((expires.getTime() - Date.now()) / 1000)) : 0;
              events = await this.push_message(events, `We sent you a verification code again. Please enter the 6-digit code. __MEVO__["resend"]`, sid, did, ip, user_agent, bot, false, is_demo);
              events.push({ type: FlowEventType.SET_INPUT_VALIDATION_RULE, payload: { type: "any", errorMessage: "Please type 'resend' or enter the 6-digit code." } });
              events.push({ type: FlowEventType.SHOW_INPUT });
              return this.send_events(events);
            }
          } catch (e) {}

          // Treat as email input; validate and start verification
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(trimmed)) {
            events = await this.push_message(
              events,
              "Please enter a valid email address.",
              sid,
              did,
              ip,
              user_agent,
              bot,
              false,
              is_demo
            );
            events.push({
              type: FlowEventType.SET_INPUT_VALIDATION_RULE,
              payload: { type: "email", errorMessage: "Please enter a valid email address." }
            });
            events.push({ type: FlowEventType.SHOW_INPUT });
            return this.send_events(events);
          }

          const codeRaw = Math.floor(100000 + Math.random() * 900000).toString();
          const code = codeRaw.replace(/^0/, '1');
          const expires = new Date(Date.now() + 10 * 60 * 1000);
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { email: trimmed.toLowerCase(), email_verified: false, email_verification_code: code, email_verification_expires_at: expires, email_verification_attempts: 0, last_verification_sent_at: new Date() } }
          ).exec();

          try {
            await this.checkHourlyIpLimit(ip, 'email_verification');
            await sendTemplateMail("lead-email-verification", trimmed.toLowerCase(), { code });
            await this.increase_email_usage(bot);
          } catch (e) {
            if ((e as any)?.status === HttpStatus.TOO_MANY_REQUESTS) {
              events = await this.push_message(events, 'Hourly email sending limit reached. Please try again later.', sid, did, ip, user_agent, bot, false, is_demo);
              events.push({ type: FlowEventType.SHOW_INPUT });
              return this.send_events(events);
            }
          }

          events = await this.push_message(
            events,
            `We sent you a verification code to your email address. Please enter the 6-digit code.__MEVO__["resend"]`,
            sid,
            did,
            ip,
            user_agent,
            bot,
            false,
            is_demo
          );
          events.push({
            type: FlowEventType.SET_INPUT_VALIDATION_RULE,
            payload: { type: "any", errorMessage: "Please type 'resend' or enter the 6-digit code." }
          });
          events.push({ type: FlowEventType.SHOW_INPUT });
          // Keep active node here to accept the code next
          return this.send_events(events);
        } else {
          // Demo mode: cannot send emails
          events = await this.push_message(events, "Email sending is not allowed in demo mode.", sid, did, ip, user_agent, bot, false, is_demo);
          if (node.children.length) {
            events.push({
              type: FlowEventType.SET_ACTIVE_NODE,
              payload: node.children[0].id // set next node as active
            });
            await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
          } else {
            events.push({
              type: FlowEventType.SET_ACTIVE_NODE,
              payload: '5' // main user input node id
            });
            await this.update_active_node(bot._id.toString(), sid, '5');
          }
          return this.send_events(events);
        }
      }
      
      // Demo modda lead güncellemelerini yapma
      if (!is_demo) {
        // update the lead with the given message according the question attribute
        const question_attribute = node.data.content[0].content.attribute;
        const customKey = node.data.content[0].content.customKey;
        
        if (question_attribute === "name") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { name: message } }
          ).exec();
        } else if (question_attribute === "email") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { email: message } }
          ).exec();
        } else if (question_attribute === "company") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { company: message } }
          ).exec();
        }else if (question_attribute === "number") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { number: message } }
          ).exec();
        } else if (question_attribute === "phone") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { phone: message } }
          ).exec();
        } else if (question_attribute === "url") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { url: message } }
          ).exec();
        } else if (question_attribute === "text") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { text: message } }
          ).exec();
        } else if (question_attribute === "date") {
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { date: message } }
          ).exec();
        }if (question_attribute === 'custom' && customKey) {
          const formattedKey = toSnakeCase(customKey);
        
          await this.leadModel.updateOne(
            { device_id: did, bot: bot._id },
            { $set: { [`customData.${formattedKey}`]: message } }
          ).exec();
        }
      } else {
        console.log("Lead update is not performed because demo flag is set");
      }

      // events = await this.push_message(events, "Thanks for the information you provided.", sid, did, ip, user_agent, bot, false, is_demo);
      
      if (node.children.length) {
        events.push({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: node.children[0].id // set next node as active
        })
        await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
      } else {
        events.push({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: '5' // main user input node id
        });
        await this.update_active_node(bot._id.toString(), sid, '5');
      }
    } else {
        const attr = node.data.content[0].content.attribute;
        const customKey = node.data.content[0].content.customKey;
        let value: any;

        if (attr === "custom" && customKey) {
          const normalizedKey = toSnakeCase(customKey);
          value = lead?.customData?.[normalizedKey];
        } else {
          value = lead?.[attr];
        }

        const isValuePresent =
          value !== undefined &&
          value !== null &&
          value !== "N/A" &&
          !(typeof value === "string" && value.trim() === "");
      if (lead && isValuePresent) {
        if (node.data.content[0].content.attribute === "email") {
          const requireVerification = !!(node?.data?.content?.[0]?.content?.verification_required);
          if (lead.email_verified) {
            events = await this.push_message(events,
              "I can see you have already left your email. Our team will use " + lead.email + " for communication.", sid, did, ip, user_agent, bot, false, is_demo);

            if (node.children.length) {
              events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: node.children[0].id });
              await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
            } else {
              events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: '5' });
              await this.update_active_node(bot._id.toString(), sid, '5');
            }
            return this.send_events(events);
          } else if (requireVerification) {
            // Email exists but not verified. Send/ensure code and prompt.
            if (!is_demo) {
              let code = lead.email_verification_code;
              let expires = lead.email_verification_expires_at ? new Date(lead.email_verification_expires_at) : null;
              const expired = !expires || expires.getTime() < Date.now();
              if (!code || expired) {
                code = Math.floor(100000 + Math.random() * 900000).toString();
                expires = new Date(Date.now() + 10 * 60 * 1000);
                await this.leadModel.updateOne(
                  { device_id: did, bot: bot._id },
                  { $set: { email_verification_code: code, email_verification_expires_at: expires } }
                ).exec();
              }
              try { await sendTemplateMail("lead-email-verification", lead.email, { code }); } catch (e) {}
            }

            events = await this.push_message(events,
              "Please enter the 6-digit code we sent to your email address.", sid, did, ip, user_agent, bot, false, is_demo);
            events.push({ type: FlowEventType.SET_INPUT_VALIDATION_RULE, payload: { type: "number", errorMessage: "Lütfen 6 haneli bir kod giriniz." } });
            events.push({ type: FlowEventType.SHOW_INPUT });
            return this.send_events(events);
          } else {
            // Verification not required, proceed
            if (node.children.length) {
              events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: node.children[0].id });
              await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
            } else {
              events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: '5' });
              await this.update_active_node(bot._id.toString(), sid, '5');
            }
            return this.send_events(events);
          }
        }

        // Non-email attribute with existing value: continue flow
        if (node.children.length) {
          events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: node.children[0].id });
          await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
        } else {
          events.push({ type: FlowEventType.SET_ACTIVE_NODE, payload: '5' });
          await this.update_active_node(bot._id.toString(), sid, '5');
        }
        return this.send_events(events);
      }

      const questionContent = node.data.content[0].content;
      const vType = questionContent?.validation?.type || 'any';
      const vError = questionContent?.validation?.errorMessage || 'Please provide a valid answer.';

      if (vType === 'one-to-ten') {
        const options = Array.from({ length: 10 }, (_, i) => String(i + 1));
        const text = String(questionContent.question || '').trim();
        const payloadText = `${text}__MEVO__${JSON.stringify(options)}`;
        events = await this.push_message(events, payloadText, sid, did, ip, user_agent, bot, false, is_demo);
        events.push({ type: FlowEventType.SET_INPUT_VALIDATION_RULE, payload: { type: 'one-to-ten', errorMessage: vError } });
        events.push({ type: FlowEventType.SHOW_INPUT });
      } else {
        events = await this.push_message(events, String(questionContent.question || ''), sid, did, ip, user_agent, bot, false, is_demo);
        events.push({ type: FlowEventType.SET_INPUT_VALIDATION_RULE, payload: questionContent.validation || { type: 'any', errorMessage: 'Please provide a valid answer.' } });
        events.push({ type: FlowEventType.SHOW_INPUT });
      }
    }
    return this.send_events(events);
  }

  async process_go_to_block(bot: Bot, node: BotFlowChild, sid: string, did: string) {
    const events = [];

    // find the target node by id
    const target_node = this.find_node_by_id(bot.flow[0], node.data.content.targetStepId);

    if (!target_node) {
      throw new HttpException(
        `Target node with id ${node.id} not found.`,
        HttpStatus.BAD_REQUEST
      );
    }

    const primary_keys = ['name', 'email', 'company', 'phone', 'url', 'number', 'date', 'text'];

    const has_condition = node.data.content.conditions_enabled;
    const conditions = Array.isArray(node.data.content.conditions) ? node.data.content.conditions : [];
    const logic = String((node.data.content.logic ?? 'AND')).trim().toUpperCase() === 'OR' ? 'OR' : 'AND';
    
    const active_user = await this.leadModel.findOne({
      device_id: did,
      bot: bot._id,
    }).exec();

    function toSnakeCase(str: string): string {
      return (str || '')
        .toLowerCase()
        .trim()
        .replace(/[^\w\s]/g, '')
        .replace(/\s+/g, '_');
    }

    function resolveFieldValue(user: any, key: string): any {
      if (!user || !key) return undefined;
      if (primary_keys.includes(key) || Object.prototype.hasOwnProperty.call(user, key)) {
        return user[key];
      }
      const normalized = toSnakeCase(key);
      return user?.customData?.[normalized];
    }

    // Normalize various date string formats to a comparable YYYYMMDD number to avoid timezone issues
    function getYMDComparable(input: any): number | null {
      if (!input) return null;
      if (input instanceof Date && !isNaN(input.getTime())) {
        const y = input.getUTCFullYear();
        const m = input.getUTCMonth() + 1;
        const d = input.getUTCDate();
        return y * 10000 + m * 100 + d;
      }
      const str = String(input).trim();
      // ISO date (yyyy-mm-dd)
      const iso = str.match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if (iso) {
        const y = Number(iso[1]);
        const m = Number(iso[2]);
        const d = Number(iso[3]);
        return y * 10000 + m * 100 + d;
      }
      // Slash date (mm/dd/yyyy)
      const slashUs = str.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
      if (slashUs) {
        const m = Number(slashUs[1]);
        const d = Number(slashUs[2]);
        const y = Number(slashUs[3]);
        return y * 10000 + m * 100 + d;
      }
      // Dotted date (dd.mm.yyyy)
      const dotted = str.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
      if (dotted) {
        const d = Number(dotted[1]);
        const m = Number(dotted[2]);
        const y = Number(dotted[3]);
        return y * 10000 + m * 100 + d;
      }
      // Fallback to Date parse and then use UTC parts
      const dt = new Date(str);
      if (!isNaN(dt.getTime())) {
        const y = dt.getUTCFullYear();
        const m = dt.getUTCMonth() + 1;
        const d = dt.getUTCDate();
        return y * 10000 + m * 100 + d;
      }
      return null;
    }

    function evaluateSingleCondition(user: any, condition: any): boolean {
      const key: string = condition?.key ?? '';
      const operator: string = condition?.operator ?? 'eq';
      const conditionValue: any = condition?.value;
      const fieldValue: any = resolveFieldValue(user, key);
      let result = false;

      switch (operator) {
        case 'is-set': {
          if (fieldValue === null || fieldValue === undefined) {
            result = false;
          } else if (typeof fieldValue === 'string') {
            result = fieldValue.trim().length > 0 && fieldValue !== 'N/A';
          } else {
            result = true;
          }
          break;
        }
        case 'includes': {
          if (fieldValue === null || fieldValue === undefined) {
            result = false;
          } else if (Array.isArray(fieldValue)) {
            result = fieldValue.includes(conditionValue);
          } else {
            result = String(fieldValue).includes(String(conditionValue ?? ''));
          }
          break;
        }
        case 'not-includes': {
          if (fieldValue === null || fieldValue === undefined) {
            result = true;
          } else if (Array.isArray(fieldValue)) {
            result = !fieldValue.includes(conditionValue);
          } else {
            result = !String(fieldValue).includes(String(conditionValue ?? ''));
          }
          break;
        }
        case 'begins-with': {
          if (fieldValue === null || fieldValue === undefined) {
            result = false;
          } else {
            result = String(fieldValue).startsWith(String(conditionValue ?? ''));
          }
          break;
        }
        case 'before':
        case 'is':
        case 'after': {
          const left = getYMDComparable(fieldValue);
          const right = getYMDComparable(conditionValue);
          if (left === null || right === null) {
            result = false;
          } else if (operator === 'before') {
            result = left < right;
          } else if (operator === 'after') {
            result = left > right;
          } else {
            result = left === right;
          }
          break;
        }
        case 'lt':
        case 'lte':
        case 'e':
        case 'gte':
        case 'gt': {
          const left = Number(fieldValue);
          const right = Number(conditionValue);
          if (Number.isNaN(left) || Number.isNaN(right)) {
            result = false;
          } else if (operator === 'lt') {
            result = left < right;
          } else if (operator === 'lte') {
            result = left <= right;
          } else if (operator === 'e') {
            result = left === right;
          } else if (operator === 'gte') {
            result = left >= right;
          } else {
            result = left > right; // 'gt'
          }
          break;
        }
        case 'ne': {
          result = String(fieldValue) !== String(conditionValue);
          break;
        }
        case 'eq':
        default: {
          result = String(fieldValue) === String(conditionValue);
          break;
        }
      }
      
      return result;
    }

    let shouldJump = true;
    if (has_condition && conditions.length > 0) {
      if (logic === 'AND') {
        shouldJump = conditions.every((c) => evaluateSingleCondition(active_user, c));
      } else {
        shouldJump = conditions.some((c) => evaluateSingleCondition(active_user, c));
      }
    }

    console.log('process_go_to_block:logicSummary', {
      has_condition,
      logic,
      conditionsCount: conditions.length,
      shouldJump,
    });

    if (!shouldJump) {
      // If conditions are not met, continue with the next node in flow if exists, else go back to main input node
      if (node.children && node.children.length > 0) {
        events.push({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: node.children[0].id,
        });
        await this.update_active_node(bot._id.toString(), sid, node.children[0].id);
        return this.send_events(events);
      }
      events.push({
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: '5',
      });
      await this.update_active_node(bot._id.toString(), sid, '5');
      return this.send_events(events);
    }

    // set the target node as active node
    events.push({
      type: FlowEventType.SET_ACTIVE_NODE,
      payload: target_node.id
    });
    await this.update_active_node(bot._id.toString(), sid, target_node.id);

    return this.send_events(events);
  }

  async process_ai_assist(bot: Bot, node: BotFlowChild, sid: string, did: string, ip: string, user_agent: string, message: string, is_demo?: boolean) {
    let events = [];
    let response;

    const chatbot_interaction_result = await this.chatbot_interaction(bot._id.toString(), {
      message: message,
      sid: sid,
      did: did,
      is_demo: is_demo || false,
      human_communication_mode: false
    }, ip, user_agent);

    console.log('chatbot_interaction_result:', chatbot_interaction_result);

    // check by using retrieve_chatbot_response method if the response is ready
    // if not, wait for 1 second and check again, try 10 times max
    for (const [attempt] of Array(10).entries()) {
      response = await this.retrieve_chatbot_response(sid, did, bot._id.toString(), is_demo || false, false);
      if (response.status) {
        break;
      }
      if (attempt < 9) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    // response has come
    if (response.status) {
      // check ai know the answer or not
      try {
        const is_response_good = await this.is_response_good(bot._id.toString(), response.message);

        if (is_response_good === 0) {
          console.log("AI response is not good, setting fallback node");
          events.push({
            type: FlowEventType.SET_ACTIVE_NODE,
            payload: '1' // fallback node id
          });
          await this.update_active_node(bot._id.toString(), sid, '1');
                  } else {
            console.log("AI response is good");
            console.log("Pushing AI response to user and saving to database");
            // const survey_messages = ['Did that answer your question?', 'Did you find the information you were looking for?', 'Was the information helpful?'];
            events = await this.push_message(events, response.message, sid, did, ip, user_agent, bot, false, is_demo);
          // try {
          //   const is_question = await this.is_question(bot._id.toString(), response.message);

          //   if (is_question === 0) {
          //     await this.push_message(events, survey_messages[Math.floor(Math.random() * survey_messages.length)], sid, did, ip, user_agent, bot, false);
          //   }
          // } catch (error) {}

          if (bot.flow[0].children[1].children.length) {
            console.log("Setting active node to next node after ai response");
            events.push({
              type: FlowEventType.SET_ACTIVE_NODE,
              payload: bot.flow[0].children[1].children[0].id // main user input node id
            });
            await this.update_active_node(bot._id.toString(), sid, bot.flow[0].children[1].children[0].id);
          } else {
            console.log("Setting active node to main user input node");
            events.push({
              type: FlowEventType.SET_ACTIVE_NODE,
              payload: '5' // main user input node id
            });
            await this.update_active_node(bot._id.toString(), sid, '5');
          }
        }
      } catch (error) {
        console.error('Error checking response good:', error);
        events.push({
          type: FlowEventType.SET_ACTIVE_NODE,
          payload: '1' // fallback node id
        });
        await this.update_active_node(bot._id.toString(), sid, '1');
      }
    }
    // response has not come
    else {
      events.push({
        type: FlowEventType.SET_ACTIVE_NODE,
        payload: '1' // fallback node id
      });
      await this.update_active_node(bot._id.toString(), sid, '1');
    }
    console.log("events:", events);
    return this.send_events(events);
  }

  async send_events(events: { type: FlowEventType, payload: any }[]) {
    return events;
  }

  find_parent_node(root: BotFlowChild, target_node_id: string): BotFlowChild | null {
    if (!root.children || !root.children.length) return null;

    for (const child of root.children) {
      if (child.id === target_node_id) {
        return root;
      }
      // recursive olarak alt dallarda ara
      const found = this.find_parent_node(child, target_node_id);
      if (found) return found;
    }

    return null;
  }

  /**
   * bot_id: bot id
   * message: message comes from user
   * matches: [{ keywords: string[], sentences: string[] }]
   * return: matched index or -1 if no match found
   */
  async find_best_match_index_with_ai(
    bot_id: string,
    message: string,
    matches: { keywords: string[]; sentences: string[] }[]
  ): Promise<number> {
    const bot = await this.botModel.findById(bot_id).exec();
    const openai_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: openai_key,
    });

    // Promptu hazırla
    const options = matches.map(
      (m, idx) =>
        `${idx}: [keywords: ${m.keywords.join(", ")} | sentences: ${m.sentences.join(", ")}]`
    ).join("\n");

    const prompt = `
      Aşağıda bir kullanıcı mesajı ve seçenekler var. 
      Her seçenek bir anahtar kelime ve cümle listesi içeriyor.
      Kullanıcı mesajı, hangi seçenekteki anahtar kelime veya cümleyle birebir veya parça eşleşme yapıyorsa, sadece o seçeneğin index numarasını döndür. 
      Eğer birden fazla eşleşme varsa en çok eşleşen seçeneği döndür. 
      Hiçbiriyle eşleşmiyorsa -1 döndür.

      Anahtar kelimeler ve cümleler büyük/küçük harf duyarsız karşılaştırılmalıdır.

      Kullanıcı mesajı: "${message}"

      Seçenekler:
      ${options}

      Cevap sadece index numarası olmalı (ör: 0, 1, 2, ... veya -1).
    `;

    const completion = await open_ai_client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "Sen bir sınıflandırma asistanısın. Sadece sayı döndür." },
        { role: "user", content: prompt }
      ],
      max_tokens: 4,
      temperature: 0,
    });

    const response = completion.choices[0].message.content.trim();
    const index = parseInt(response, 10);
    return isNaN(index) ? -1 : index;
  }

  /**
   * bot_id: bot id
   * message: message comes from user
   * matches: [{ keywords: string[], sentences: string[] }]
   * return: matched index or -1 if no match found
   */
  async is_response_good(
    bot_id: string,
    message: string,
  ): Promise<number> {
    const bot = await this.botModel.findById(bot_id).exec();
    const openai_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: openai_key,
    });
    // Promptu hazırla
    const prompt = `
      There is a message from AI in below. If in this message, AI says something indicate it doesn't know or could not found the answer, return 0, otherwise return 1.

      Message: "${message}"

      Response must be only 0 or 1.
    `;

    const completion = await open_ai_client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a classification assistant. Only return number 0 or 1." },
        { role: "user", content: prompt }
      ],
      max_tokens: 4,
      temperature: 0,
    });

    const response = completion.choices[0].message.content.trim();
    const index = parseInt(response, 10);
    return isNaN(index) ? -1 : index;
  }

  async is_resend_request(
    bot_id: string,
    message: string,
  ): Promise<number> {
    const bot = await this.botModel.findById(bot_id).exec();
    const openai_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: openai_key,
    });
    const prompt = `User might be asking to resend verification code. If the message intent is to resend or send code again (examples: 'resend', 'send again', 'I haven't received code', 'kod gelmedi', 'yeniden gönder', 'tekrar yolla'), return 1, otherwise return 0.\n\nMessage: "${message}"\n\nOnly return 0 or 1.`;
    const completion = await open_ai_client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are an intent classifier. Only return number 0 or 1." },
        { role: "user", content: prompt }
      ],
      max_tokens: 4,
      temperature: 0,
    });
    const response = completion.choices[0].message.content.trim();
    const index = parseInt(response, 10);
    return isNaN(index) ? 0 : index;
  }

  async checkHourlyIpLimit(ip: string, endpoint: string, limit: number = 2): Promise<void> {
    const hourStart = new Date();
    hourStart.setMinutes(0, 0, 0);
    const existing = await this.ipTrackingModel.findOne({ ip, endpoint, date: hourStart }).exec();
    if (existing && existing.requestCount >= limit) {
      throw new HttpException('bots.EMAIL_LIMIT_REACHED', HttpStatus.TOO_MANY_REQUESTS);
    }
    if (existing) {
      await this.ipTrackingModel.findByIdAndUpdate(existing._id, { $inc: { requestCount: 1 } }).exec();
    } else {
      await this.ipTrackingModel.create({ ip, endpoint, date: hourStart, requestCount: 1 });
    }
  }

  async is_question(
    bot_id: string,
    message: string,
  ): Promise<number> {
    const bot = await this.botModel.findById(bot_id).exec();
    const openai_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: openai_key,
    });
    // Promptu hazırla
    const prompt = `
      There is a message from AI in below. If in this message, AI asking a question or a conversation ending like thanks, thank you etc, return 1, otherwise return 0.

      Message: "${message}"

      Response must be only 0 or 1.
    `;

    const completion = await open_ai_client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a classification assistant. Only return number 0 or 1." },
        { role: "user", content: prompt }
      ],
      max_tokens: 4,
      temperature: 0,
    });

    const response = completion.choices[0].message.content.trim();
    const index = parseInt(response, 10);
    return isNaN(index) ? -1 : index;
  }

  /**
   * bot_id: bot id
   * content: web page content
   * return: { question: string, answer: string }
   */
  async generate_starter(
    bot_id: string,
    content: string,
    questions: { question: string, answer: string }[],
    max_questions: number = 1
  ): Promise<{ question: string, answer: string }[]> {
    const bot = await this.botModel.findById(bot_id).exec();
    const openai_key = await this.get_api_key_for_bot(bot);
    const open_ai_client = new OpenAI({
      apiKey: openai_key,
    });

    // Promptu hazırla
    const prompt = `
      Here is the content of the page:
      "${content}"

      Create ${max_questions} questions and answers from the content above, and return them in raw json array format.
      Never return in markdown format, only raw json array.

      [
        {
          "question": "The question a user might ask",
          "answer": "The answer to that question"
        },
        {
          "question": "The question a user might ask",
          "answer": "The answer to that question"
        },
        {
          "question": "The question a user might ask",
          "answer": "The answer to that question"
        },
      ]
    
      Questions must be max 4 words, answers must be longer and detailed.

      Do not generate questions that are already in the list.
      ${questions.map(q => `${q.question}`).join(", ")}
    `;

    const completion = await open_ai_client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a question and answer generator for an AI assistant. You should write the response in the following format, return raw json array, do not include any other text, do not return in markdown format, only raw json array." },
        { role: "user", content: prompt }
      ],
      temperature: 0,
    });

    return JSON.parse(completion.choices[0].message.content.trim());
  }

  async streamInteractWithAssistant(
    bot_id: string,
    payload: BotInteractionDto,
    ip: string,
    userAgent: string,
    res: Response
  ): Promise<void> {
    console.log("streamInteractWithAssistant called for bot:", bot_id);
    console.log("payload:", payload);
  
    try {
      const bot = await this.botModel.findById(bot_id).exec();
      
      if (!bot) {
        console.log("Bot not found:", bot_id);
        res.write(`data: ${JSON.stringify({ error: 'Bot not found' })}\n\n`);
        res.end();
        return;
      }
  
      console.log("Bot found:", bot.name);
  
      // Check if interaction is allowed
      const isAllowed = await this.is_chatbot_interaction_allowed(bot);
      if (!isAllowed) {
        console.log("Interaction not allowed for bot:", bot_id);
        res.write(`data: ${JSON.stringify({ error: 'Interaction not allowed' })}\n\n`);
        res.end();
        return;
      }
  
          console.log("Starting to save user message and stream response");

    // Demo kontrolü ekle - mesajları sadece demo değilse kaydet
    if (!payload.is_demo) {
      // Save user message locally
      await this.create_local_message(userAgent, ip, payload, bot, MessageSender.USER);
      await this.increase_session_count_and_set_bot_unread(bot);
    } else {
      console.log("User message is not saved because demo flag is set");
    }
  
          // Stream response from OpenAI
    await this.streamAssistantResponse(bot, payload, res, payload.is_demo);
      
    } catch (error) {
      console.error('Stream interaction error:', error);
      res.write(`data: ${JSON.stringify({ error: 'Internal server error' })}\n\n`);
      res.end();
    }
  }

  async streamAssistantResponse(bot: Bot, payload: BotInteractionDto, res: Response, is_demo: boolean = false): Promise<void> {
    const api_key = await this.get_api_key_for_bot(bot);
    const openai = new OpenAI({
      apiKey: api_key,
    });
  
    const target_assistant_id = bot.config.is_custom_assistant_enabled
      ? bot.config.custom_assistant_id
      : bot.config.assistant_id;
  
    // Find or create thread
    let thread_id;
    let local_thread = await this.threadModel.findOne({
      session: payload.sid,
      bot: bot._id,
      assistant_id: target_assistant_id,
    });
  
    if (!local_thread) {
      const vector_store_ids = [];
      const tool_resources: { [key: string]: any } = {};
  
      if (bot.config.is_custom_assistant_enabled) {
        if (bot.config.custom_vector_store_id) {
          vector_store_ids.push(bot.config.custom_vector_store_id);
          tool_resources.file_search = { vector_store_ids };
        }
      } else {
        vector_store_ids.push(bot.config.vector_store_id);
        tool_resources.file_search = { vector_store_ids };
      }
  
      const remote_thread = await openai.beta.threads.create({
        messages: [
          {
            role: "user",
            content: payload.message,
          },
        ],
        tool_resources,
      });
  
      local_thread = new this.threadModel({
        session: payload.sid,
        bot: bot._id,
        thread_id: remote_thread.id,
        assistant_id: target_assistant_id,
      });
      await local_thread.save();
  
      thread_id = remote_thread.id;
    } else {
      thread_id = local_thread.thread_id;
      
      // Add message to existing thread
      await openai.beta.threads.messages.create(thread_id, {
        role: "user",
        content: payload.message,
      });
    }
  
    // Cancel existing run if any
    if (local_thread.run_id) {
      try {
        const existing_run = await openai.beta.threads.runs.retrieve(
          local_thread.thread_id,
          local_thread.run_id
        );
  
        if (existing_run.status === "in_progress") {
          await openai.beta.threads.runs.cancel(
            local_thread.thread_id,
            local_thread.run_id
          );
        }
      } catch (error) {
        console.error("Error retrieving or canceling the existing run:", error);
      }
    }
  
    let fullResponse = '';
  
    // Stream the response
    const stream = openai.beta.threads.runs.stream(thread_id, {
      assistant_id: target_assistant_id,
    });
  
    stream.on('textCreated', (text) => {
      res.write(`data: ${JSON.stringify({ type: 'text_created', content: text.value })}\n\n`);
    });
  
    stream.on('textDelta', (textDelta, snapshot) => {
      const content = textDelta.value || '';
      fullResponse += content;
      res.write(`data: ${JSON.stringify({ type: 'text_delta', content })}\n\n`);
    });
  
    stream.on('runStepCreated', (runStep) => {
      local_thread.run_id = runStep.run_id;
      local_thread.save();
      res.write(`data: ${JSON.stringify({ type: 'run_step_created', step_id: runStep.id })}\n\n`);
    });
  
        stream.on('end', async () => {
      // Demo modda AI yanıtını veritabanına kaydetme
      if (!is_demo && fullResponse.trim()) {
        const aiResponse = new this.messageModel({
          bot: bot._id,
          content: fullResponse,
          session: payload.sid,
          did: payload.did,
          sender: MessageSender.BOT,
          ip: '127.0.0.1',
          geo: geoip.lookup('127.0.0.1'),
          device: {
            os: 'Mevo OS',
            browser: 'Mevo Browser',
            device: 'MevoBook Pro',
          },
          unread: true,
          notificationSent: true,
        });
        await aiResponse.save();
      } else if (is_demo) {
        console.log("AI response is not saved because demo flag is set");
      }

      res.write(`data: ${JSON.stringify({ type: 'completed', content: fullResponse })}\n\n`);
      res.end();
    });
  
    stream.on('error', (error) => {
      console.error('Stream error:', error);
      res.write(`data: ${JSON.stringify({ type: 'error', error: error.message })}\n\n`);
      res.end();
    });
  }

  async getQuestions(website_content: string): Promise<{ question: string; answer: string }[]> {
    const openai_key = this.configService.get<string>("MEVO_OPENAI_KEY");
    const open_ai_client = new OpenAI({ apiKey: openai_key });
  
    const response = await open_ai_client.chat.completions.create({
      model: "gpt-4.1-2025-04-14",
      temperature: 0,
      messages: [
        {
          role: "system",
          content: "You are a question-generation assistant. Use the provided function to return exactly three question/answer pairs in JSON."
        },
        {
          role: "user",
          content: `
  Below is the content of a webpage. Generate three short questions a user might ask about it, and their answers.
  `
        },
        {
          role: "user",
          content: website_content
        }
      ],
      functions: [
        {
          name: "generate_questions",
          description: "Returns exactly three question/answer objects",
          parameters: {
            type: "object",
            properties: {
              questions: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    question: { type: "string", description: "The user question" },
                    answer:   { type: "string", description: "The answer" }
                  },
                  required: ["question", "answer"]
                },
                minItems: 3,
                maxItems: 3
              }
            },
            required: ["questions"]
          }
        }
      ],
      function_call: { name: "generate_questions" }
    });
  
    const args = JSON.parse(response.choices[0].message.function_call!.arguments!);
    return args.questions;
  }

  async getDominantColor(imageUrl: string) {
    const tmpFilePath = path.join(os.tmpdir(), `img-${Date.now()}.tmp`);
    let pngFilePath: string | null = null;
  
    try {
      // Resmi indir
      const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      const imageBuffer = Buffer.from(response.data);
      
      // Content-Type'ı kontrol et
      const contentType = response.headers['content-type'] || '';
      const isSvg = contentType.includes('svg') || imageUrl.toLowerCase().includes('.svg');
      const isIco = contentType.includes('image/x-icon') || imageUrl.toLowerCase().includes('.ico');
  
      if (isSvg || isIco) {
        // Sadece SVG'leri PNG'ye çevir
        pngFilePath = path.join(os.tmpdir(), `img-${Date.now()}.png`);
        
        try {
          const processedBuffer = await sharp(imageBuffer)
            .png()
            .resize(512, 512, { fit: 'inside', withoutEnlargement: true })
            .toBuffer();
          
          fs.writeFileSync(pngFilePath, processedBuffer);
          const palette = await Vibrant.from(pngFilePath).getPalette();
          return this.extractBestColor(palette);
          
        } catch (sharpError) {
          return "#000";
        }
      } else {
        // ICO, PNG, JPEG, WebP vs. - hepsini direkt Vibrant'a ver
        fs.writeFileSync(tmpFilePath, imageBuffer);
        const palette = await Vibrant.from(tmpFilePath).getPalette();
        return this.extractBestColor(palette);
      }
  
    } catch (error) {
      return "#000";
    } finally {
      // Cleanup
      [tmpFilePath, pngFilePath].forEach(filePath => {
        if (filePath && fs.existsSync(filePath)) {
          fs.unlink(filePath, err => {
            if (err) console.warn('Cleanup error:', err);
          });
        }
      });
    }
  }

  async getImageUrl(url: string, website_content: string): Promise<string> {
    const $ = cheerio.load(website_content);

    // try to find the favicon
    let primaryIcon = $("link[rel='apple-touch-icon']");
    let secondaryIcon = $("link[rel='icon']");
    let thirdIcon = $("link[rel='shortcut icon']");

    // extract the hostname from the url
    let hostname = new URL(url).hostname;

    try {
      return primaryIcon[0].attribs.href.includes("http") ? primaryIcon[0].attribs.href : 'https://' + hostname + primaryIcon[0].attribs.href;
    } catch (error) {
      try {
        return secondaryIcon[0].attribs.href.includes("http") ? secondaryIcon[0].attribs.href : 'https://' + hostname + secondaryIcon[0].attribs.href;
      } catch (error) {
        try {
          return thirdIcon[0].attribs.href.includes("http") ? thirdIcon[0].attribs.href : 'https://' + hostname + thirdIcon[0].attribs.href;
        } catch (error) {
          return 'https://' + hostname + '/favicon.ico';
        }
      }
    }
  }

  private extractBestColor(palette: any): string {
    return palette.Vibrant?.hex || 
           palette.DarkVibrant?.hex || 
           palette.LightVibrant?.hex || 
           palette.Muted?.hex || 
           "#000000";
  }

  async generate_data_from_url(url: string): Promise<{
    hex: string,
    image: string,
    questions: string[],
  }> {
    let image = "";
    let hex = "#000";
    let questions = [];
    let website_content = {
      data: "",
    };
    let website_content_markdown = {
      data: ""
    }

    let cleaned_url = this.cleanUrl(url);
    const api_key = this.configService.get<string>("SCRAPE_DO_API_KEY");
    cleaned_url = cleaned_url.includes("http") ? cleaned_url : `https://${cleaned_url}`;
    
    try {
      website_content = await axios.get(`https://api.scrape.do/?token=${api_key}&url=${cleaned_url}`);
      website_content_markdown = await axios.get(`https://api.scrape.do/?token=${api_key}&url=${cleaned_url}&output=markdown`);
    } catch (error) {
      console.error("Error getting website content from url:", error);
      return {
        hex: "#000",
        image: "",
        questions: [],
      };
    }

    try {
      image = await this.getImageUrl(cleaned_url, website_content.data);
    } catch (error) {}

    try {
      hex = await this.getDominantColor(image);
    } catch (error) {}

    try {
      questions = await this.getQuestions(website_content_markdown.data);
    } catch (error) {}

    return {
      hex,
      image,
      questions,
    };
  }

  async cleanupOldIpTrackingRecords(): Promise<void> {
    try {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const result = await this.ipTrackingModel.deleteMany({
        date: { $lt: thirtyDaysAgo }
      }).exec();
      
      console.log(`Cleaned up ${result.deletedCount} old IP tracking records`);
    } catch (error) {
      console.error('Error cleaning up IP tracking records:', error);
    }
  }

  private validateUrl(url: string): boolean {
    try {
      const fullUrl = url.startsWith('http') ? url : `https://${url}`;
      const parsed = new URL(fullUrl);
      
      // Internal IP ranges ve localhost engelle (SSRF koruması)
      const hostname = parsed.hostname;
      const blockedPatterns = [
        /^localhost$/i,
        /^127\./,           // 127.0.0.1 ve benzeri
        /^10\./,            // 10.0.0.0/8
        /^172\.(1[6-9]|2[0-9]|3[0-1])\./,  // 172.16.0.0/12
        /^192\.168\./,      // 192.168.0.0/16
        /^169\.254\./,      // AWS/Cloud metadata endpoint
        /^fe80::/,          // IPv6 link-local
        /^::1$/,            // IPv6 localhost
        /^0\.0\.0\.0$/,     // Invalid IP
      ];
      
      // Blocked patterns kontrolü
      if (blockedPatterns.some(pattern => pattern.test(hostname))) {
        return false;
      }

      // Port kontrolü (sadece standart HTTP/HTTPS portları)
      const port = parsed.port;
      if (port && !['80', '443', ''].includes(port)) {
        return false;
      }

      return true;
    } catch {
      return false;
    }
  }

  async cleanupExpiredClarityCache(): Promise<void> {
    try {
      const result = await this.clarityCacheModel.deleteMany({
        expiresAt: { $lt: new Date() }
      }).exec();
      
      console.log(`Cleaned up ${result.deletedCount} expired clarity cache records`);
    } catch (error) {
      console.error('Error cleaning up expired clarity cache records:', error);
    }
  }

  async checkDailyIpLimit(ip: string, endpoint: string, limit: number = 10): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Günün başlangıcı
    
    console.log(`Rate limit check for IP: ${ip}, endpoint: ${endpoint}, limit: ${limit}, date: ${today.toISOString()}`);
    
    try {
      // Periyodik temizlik (günde bir kez rastgele)
      if (Math.random() < 0.01) { // %1 şans
        this.cleanupOldIpTrackingRecords();
        this.cleanupExpiredClarityCache();
      }
      
      // Bugün için mevcut kaydı bul veya oluştur
      const existingRecord = await this.ipTrackingModel.findOne({
        ip,
        endpoint,
        date: today,
      }).exec();

      if (existingRecord) {
        console.log(`Existing record found for IP ${ip}: ${existingRecord.requestCount}/${limit} requests used`);
        
        // Limit kontrolü
        if (existingRecord.requestCount >= limit) {
          console.log(`Rate limit exceeded for IP ${ip}: ${existingRecord.requestCount}/${limit}`);
          throw new HttpException(
            `Daily limit of ${limit} requests exceeded. Please try again tomorrow.`,
            HttpStatus.TOO_MANY_REQUESTS,
          );
        }

        // İstek sayısını artır
        await this.ipTrackingModel.findByIdAndUpdate(
          existingRecord._id,
          { $inc: { requestCount: 1 } }
        ).exec();
        console.log(`Updated request count for IP ${ip}: ${existingRecord.requestCount + 1}/${limit}`);
      } else {
        // Yeni kayıt oluştur
        console.log(`Creating new rate limit record for IP ${ip}`);
        await this.ipTrackingModel.create({
          ip,
          endpoint,
          date: today,
          requestCount: 1,
        });
        console.log(`Created new record for IP ${ip}: 1/${limit} requests used`);
      }
    } catch (error) {
      throw error;
    }
  }

  async findOrCreateBotByUrl(url: string, requestIp?: string): Promise<{
    success: boolean;
    data: { botId: string, theme: string };
    message: string;
  }> {
    try {
      // Rate limiting kontrolü (günde 3 istek)
      
      // URL'yi temizle
      const cleanedUrl = this.cleanUrl(url);
      const normalizedUrl = cleanedUrl.includes("http") ? cleanedUrl : `https://${cleanedUrl}`;

      // Mevcut bot'ları ara
      const query: any = { previewUrl: normalizedUrl };
      // if (requestIp) {
      //   query.previewRequestIp = requestIp;
      // }
      
      const existingBot = await this.botModel.findOne(query).exec();
      
      if (existingBot) {
        await send_telegram_notification(
          `New preview request: ${normalizedUrl}, existing bot found.`
        )
        // Eğer bot varsa ID'sini döndür
        return { 
          success: true,
          data: { botId: existingBot._id.toString(), theme: existingBot.appearance.theme },
          message: 'Existing bot found'
        };
      } else {
        if (requestIp && requestIp !== 'unknown') {
          await this.checkDailyIpLimit(requestIp, 'find-or-create-by-url', 10);
        }
      }
      
      // Bot yoksa yeni bot oluştur
      console.log(`Bot not found for URL: ${normalizedUrl}, creating new bot...`);
      
      // 1. URL'den data üret
      const urlData = await this.generate_data_from_url(normalizedUrl);
      
      // 2. Bot oluşturma payload'ı hazırla
      const hostname = new URL(normalizedUrl).hostname;
      const defaultOrganization = this.configService.get('DEFAULT_ORGANIZATION');
      const defaultCreatedBy = this.configService.get('DEFAULT_CREATED_BY');
      
      if (!defaultOrganization || !defaultCreatedBy) {
        throw new HttpException(
          'Default organization or user not configured',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
      
      const createBotPayload: CreateViaWizardDto = {
        title: `Ask anything to AI`,
        description: `Auto-generated bot for ${normalizedUrl}`,
        themeColor: urlData.hex || '#3B82F6',
        callToAction: 'How can I help you?',
        brandLogoUrl: urlData.image || '',
        organization: defaultOrganization,
        leadCaptureMode: 'none',
        notificationType: NotificationType.ALL,
        notificationReceiverName: '',
        notificationReceiverEmail: '',
        notificationReceiverUrl: '',
        createdBy: defaultCreatedBy,
        trainingContent: `Website: ${normalizedUrl}`,
        chatbotType: 'from_scratch',
      };
      
      // 3. Bot'u oluştur (race condition önlemek için unique check ile)
      // Double-check: Aynı anda başka bir istek bot oluşturmuş olabilir
      const doubleCheckBot = await this.botModel.findOne({
        previewUrl: normalizedUrl,
        previewRequestIp: requestIp || ''
      }).exec();
      
      if (doubleCheckBot) {
        await send_telegram_notification(
          `New preview request: ${normalizedUrl}, existing bot found.`
        )
        return { 
          success: true,
          data: { botId: doubleCheckBot._id.toString(), theme: doubleCheckBot.appearance.theme },
          message: 'Existing bot found'
        };
      }
      
      const createdBot = await this.create_via_wizard_v3(createBotPayload);
      
      if (!createdBot) {
        throw new HttpException(
          'Bot creation returned no response',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
      
      if (!createdBot.success) {
        throw new HttpException(
          'Bot creation failed',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
      
      if (!createdBot.bot || !createdBot.bot._id) {
        throw new HttpException(
          'Bot creation succeeded but no bot data returned',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
      
      const botId = createdBot.bot._id.toString();
      
      // 3.5. Bot'a previewUrl ve previewRequestIp alanlarını ekle
      await this.botModel.findByIdAndUpdate(botId, {
        previewUrl: normalizedUrl,
        previewRequestIp: requestIp || '',
      }, { new: true }).exec();
      
      // 4. URL'yi scrape et
      try {
        await this.scrape_url(normalizedUrl, botId, true);
      } catch (scrapeError) {
        console.error(`Error scraping URL: ${normalizedUrl}`, scrapeError);
        // Scraping hatası bot oluşturmasını engellemesin
      }
      
      await send_telegram_notification(
        `New preview request: ${normalizedUrl}, created.`
      )
      return { 
        success: true,
        data: { botId, theme: urlData.hex },
        message: 'Bot found or created successfully'
      };
      
    } catch (error) {
      await send_telegram_notification(
        `New preview request: ${url}, failed to create bot. ${error}`
      )
      throw error;
    }
  }

  async getWebsiteScreenshot(url: string, res: any): Promise<void> {
    try {
      // URL'yi temizle ve normalize et
      const cleanedUrl = this.cleanUrl(url);
      const normalizedUrl = cleanedUrl.includes("http") ? cleanedUrl : `https://${cleanedUrl}`;
      
      // ApiFlash API key'i al
      const apiKey = this.configService.get<string>('APIFLASH_ACCESS_KEY');
      if (!apiKey) {
        throw new HttpException(
          'Screenshot service not configured',
          HttpStatus.SERVICE_UNAVAILABLE,
        );
      }

      // ApiFlash API URL'ini oluştur
      const screenshotUrl = `https://api.apiflash.com/v1/urltoimage` +
        `?access_key=${apiKey}` +
        `&wait_until=page_loaded` +
        `&url=${encodeURIComponent(normalizedUrl)}` +
        `&width=1920` +
        `&height=1080` +
        `&format=png` +
        `&no_ads=true` +
        `&no_cookie_banners=true`;

      // ApiFlash'tan screenshot al
      const response = await this.httpService.axiosRef.get(screenshotUrl, {
        responseType: 'stream',
        timeout: 30000, // 30 saniye timeout
      });

      // Response headers'ı ayarla
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Cache-Control', 'public, max-age=3600'); // 1 saat cache
      res.setHeader('Content-Disposition', `inline; filename="screenshot-${Date.now()}.png"`);

      // Stream'i direkt frontend'e pipe et
      response.data.pipe(res);

    } catch (error) {
      console.error('Screenshot API error:', error);
      
      if (error.response?.status === 402) {
        throw new HttpException(
          'Screenshot service quota exceeded',
          HttpStatus.SERVICE_UNAVAILABLE,
        );
      } else if (error.response?.status === 400) {
        throw new HttpException(
          'Invalid URL for screenshot',
          HttpStatus.BAD_REQUEST,
        );
      } else {
        throw new HttpException(
          'Screenshot service temporarily unavailable',
          HttpStatus.SERVICE_UNAVAILABLE,
        );
      }
    }
  }

  async clarity_test(url: string): Promise<{
    success: boolean;
    overall_score?: number;
    readability_score?: number;
    readability_improvement?: string;
    jargon_clarity_score?: number;
    jargon_clarity_improvement?: string;
    cta_clarity_score?: number;
    cta_clarity_improvement?: string;
    info_density_score?: number;
    info_density_improvement?: string;
    bot?: {
      botId: string;
      theme: string;
    };
    error?: string;
  }> {
    try {
      // 1. URL'i temizle ve validate et
      let cleaned_url = this.cleanUrl(url);
      cleaned_url = cleaned_url.includes("http") ? cleaned_url : `https://${cleaned_url}`;
      
      // URL güvenlik kontrolü
      if (!this.validateUrl(cleaned_url)) {
        return {
          success: false,
          error: "Invalid or potentially unsafe URL"
        };
      }

      // 2. Cache'ten kontrol et
      const cachedResult = await this.clarityCacheModel.findOne({
        url: cleaned_url,
        expiresAt: { $gt: new Date() }
      }).exec();

      if (cachedResult) {
        console.log(`Clarity test cache hit for URL: ${cleaned_url}`);
        
        // Cache objesini clone et (mutation'ı önlemek için)
        const result = JSON.parse(JSON.stringify(cachedResult.result));
        
        // Cache hit olsa bile bot bilgisini güncel al
        try {
          const botResult = await this.findOrCreateBotByUrl(cleaned_url, 'cache-hit');
          if (botResult.success && botResult.data) {
            result.bot = {
              botId: botResult.data.botId,
              theme: botResult.data.theme
            };
          }
        } catch (error) {
          console.error('Error getting bot for cached clarity result:', error);
          // Bot hatası clarity result'ını etkilemesin
        }
        
        return result;
      }

      console.log(`Clarity test cache miss for URL: ${cleaned_url}`);

      // 3. scrape.do kullanarak website'i scrape et
      const api_key = this.configService.get<string>("SCRAPE_DO_API_KEY");
      if (!api_key) {
        throw new Error("SCRAPE_DO_API_KEY is not configured");
      }

      let website_content_markdown;
      try {
        website_content_markdown = await axios.get(
          `https://api.scrape.do/?token=${api_key}&url=${cleaned_url}&output=markdown`
        );
        
        // Content validation
        if (!website_content_markdown.data || typeof website_content_markdown.data !== 'string') {
          return {
            success: false,
            error: "No content found or invalid content format"
          };
        }

        // Content size check (OpenAI token limit protection)
        const maxContentLength = 50000; // ~12-15K tokens güvenli sınır
        if (website_content_markdown.data.length > maxContentLength) {
          website_content_markdown.data = website_content_markdown.data.substring(0, maxContentLength) + "\n\n[Content truncated due to size limits]";
          console.log(`Content truncated for URL: ${cleaned_url} (original length: ${website_content_markdown.data.length})`);
        }

      } catch (error) {
        console.error("Error scraping website:", error);
        return {
          success: false,
          error: "Failed to scrape website content"
        };
      }

      // 3. GPT-4o kullanarak clarity test yap
      const openai_key = this.configService.get<string>("MEVO_OPENAI_KEY");
      if (!openai_key) {
        throw new Error("MEVO_OPENAI_KEY is not configured");
      }

      const open_ai_client = new OpenAI({ apiKey: openai_key });

      let response;
      try {
        response = await open_ai_client.chat.completions.create({
          model: "gpt-4o",
          temperature: 0,
          messages: [
            {
              role: "system",
              content: "You are a website clarity analysis expert. Analyze the provided website content and evaluate its clarity. Use the provided function to return a structured response."
            },
            {
              role: "user",
              content: `
                           You are a website clarity evaluation assistant.
   
               Please return a JSON with the following fields:
   
               1. readability_score: Rate from 1 to 10 how easy the content is to read (10 = very easy).
               2. readability_improvement: If score is less than 10, provide a specific improvement suggestion. Leave empty if score is 10.
               3. jargon_clarity_score: Rate from 1 to 10 how free the content is from buzzwords or complex technical jargon.
               4. jargon_clarity_improvement: If score is less than 10, provide a specific suggestion to reduce jargon. Leave empty if score is 10.
               5. cta_clarity_score: From 1 to 10, how clear and visible the main call-to-action (CTA) is.
               6. cta_clarity_improvement: If score is less than 10, provide a specific suggestion to improve CTA clarity. Leave empty if score is 10.
               7. info_density_score: From 1 to 10, how focused and well-structured the information is.
               8. info_density_improvement: If score is less than 10, provide a specific suggestion to improve information structure. Leave empty if score is 10.
   
               Return only a valid JSON object.


              Website content:
              ${website_content_markdown.data}
              `
            }
          ],
          functions: [
            {
              name: "clarity_analysis",
              description: "Analyzes website content clarity and returns a structured response with specific metrics",
              parameters: {
                type: "object",
                properties: {
                  readability_score: {
                    type: "number",
                    description: "Rate from 1 to 10 how easy the content is to read (10 = very easy)",
                    minimum: 1,
                    maximum: 10
                  },
                  readability_improvement: {
                    type: "string",
                    description: "Improvement suggestion for readability if score is less than 10. Leave empty if score is 10."
                  },
                  jargon_clarity_score: {
                    type: "number",
                    description: "Rate from 1 to 10 how free the content is from buzzwords or complex technical jargon",
                    minimum: 1,
                    maximum: 10
                  },
                  jargon_clarity_improvement: {
                    type: "string",
                    description: "Improvement suggestion for reducing jargon if score is less than 10. Leave empty if score is 10."
                  },
                  cta_clarity_score: {
                    type: "number",
                    description: "Rate from 1 to 10 how clear and visible the main call-to-action (CTA) is",
                    minimum: 1,
                    maximum: 10
                  },
                  cta_clarity_improvement: {
                    type: "string",
                    description: "Improvement suggestion for call-to-action clarity if score is less than 10. Leave empty if score is 10."
                  },
                  info_density_score: {
                    type: "number",
                    description: "Rate from 1 to 10 how focused and well-structured the information is",
                    minimum: 1,
                    maximum: 10
                  },
                  info_density_improvement: {
                    type: "string",
                    description: "Improvement suggestion for information structure if score is less than 10. Leave empty if score is 10."
                  }
                },
                required: ["readability_score", "readability_improvement", "jargon_clarity_score", "jargon_clarity_improvement", "cta_clarity_score", "cta_clarity_improvement", "info_density_score", "info_density_improvement"]
              }
            }
          ],
          function_call: { name: "clarity_analysis" }
        });
      } catch (error) {
        console.error("Error calling OpenAI API:", error);
        return {
          success: false,
          error: "Failed to analyze website content with AI"
        };
      }

      // Response validation ve JSON parsing
      if (!response?.choices?.[0]?.message?.function_call?.arguments) {
        console.error("Invalid OpenAI response structure");
        return {
          success: false,
          error: "Invalid AI analysis response"
        };
      }

      let args;
      try {
        args = JSON.parse(response.choices[0].message.function_call.arguments);
      } catch (error) {
        console.error("Error parsing OpenAI function arguments:", error);
        return {
          success: false,
          error: "Failed to parse AI analysis results"
        };
      }

      // Score validation
      const requiredScores = ['readability_score', 'jargon_clarity_score', 'cta_clarity_score', 'info_density_score'];
      for (const scoreField of requiredScores) {
        if (typeof args[scoreField] !== 'number' || args[scoreField] < 1 || args[scoreField] > 10) {
          console.error(`Invalid score for ${scoreField}:`, args[scoreField]);
          return {
            success: false,
            error: "Invalid AI analysis scores"
          };
        }
      }

      // Overall score hesapla (4 score'un ortalaması)
      const overallScore = Math.round(
        (args.readability_score + args.jargon_clarity_score + args.cta_clarity_score + args.info_density_score) / 4
      );

      const result: any = {
        success: true,
        overall_score: overallScore,
        readability_score: args.readability_score,
        readability_improvement: args.readability_improvement,
        jargon_clarity_score: args.jargon_clarity_score,
        jargon_clarity_improvement: args.jargon_clarity_improvement,
        cta_clarity_score: args.cta_clarity_score,
        cta_clarity_improvement: args.cta_clarity_improvement,
        info_density_score: args.info_density_score,
        info_density_improvement: args.info_density_improvement
      };

      // 4. Bot oluştur veya bul
      try {
        const botResult = await this.findOrCreateBotByUrl(cleaned_url, 'clarity-analysis');
        if (botResult.success && botResult.data) {
          result.bot = {
            botId: botResult.data.botId,
            theme: botResult.data.theme
          };
        }
      } catch (error) {
        console.error('Error creating bot for clarity analysis:', error);
        // Bot hatası clarity result'ını etkilemesin
      }

      // 5. Sonucu cache'e kaydet (24 saat süreyle)
      try {
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24); // 24 saat cache

        await this.clarityCacheModel.findOneAndUpdate(
          { url: cleaned_url },
          {
            url: cleaned_url,
            result: result,
            expiresAt: expiresAt
          },
          { upsert: true, new: true }
        ).exec();

        console.log(`Clarity test result cached for URL: ${cleaned_url}`);
      } catch (cacheError) {
        console.error("Error caching clarity test result:", cacheError);
        // Cache hatası sonucu etkilemesin, sadece log
      }

      return result;

    } catch (error) {
      console.error("Error in clarity test:", error);
      return {
        success: false,
        error: error.message || "An unexpected error occurred"
      };
    }
  }
}
