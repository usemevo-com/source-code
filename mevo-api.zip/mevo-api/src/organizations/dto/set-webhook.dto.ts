import { ApiProperty } from "@nestjs/swagger";

export class SetWebhookDto {
  @ApiProperty({ type: "string" })
  webhookURL: string;
}
