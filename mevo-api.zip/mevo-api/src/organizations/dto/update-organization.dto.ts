import { IsBoolean, IsNotEmpty, IsOptional, IsString } from "class-validator";
import { Exclude } from "class-transformer";
import { ApiProperty } from "@nestjs/swagger";

export class UpdateOrganizationDto {
  @IsOptional()
  @Exclude()
  _id?: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  name: string;

  @IsBoolean()
  @IsOptional()
  @ApiProperty({ type: "boolean" })
  sendEmailNotificationToAdmins: boolean;
}
