import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";
import { SecretKey } from "../entities/secret.schema";

export class AddSecretDto {
  @IsNotEmpty()
  @ApiProperty({ type: "string", enum: SecretKey })
  key: string;

  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  value: string;
}
