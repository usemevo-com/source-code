import { IsArray, IsNotEmpty } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";

export class UpgradeTierDto {
  @IsArray()
  @IsNotEmpty()
  @ApiProperty({ type: Array })
  keys: string[];
}
