import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty } from 'class-validator';

export class BlogPostDto {
  @IsNotEmpty()
  @ApiProperty({ type: 'string' })
  postTitle: string;
}
