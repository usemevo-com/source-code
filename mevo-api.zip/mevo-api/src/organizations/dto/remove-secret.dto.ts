import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty } from "class-validator";
import { SecretKey } from "../entities/secret.schema";

export class RemoveSecretDto {
  @IsNotEmpty()
  @ApiProperty({ type: "string", enum: SecretKey })
  key: string;
}
