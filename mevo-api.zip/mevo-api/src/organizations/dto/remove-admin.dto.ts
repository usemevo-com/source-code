import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty } from 'class-validator';

export class RemoveAdminDto {
  @IsNotEmpty()
  @IsEmail()
  @ApiProperty({ type: 'string' })
  email: string;
}
