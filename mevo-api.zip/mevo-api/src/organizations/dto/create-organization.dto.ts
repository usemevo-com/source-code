import { ApiProperty } from '@nestjs/swagger'
import { IsNotEmpty, IsOptional } from 'class-validator'
import { User } from '../../users/entities/user.schema'
import { Exclude } from 'class-transformer'

export class CreateOrganizationDto {
  @IsNotEmpty()
  @ApiProperty({ type: 'string', required: true })
  name: string

  @IsOptional()
  @ApiProperty({ type: 'string', required: false })
  domain: string

  @Exclude()
  admins: User[]

  @IsOptional()
  migration: boolean;

  @IsOptional()
  bot: string;

  @IsOptional()
  version: string;
}
