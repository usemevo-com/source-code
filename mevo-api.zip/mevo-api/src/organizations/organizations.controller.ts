import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Req,
  ForbiddenException,
  NotFoundException,
  Query,
  HttpException,
  HttpStatus,
  UseGuards,
} from "@nestjs/common";
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { OrganizationsService } from "./organizations.service";
import { CreateOrganizationDto } from "./dto/create-organization.dto";
import { UpdateOrganizationDto } from "./dto/update-organization.dto";
import { AddAdminDto } from "./dto/add-admin.dto";
import { RemoveAdminDto } from "./dto/remove-admin.dto";
import { RemoveUserDto } from "./dto/remove-user.dto";
import { AddUserDto } from "./dto/add-user.dto";
import { RemoveOrganizationDto } from "./dto/remove-organization.dto";
import { isObjectIdPipe } from "../common/pipes/isObjectIdPipe";
import RequestWithUser from "../auth/interfaces/request-with-user";
import { hasAdminAccess, hasUserAccess } from "../auth/helpers/has-access";
import { SetWebhookDto } from "./dto/set-webhook.dto";
import { PlanType } from "./entities/plan";
import { AddSecretDto } from "./dto/add-secret.dto";
import { RemoveSecretDto } from "./dto/remove-secret.dto";
import { UpgradeTierDto } from "./dto/upgrade-tier.dto";
import { AddListenerDto } from "./dto/add-listener.dto";
import { Public } from "src/auth/helpers/is-public";
import JwtAuthenticationGuard from "src/auth/guards/jwt-authentication.guard";

@ApiBearerAuth()
@ApiTags("organizations")
@Controller("organizations")
export class OrganizationsController {
  constructor(private readonly organizationsService: OrganizationsService) {}

  @Post()
  create(
    @Body() createOrganizationDto: CreateOrganizationDto,
    @Req() request: RequestWithUser
  ) {
    createOrganizationDto.admins = [request.user];
    return this.organizationsService.create(createOrganizationDto);
  }

  @Post("v3")
  createV3(
    @Body() createOrganizationDto: CreateOrganizationDto,
    @Req() request: RequestWithUser
  ) {
    createOrganizationDto.admins = [request.user];
    createOrganizationDto.version = "3";
    return this.organizationsService.create(createOrganizationDto);
  }

  @Get("recent-interactions/:oid")
  async getRecentInteractions(
    @Param("oid", new isObjectIdPipe()) oid: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id: oid,
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.organizationsService.recentInteractions(oid);
    }

    throw new ForbiddenException();
  }

  @Get("message-chart-data/:oid")
  async getMessageChartData(
    @Param("oid", new isObjectIdPipe()) oid: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id: oid,
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.organizationsService.getMessagesChartData(oid);
    }

    throw new ForbiddenException();
  }

  @Get("stats/:oid")
  async getStats(
    @Param("oid", new isObjectIdPipe()) oid: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id: oid,
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return this.organizationsService.getStats(oid);
    }

    throw new ForbiddenException();
  }

  @Get("v3")
  findAllV3(@Req() request: RequestWithUser) {
    return this.organizationsService.findAll({
       $and: [ { $or: [{ admins: request.user._id }, { users: request.user._id }] }, { version: "3" }]
    });
  }

  @Get()
  findAll(@Req() request: RequestWithUser) {
    return this.organizationsService.findAll({
      $and: [ { $or: [{ admins: request.user._id }, { users: request.user._id }] }, { version: "2" }]
    });
  }

  @Get(":id")
  async findOne(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (
      hasAdminAccess(organization, request.user) ||
      hasUserAccess(organization, request.user)
    ) {
      return organization;
    }

    throw new ForbiddenException();
  }

  @Post(":id/upgrade-tier")
  async upgradeTier(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() upgradeTierDto: UpgradeTierDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.upgradeTier({
        organization: _id,
        keys: upgradeTierDto.keys,
      });
    }

    throw new ForbiddenException();
  }

  @Patch(":id")
  async update(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() updateOrganizationDto: UpdateOrganizationDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.update({ _id }, updateOrganizationDto);
    }

    throw new ForbiddenException();
  }

  @Delete(":id")
  async remove(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() removeOrganizationDto: RemoveOrganizationDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.remove({ _id }, removeOrganizationDto);
    }

    throw new ForbiddenException();
  }

  @Post(":id/add-admin")
  async addAdmin(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addAdminDto: AddAdminDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (!organization) throw new NotFoundException("organizations.NOT_FOUND");

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.addAdmin({ _id }, addAdminDto);
    }

    throw new ForbiddenException();
  }

  @Post(":id/remove-admin")
  async removeAdmin(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() removeAdmin: RemoveAdminDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.removeAdmin({ _id }, removeAdmin);
    }

    throw new ForbiddenException();
  }

  @Post(":id/add-user")
  async addUser(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addUserDto: AddUserDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.addUser({ _id }, addUserDto);
    }

    throw new ForbiddenException();
  }

  @Post(":id/remove-user")
  async removeUser(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() removeUser: RemoveUserDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.removeUser({ _id }, removeUser);
    }

    throw new ForbiddenException();
  }

  @Post(":id/add-secret")
  async addSecret(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addSecretDto: AddSecretDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.addSecret({ _id }, addSecretDto);
    }
  }

  @Post(":id/remove-secret")
  async removeSecret(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() removeSecretDto: RemoveSecretDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.removeSecret({ _id }, removeSecretDto);
    }
  }

  @Post("set-webhook/:id")
  async setWebhook(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() webhookData: SetWebhookDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (organization.plan === PlanType.BASIC) {
      throw new ForbiddenException("organizations.NEED_PRO_SUBSCRIPTION");
    }

    if (hasAdminAccess(organization, request.user)) {
      return this.organizationsService.setWebhook({ _id }, webhookData);
    }

    throw new ForbiddenException();
  }
}
