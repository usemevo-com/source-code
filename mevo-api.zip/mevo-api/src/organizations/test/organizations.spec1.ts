import * as request from "supertest";
import { Test } from "@nestjs/testing";
import { INestApplication, ValidationPipe } from "@nestjs/common";
import { Model } from "mongoose";
import { getModelToken } from "@nestjs/mongoose";
import { AppModule } from "../../app.module";
import {
  Organization,
  OrganizationDocument,
} from "../entities/organization.schema";
import { User, UserDocument } from "../../users/entities/user.schema";
import { getToken } from "../../common/helpers/get-token";

let app: INestApplication;
let organizationModel: Model<OrganizationDocument>;
let userModel: Model<UserDocument>;
let createdOrganization;
let createdOrganization2;
let createdOrganization3;
let createdOrganization4;
let createdOrganization5;
let createdUser1;
let createdUser2;
let createdUser3;
let user4;
let user5;
let authToken;
let authUser;

beforeAll(async () => {
  const moduleRef = await Test.createTestingModule({
    providers: [
      {
        provide: getModelToken(Organization.name),
        useValue: Model,
      },
      {
        provide: getModelToken(User.name),
        useValue: Model,
      },
    ],
    imports: [AppModule],
  }).compile();

  // clear organizations collection
  organizationModel = moduleRef.get<Model<OrganizationDocument>>(
    getModelToken(Organization.name)
  );
  await organizationModel.deleteMany({});

  // clear users collection
  userModel = moduleRef.get<Model<UserDocument>>(getModelToken(User.name));
  await userModel.deleteMany({});

  // create a user
  createdUser1 = await new userModel({
    name: "Dummy user 1",
    email: "dummyuser1_mevo_test@gmail.com",
    password: "123456",
  }).save();

  createdUser2 = await new userModel({
    name: "Dummy user 2",
    email: "dummyuser2_mevo_test@gmail.com",
    password: "123456",
  }).save();

  createdUser3 = await new userModel({
    name: "Dummy user 3",
    email: "dummyuser3_mevo_test@gmail.com",
    password: "123456",
  }).save();

  // start app instance
  app = moduleRef.createNestApplication();
  app.useGlobalPipes(new ValidationPipe());
  await app.init();
  // get auth token
  const auth = await getToken(
    request(app.getHttpServer()),
    "user_mevo_test@gmail.com"
  );
  authToken = auth.token;
  authUser = auth.user;

  user4 = await getToken(
    request(app.getHttpServer()),
    "user4_mevo_test@gmail.com"
  );
  user5 = await getToken(
    request(app.getHttpServer()),
    "user5_mevo_test@gmail.com"
  );

  createdOrganization3 = await new organizationModel({
    name: "org3",
    admins: [user4.user._id],
    users: [user5.user._id],
  }).save();

  createdOrganization4 = await new organizationModel({
    name: "org4",
    admins: [user5.user._id],
    users: [user4.user._id],
  }).save();

  createdOrganization5 = await new organizationModel({
    name: "org5",
    admins: [],
    users: [],
  }).save();
});

describe("organizations", () => {
  test(`should return authentication error`, () => {
    return request(app.getHttpServer()).get("/organizations").expect(401);
  });

  test(`should get empty array`, async () => {
    await request(app.getHttpServer())
      .get("/organizations")
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200);
  });
});

describe("try to create an organization", () => {
  it("should return authentication error", () => {
    return request(app.getHttpServer())
      .post("/organizations")
      .send({})
      .expect(401);
  });

  it(`should return validation error while trying with empty body`, () => {
    return request(app.getHttpServer())
      .post("/organizations")
      .set("Cookie", `Authentication=${authToken}`)
      .send({})
      .expect(400);
  });

  it(`should create an organization with correct body`, () => {
    return request(app.getHttpServer())
      .post("/organizations")
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Primary" })
      .expect(201)
      .then((response) => {
        createdOrganization = response.body;
      });
  });

  it(`should create an organization with correct body`, () => {
    return request(app.getHttpServer())
      .post("/organizations")
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Another" })
      .expect(201)
      .then(async (response) => {
        createdOrganization2 = response.body;
        await organizationModel.findOneAndUpdate(
          {
            _id: createdOrganization2._id,
          },
          { plan: "pro" }
        );
      });
  });
});

describe("try to get single organization by id", () => {
  it(`should return authentication error with incorrect id`, async () => {
    return request(app.getHttpServer()).get("/organizations/1").expect(401);
  });

  it(`should return validation error with incorrect id`, async () => {
    return request(app.getHttpServer())
      .get("/organizations/1")
      .set("Cookie", `Authentication=${authToken}`)
      .expect(400);
  });

  it(`should return 404 error for non-existing organization`, async () => {
    return request(app.getHttpServer())
      .get("/organizations/111111111111111111111111")
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });

  it(`should return organization detail`, async () => {
    return request(app.getHttpServer())
      .get(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(response.body.name).toEqual("Primary");
      });
  });
});

describe("try to update organization name", () => {
  it(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .patch(`/organizations/111111111111111111111111`)
      .send({ name: "Secondary" })
      .expect(401);
  });

  it(`should return not found error while try to update non-existing organization`, () => {
    return request(app.getHttpServer())
      .patch(`/organizations/111111111111111111111111`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Secondary" })
      .expect(404);
  });

  it(`should return validation error while try to update organization with empty body`, () => {
    return request(app.getHttpServer())
      .patch(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send()
      .expect(400);
  });

  it(`should update organization name`, () => {
    return request(app.getHttpServer())
      .patch(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Secondary" })
      .expect(200);
  });
});

describe("try to add user to organization", () => {
  it(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-user`)
      .send({})
      .expect(401);
  });

  it(`should return validation error when request body is empty`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({})
      .expect(400);
  });

  it(`should return user not found error when email is not exist`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: "furkan_mevo_test@gmail.com" })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("users.NOT_FOUND");
      });
  });

  it(`should return validation error while try to add user into invalid organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/1/add-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(400);
  });

  it(`should return validation error while try to add user to non-existent organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/63b0bcbc3ab013855eecf200/add-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser1.email })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("organizations.NOT_FOUND");
      });
  });

  it(`should send user invitation for organization`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser1.email })
      .expect(201);
  });

  it(`should send user invitation for organization`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser3.email })
      .expect(201);
  });

  it(`should send admin invitation for organization`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization2._id}/add-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser3.email })
      .expect(201);
  });
});

describe("try to remove user from organization", () => {
  it(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-user`)
      .send({})
      .expect(401);
  });

  it(`should return validation error when request body is empty`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({})
      .expect(400);
  });

  it(`should return user not found error when email is not exist`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: "furkan_mevo_test@gmail.com" })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("users.NOT_FOUND");
      });
  });

  it(`should return validation error while try to remove user with invalid organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/1/remove-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(400);
  });

  it(`should return validation error while try to remove user from non-existent organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/63b0bcbc3ab013855eecf200/remove-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser1.email })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("organizations.NOT_FOUND");
      });
  });

  it(`should remove user from organizaiton`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-user`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser1.email })
      .expect(201);
  });

  it(`should verify users array of organization`, () => {
    return request(app.getHttpServer())
      .get(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(
          response.body.users.filter(
            (u) => u._id.toString() === createdUser1._id.toString()
          ).length
        ).toEqual(0);
      });
  });
});

describe("try to add admin to organization", () => {
  it(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-admin`)
      .send({})
      .expect(401);
  });

  it(`should return validation error when request body is empty`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({})
      .expect(400);
  });

  it(`should return validation error while try to add user into invalid organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/1/add-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(400);
  });

  it(`should return validation error while try to add user to non-existent organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/63b0bcbc3ab013855eecf200/add-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser1.email })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("organizations.NOT_FOUND");
      });
  });

  it(`should return add another admin first error`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser2.email })
      .expect(400)
      .then((response) => {
        expect(response.body.message).toEqual(
          "organizations.ADD_ANOTHER_ADMIN_BEFORE_REMOVING_YOURSELF"
        );
      });
  });

  it(`should add admin to organizaiton`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/add-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser2.email })
      .expect(201);
  });
});

describe("try to remove admin from organization", () => {
  it(`should return authentication error`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-admin`)
      .send({})
      .expect(401);
  });

  it(`should return validation error when request body is empty`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({})
      .expect(400);
  });

  it(`should return user not found error when email is not exist`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: "furkan_mevo_test@gmail.com" })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("users.NOT_FOUND");
      });
  });

  it(`should return validation error while try to remove admin with invalid organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/1/remove-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(400);
  });

  it(`should return validation error while try to remove admin from non-existent organization id,`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/63b0bcbc3ab013855eecf200/remove-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser2.email })
      .expect(404)
      .then((response) => {
        expect(response.body.message).toEqual("organizations.NOT_FOUND");
      });
  });

  it(`should remove admin from organizaiton`, async () => {
    // add another admin directly via model
    const organization = await organizationModel.findOne({
      _id: createdOrganization._id,
    });
    organization.admins.push(createdUser1);
    await organization.save();

    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization._id}/remove-admin`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ email: createdUser2.email })
      .expect(201);
  });

  it(`should verify admins array of organization`, () => {
    return request(app.getHttpServer())
      .get(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(200)
      .then((response) => {
        expect(
          response.body.admins.filter(
            (u) => u._id.toString() === createdUser2._id.toString()
          ).length
        ).toEqual(0);
      });
  });
});

describe("try to remove an organization", () => {
  it(`should return authentication error,`, () => {
    return request(app.getHttpServer())
      .delete(`/organizations/1`)
      .send({ name: "Primary" })
      .expect(401);
  });

  it(`should return validation error while try to remove organization with invalid id,`, () => {
    return request(app.getHttpServer())
      .delete(`/organizations/1`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Primary" })
      .expect(400);
  });

  it(`should return validation error while try to remove organization without name`, () => {
    return request(app.getHttpServer())
      .delete(`/organizations/63b0bcbc3ab013855eecf200`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(400);
  });

  it(`should return validation error while try to remove organization with incorrect name`, () => {
    return request(app.getHttpServer())
      .delete(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Primaryy" })
      .expect(400)
      .then((response) => {
        expect(response.body.message).toEqual(
          "organizations.INCORRECT_ORGANIZATION_NAME"
        );
      });
  });

  it("should return organization not found error while try to removing with non-existend organization id", () => {
    return request(app.getHttpServer())
      .delete(`/organizations/111111111111111111111111`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Secondary" })
      .expect(404);
  });

  it("should return organization not found error while try to removing with non-existend organization id", () => {
    return request(app.getHttpServer())
      .delete(`/organizations/${createdOrganization2._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Another" })
      .expect(400)
      .then((response) => {
        expect(response.body.message).toEqual(
          "organizations.SUBSCRIPTION_EXISTS"
        );
      });
  });

  it(`should remove organization`, () => {
    return request(app.getHttpServer())
      .delete(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .send({ name: "Secondary" })
      .expect(200);
  });

  it(`should verify organization removed`, () => {
    return request(app.getHttpServer())
      .get(`/organizations/${createdOrganization._id}`)
      .set("Cookie", `Authentication=${authToken}`)
      .expect(404);
  });
});

describe("test authorization", () => {
  it("should return 2 + 1 of current organizations (2 external, 1 default organization)", () => {
    return request(app.getHttpServer())
      .get("/organizations")
      .set("Cookie", `Authentication=${user4.token}`)
      .expect(200)
      .then((response) => {
        expect(response.body.length).toEqual(3);
      });
  });

  it("should return authroization error while try to access organizaiton without permission", () => {
    return request(app.getHttpServer())
      .get("/organizations/" + createdOrganization5._id)
      .set("Cookie", `Authentication=${user4.token}`)
      .expect(403);
  });

  it("should return authorization error while try to update organization without permission", () => {
    return request(app.getHttpServer())
      .patch("/organizations/" + createdOrganization5._id)
      .set("Cookie", `Authentication=${user4.token}`)
      .send({ name: "Secondary" })
      .expect(403);
  });

  it("should return authorization error while try to delete organization without permission", () => {
    return request(app.getHttpServer())
      .delete("/organizations/" + createdOrganization5._id)
      .set("Cookie", `Authentication=${user4.token}`)
      .send({ name: "org5" })
      .expect(403);
  });

  it(`should return authroziation error while try to add admin to organizaiton without permission`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization5._id}/add-admin`)
      .set("Cookie", `Authentication=${user4.token}`)
      .send({ email: createdUser2.email })
      .expect(403);
  });

  it(`should return authroziation error while try to remove admin to organizaiton without permission`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization5._id}/remove-admin`)
      .set("Cookie", `Authentication=${user4.token}`)
      .send({ email: createdUser2.email })
      .expect(403);
  });

  it(`should return authroziation error while try to add user to organizaiton without permission`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization5._id}/add-user`)
      .set("Cookie", `Authentication=${user4.token}`)
      .send({ email: createdUser2.email })
      .expect(403);
  });

  it(`should return authroziation error while try to remove user to organizaiton without permission`, () => {
    return request(app.getHttpServer())
      .post(`/organizations/${createdOrganization5._id}/remove-user`)
      .set("Cookie", `Authentication=${user4.token}`)
      .send({ email: createdUser2.email })
      .expect(403);
  });
});

afterAll(async () => {
  // clear collections
  await organizationModel.deleteMany({});
  await userModel.deleteMany({});
  // close app
  await app.close();
});
