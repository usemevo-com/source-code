import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type SecretDocument = HydratedDocument<Secret>;

export enum SecretKey {
  OPEN_AI_KEY = "open_ai_key",
  AVAILABILITY = "availability",
}

@Schema({
  timestamps: true,
})
export class Secret {
  _id: string;

  @Prop({ required: true, type: String, enum: SecretKey })
  key: string;

  @Prop({ required: true, type: String })
  value: string;
}

export const SecretSchema = SchemaFactory.createForClass(Secret);
