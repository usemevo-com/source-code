import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { User } from "../../users/entities/user.schema";
import { PlanType } from "./plan";
import { Period } from "../../subscriptions/entities/period.schema";
import { Secret } from "./secret.schema";

export type OrganizationDocument = HydratedDocument<Organization>;

@Schema({
  timestamps: true,
})
export class Organization {
  _id: string;

  @Prop({ required: true })
  name: string;

  @Prop({ type: String })
  domain: string;

  @Prop({
    required: true,
    type: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        autopopulate: {
          select: "name email picture",
        },
      },
    ],
  })
  admins: User[];

  @Prop({
    required: true,
    type: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        autopopulate: {
          select: "name email picture",
        },
      },
    ],
  })
  users: User[];

  @Prop({
    required: true,
    type: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        autopopulate: {
          select: "email",
        },
      },
    ],
    default: [],
  })
  listeners: User[];

  @Prop({ type: String, enum: PlanType, default: PlanType.BASIC })
  plan: PlanType;

  @Prop({ type: String })
  stripeCustomerId: string;

  @Prop({ type: String })
  subscriptionId: string;

  @Prop({ type: Boolean })
  subscriptionCancelled: boolean;

  @Prop({ type: Date })
  subscriptionEndAt: Date | null;

  @Prop({ type: Date })
  lastNotificationSentAt: Date | null;

  @Prop({ default: false })
  isRemoved: boolean;

  @Prop({
    required: false,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Period",
    autopopulate: {
      select: "usage start end plan subscriptionType",
    },
  })
  activePeriod: Period;

  @Prop({ type: Number, default: 0, required: false })
  failedPaymentTry: number;

  @Prop({ type: String, required: false })
  webhookURL: string;

  @Prop({
    type: [
      {
        required: false,
        type: mongoose.Schema.Types.ObjectId,
        ref: "Secret",
      },
    ],
  })
  secrets: Secret[];

  @Prop({ required: false, type: Boolean, default: false })
  apiKeySet: boolean;

  @Prop({ required: true, type: Boolean, default: true })
  sendEmailNotificationsToAdmins: boolean;

  @Prop({ required: false, type: Number, default: 0 })
  monthlyTokenUsage: number;

  @Prop({ required: false, type: Number, default: 0 })
  trainingCharacterUsage: number;

  @Prop({ required: false, type: Date })
  lastLimitEmailSentAt: Date | null;

  @Prop({ required: false, type: Number, default: 0 })
  customDomainUsage: number;

  @Prop({ required: false, type: Boolean, default: false })
  brandRemoval: boolean;

  @Prop({ required: false, type: Boolean, default: false })
  extraCharacters: boolean;

  @Prop({ required: false, type: Boolean, default: false })
  useLegacyPricing: boolean;

  @Prop({ required: false, default: false, type: Boolean })
  tcFixApplied: boolean;

  @Prop({ required: false, type: String, default: "" })
  organizationSize: string;

  @Prop({ required: false, type: Boolean, default: 0 })
  trainingCharacterExceeded: boolean;

  @Prop({ required: false, type: String, default: "2" })
  version: string;
}

export const OrganizationSchema = SchemaFactory.createForClass(Organization);
