import mongoose, { Model } from "mongoose";
import {
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { HttpService } from "@nestjs/axios";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { CreateOrganizationDto } from "./dto/create-organization.dto";
import { UpdateOrganizationDto } from "./dto/update-organization.dto";
import { AddAdminDto } from "./dto/add-admin.dto";
import {
  Organization,
  OrganizationDocument,
} from "./entities/organization.schema";
import { RemoveAdminDto } from "./dto/remove-admin.dto";
import { AddUserDto } from "./dto/add-user.dto";
import { RemoveUserDto } from "./dto/remove-user.dto";
import { RemoveOrganizationDto } from "./dto/remove-organization.dto";
import { BasicPlan, PlanType, Plans, ProPlan } from "./entities/plan";
import { User } from "../users/entities/user.schema";
import { HttpResponseWithMessage } from "../common/helpers/response";
import { BotsService } from "../bots/bots.service";
import { UsersService } from "../users/users.service";
import {
  Role,
  Invitation,
  InvitationDocument,
} from "../invitation/entities/invitation.schema";
import { randomHex } from "../auth/helpers/random-hex";
import { getMinDiff } from "../common/helpers/get-date-diff";
import { sendTemplateMail } from "../common/helpers/send-mail";
import { SubscriptionsService } from "../subscriptions/subscriptions.service";
import { encrypt, decrypt } from "../common/helpers/crypto";
import { SetWebhookDto } from "./dto/set-webhook.dto";
import { Secret, SecretDocument, SecretKey } from "./entities/secret.schema";
import { AddSecretDto } from "./dto/add-secret.dto";
import { Bot, BotDocument } from "../bots/entities/bot.schema";
import { RemoveSecretDto } from "./dto/remove-secret.dto";
import { ConfigService } from "@nestjs/config";
import { UpgradeTierDto } from "./dto/upgrade-tier.dto";
import {
  ProductKey,
  ProductKeyDocument,
} from "src/subscriptions/entities/product-key.schema";
import {
  Message,
  MessageDocument,
  MessageSender,
} from "src/bots/entities/message.schema";
import { ObjectId } from "bson";
import { Lead, LeadDocument } from "src/leads/entities/lead.schema";
import { firstValueFrom } from "rxjs";
import {
  Period,
  PeriodDocument,
} from "src/subscriptions/entities/period.schema";

@Injectable()
export class OrganizationsService {
  constructor(
    private configService: ConfigService,
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Invitation.name)
    private invitationModel: Model<InvitationDocument>,
    @InjectModel(Secret.name)
    private secretModel: Model<SecretDocument>,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
    @InjectModel(Message.name)
    private messageModel: Model<MessageDocument>,
    @InjectModel(Lead.name)
    private leadModel: Model<LeadDocument>,
    @InjectModel(Period.name)
    private periodModel: Model<PeriodDocument>,
    @InjectModel(ProductKey.name)
    private productKeyModel: Model<ProductKeyDocument>,
    @InjectConnection() private readonly connection: mongoose.Connection,
    private readonly botsService: BotsService,
    private readonly usersService: UsersService,
    private readonly httpService: HttpService,
    private readonly subscriptionsService: SubscriptionsService
  ) {}

  async getMessagesChartData(oid: string) {
    const bots = await this.botModel.find({
      organization: new ObjectId(oid),
    });

    const botIds = bots.map((bot) => bot._id);

    const chartData = await this.messageModel.aggregate([
      {
        $match: {
          bot: {
            $in: botIds,
          },
        },
      },
      {
        $project: {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
        },
      },
      {
        $group: {
          _id: { year: "$year", month: "$month" },
          count: { $sum: 1 },
        },
      },
      {
        $sort: { "_id.year": -1, "_id.month": -1 },
      },
      {
        $limit: 6,
      },
      {
        $project: {
          _id: 0,
          year: "$_id.year",
          month: "$_id.month",
          count: 1,
        },
      },
    ]);

    return chartData;
  }

  async getStats(oid: string) {
    const bots = await this.botModel.find({
      organization: new ObjectId(oid),
    });

    const botIds = bots.map((bot) => bot._id);

    const thisMonth = new Date();
    thisMonth.setDate(1);

    const aMonthLater = new Date();
    aMonthLater.setMonth(aMonthLater.getMonth() + 1);
    aMonthLater.setDate(1);

    const aMonthAgo = new Date();
    aMonthAgo.setMonth(aMonthAgo.getMonth() - 1);
    aMonthAgo.setDate(1);

    const answeredQuestions = await this.messageModel.countDocuments({
      createdAt: {
        $gte: thisMonth,
        $lt: aMonthLater,
      },
      bot: {
        $in: botIds,
      },
      sender: MessageSender.BOT,
    });

    const previousAnsweredQuestions = await this.messageModel.countDocuments({
      createdAt: {
        $gte: aMonthAgo,
        $lt: thisMonth,
      },
      bot: {
        $in: botIds,
      },
      sender: MessageSender.BOT,
    });

    const capturedLeads = await this.leadModel.countDocuments({
      createdAt: {
        $gte: thisMonth,
        $lt: aMonthLater,
      },
      bot: {
        $in: botIds,
      },
    });

    const previousCapturedLeads = await this.leadModel.countDocuments({
      createdAt: {
        $gte: aMonthAgo,
        $lt: thisMonth,
      },
      bot: {
        $in: botIds,
      },
    });

    const startedConversations = await this.messageModel.aggregate([
      {
        $match: {
          bot: {
            $in: botIds,
          },
          createdAt: {
            $gte: thisMonth,
            $lt: aMonthLater,
          },
        },
      },
      {
        $group: {
          _id: "$session",
        },
      },
      {
        $count: "total",
      },
    ]);

    const previousStartedConversations = await this.messageModel.aggregate([
      {
        $match: {
          bot: {
            $in: botIds,
          },
          createdAt: {
            $gte: aMonthAgo,
            $lt: thisMonth,
          },
        },
      },
      {
        $group: {
          _id: "$session",
        },
      },
      {
        $count: "total",
      },
    ]);

    const totalViewCount = await this.botModel.aggregate([
      {
        $match: {
          _id: {
            $in: botIds,
          },
        },
      },
      {
        $group: {
          _id: null,
          totalViewCount: {
            $sum: "$viewCount",
          },
        },
      },
    ]);

    if (!totalViewCount.length) {
      totalViewCount.push({ totalViewCount: 0, _id: null });
    }

    return {
      current: {
        answeredQuestions,
        capturedLeads,
        startedConversations: startedConversations.length,
        totalViewCount: totalViewCount[0].totalViewCount,
      },
      previous: {
        answeredQuestions: previousAnsweredQuestions,
        capturedLeads: previousCapturedLeads,
        startedConversations: previousStartedConversations.length,
      },
    };
  }

  async recentInteractions(oid: string) {
    const bots = await this.botModel.find({
      organization: new ObjectId(oid),
    });

    const botIds = bots.map((bot) => bot._id);

    const recentInteractions = await this.messageModel.aggregate([
      {
        $match: {
          bot: {
            $in: botIds,
          },
        },
      },
      {
        $group: {
          _id: "$session",
          messages: { $push: "$$ROOT" },
        },
      },
      {
        $addFields: {
          messagesCount: { $size: "$messages" },
          lastInteractionDate: {
            $last: "$messages.updatedAt",
          },
          location: {
            $first: "$messages.geo",
          },
          bot: {
            $first: "$messages.bot",
          },
        },
      },
      {
        $lookup: {
          from: "leads",
          let: { session_id: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $in: ["$$session_id", "$sid"],
                },
              },
            },
          ],
          as: "lead",
        },
      },
      {
        $sort: {
          "messages.updatedAt": -1,
        },
      },
      {
        $project: {
          _id: 1,
          messagesCount: 1,
          lead: 1,
          lastInteractionDate: 1,
          location: 1,
          bot: 1,
        },
      },
      {
        $limit: 5,
      },
    ]);

    return recentInteractions;
  }

  async create(
    createOrganizationDto: CreateOrganizationDto
  ): Promise<Organization> {
    // create organization
    const createdOrganization = new this.organizationModel(
      createOrganizationDto
    );

    // save
    const organization = await createdOrganization.save();

    // throw 500 if organization is not created
    if (!organization)
      throw new HttpException(
        "organizations.COULD_NOT_CREATE_ORGANIZATION",
        HttpStatus.INTERNAL_SERVER_ERROR
      );

    // create a period
    const period = await this.subscriptionsService.createPeriod(
      organization._id,
      PlanType.BASIC
    );

    // throw 500 if period is not created and remove create organization
    if (!period) {
      await this.organizationModel.remove({ _id: organization._id });
      throw new HttpException(
        "organizations.COULD_NOT_CREATE_PERIOD",
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }

    // link period to organization
    organization.activePeriod = period;

    if (createOrganizationDto.migration) {
      // find all the organizations that user is in admins array
      const organizations = await this.organizationModel.find({
        admins: { $in: [createOrganizationDto.admins[0]._id] },
      });

      // remove the organizations with the name 'My organization' and the one user is admin of
      organizations.forEach(async (organization) => {
        if (organization.name === 'My organization') {
          await organization.remove();
        }
      });

      const organization = await this.organizationModel.findOne({
        admins: { $in: [createOrganizationDto.admins[0]._id] },
      });

      await this.botsService.assign_bot_to_user(createOrganizationDto.bot, organization.admins[0]._id.toString());
    }

    return await organization.save();
  }

  async findAll(condition: { [key: string]: any }): Promise<Organization[]> {
    const organizations = await this.organizationModel
      .find({ $and: [condition, { isRemoved: { $ne: true } }] })
      .exec();

    for (var organization of organizations) {
      const period = await this.periodModel.findOne({
        _id: organization.activePeriod,
      });

      organization.activePeriod = period;
    }

    return organizations;
  }

  async findOne(condition: { [key: string]: any }): Promise<Organization> {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .select(
        "name trainingCharacterUsage domain admins users plan createdAt sendEmailNotificationsToAdmins apiKeySet subscriptionCancelled subscriptionEndAt failedPaymentTry monthlyTokenUsage"
      )
      .exec();

    if (!organization) throw new NotFoundException("organizations.NOT_FOUND");

    return organization;
  }

  async update(
    condition: { [key: string]: any },
    organizationDto: UpdateOrganizationDto
  ): Promise<Organization> {
    return this.organizationModel.findByIdAndUpdate(
      condition,
      organizationDto,
      {
        new: true,
      }
    );
  }

  async setWebhook(
    condition: { [key: string]: any },
    setWebhook: SetWebhookDto
  ): Promise<Organization> {
    return this.organizationModel.findByIdAndUpdate(condition, setWebhook, {
      new: true,
    });
  }

  async sendInvitation(role: Role, email: string, organization: string) {
    try {
      // check if user is already has invitation
      const invitationCheck = await this.invitationModel
        .findOne({
          $and: [{ email: email }, { organization: organization }],
        })
        .exec();

      if (invitationCheck && email.indexOf("mevo_test") === -1) {
        // @ts-ignore
        if (getMinDiff(invitationCheck.createdAt) < 5) {
          throw new HttpException(
            "organizations.YOU_NEED_TO_WAIT_5_MINUTES_TO_SEND_ANOTHER_INVITATION",
            400
          );
        }
      }

      const code = randomHex(16);
      const organizationDoc = await this.organizationModel
        .findById(organization)
        .exec();

      const session = await this.connection.startSession();

      const transaction = await session.withTransaction(async () => {
        // remove old invitations
        await this.invitationModel
          .remove({
            $and: [{ email: email }, { organization: organization }],
          })
          .session(session)
          .exec();

        // create new invitation
        const invitation = new this.invitationModel({
          code,
          role,
          email,
          organization,
        });

        await invitation.save({ session });
      });

      session.endSession();

      if (transaction.ok === 1) {
        sendTemplateMail("invitation", email, {
          code,
          role,
          email,
          organization: organizationDoc.name,
        });
        return HttpResponseWithMessage("invitation-sent", 200);
      } else {
        return HttpResponseWithMessage(
          "common.TRANSACTION_FAILED",
          HttpStatus.INTERNAL_SERVER_ERROR
        );
      }
    } catch (err) {
      throw new HttpException(err, 400);
    }
  }

  async upgradeTier(payload: { keys: string[]; organization: string }) {
    let isDealify = false;

    if (payload.keys.length > 3) {
      throw new HttpException(
        "organizations.MAXIMUM_3_KEYS_ALLOWED",
        HttpStatus.BAD_REQUEST
      );
    }

    const organization: Organization = await this.organizationModel
      .findById(payload.organization)
      .exec();

    const allowedTiers = [
      PlanType.BASIC,
      PlanType.LTD_NEW_TIER1,
      PlanType.LTD_NEW_TIER2,
    ];

    if (!allowedTiers.includes(organization.plan)) {
      throw new HttpException(
        "organizations.INVALID_PLAN_FOR_UPGRADE",
        HttpStatus.BAD_REQUEST
      );
    }

    const validKeys = await this.productKeyModel
      .find({
        key: { $in: payload.keys },
        isUsed: { $ne: true },
      })
      .exec();

    if (validKeys.length !== payload.keys.length) {
      throw new HttpException(
        "organizations.INVALID_PRODUCT_KEY",
        HttpStatus.BAD_REQUEST
      );
    }

    if (validKeys[0].vendor === "dealify") {
      isDealify = true;
    }

    const tiersArr = [
      PlanType.BASIC,
      PlanType.LTD_NEW_TIER1,
      PlanType.LTD_NEW_TIER2,
      PlanType.LTD_NEW_TIER3,
      PlanType.DEALIFY,
    ];

    let targetTierIndex =
      tiersArr.indexOf(organization.plan) + validKeys.length;

    if (targetTierIndex > 3) {
      targetTierIndex = 3;
    }

    if (isDealify) {
      targetTierIndex = 4;
    }

    const session = await this.connection.startSession();

    const transaction = await session.withTransaction(async () => {
      await this.organizationModel
        .findByIdAndUpdate(
          { _id: organization._id },
          { plan: tiersArr[targetTierIndex], useLegacyPricing: true }
        )
        .session(session)
        .exec();

      await this.productKeyModel
        .updateMany(
          {
            key: { $in: payload.keys },
          },
          {
            isUsed: true,
            usedBy: organization.admins[0]._id,
            for: organization._id,
          }
        )
        .session(session)
        .exec();
    });

    try {
      const { data } = await firstValueFrom(
        this.httpService.post(
          "https://api.telegram.org/bot7829408371:AAFs4wqDl7annRiY9D5oGpiRN6Hs3UkLKO4/sendMessage",
          {
            chat_id: 406038897,
            text: `🤑 Product Key Used
    
🧑🏼‍🦰 ${organization.admins[0].name} - ${organization.admins[0].email}
🎯 ${payload.keys.length} keys used
🧩 Customer from ${validKeys[0].vendor}
`,
          },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        )
      );
    } catch (err) {}

    session.endSession();

    if (transaction.ok === 1) {
      return HttpResponseWithMessage("organizations.UPGRADE_SUCCEED", 200);
    } else {
      return HttpResponseWithMessage(
        "organizations.PLEASE_CONTACT_SUPPORT",
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  async addAdmin(condition: { [key: string]: any }, addAdminDto: AddAdminDto) {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .exec();

    const isUserLimitReached =
      organization.admins.length + organization.users.length >=
        Plans[organization.plan].limits.users &&
      addAdminDto.email.indexOf("mevo_test") === -1;

    if (isUserLimitReached) {
      throw new HttpException(
        "organizations.USER_LIMIT_REACHED_FOR_THIS_PLAN",
        HttpStatus.BAD_REQUEST
      );
    }

    const isAlreadyAdmin = organization.admins.find(
      (admin) => admin.email === addAdminDto.email
    );

    if (isAlreadyAdmin) {
      throw new HttpException(
        "organizations.USER_ALREADY_ADMIN_IN_THIS_ORGANIZATION",
        HttpStatus.BAD_REQUEST
      );
    }

    // remove this user from users array if exist
    // bcz it'll be pushed into admins array
    organization.users = organization.users.filter((user) => {
      return user.email !== addAdminDto.email;
    });

    // save
    await organization.save();

    const invitationResult = await this.sendInvitation(
      Role.ADMIN,
      addAdminDto.email,
      organization._id
    );
    return invitationResult;
  }

  async removeAdmin(
    condition: { [key: string]: any },
    removeAdminDto: RemoveAdminDto
  ): Promise<boolean> {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .exec();

    const user: User = await this.usersService.findOne({
      email: removeAdminDto.email,
    });

    if (!user) {
      throw new HttpException("users.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    const isUserOnlyAdminInOrganization = organization.admins.length === 1;

    if (isUserOnlyAdminInOrganization) {
      throw new HttpException(
        "organizations.ADD_ANOTHER_ADMIN_BEFORE_REMOVING_YOURSELF",
        HttpStatus.BAD_REQUEST
      );
    }

    organization.admins = organization.admins.filter(
      (admins) => admins.email !== removeAdminDto.email
    );
    await organization.save();

    return true;
  }

  async addUser(condition: { [key: string]: any }, addUserDto: AddUserDto) {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .exec();

    const isUserLimitReached =
      organization.admins.length + organization.users.length >=
        Plans[organization.plan].limits.users &&
      addUserDto.email.indexOf("mevo_test") === -1;

    if (isUserLimitReached) {
      throw new HttpException(
        "organizations.USER_LIMIT_REACHED_FOR_THIS_PLAN",
        HttpStatus.BAD_REQUEST
      );
    }

    const isUserAlreadyExistInOrganization = organization.users.find(
      (user) => user.email === addUserDto.email
    );

    if (isUserAlreadyExistInOrganization) {
      throw new HttpException(
        "organizations.USER_ALREADY_ADMIN_IN_THIS_ORGANIZATION",
        HttpStatus.BAD_REQUEST
      );
    }

    // remove this user from users array if exist
    // bcz it'll be pushed into admins array
    organization.admins = organization.admins.filter((user) => {
      return user.email !== addUserDto.email;
    });

    // save
    await organization.save();

    const invitationResult = await this.sendInvitation(
      Role.USER,
      addUserDto.email,
      organization._id
    );
    return invitationResult;
  }

  async addSecret(
    condition: { [key: string]: any },
    addSecretDto: AddSecretDto
  ) {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .populate("secrets")
      .exec();

    if (addSecretDto.key === SecretKey.OPEN_AI_KEY) {
      if (Plans[organization.plan].limits.customApiKey === 0) {
        throw new HttpException(
          "organizations.OPEN_AI_KEY_NOT_ALLOWED_FOR_BASIC_PLAN",
          HttpStatus.BAD_REQUEST
        );
      }

      if (organization.apiKeySet) {
        const existingKey = organization.secrets.find(
          (secret) => secret.key === SecretKey.OPEN_AI_KEY
        );

        if (existingKey) {
          await this.secretModel.remove({
            _id: existingKey._id,
          });
          organization.secrets = organization.secrets.filter(
            (secret) => secret._id !== existingKey._id
          );
        }
      }

      organization.apiKeySet = true;
    }

    const newSecret = new this.secretModel({
      key: addSecretDto.key,
      value: encrypt(
        addSecretDto.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      ),
    });
    const savedSecret = await newSecret.save();

    organization.secrets.push(savedSecret);
    await organization.save();

    return true;
  }

  async encryptSecrets() {
    const secrets = await this.secretModel.find({}).exec();

    for (const secret of secrets) {
      secret.value = encrypt(
        secret.value,
        this.configService.get<string>("MEVO_SECRET_KEY")
      );
      await secret.save();
    }

    return true;
  }

  async removeSecret(
    condition: { [key: string]: any },
    removeSecretDto: RemoveSecretDto
  ) {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .populate("secrets")
      .exec();

    const currentSecret = organization.secrets.find(
      (secret) => secret.key === removeSecretDto.key
    );

    if (currentSecret) {
      await this.secretModel.remove({
        _id: currentSecret._id,
      });

      if (currentSecret.key === SecretKey.OPEN_AI_KEY) {
        organization.apiKeySet = false;
      }

      organization.secrets = organization.secrets.filter(
        (secret) => secret.key !== removeSecretDto.key
      );

      await organization.save();

      return true;
    } else {
      return false;
    }
  }

  async removeUser(
    condition: { [key: string]: any },
    removeUserDto: RemoveUserDto
  ): Promise<boolean> {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .exec();

    const user: User = await this.usersService.findOne({
      email: removeUserDto.email,
    });

    if (!user) {
      throw new HttpException("users.NOT_FOUND", HttpStatus.NOT_FOUND);
    }

    organization.users = organization.users.filter(
      (users) => users.email !== removeUserDto.email
    );
    await organization.save();

    return true;
  }

  async remove(
    condition: { [key: string]: any },
    removeOrganizationDto: RemoveOrganizationDto
  ) {
    const session = await this.connection.startSession();

    const transaction = await session.withTransaction(async () => {
      const organization = await this.organizationModel
        .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
        .exec();

      if (organization.name !== removeOrganizationDto.name) {
        throw new HttpException(
          "organizations.INCORRECT_ORGANIZATION_NAME",
          HttpStatus.BAD_REQUEST
        );
      }

      if (organization.plan === PlanType.PRO) {
        throw new HttpException(
          "organizations.SUBSCRIPTION_EXISTS",
          HttpStatus.BAD_REQUEST
        );
      }

      const bots = await this.botsService.findAll({
        organization: organization._id,
      });

      for (const bot of bots) {
        await this.botsService.remove_bot(bot._id);
      }

      await this.organizationModel
        .findByIdAndUpdate(condition, { isRemoved: true })
        .session(session)
        .exec();

      await this.botsService.removeMany(
        { organization: condition._id },
        session
      );
    });

    session.endSession();

    if (transaction.ok === 1) {
      return HttpResponseWithMessage("removed", 200);
    } else {
      return HttpResponseWithMessage(
        "common.TRANSACTION_FAILED",
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }
}
