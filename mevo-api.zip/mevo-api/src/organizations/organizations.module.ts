import { Module, forwardRef } from "@nestjs/common";
import { OrganizationsService } from "./organizations.service";
import { OrganizationsController } from "./organizations.controller";
import { MongooseModule } from "@nestjs/mongoose";
import { ConfigModule } from "@nestjs/config";
import {
  Organization,
  OrganizationSchema,
} from "./entities/organization.schema";
import { User, UserSchema } from "../users/entities/user.schema";
import {
  Invitation,
  InvitationSchema,
} from "../invitation/entities/invitation.schema";
import { Bot, BotSchema } from "../bots/entities/bot.schema";
import { BotsModule } from "../bots/bots.module";
import { UsersModule } from "../users/users.module";
import { SubscriptionsModule } from "../subscriptions/subscriptions.module";
import { Period, PeriodSchema } from "../subscriptions/entities/period.schema";
import { Secret, SecretSchema } from "./entities/secret.schema";
import {
  ProductKey,
  ProductKeySchema,
} from "src/subscriptions/entities/product-key.schema";
import { Message, MessageSchema } from "src/bots/entities/message.schema";
import { Lead, LeadSchema } from "src/leads/entities/lead.schema";
import { HttpModule } from "@nestjs/axios";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Invitation.name, schema: InvitationSchema },
      { name: Organization.name, schema: OrganizationSchema },
      { name: User.name, schema: UserSchema },
      { name: Bot.name, schema: BotSchema },
      { name: Period.name, schema: PeriodSchema },
      { name: Secret.name, schema: SecretSchema },
      { name: ProductKey.name, schema: ProductKeySchema },
      { name: Message.name, schema: MessageSchema },
      { name: Lead.name, schema: LeadSchema },
    ]),
    forwardRef(() => UsersModule),
    forwardRef(() => SubscriptionsModule),
    forwardRef(() => BotsModule),
    ConfigModule,
    HttpModule,
  ],
  controllers: [OrganizationsController],
  providers: [OrganizationsService],
  exports: [OrganizationsService],
})
export class OrganizationsModule {}
