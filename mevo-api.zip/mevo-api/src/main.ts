import * as cookieParser from "cookie-parser";
import { NestExpressApplication } from "@nestjs/platform-express"
import { NestFactory } from "@nestjs/core";
import { ValidationPipe } from "@nestjs/common";
import { AppModule } from "./app.module";
import { prepareSwagger } from "./common/helpers/swagger";

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    cors: true,
    rawBody: true,
  });
  app.use(cookieParser());
  app.useGlobalPipes(new ValidationPipe());
  app.set("trust proxy", 1);
  prepareSwagger(app);
  await app.listen(process.env.PORT);
}

bootstrap();
