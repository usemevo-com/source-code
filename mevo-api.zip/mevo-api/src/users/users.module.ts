import { Module, forwardRef } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { HttpModule } from "@nestjs/axios";
import { UsersService } from "./users.service";
import { UsersController } from "./users.controller";
import { User, UserSchema } from "./entities/user.schema";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { SubscriptionsModule } from "../subscriptions/subscriptions.module";
import { ConfigModule } from "@nestjs/config";
import { OrganizationsModule } from "src/organizations/organizations.module";
// Bot related imports for GDPR deletion
import { Bot, BotSchema } from "../bots/entities/bot.schema";
import { Message, MessageSchema } from "../bots/entities/message.schema";
import { Lead, LeadSchema } from "../leads/entities/lead.schema";
import { UserResponse, UserResponseSchema } from "../user-responses/entities/user-response.schema";
import { Link, LinkSchema } from "../bots/entities/link.schema";
import { Text, TextSchema } from "../bots/entities/text.schema";
import { File, FileSchema } from "../bots/entities/file.schema";
import { Question, QuestionSchema } from "../bots/entities/question.schema";
import { Product, ProductSchema } from "../bots/entities/product.schema";
import { Embedding, EmbeddingSchema } from "../bots/entities/embedding.schema";
import { Thread, ThreadSchema } from "../bots/entities/thread.schema";
import { Session, SessionSchema } from "../bots/entities/session.schema";
import { NotificationReceiver, NotificationReceiverSchema } from "../bots/entities/notification-receiver.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Organization.name, schema: OrganizationSchema },
      // Bot related models for GDPR deletion
      { name: Bot.name, schema: BotSchema },
      { name: Message.name, schema: MessageSchema },
      { name: Lead.name, schema: LeadSchema },
      { name: UserResponse.name, schema: UserResponseSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Text.name, schema: TextSchema },
      { name: File.name, schema: FileSchema },
      { name: Question.name, schema: QuestionSchema },
      { name: Product.name, schema: ProductSchema },
      { name: Embedding.name, schema: EmbeddingSchema },
      { name: Thread.name, schema: ThreadSchema },
      { name: Session.name, schema: SessionSchema },
      { name: NotificationReceiver.name, schema: NotificationReceiverSchema },
    ]),
    forwardRef(() => SubscriptionsModule),
    forwardRef(() => OrganizationsModule),
    HttpModule,
    ConfigModule,
  ],
  controllers: [UsersController],
  providers: [UsersService],
  exports: [UsersService],
})
export class UsersModule {}
