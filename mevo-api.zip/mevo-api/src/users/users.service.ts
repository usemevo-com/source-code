import mongoose, { Model } from "mongoose";
import * as bcrypt from "bcrypt";
import { catchError, firstValueFrom } from "rxjs";
import { AxiosError } from "axios";
import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
} from "@nestjs/common";
import { HttpService } from "@nestjs/axios";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { CreateUserDto } from "./dto/create-user.dto";
import { User, UserDocument } from "./entities/user.schema";
import { ForgotPasswordDto } from "./dto/forgot-password.dto";
import { randomHex } from "../auth/helpers/random-hex";
import { ResetPasswordDto } from "./dto/reset-password.dto";
import { emailWhitelist, sendTemplateMail } from "../common/helpers/send-mail";
import {
  Organization,
  OrganizationDocument,
} from "../organizations/entities/organization.schema";
import { Plans, PlanType } from "../organizations/entities/plan";
import { SubscriptionsService } from "../subscriptions/subscriptions.service";
import { ConfigService } from "@nestjs/config";
import { AddListenerDto } from "src/organizations/dto/add-listener.dto";
import { HttpResponseWithMessage } from "../common/helpers/response";
// Bot related imports
import { Bot, BotDocument } from "../bots/entities/bot.schema";
import { Message, MessageDocument } from "../bots/entities/message.schema";
import { Lead, LeadDocument } from "../leads/entities/lead.schema";
import { UserResponse, UserResponseDocument } from "../user-responses/entities/user-response.schema";
import { Link, LinkDocument } from "../bots/entities/link.schema";
import { Text, TextDocument } from "../bots/entities/text.schema";
import { File, FileDocument } from "../bots/entities/file.schema";
import { Question, QuestionDocument } from "../bots/entities/question.schema";
import { Product, ProductDocument } from "../bots/entities/product.schema";
import { Embedding, EmbeddingDocument } from "../bots/entities/embedding.schema";
import { Thread, ThreadDocument } from "../bots/entities/thread.schema";
import { Session, SessionDocument } from "../bots/entities/session.schema";
import { NotificationReceiver, NotificationReceiverDocument } from "../bots/entities/notification-receiver.schema";

@Injectable()
export class UsersService {
  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Bot.name) private botModel: Model<BotDocument>,
    @InjectModel(Message.name) private messageModel: Model<MessageDocument>,
    @InjectModel(Lead.name) private leadModel: Model<LeadDocument>,
    @InjectModel(UserResponse.name) private userResponseModel: Model<UserResponseDocument>,
    @InjectModel(Link.name) private linkModel: Model<LinkDocument>,
    @InjectModel(Text.name) private textModel: Model<TextDocument>,
    @InjectModel(File.name) private fileModel: Model<FileDocument>,
    @InjectModel(Question.name) private questionModel: Model<QuestionDocument>,
    @InjectModel(Product.name) private productModel: Model<ProductDocument>,
    @InjectModel(Embedding.name) private embeddingModel: Model<EmbeddingDocument>,
    @InjectModel(Thread.name) private threadModel: Model<ThreadDocument>,
    @InjectModel(Session.name) private sessionModel: Model<SessionDocument>,
    @InjectModel(NotificationReceiver.name) private notificationReceiverModel: Model<NotificationReceiverDocument>,
    private readonly subscriptionsService: SubscriptionsService,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

  async addListener(
    condition: { [key: string]: any },
    addListenerDto: AddListenerDto
  ) {
    const organization = await this.organizationModel
      .findOne({ $and: [condition, { isRemoved: { $ne: true } }] })
      .exec();

    const isUserLimitReached =
      organization.admins.length +
        organization.users.length +
        organization.listeners?.length >=
      Plans[organization.plan].limits.users;

    if (isUserLimitReached) {
      throw new HttpException(
        "organizations.USER_LIMIT_REACHED_FOR_THIS_PLAN",
        HttpStatus.BAD_REQUEST
      );
    }

    const isUserAlreadyExistInOrganization = organization.users.find(
      (user) => user.email === addListenerDto.email
    );

    const isAdminAlreadyExistInOrganization = organization.admins.find(
      (admin) => admin.email === addListenerDto.email
    );

    const isListenerAlreadyExistInOrganization =
      organization.listeners &&
      organization.listeners.find(
        (listener) => listener.email === addListenerDto.email
      );

    if (
      isUserAlreadyExistInOrganization ||
      isAdminAlreadyExistInOrganization ||
      isListenerAlreadyExistInOrganization
    ) {
      throw new HttpException(
        "organizations.USER_ALREADY_EXIST_IN_THIS_ORGANIZATION",
        HttpStatus.BAD_REQUEST
      );
    }

    const notificationConsentKey = bcrypt.hashSync(addListenerDto.email, 10);
    const listener = new this.userModel({
      name: "notification listener",
      email: addListenerDto.email,
      notificationConsentKey,
      isActive: false,
      listenerOf: organization._id,
    });

    await listener.save();

    sendTemplateMail("listener-invitation", addListenerDto.email, {
      consentKey: notificationConsentKey,
      oid: organization._id,
    });

    return true;
  }

  async removeListener(
    condition: { [key: string]: any },
    removeListenerDto: AddListenerDto
  ) {
    const listener = await this.userModel
      .findOne({ email: removeListenerDto.email, listenerOf: condition._id })
      .exec();

    if (!listener) {
      throw new HttpException(
        "organizations.USER_NOT_FOUND_IN_THIS_ORGANIZATION",
        HttpStatus.BAD_REQUEST
      );
    }

    const organization = await this.organizationModel
      .findOne({ _id: condition._id })
      .exec();

    organization.listeners = organization.listeners.filter(
      (l) => l.email !== removeListenerDto.email
    );

    await organization.save();
    await listener.remove();

    return true;
  }

  async giveListenerConsent(
    notificationConsentKey: string,
    organizationId: string
  ) {
    const listener = await this.userModel
      .findOne({
        $and: [{ notificationConsentKey }, { isActive: { $ne: true } }],
      })
      .exec();

    if (!listener) {
      return "Invalid consent key. Communicate with the organization admin.";
    }

    listener.isActive = true;
    await listener.save();

    const organization = await this.organizationModel
      .findOne({ _id: organizationId })
      .exec();

    if (!organization) {
      return "Organization information is wrong. Communicate with the organization admin.";
    }

    organization.listeners.push(listener);
    await organization.save();

    return true;
  }

  async create(createUserDto: CreateUserDto): Promise<User> {
    const isEmailAlreadyUsed = await this.userModel
      .findOne({ email: createUserDto.email })
      .exec();

    if (isEmailAlreadyUsed) {
      throw new HttpException(
        "prelogin.USER_ALREADY_EXISTS",
        HttpStatus.BAD_REQUEST
      );
    }

    const session = await this.connection.startSession();

    const transaction = await session.withTransaction(async () => {
      const user = new this.userModel({ ...createUserDto });
      const createdUser = await user.save({ session });
      createdUser.password = undefined;

      try {
        if (createdUser.email.indexOf("mevo_test") === -1) {
          if (createUserDto.appSumoKey) {
            await this.addUserToSendinblue(createdUser, 9);
          } else {
            await this.addUserToSendinblue(createdUser);
          }
        }

        const name =
          createUserDto.name.split(" ").length > 1
            ? createUserDto.name.split(" ")[0]
            : createUserDto.name;

        sendTemplateMail("register", createUserDto.email, {
          name,
        });
      } catch (err) {
        console.log("user could not added to sendinblue", err);
      }

      try {
        const { data } = await firstValueFrom(
          this.httpService.post(
            "https://api.telegram.org/bot7829408371:AAFs4wqDl7annRiY9D5oGpiRN6Hs3UkLKO4/sendMessage",
            {
              chat_id: 406038897,
              text: `🧑🏼‍🦰 User created
      
🏢 ${createdUser.name}
✉️ ${createdUser.email}
      `,
            },
            {
              headers: {
                "Content-Type": "application/json",
              },
            }
          )
        );
      } catch (err) {}

      const organization = new this.organizationModel({
        name: "My organization",
        admins: [createdUser],
        plan: createUserDto.appSumoKey
          ? PlanType.LTD_NEW_TIER1
          : PlanType.BASIC,
      });

      try {
        const savedOrganization = await organization.save({ session });
        const period = await this.subscriptionsService.createPeriod(
          organization._id,
          createUserDto.appSumoKey ? PlanType.LTD_NEW_TIER1 : PlanType.BASIC,
          session
        );
        savedOrganization.activePeriod = period;
        await savedOrganization.save({ session });
      } catch (err) {
        console.log("organization could not saved", err);
      }
    });

    session.endSession();

    if (transaction.ok === 1) {
      const user = await this.userModel
        .findOne({ email: createUserDto.email })
        .exec();

      return user;
    } else {
      console.log(transaction);
      throw new HttpException(
        "common.TRANSACTION_FAILED",
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async findAll(condition: { [key: string]: any }): Promise<User[]> {
    return this.userModel.find(condition).exec();
  }

  findOne(condition: { [key: string]: any }) {
    return this.userModel.findOne(condition).exec();
  }

  async forgotPassword(forgotPasswordDto: ForgotPasswordDto) {
    function escapeRegExp(string: string) {
      return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    const escapedEmail = escapeRegExp(forgotPasswordDto.email);
    
    const user = await this.userModel.findOne({
      email: new RegExp(`^${escapedEmail}$`, 'i'),
    });

    if (!user) {
      return { message: "prelogin.EMAIL_SENT_IF_USER_EXIST" };
    }

    if (
      user.lastPasswordReset &&
      Date.now() - user.lastPasswordReset.getTime() < 60000
    ) {
      return { message: "prelogin.WAIT_10_MINUTES" };
    }

    const key = randomHex(16);
    await this.userModel.findOneAndUpdate(
      {
        _id: user._id,
      },
      { passwordResetKey: key, lastPasswordReset: new Date() }
    );

    if (emailWhitelist.indexOf(forgotPasswordDto.email) === -1) {
      const zeroBounceKey = this.configService.get<string>("ZERO_BOUNCE_KEY");

      const { data } = await firstValueFrom(
        this.httpService
          .get(
            `https://api.zerobounce.net/v2/validate?api_key=${zeroBounceKey}&email=${forgotPasswordDto.email}`
          )
          .pipe(
            catchError((error: AxiosError) => {
              throw new HttpException(
                "prelogin.WE_COULD_NOT_VERIFY_YOUR_EMAIL",
                HttpStatus.BAD_REQUEST
              );
            })
          )
      );

      if (data.status !== "valid") {
        return { message: "prelogin.EMAIL_SENT_IF_USER_EXIST" };
      }
    }

    sendTemplateMail("forgotten-password", forgotPasswordDto.email, {
      key,
      email: forgotPasswordDto.email,
    });

    return { message: "prelogin.EMAIL_SENT_IF_USER_EXIST" };
  }

  async resetPassword(resetPasswordDto: ResetPasswordDto) {
    const user = await this.userModel.findOne({
      $and: [
        { passwordResetKey: resetPasswordDto.key },
        { email: resetPasswordDto.email },
      ],
    });

    if (!user) {
      throw new BadRequestException("prelogin.INVALID_RESET_KEY");
    }

    const hashedPassword = await bcrypt.hash(resetPasswordDto.password, 10);

    await this.userModel.findOneAndUpdate(
      {
        _id: user._id,
      },
      { passwordResetKey: "", password: hashedPassword }
    );

    return { message: "prelogin.PASSWORD_RESET_SUCCESSFUL" };
  }

  async createWithGoogle(userData: {
    id?: string;
    email?: string;
    name?: string;
    picture?: string;
    locale?: string;
  }) {
    const session = await this.connection.startSession();

    const transaction = await session.withTransaction(async () => {
      const newUser = await this.userModel.create({
        email: userData.email.toLowerCase(),
        name: userData.name,
        picture: userData.picture,
        locale: userData.locale,
        isRegisteredWithGoogle: true,
      });

      const createdUser = await newUser.save();
      try {
        await this.addUserToSendinblue(createdUser);

        const name =
          userData.name.split(" ").length > 1
            ? userData.name.split(" ")[0]
            : userData.name;

        sendTemplateMail("register", userData.email, {
          name,
        });
      } catch (err) {
        console.log("user could not added to sendinblue");
      }

      try {
        const { data } = await firstValueFrom(
          this.httpService.post(
            "https://api.telegram.org/bot7829408371:AAFs4wqDl7annRiY9D5oGpiRN6Hs3UkLKO4/sendMessage",
            {
              chat_id: 406038897,
              text: `🧑🏼‍🦰 User created
      
🏢 ${createdUser.name}
✉️ ${createdUser.email}
      `,
            },
            {
              headers: {
                "Content-Type": "application/json",
              },
            }
          )
        );
      } catch (err) {}

      const organization = new this.organizationModel({
        name: "My organization",
        admins: [createdUser],
      });
      const savedOrganization = await organization.save({ session });
      const period = await this.subscriptionsService.createPeriod(
        organization._id,
        PlanType.BASIC,
        session
      );
      savedOrganization.activePeriod = period;
      await savedOrganization.save({ session });
    });

    session.endSession();

    if (transaction.ok === 1) {
      const user = await this.userModel
        .findOne({ email: userData.email })
        .exec();

      return user;
    } else {
      throw new HttpException(
        "common.TRANSACTION_FAILED",
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async addUserToSendinblue(user: User, listId: number = 8) {
    const value = await firstValueFrom(
      this.httpService
        .post(
          "https://api.sendinblue.com/v3/contacts",
          {
            listIds: [13],
            email: user.email,
          },
          {
            headers: {
              "Content-Type": "application/json",
              "api-key": `${process.env.MAIL_SENDINBLUE_API_KEY}`,
            },
          }
        )
        .pipe(
          catchError((error: AxiosError) => {
            console.log(error, "error");
            throw "An error happened while adding user to sendinblue";
          })
        )
    );
  }

  /**
   * GDPR Compliant: Delete all user data permanently
   * This includes:
   * - All bots and their complete data (messages, leads, training data)
   * - Organizations where user is admin
   * - Removing user from organizations where they are member/listener
   * - User account anonymization
   */
  async deleteAccount(userId: string, confirmationEmail: string) {
    const session = await this.connection.startSession();
    
    try {
      await session.withTransaction(async () => {
        // Find the user
        const user = await this.userModel.findById(userId).session(session).exec();
        
        if (!user) {
          throw new HttpException("User not found", HttpStatus.NOT_FOUND);
        }

        // Confirmation check
        if (user.email !== confirmationEmail) {
          throw new HttpException(
            "Email confirmation does not match",
            HttpStatus.BAD_REQUEST
          );
        }

        // 1. Find organizations where user is admin
        const adminOrganizations = await this.organizationModel
          .find({
            admins: userId,
            isRemoved: { $ne: true }
          })
          .session(session)
          .exec();

        // 2. Check if any organization has a paid plan (non-basic)
        const hasPaidPlan = adminOrganizations.some(org => org.plan !== PlanType.BASIC);
        
        if (hasPaidPlan) {
          throw new HttpException(
            "You have active paid subscriptions. Please contact hi@usemevo.com to delete your account and data.",
            HttpStatus.FORBIDDEN
          );
        }

        const organizationIds = adminOrganizations.map(org => org._id);

        if (organizationIds.length > 0) {
          // 3. Find all bots belonging to these organizations
          const bots = await this.botModel
            .find({ organization: { $in: organizationIds } })
            .session(session)
            .exec();

          const botIds = bots.map(bot => bot._id);

          if (botIds.length > 0) {
            // 4. Delete all bot-related data (GDPR physical deletion)
            console.log(`Deleting data for ${botIds.length} bots...`);

            // Delete training data
            await Promise.all([
              this.linkModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.textModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.fileModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.questionModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.productModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
            ]);

            // Delete conversations and user data
            await Promise.all([
              this.messageModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.leadModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.userResponseModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.threadModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.sessionModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
              this.notificationReceiverModel.deleteMany({ bot: { $in: botIds } }).session(session).exec(),
            ]);

            // 5. Delete the bots themselves
            await this.botModel.deleteMany({ _id: { $in: botIds } }).session(session).exec();
            
            console.log(`Successfully deleted all data for ${botIds.length} bots`);
          }

          // 6. Delete organizations where user is admin
          await this.organizationModel
            .deleteMany({ _id: { $in: organizationIds } })
            .session(session)
            .exec();
        }

        // 7. Remove user from organizations where they are member
        await this.organizationModel
          .updateMany(
            { users: userId },
            { $pull: { users: userId } },
            { session }
          )
          .exec();

        // 8. Remove user from organizations where they are listener
        await this.organizationModel
          .updateMany(
            { listeners: userId },
            { $pull: { listeners: userId } },
            { session }
          )
          .exec();

        // 9. Delete any leads/responses where user might be referenced
        await this.leadModel.deleteMany({ organization: { $in: organizationIds } }).session(session).exec();

        // 10. Anonymize user account data (GDPR compliant)
        await this.userModel
          .findByIdAndUpdate(
            userId,
            { 
              isRemoved: true,
              email: `deleted_${Date.now()}@deleted.local`,
              name: 'Deleted User',
              password: null,
              passwordResetKey: null,
              notificationConsentKey: null,
              picture: null,
              locale: null,
              role: null
            },
            { session }
          )
          .exec();

        console.log(`GDPR deletion completed for user ${userId}`);
      });

      return HttpResponseWithMessage("Account and all associated data deleted successfully", 200);
    } catch (error) {
      console.error('GDPR deletion error:', error);
      throw error;
    } finally {
      await session.endSession();
    }
  }

  async updateUserRole(user: User, role: string) {
    const updatedUser = await this.userModel
      .findOneAndUpdate(
        { _id: user._id },
        { role },
        { new: true }
      )
      .exec();

    if (!updatedUser) {
      throw new HttpException(
        "User not found",
        HttpStatus.NOT_FOUND
      );
    }

    return updatedUser;
  }
}
