import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty } from 'class-validator';

export class ResetPasswordDto {
  @IsNotEmpty()
  @IsEmail()
  @ApiProperty({ type: 'string' })
  email: string;

  @IsNotEmpty()
  @ApiProperty({ type: 'string' })
  key: string;

  @IsNotEmpty()
  @ApiProperty({ type: 'string' })
  password: string;
}
