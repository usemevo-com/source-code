import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsOptional } from "class-validator";

export class CreateUserDto {
  @IsNotEmpty()
  @IsEmail()
  @ApiProperty({ type: "string" })
  email: string;

  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  name: string;

  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  password: string;

  @IsOptional()
  @ApiProperty({ type: "string" })
  appSumoKey: string;

  @IsOptional()
  @ApiProperty({ type: "string" })
  bot: string;
}
