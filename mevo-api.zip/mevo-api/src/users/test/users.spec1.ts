import * as request from "supertest";
import * as bcrypt from "bcrypt";
import { Test } from "@nestjs/testing";
import { INestApplication, ValidationPipe } from "@nestjs/common";
import { Model } from "mongoose";
import { getModelToken } from "@nestjs/mongoose";
import { AppModule } from "../../app.module";
import { User, UserDocument } from "../entities/user.schema";
import { getToken } from "../../common/helpers/get-token";

let app: INestApplication;
let userModel: Model<UserDocument>;
let authToken;
let authUser;

beforeAll(async () => {
  const moduleRef = await Test.createTestingModule({
    providers: [
      {
        provide: getModelToken(User.name),
        useValue: Model,
      },
    ],
    imports: [AppModule],
  }).compile();

  // clear users collection
  userModel = moduleRef.get<Model<UserDocument>>(getModelToken(User.name));
  await userModel.deleteMany({});

  // start app instance
  app = moduleRef.createNestApplication();
  app.useGlobalPipes(new ValidationPipe());
  await app.init();
  // get auth token
  const auth = await getToken(
    request(app.getHttpServer()),
    "furkan_mevo_test@gmail.com"
  );
  authToken = auth.token;
  authUser = auth.user;
});

describe("test password reset", () => {
  test(`should return validation error without email`, () => {
    return request(app.getHttpServer())
      .post("/users/forgot-password")
      .send({})
      .expect(400);
  });

  test(`should return email sent message`, () => {
    return request(app.getHttpServer())
      .post("/users/forgot-password")
      .send({ email: "furkan_mevo_test@gmail.com" })
      .expect(200)
      .then((response) => {
        expect(response.body.message).toEqual(
          "prelogin.EMAIL_SENT_IF_USER_EXIST"
        );
      });
  });

  test(`should return validation error without email key and password`, async () => {
    await request(app.getHttpServer())
      .post("/users/reset-password")
      .send({})
      .expect(400);
  });

  test(`should reset password`, async () => {
    const user = await userModel.findOne({
      email: "furkan_mevo_test@gmail.com",
    });
    const key = user.passwordResetKey;

    await request(app.getHttpServer())
      .post("/users/reset-password")
      .send({
        email: "furkan_mevo_test@gmail.com",
        key: key,
        password: "new-password",
      })
      .expect(200)
      .then((response) => {
        expect(response.body.message).toEqual(
          "prelogin.PASSWORD_RESET_SUCCESSFUL"
        );
      });
  });

  test("should verify new password", async () => {
    const user = await userModel.findOne({
      email: "furkan_mevo_test@gmail.com",
    });
    expect(user.passwordResetKey).toEqual("");

    await request(app.getHttpServer())
      .post("/auth/login")
      .send({
        email: "furkan_mevo_test@gmail.com",
        password: "new-password",
      })
      .expect(200);
  });
});

afterAll(async () => {
  // clear collections
  await userModel.deleteMany({});
  // close app
  await app.close();
});
