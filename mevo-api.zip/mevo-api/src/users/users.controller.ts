import {
  Body,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  HttpCode,
  Param,
  Post,
  Query,
  Req,
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { UsersService } from "./users.service";
import { Public } from "../auth/helpers/is-public";
import { ForgotPasswordDto } from "./dto/forgot-password.dto";
import { ResetPasswordDto } from "./dto/reset-password.dto";
import { Throttle, minutes } from "@nestjs/throttler";
import { isObjectIdPipe } from "src/common/pipes/isObjectIdPipe";
import { AddListenerDto } from "src/organizations/dto/add-listener.dto";
import RequestWithUser from "src/auth/interfaces/request-with-user";
import { OrganizationsService } from "src/organizations/organizations.service";
import { PlanType } from "src/organizations/entities/plan";
import { hasAdminAccess } from "src/auth/helpers/has-access";
import { UpdateRoleDto } from "./dto/update-role.dto";

// DTO for account deletion
export class DeleteAccountDto {
  email: string;
}

@ApiTags("users")
@Controller("users")
export class UsersController {
  constructor(
    private readonly userService: UsersService,
    private readonly organizationsService: OrganizationsService
  ) {}

  @Throttle({ default: { limit: 2, ttl: minutes(5) } })
  @Public()
  @HttpCode(200)
  @Post("forgot-password")
  forgotPassword(@Body() forgotPasswordDto: ForgotPasswordDto) {
    return this.userService.forgotPassword(forgotPasswordDto);
  }

  @Public()
  @HttpCode(200)
  @Post("reset-password")
  resetPassword(@Body() resetPasswordDto: ResetPasswordDto) {
    return this.userService.resetPassword(resetPasswordDto);
  }

  @Post("update-role")
  async updateRole(
    @Body() updateRoleDto: UpdateRoleDto,
    @Req() request: RequestWithUser
  ) {
    return this.userService.updateUserRole(request.user, updateRoleDto.role);
  }

  @Post(":id/add-listener")
  async addListener(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addListener: AddListenerDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (organization.plan === PlanType.BASIC) {
      throw new ForbiddenException("organizations.NEED_PRO_SUBSCRIPTION");
    }

    if (hasAdminAccess(organization, request.user)) {
      return this.userService.addListener({ _id }, addListener);
    }

    throw new ForbiddenException();
  }

  @Post(":id/remove-listener")
  async removeListener(
    @Param("id", new isObjectIdPipe()) _id: string,
    @Body() addListener: AddListenerDto,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({
      _id,
    });

    if (organization.plan === PlanType.BASIC) {
      throw new ForbiddenException("organizations.NEED_PRO_SUBSCRIPTION");
    }

    if (hasAdminAccess(organization, request.user)) {
      return this.userService.removeListener({ _id }, addListener);
    }

    throw new ForbiddenException();
  }

  @Delete("account")
  @HttpCode(200)
  async deleteAccount(
    @Body() deleteAccountDto: DeleteAccountDto,
    @Req() request: RequestWithUser
  ) {
    return this.userService.deleteAccount(request.user._id, deleteAccountDto.email);
  }

  @Public()
  @Get(":id/give-consent")
  async giveListenerConsent(
    @Param("id", new isObjectIdPipe()) organizationId: string,
    @Query("notification-consent-key") notificationConsentKey: string
  ) {
    return this.userService.giveListenerConsent(
      notificationConsentKey,
      organizationId
    );
  }
}
