import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Organization } from "src/organizations/entities/organization.schema";

export type UserDocument = HydratedDocument<User>;

@Schema({
  timestamps: true,
})
export class User {
  _id: string;

  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  email: string;

  @Prop({ required: false })
  password: string;

  @Prop({ required: false, default: false })
  isActive: boolean;

  @Prop({ type: String, required: false })
  passwordResetKey: string;

  @Prop({ type: String, required: false })
  notificationConsentKey: string;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
  })
  listenerOf: Organization;

  @Prop({ type: Date, required: false })
  lastPasswordReset: Date;

  @Prop({ default: false })
  isRegisteredWithGoogle: boolean;

  @Prop({ default: false })
  isNotificationReceiver: boolean;

  @Prop({ required: false })
  picture: string;

  @Prop({ required: false })
  locale: string;

  @Prop({ required: false, type: String, default: "" })
  role: string;
}

export const UserSchema = SchemaFactory.createForClass(User);
