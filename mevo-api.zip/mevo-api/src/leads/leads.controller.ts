import { Body, Controller, Delete, Get, Param, Post, Query, Req } from "@nestjs/common";
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { LeadsService } from "./leads.service";
import { Public } from "src/auth/helpers/is-public";
import { isObjectIdPipe } from "src/common/pipes/isObjectIdPipe";
import { Throttle, minutes } from "@nestjs/throttler";
import { CreateLeadDto } from "./dto/create-lead.dto";
import { Bot } from "src/bots/entities/bot.schema";
import { BotsService } from "src/bots/bots.service";
import { hasAdminAccess, hasUserAccess } from "src/auth/helpers/has-access";
import RequestWithUser from "src/auth/interfaces/request-with-user";
import { OrganizationsService } from "src/organizations/organizations.service";

@ApiBearerAuth()
@ApiTags("leads")
@Controller("leads")
export class LeadsController {
  constructor(
    private readonly leadsService: LeadsService,
    private readonly botsService: BotsService,
    private readonly organizationsService: OrganizationsService
  ) {}

  // @Throttle({ default: { limit: 2, ttl: minutes(5) } })
  @Public()
  @Post("create/:bid")
  async createLead(
    @Param("bid", new isObjectIdPipe()) bid: string,
    @Body() createLeadDto: CreateLeadDto
  ) {
    return this.leadsService.create(bid, createLeadDto);
  }

  @Get("list-by-bot/:bid")
  async listLeads(
    @Param("bid", new isObjectIdPipe()) bid: string,
    @Req() request: RequestWithUser,
    @Query() query: Record<string, any>
  ) {
    const bot: Bot = await this.botsService.findOne({
      _id: bid,
    });

    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      console.log(query, 'query');
      return this.leadsService.getLeadsByBot(bid, query);
    }
  }

  @Get("list-by-organization/:oid")
  async listLeadsByOrganization(
    @Param("oid", new isObjectIdPipe()) oid: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({ _id: oid });

    if (
      hasUserAccess(organization, request.user) ||
      hasAdminAccess(organization, request.user)
    ) {
      return this.leadsService.getLeadsByOrganization(oid);
    }
  }

  @Get("get-by-session/:oid/:sid")
  async getLeadBySession(
    @Param("oid", new isObjectIdPipe()) oid: string,
    @Param("sid") sid: string,
    @Req() request: RequestWithUser
  ) {
    const organization = await this.organizationsService.findOne({ _id: oid });

    if (
      hasUserAccess(organization, request.user) ||
      hasAdminAccess(organization, request.user)
    ) {
      const botId = String((request as any)?.query?.bid || (request as any)?.body?.bid || '');
      if (botId) {
        await this.leadsService.updateLeadGeoFromMessages(botId, sid);
      }
      return this.leadsService.getLeadBySession(sid);
    }
  }

  @Public()
  @Get("check")
  async checkLeadForDevice(
    @Query("device_id") device_id: string,
    @Query("bot_id") bot_id: string
  ) {
    return this.leadsService.checkLeadByDevice(device_id, bot_id);
  }

  @Delete('delete-many/:bid')
  async deleteMany(
    @Param('bid', new isObjectIdPipe()) bid: string,
    @Body('ids') ids: string[],
    @Req() request: RequestWithUser
  ) {
    const bot: Bot = await this.botsService.findOne({ _id: bid });
    if (
      hasAdminAccess(bot.organization, request.user) ||
      hasUserAccess(bot.organization, request.user)
    ) {
      return this.leadsService.deleteManyLeads(bid, ids);
    }
  }
}
