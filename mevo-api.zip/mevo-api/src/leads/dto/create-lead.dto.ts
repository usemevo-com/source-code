import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional } from "class-validator";

export class CreateLeadDto {
  @IsOptional()
  @ApiProperty({ type: "string" })
  name: string;

  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  email: string;

  // @IsNotEmpty()
  // @ApiProperty({ type: "string" })
  // sid: string;

  @IsNotEmpty()
  @ApiProperty({ type: "string" })
  device_id: string;

  @IsOptional()
  @ApiProperty({ type: "string" })
  organization: string;

  @IsOptional()
  @ApiProperty({ type: "boolean" })
  is_demo: boolean;
}
