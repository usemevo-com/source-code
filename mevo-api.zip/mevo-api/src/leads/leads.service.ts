import mongoose, { Model } from "mongoose";
import { Injectable } from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { ResponseFile, ResponseFileDocument } from "src/bots/entities/response-file.schema";
import { StorageService } from "src/common/helpers/storage.service";
import {
  Organization,
  OrganizationDocument,
} from "../organizations/entities/organization.schema";
import { Bot, BotDocument } from "../bots/entities/bot.schema";
import { ConfigService } from "@nestjs/config";
import { Lead, LeadDocument } from "./entities/lead.schema";

@Injectable()
export class LeadsService {
  constructor(
    private configService: ConfigService,
    @InjectModel(Organization.name)
    private organizationModel: Model<OrganizationDocument>,
    @InjectModel(Bot.name)
    private botModel: Model<BotDocument>,
    @InjectModel(Lead.name)
    private leadModel: Model<LeadDocument>,
    @InjectModel(ResponseFile.name)
    private responseFileModel: Model<ResponseFileDocument>,
    private readonly storageService: StorageService,

    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

  async create(botId: string, lead: any) {
    const bot = await this.botModel.findById(botId).exec();

    if (!bot) {
      throw new Error("Bot not found");
    }

    // const existingLead = await this.leadModel
    //   .findOne({ email: lead.email, bot: botId })
    //   .exec();

    // if (existingLead) {
    //   if (!existingLead.sid.includes(lead.sid)) {
    //     existingLead.sid.push(lead.sid);
    //     await existingLead.save();
    //   }
    //   return true;
    // }

    if (!lead.is_demo) {
      const generatedLead = new this.leadModel({
        ...lead,
        bot,
        organization: bot.organization,
      });

      await generatedLead.save();
    } else {
      console.log("lead hasn't been saved because it is a demo lead.");
    }

    return true;
  }

  async getLeadsByBot(botId: string, query?: Record<string, any>) {
    const andConditions: any[] = [{ bot: botId }];

    if (query) {
      // hasEmail=true -> email exists, is a string and is not equal to "N/A" (case-insensitive, optional spaces or slash)
      if (String(query.hasEmail).toLowerCase() === 'true') {
        andConditions.push({
          email: {
            $exists: true,
            $type: 'string',
            $not: /^\s*n\/?a\s*$/i,
          },
        });
      }
      // hasCompany=true -> company exists, is a string and is not equal to "N/A" (case-insensitive, optional spaces or slash)
      if (String(query.hasCompany).toLowerCase() === 'true') {
        andConditions.push({
          company: {
            $exists: true,
            $type: 'string',
            $not: /^\s*n\/?a\s*$/i,
          },
        });
      }

      if (String(query.hasEmailVerified).toLowerCase() === 'true') {
        andConditions.push({
          email_verified: true,
        });
      }

      // name contains
      if (typeof query.qName === 'string' && query.qName.trim() !== '') {
        andConditions.push({ name: { $regex: new RegExp(query.qName, 'i') } });
      }
      // email contains
      if (typeof query.qEmail === 'string' && query.qEmail.trim() !== '') {
        andConditions.push({ email: { $regex: new RegExp(query.qEmail, 'i') } });
      }
      // phone contains
      if (typeof query.qPhone === 'string' && query.qPhone.trim() !== '') {
        andConditions.push({ phone: { $regex: new RegExp(query.qPhone, 'i') } });
      }
      // url contains
      if (typeof query.qUrl === 'string' && query.qUrl.trim() !== '') {
        andConditions.push({ url: { $regex: new RegExp(query.qUrl, 'i') } });
      }
      // custom data key/value contains
      if (
        typeof query.customKey === 'string' && query.customKey.trim() !== '' &&
        typeof query.customValue === 'string' && query.customValue.trim() !== ''
      ) {
        const safeKey = String(query.customKey).replace(/[^a-zA-Z0-9_.-]/g, '');
        const dynamicCond: any = {};
        dynamicCond[`customData.${safeKey}`] = { $regex: new RegExp(query.customValue, 'i') };
        andConditions.push(dynamicCond);
      }
    }

    const finalFilter = andConditions.length > 1 ? { $and: andConditions } : andConditions[0];

    return this.leadModel.find(finalFilter).exec();
  }

  async checkLeadByDevice(device_id: string, bot_id: string) {
    const lead = await this.leadModel
      .findOne({ device_id, bot: bot_id })
      .exec();

    console.log(lead);

    if (lead) {
      return lead;
    } else {
      return false;
    }
  }

  async getLeadsByOrganization(organizationId: string) {
    return this.leadModel
      .find({ organization: organizationId })
      .populate("bot", "name")
      .exec();
  }

  async getLeadBySession(sessionId: string) {
    return this.leadModel.findOne({ sid: { $in: [sessionId] } }).exec();
  }

  async updateLeadGeoFromMessages(botId: string, sessionId: string) {
    // Aggregate latest geo data from messages collection for this session and bot, set to lead.geo
    const latestGeo = await this.connection.collection('messages').find({
      bot: new mongoose.Types.ObjectId(botId),
      session: sessionId,
      geo: { $exists: true }
    }).sort({ createdAt: -1 }).limit(1).toArray();

    if (latestGeo && latestGeo.length) {
      const geo: any = latestGeo[0].geo || {};
      const city = geo?.city || geo?.metadata?.city;
      const country = geo?.country || geo?.metadata?.country;
      await this.leadModel.updateMany(
        { sid: { $in: [sessionId] }, bot: botId },
        { $set: { geo: { city: city || 'N/A', country: country || 'N/A' } } }
      ).exec();
    }
  }

  async deleteManyLeads(botId: string, ids: string[]) {
    // if ids empty, delete all for bot
    if (!Array.isArray(ids) || ids.length === 0) {
      // delete all leads for bot → cascade attachments
      const leads = await this.leadModel.find({ bot: botId }).exec();
      await this.removeAttachmentsForLeads(leads);
      const res = await this.leadModel.deleteMany({ bot: botId }).exec();
      return { deletedCount: res.deletedCount ?? 0 };
    }
    const objectIds = ids
      .filter((id) => typeof id === 'string' && mongoose.Types.ObjectId.isValid(id))
      .map((id) => new mongoose.Types.ObjectId(id));

    const leads = await this.leadModel.find({ _id: { $in: objectIds }, bot: botId }).exec();
    await this.removeAttachmentsForLeads(leads);
    const res = await this.leadModel.deleteMany({ _id: { $in: objectIds }, bot: botId }).exec();
    return { deletedCount: res.deletedCount ?? 0 };
  }

  private async removeAttachmentsForLeads(leads: LeadDocument[]) {
    try {
      const fileIds = new Set<string>();

      const collectIds = (val: any) => {
        if (!val && val !== 0) return;
        if (typeof val === 'string') {
          if (val.startsWith('file:')) {
            const rid = val.replace('file:', '').trim();
            if (rid) fileIds.add(rid);
          }
          return;
        }
        if (Array.isArray(val)) {
          val.forEach(collectIds);
          return;
        }
        if (typeof val === 'object') {
          Object.values(val).forEach(collectIds);
          return;
        }
      };

      for (const lead of leads) {
        collectIds((lead?.customData || {}) as Record<string, any>);
      }
      if (!fileIds.size) return;

      const ids = Array.from(fileIds);
      const docs = await this.responseFileModel.find({ _id: { $in: ids } }).exec();

      await Promise.all(
        docs.map(async (doc) => {
          try {
            if (doc?.key) await this.storageService.deleteObject(doc.key);
          } catch (e) {
            // ignore per-item errors
          }
        })
      );

      await this.responseFileModel.deleteMany({ _id: { $in: ids } }).exec();
    } catch (e) {
      // ignore errors during best-effort cleanup
    }
  }
}
