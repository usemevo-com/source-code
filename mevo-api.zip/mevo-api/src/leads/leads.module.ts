import { Module, forwardRef } from "@nestjs/common";
import { LeadsController } from "./leads.controller";
import { LeadsService } from "./leads.service";
import { MongooseModule } from "@nestjs/mongoose";
import { ConfigModule } from "@nestjs/config";
import {
  Lead,
  LeadSchema,
} from "./entities/lead.schema";
import { Bot, BotSchema } from "../bots/entities/bot.schema";
import { Organization, OrganizationSchema } from "src/organizations/entities/organization.schema";
import { BotsModule } from "../bots/bots.module";
import { OrganizationsModule } from "src/organizations/organizations.module";
import { ResponseFile, ResponseFileSchema } from "src/bots/entities/response-file.schema";
import { StorageService } from "src/common/helpers/storage.service";


@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Lead.name, schema: LeadSchema },
      { name: Bot.name, schema: BotSchema },
      { name: Organization.name, schema: OrganizationSchema },
      { name: ResponseFile.name, schema: ResponseFileSchema },
    ]),
    forwardRef(() => BotsModule),
    forwardRef(() => OrganizationsModule),
    ConfigModule,
  ],
  controllers: [LeadsController],
  providers: [LeadsService, StorageService],
  exports: [LeadsService],
})
export class LeadsModule {}
