import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Bot } from "src/bots/entities/bot.schema";
import { Organization } from "src/organizations/entities/organization.schema";

export type LeadDocument = HydratedDocument<Lead>;

@Schema({
  timestamps: true,
})
export class Lead {
  _id: string;

  @Prop({ required: false })
  name: string;

  @Prop({ required: true })
  email: string;

  @Prop({ required: false, default: false })
  email_verified: boolean;

  @Prop({ required: false })
  email_verification_code?: string;

  @Prop({ required: false })
  email_verification_expires_at?: Date;

  @Prop({ required: false, type: Number, default: 0 })
  email_verification_attempts?: number;

  @Prop({ required: false })
  last_verification_sent_at?: Date;

  @Prop({ type: String })
  company: string;

  @Prop({ required: false })
  phone: string;

  @Prop({ required: false })
  url: string;

  @Prop({ required: false, type: Object })
  geo?: { city?: string; country?: string };

  @Prop({ type: mongoose.Schema.Types.Mixed, required: false, default: {} })
  customData: Record<string, any>;

  @Prop({ required: true })
  sid: string[];

  @Prop({ required: true })
  device_id: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bot",
  })
  bot: Bot;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Organization",
  })
  organization: Organization;
}

export const LeadSchema = SchemaFactory.createForClass(Lead);
