import * as request from "supertest";
import { Test } from "@nestjs/testing";
import { INestApplication, ValidationPipe } from "@nestjs/common";
import { Model } from "mongoose";
import { getModelToken } from "@nestjs/mongoose";
import { AppModule } from "../../app.module";
import { User, UserDocument } from "../../users/entities/user.schema";

describe("Auth", () => {
  let app: INestApplication;
  let userModel: Model<UserDocument>;
  let authToken;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [
        {
          provide: getModelToken(User.name),
          useValue: Model,
        },
      ],
      imports: [AppModule],
    }).compile();

    // clear organizations collection
    userModel = moduleRef.get<Model<UserDocument>>(getModelToken(User.name));
    await userModel.deleteMany({});

    // start app instance
    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe());
    await app.init();
  });

  describe("try to register without required fields", () => {
    test(`should return validation error without email`, () => {
      return request(app.getHttpServer())
        .post(`/auth/register`)
        .send({ name: "Furkan", password: "123456" })
        .expect(400);
    });

    test(`should return validation error with invalid email name`, () => {
      return request(app.getHttpServer())
        .post(`/auth/register`)
        .send({ email: "furkan", name: "Furkan", password: "123456" })
        .expect(400);
    });

    test(`should return validation error without name`, () => {
      return request(app.getHttpServer())
        .post(`/auth/register`)
        .send({ email: "furkan_mevo_test@gmail.com", password: "123456" })
        .expect(400);
    });

    test(`should return validation error without password`, () => {
      return request(app.getHttpServer())
        .post(`/auth/register`)
        .send({ name: "Furkan", email: "furkan_mevo_test@gmail.com" })
        .expect(400);
    });
  });

  describe("try to register with correct fields", () => {
    test(`should register successfully and return user object`, () => {
      return request(app.getHttpServer())
        .post(`/auth/register`)
        .send({
          name: "Furkan",
          email: "furkan_mevo_test@gmail.com",
          password: "123456",
        })
        .expect(201)
        .then((response) => {
          expect(response.body.name).toEqual("Furkan");
          expect(response.body.email).toEqual("furkan_mevo_test@gmail.com");
          expect(response.body.password).toEqual(undefined);
        });
    });

    test(`should return user already-have-an-account`, () => {
      return request(app.getHttpServer())
        .post(`/auth/register`)
        .send({
          name: "Furkan",
          email: "furkan_mevo_test@gmail.com",
          password: "123456",
        })
        .expect(400)
        .then((response) => {
          expect(response.body.message).toEqual("prelogin.USER_ALREADY_EXISTS");
        });
    });
  });

  describe("test login", () => {
    test("it should return wrong credentials error", () => {
      return request(app.getHttpServer())
        .post(`/auth/login`)
        .send({ email: "furkan_mevo_test@gmail.com", password: "1234567" })
        .expect(400)
        .then((response) => {
          expect(response.body.message).toEqual("prelogin.WRONG_CREDENTIALS");
        });
    });

    test("it should login", () => {
      return request(app.getHttpServer())
        .post(`/auth/login`)
        .send({ email: "furkan_mevo_test@gmail.com", password: "123456" })
        .expect(200)
        .then((response) => {
          authToken = response.headers["set-cookie"][0]
            .split(";")[0]
            .split("=")[1];
        });
    });
  });

  describe("test verify endpoint", () => {
    test(`should return authentication error`, () => {
      return request(app.getHttpServer()).get(`/auth/verify`).expect(401);
    });

    test(`should return user data`, () => {
      return request(app.getHttpServer())
        .get(`/auth/verify`)
        .set("Cookie", `Authentication=${authToken}`)
        .expect(200);
    });
  });

  afterAll(async () => {
    // clear collections
    await userModel.deleteMany({});
    // close app
    await app.close();
  });
});
