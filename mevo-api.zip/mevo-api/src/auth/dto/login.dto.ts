import { ApiProperty } from '@nestjs/swagger'
import { IsEmail, IsNotEmpty, IsOptional } from 'class-validator'

export class LoginDto {
  @IsEmail()
  @IsNotEmpty()
  @ApiProperty({ type: 'string', required: true })
  email: string

  @IsNotEmpty()
  @ApiProperty({ type: 'string', required: true })
  password: string
}
