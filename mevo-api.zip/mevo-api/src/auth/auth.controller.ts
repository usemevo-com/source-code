import {
  Body,
  Controller,
  Get,
  HttpCode,
  Post,
  Query,
  Req,
  Res,
  UseGuards,
} from "@nestjs/common";
import { Response } from "express";
import { CreateUserDto } from "../users/dto/create-user.dto";
import { AuthService } from "./auth.service";
import { LocalAuthenticationGuard } from "./guards/local-authentication.guard";
import RequestWithUser from "./interfaces/request-with-user";
import { Public } from "./helpers/is-public";
import { LoginDto } from "./dto/login.dto";
import { SkipThrottle, Throttle, minutes } from "@nestjs/throttler";

@Controller("auth")
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Throttle({ default: { limit: 4, ttl: minutes(1) } })
  @Public()
  @Post("register")
  register(
    @Body() createUserDto: CreateUserDto,
    @Query("appsumo_key") appSumoKey: string
  ) {
    if (appSumoKey) {
      return this.authService.register(createUserDto, appSumoKey);
    } else {
      return this.authService.register(createUserDto);
    }
  }

  @HttpCode(200)
  @Public()
  @UseGuards(LocalAuthenticationGuard)
  @Post("login")
  logIn(
    @Body() loginDto: LoginDto,
    @Req() request: RequestWithUser,
    @Res() response: Response
  ) {
    const { user } = request;
    const cookie = this.authService.getCookieWithJwtToken(user._id);
    response.setHeader("Set-Cookie", cookie);
    return response.send(user);
  }

  @Post("logout")
  async logOut(@Req() request: RequestWithUser, @Res() response: Response) {
    response.setHeader("Set-Cookie", this.authService.getCookieForLogOut());
    return response.sendStatus(200);
  }

  @Get("verify")
  authenticate(@Req() request: RequestWithUser) {
    const user = request.user;
    user.password = undefined;
    user.passwordResetKey = undefined;
    return user;
  }
}
