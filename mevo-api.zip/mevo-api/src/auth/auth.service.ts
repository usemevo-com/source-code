import * as bcrypt from "bcrypt";
import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import mongoose, { Model } from "mongoose";
import { JwtService } from "@nestjs/jwt";
import { ConfigService } from "@nestjs/config";
import { UsersService } from "../users/users.service";
import { CreateUserDto } from "../users/dto/create-user.dto";
import { LoginDto } from "./dto/login.dto";
import { TokenPayload } from "./interfaces/token-payload";
import { ProductKey } from "../subscriptions/entities/product-key.schema";
import { HttpService } from "@nestjs/axios";
import { catchError, firstValueFrom } from "rxjs";
import { AxiosError } from "axios";
import { BotsService } from "src/bots/bots.service";

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly httpService: HttpService,
    private readonly botsService: BotsService,
    @InjectModel(ProductKey.name)
    private productKeyModel: Model<ProductKey>,
    @InjectConnection() private readonly connection: mongoose.Connection
  ) {}

  emailWhiteList = ["tools@hotstreakproductions.com"];

  async register(registerDto: CreateUserDto, appSumoKey: string = "") {
    const hashedPassword = await bcrypt.hash(registerDto.password, 10);

    // throw new HttpException(
    //   "We stopped accepting new users for a short time. Please check back later.",
    //   HttpStatus.BAD_REQUEST
    // );

    try {
      const userPayload = {
        ...registerDto,
        email: registerDto.email.toLowerCase(),
        password: hashedPassword,
      };

      if (appSumoKey) {
        userPayload.appSumoKey = appSumoKey;

        const productKey = await this.productKeyModel.findOne({
          key: appSumoKey,
          isUsed: false,
        });

        if (!productKey) {
          throw new HttpException(
            "prelogin.INVALID_APPSUMO_KEY",
            HttpStatus.BAD_REQUEST
          );
        }
      }

      if (false) {
        const zeroBounceKey = this.configService.get<string>("ZERO_BOUNCE_KEY");

        const { data } = await firstValueFrom(
          this.httpService
            .get(
              `https://api.zerobounce.net/v2/validate?api_key=${zeroBounceKey}&email=${userPayload.email}`
            )
            .pipe(
              catchError((error: AxiosError) => {
                throw new HttpException(
                  "prelogin.WE_COULD_NOT_VERIFY_YOUR_EMAIL",
                  HttpStatus.BAD_REQUEST
                );
              })
            )
        );

        if (data.status !== "valid") {
          throw new HttpException(
            "prelogin.INVALID_EMAIL_ADDRESS",
            HttpStatus.BAD_REQUEST
          );
        }
      }

      const createdUser = await this.usersService.create(userPayload);

      // set isUsed to true
      if (appSumoKey) {
        await this.productKeyModel.updateOne(
          { key: appSumoKey },
          {
            $set: { isUsed: true, usedBy: createdUser._id, usedAt: new Date() },
          }
        );
      }
      // sendTemplateMail("register", createdUser.email);

      createdUser.password = undefined;

      if (registerDto.bot) {
        await this.botsService.assign_bot_to_user(registerDto.bot, createdUser._id.toString());
      }

      return createdUser;
    } catch (err) {
      if (err.message === "prelogin.USER_ALREADY_EXISTS") {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      } else if (err.message === "prelogin.INVALID_APPSUMO_KEY") {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      } else if (err.message === "prelogin.INVALID_EMAIL_ADDRESS") {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      } else {
        console.log(err, 'err');
        throw new HttpException(
          "common.TRANSACTION_FAILED",
          HttpStatus.BAD_REQUEST
        );
      }
    }
  }

  async getAuthenticatedUser(loginDto: LoginDto) {
    try {
      const user = await this.usersService.findOne({ email: loginDto.email.toLowerCase() });
      const isPasswordMatching = await bcrypt.compare(
        loginDto.password,
        user.password
      );

      if (!isPasswordMatching) {
        throw new HttpException(
          "prelogin.WRONG_CREDENTIALS",
          HttpStatus.BAD_REQUEST
        );
      }

      user.password = undefined;

      return user;
    } catch (err) {
      throw new HttpException(
        "prelogin.WRONG_CREDENTIALS",
        HttpStatus.BAD_REQUEST
      );
    }
  }

  getCookieWithJwtToken(userId: string) {
    const payload: TokenPayload = { userId };
    const token = this.jwtService.sign(payload);
    return `Authentication=${token}; HttpOnly; Path=/; Max-Age=${this.configService.get<number>(
      "JWT_EXPIRATION_TIME"
    )}`;
  }

  getCookieForLogOut() {
    return `Authentication=; HttpOnly; Path=/; Max-Age=0;`;
  }
}
