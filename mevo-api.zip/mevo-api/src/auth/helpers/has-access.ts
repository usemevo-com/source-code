import { Organization } from '../../organizations/entities/organization.schema';
import { User } from '../../users/entities/user.schema';

export function hasUserAccess(
  organization: Organization,
  loggedInUser: User,
): boolean {
  if (
    !organization.users.filter(
      (user) => user._id.toString() === loggedInUser._id.toString(),
    ).length
  ) {
    return false;
  }
  return true;
}

export function hasAdminAccess(
  organization: Organization,
  loggedInUser: User,
): boolean {
  if (
    !organization.admins.filter(
      (admin) => admin._id.toString() === loggedInUser._id.toString(),
    ).length
  ) {
    return false;
  }
  return true;
}
