import * as crypto from 'crypto';

export function randomHex(bytes: number) {
  return crypto.randomBytes(bytes).toString('hex');
}

export function randomHexBits(bits: number) {
  return crypto.randomBytes(Math.ceil(bits / 8)).toString('hex');
}

export function randomHexLength(length: number) {
  return crypto
    .randomBytes(Math.ceil(length / 2))
    .toString('hex')
    .slice(0, length);
}
