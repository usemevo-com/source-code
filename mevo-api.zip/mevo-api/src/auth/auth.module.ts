import { forwardRef, Module } from "@nestjs/common";
import { PassportModule } from "@nestjs/passport";
import { ConfigModule } from "@nestjs/config";
import { JwtModule } from "@nestjs/jwt";
import { MongooseModule } from "@nestjs/mongoose";
import { AuthService } from "./auth.service";
import { AuthController } from "./auth.controller";
import { LocalStrategy } from "./strategies/local.strategy";
import { JwtStrategy } from "./strategies/jwt.strategy";
import { getJWTOptions } from "../common/helpers/jwt-options";
import { UsersModule } from "../users/users.module";
import {
  ProductKey,
  ProductKeySchema,
} from "../subscriptions/entities/product-key.schema";
import { HttpModule } from "@nestjs/axios";
import { BotsModule } from "src/bots/bots.module";

@Module({
  providers: [AuthService, LocalStrategy, JwtStrategy],
  imports: [
    MongooseModule.forFeature([
      { name: ProductKey.name, schema: ProductKeySchema },
    ]),
    UsersModule,
    forwardRef(() => BotsModule),
    PassportModule,
    ConfigModule,
    HttpModule,
    JwtModule.registerAsync(getJWTOptions()),
  ],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}