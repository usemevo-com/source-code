import { MulterOptions } from "@nestjs/platform-express/multer/interfaces/multer-options.interface";
import { diskStorage } from "multer";

export const uploadOptions: MulterOptions = {
  storage: diskStorage({
    destination: "./uploads", // Choose your destination folder
    filename: (req, file, callback) => {
      const filename = `${Date.now()}-${file.originalname}`;
      callback(null, filename);
    },
  }),
};
