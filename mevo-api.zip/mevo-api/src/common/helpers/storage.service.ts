import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

@Injectable()
export class StorageService {
  private s3: S3Client;
  private bucket: string;

  constructor(private readonly configService: ConfigService) {
    const region = this.configService.get<string>("SPACES_REGION");
    const endpoint = this.configService.get<string>("SPACES_ENDPOINT");
    const accessKeyId = this.configService.get<string>("SPACES_KEY");
    const secretAccessKey = this.configService.get<string>("SPACES_SECRET");

    this.bucket = this.configService.get<string>("SPACES_BUCKET");

    this.s3 = new S3Client({
      region,
      endpoint: endpoint?.startsWith("http") ? endpoint : `https://${endpoint}`,
      forcePathStyle: false,
      credentials: {
        accessKeyId: accessKeyId || "",
        secretAccessKey: secretAccessKey || "",
      },
    });
  }

  async putObject(params: {
    key: string;
    body: Buffer | Uint8Array | Blob | string;
    contentType?: string;
  }): Promise<void> {
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: params.key,
      Body: params.body,
      ContentType: params.contentType,
      ACL: "private",
    } as any);
    await this.s3.send(command);
  }

  async getSignedUrl(key: string, expiresInSeconds: number = 60, filename?: string): Promise<string> {
    const headers: any = { Bucket: this.bucket, Key: key };
    if (filename) {
      // basic filename sanitization
      const safe = filename.replace(/[^a-zA-Z0-9._-]+/g, '-').slice(0, 140);
      headers.ResponseContentDisposition = `attachment; filename="${safe}"`;
    }
    const getObjectCommand = new GetObjectCommand(headers);
    return await getSignedUrl(this.s3, getObjectCommand, { expiresIn: expiresInSeconds });
  }

  async deleteObject(key: string): Promise<void> {
    const command = new DeleteObjectCommand({ Bucket: this.bucket, Key: key } as any);
    await this.s3.send(command);
  }
}


