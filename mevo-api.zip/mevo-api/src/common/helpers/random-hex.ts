import * as crypto from "crypto";
const algorithm = "aes-256-cbc";

export function randomHex(bytes: number) {
  return crypto.randomBytes(bytes).toString("hex");
}

export function randomHexBits(bits: number) {
  return crypto.randomBytes(Math.ceil(bits / 8)).toString("hex");
}

export function randomHexLength(length: number) {
  return crypto
    .randomBytes(Math.ceil(length / 2))
    .toString("hex")
    .slice(0, length);
}

export function encrypt(value, key, iv) {
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  let encrypted = cipher.update(value, "utf8", "hex");
  encrypted += cipher.final("hex");
  return encrypted;
}

export function decrypt(encrypted, key, iv) {
  const decipher = crypto.createDecipheriv(algorithm, key, iv);
  let decrypted = decipher.update(encrypted, "hex", "utf8");
  decrypted += decipher.final("utf8");
  return decrypted;
}
