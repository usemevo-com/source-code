import { firstValueFrom } from "rxjs";
import { HttpService } from "@nestjs/axios";

export async function send_telegram_notification(message: string) {
  const httpService = new HttpService();

  try {
    await firstValueFrom(
      httpService.post(
        "https://api.telegram.org/bot7829408371:AAFs4wqDl7annRiY9D5oGpiRN6Hs3UkLKO4/sendMessage",
        {
          chat_id: 406038897,
          text: message,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
    );
  } catch (err) {
    console.log(err, 'error sending telegram notification');
  }
}
