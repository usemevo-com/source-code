export async function getToken(request, email) {
  // register
  await request
    .post('/auth/register')
    .send({ name: 'user', email: email, password: '123456' })
    .expect(201);
  // login
  const response = await request
    .post('/auth/login')
    .send({ email: email, password: '123456' })
    .expect(200);
  // return token
  return {
    token: response.headers['set-cookie'][0].split(';')[0].split('=')[1],
    user: response.body,
  };
}
