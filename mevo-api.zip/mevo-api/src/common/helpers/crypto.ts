import * as crypto from "crypto";

const algorithm = "aes-192-cbc";
const iv = Buffer.from([
  6, 27, 159, 228, 177, 220, 126, 198, 59, 71, 65, 242, 190, 133, 113, 108,
]);

function getKey(secret: string) {
  return crypto.scryptSync(secret, "salt", 24);
}

export function encrypt(text: string, secret: string) {
  const key = getKey(secret);
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  return cipher.update(text, "utf8", "hex") + cipher.final("hex");
}

export function decrypt(text: string, secret: string) {
  const key = getKey(secret);
  const decipher = crypto.createDecipheriv(algorithm, key, iv);
  return decipher.update(text, "hex", "utf8") + decipher.final("utf8");
}
