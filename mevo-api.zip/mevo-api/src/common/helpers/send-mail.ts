// TODO: convert this file to a class
// replace process.env usages with configService usages
import * as sib from "@sendinblue/client";

export const emailWhitelist = [
  "de_crescenzo.nicola@yahoo.fr",
  "tools@hotstreakproductions.com",
  "lead@gsxtransport.co.uk",
];

type predefinedTemplates =
  | "forgotten-password"
  | "listener-invitation"
  | "register"
  | "upgrade"
  | "invitation"
  | "invitation-accepted"
  | "cancel"
  | "continue"
  | "payment-failed"
  | "downgraded"
  | "response-received"
  | "ai-interaction"
  | "ai-interaction-without-lead"
  | "upgraded-paid-plan"
  | "downgraded-paid-plan"
  | "agent-reply"
  | "limit-reached"
  | "new-conversation"
  | "ok-but-need-more-character-limit"
  | "need-more-character-limit"
  | "training-completed"
  | "lead-email-verification";

interface MailOptions {
  to: string;
  template?: predefinedTemplates;
  params?: object;
  html?: string;
  text?: string;
}

const TEMPLATE_TO_ID: { [key in predefinedTemplates]: number } = {
  register: 15,
  "forgotten-password": 16,
  "response-received": 13,
  "listener-invitation": 75,
  upgrade: 17,
  invitation: 18,
  "invitation-accepted": 19,
  cancel: 20,
  continue: 21,
  "payment-failed": 22,
  downgraded: 23,
  "limit-reached": 30,
  "ai-interaction": 61,
  "ai-interaction-without-lead": 62,
  "upgraded-paid-plan": 78,
  "downgraded-paid-plan": 79,
  "agent-reply": 83,
  "new-conversation": 102,
  "training-completed": 103,
  "ok-but-need-more-character-limit": 105,
  "need-more-character-limit": 106,
  "lead-email-verification": 107,
};

export function sendMail() {
  const apiKey = process.env.MAIL_SENDINBLUE_API_KEY;
  const from = process.env.MAIL_FROM;
  const fromName = process.env.MAIL_FROM_NAME;

  if (!apiKey) {
    throw new Error("Mail sending api-key is missing");
  }

  const sender = new sib.TransactionalEmailsApi();
  sender.setApiKey(sib.TransactionalEmailsApiApiKeys.apiKey, apiKey);

  return function sendMailSendinBlueApi(opts: MailOptions) {
    const email = new sib.SendSmtpEmail();

    if (opts.template) {
      email.templateId = TEMPLATE_TO_ID[opts.template];
    }

    email.sender = { email: from, name: fromName };
    email.to = [{ email: opts.to }];
    email.params = opts.params;

    return sender
      .sendTransacEmail(email)
      .then(() => "ok")
      .catch((e) => {
        console.log("[MAIL] Failed to deliver!", opts, e);
      });
  };
}

export function sendTemplateMail(
  template: predefinedTemplates,
  to: string,
  params?: Record<string, any>
) {
  return sendMail()({
    to,
    template,
    params,
  });
}
