import { ConfigModule, ConfigService } from "@nestjs/config";

export function getMongooseOptions() {
  return {
    imports: [ConfigModule],
    inject: [ConfigService],
    useFactory: async (configService: ConfigService) => ({
      uri: configService.get<string>("MONGODB_URI"),
      connectionFactory: (connection) => {
        // eslint-disable-next-line
        connection.plugin(require("mongoose-autopopulate"));
        return connection;
      },
    }),
  };
}
