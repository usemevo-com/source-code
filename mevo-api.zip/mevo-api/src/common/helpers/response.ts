export function HttpResponseWithMessage(message: string, statusCode = 200) {
  return {
    message,
    statusCode,
  };
}
