export function getMinDiff(date: Date): number {
  const unixTime = new Date(date).valueOf();
  const diff = Math.abs(Date.now() - unixTime);
  return Math.floor(diff / 1000 / 60);
}
