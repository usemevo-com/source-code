import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';

@Injectable()
export class isObjectIdPipe implements PipeTransform {
  transform(value: any) {
    if (typeof value === 'undefined') {
      throw new BadRequestException('Missing ID parameter');
    }
    if (value.length !== 24) {
      throw new BadRequestException('ID parameter must be an ObjectID');
    }
    return value;
  }
}
