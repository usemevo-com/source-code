import mongoose, { Model } from "mongoose";
import { Injectable, Logger } from "@nestjs/common";
import { InjectConnection, InjectModel } from "@nestjs/mongoose";
import { Cron, CronExpression } from "@nestjs/schedule";
import { Message, MessageDocument } from "src/bots/entities/message.schema";
import { sendTemplateMail } from "src/common/helpers/send-mail";
import { User, UserDocument } from "src/users/entities/user.schema";
import { PlanType } from "src/organizations/entities/plan";
import { HttpService } from "@nestjs/axios";
import { firstValueFrom } from "rxjs";
import {
  NotificationReceiver,
  NotificationReceiverDocument,
} from "src/bots/entities/notification-receiver.schema";

@Injectable()
export class NotificationManagerService {
  private readonly logger = new Logger(NotificationManagerService.name);

  constructor(
    @InjectConnection() private readonly connection: mongoose.Connection,
    @InjectModel(Message.name)
    private messageModel: Model<MessageDocument>,
    @InjectModel(User.name)
    private userModel: Model<UserDocument>,
    @InjectModel(NotificationReceiver.name)
    private notificationReceiverModel: Model<NotificationReceiverDocument>,
    private readonly httpService: HttpService
  ) {}

  @Cron(CronExpression.EVERY_5_MINUTES)
  async handleCron() {
    this.logger.debug(`Notification manager started...`);

    // find all messages that have not been sent a notification and are created in the last 5 minutes
    let sessions: any = await this.messageModel.aggregate([
      {
        $match: {
          notificationSent: false,
          createdAt: {
            $gte: new Date(Date.now() - 1000 * 60 * 5),
          },
          isEvent: { $ne: true },
        },
      },
      {
        $group: {
          _id: "$session",
          messages: {
            $push: "$$ROOT",
          },
        },
      },
      {
        $lookup: {
          from: "bots",
          localField: "messages.bot",
          foreignField: "_id",
          as: "bot",
        },
      },
      {
        $lookup: {
          from: "organizations",
          localField: "bot.organization",
          foreignField: "_id",
          as: "organization",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "organization.admins",
          foreignField: "_id",
          as: "admins",
        },
      },
      {
        $lookup: {
          from: "leads",
          localField: "messages.did",
          foreignField: "device_id",
          as: "lead",
        },
      },
      {
        $project: {
          _id: 1,
          organization: 1,
          bot: 1,
          admins: 1,
          messages: 1,
          lead: {
            $cond: {
              if: { $eq: [{ $size: "$lead" }, 0] },
              then: { email: "N/A", name: "N/A", company: "N/A" },
              else: { $first: "$lead" },
            },
          },
        },
      },
      {
        $unwind: {
          path: "$lead",
        },
      },
    ]);

    // get the messages from the model by using session property of the messages in for of the messages array
    for (var session of sessions) {
      session.messages = await this.messageModel.find({ session: session._id, isEvent: { $ne: true } });
      session.admins = session.admins.map((admin) => admin.email);
    }

    // array to store all the email notifications
    let emailNotifications = [];

    // iterate over the sessions and prepare the email content
    sessions.forEach(async (session, index) => {
      let messages = [];
      let recipients = [];

      session.messages.forEach((m) => {
        messages.push({
          sender: m.sender,
          content: m.content,
          createdAt: m.createdAt,
        });
      });

      const hasNotificationPreferenceSet =
        typeof session.organization[0].sendEmailNotificationsToAdmins !==
        "undefined";

      // add organization admins to recipients if the notification preference is set
      if (
        !hasNotificationPreferenceSet ||
        (hasNotificationPreferenceSet &&
          session.organization[0].sendEmailNotificationsToAdmins)
      ) {
        recipients = session.admins;
      }

      // add bot specific recipients if they are set
      const notification_receivers = await this.notificationReceiverModel.find({
        bot: session.bot[0]._id,
      });

      const email_receivers = notification_receivers.filter(
        (receiver) => receiver.type === "email"
      );
      const webhook_receivers = notification_receivers.filter(
        (receiver) => receiver.type === "webhook"
      );

      if (email_receivers.length) {
        email_receivers.forEach((receiver) => {
          recipients.push(receiver.payload.email);
        });
      }

      // make recipients unique
      recipients = [...new Set(recipients)];

      // prepare email content
      let emailContent = {
        messages: messages.sort((a, b) => a.createdAt - b.createdAt),
        leadName: session.lead.name || "Unknown",
        leadEmail: session.lead.email || "Unknown",
        leadCompany: session.lead.company || "Unknown",
        recipients,
        bot: session.bot[0].name,
        bot_id: session.bot[0]._id,
        organization: session.organization[0].name,
        organization_id: session.organization[0]._id,
        session: session._id,
      };

      // add email content to the email notifications array
      emailNotifications.push(emailContent);

      // is there a chatbot specific webhook?
      if (webhook_receivers.length) {
        // send webhook
        for (const webhook_receiver of webhook_receivers) {
          try {
            const { data } = await firstValueFrom(
              this.httpService.post(webhook_receiver.payload.url, {
                content: JSON.stringify({
                  messages,
                  leadName: session.lead.name || "Unknown",
                  leadEmail: session.lead.email || "Unknown",
                  leadCompany: session.lead.company || "Unknown",
                  recipients,
                  bot: session.bot[0].name,
                  organization: session.organization[0].name,
                  session: session._id,
                }),
              })
            );
          } catch (err) {}
        }
      }

      if (session.organization[0].webhookURL) {
        // send webhook
        try {
          if (
            session.organization[0].webhookURL &&
            session.organization[0].plan !== PlanType.BASIC
          ) {
            const { data } = await firstValueFrom(
              this.httpService.post(session.organization[0].webhookURL, {
                content: JSON.stringify({
                  messages,
                  leadName: session.lead.name || "Unknown",
                  leadEmail: session.lead.email || "Unknown",
                  leadCompany: session.lead.company || "Unknown",
                  recipients,
                  bot: session.bot[0].name,
                  organization: session.organization[0].name,
                  session: session._id,
                }),
              })
            );
          }
        } catch (err) {}
      }

      // send email notifications for the last session
      if (index === sessions.length - 1) {
        // start sending email notifications
        emailNotifications.forEach((emailContent) => {
          // send email to each recipient
          emailContent.recipients.forEach((recipient) => {
            const last_message_from_user = emailContent.messages
              .filter((m) => m.sender === 'USER')
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];

            try {
              // send the email
              sendTemplateMail('new-conversation', recipient, {
                organization: emailContent.organization,
                organization_id: emailContent.organization_id,
                bot: emailContent.bot,
                bot_id: emailContent.bot_id,
                session: emailContent.session,
                leadName: emailContent.leadName,
                leadEmail: emailContent.leadEmail,
                leadCompany: emailContent.leadCompany,
                messages: emailContent.messages,
                subject: `New conversation activity: ${last_message_from_user.content.length > 36 ? last_message_from_user.content.substring(0, 36) : last_message_from_user.content}...`
              });
            } catch (e) {}
          });
        });

        // update the notificationSent field in the message model
        this.messageModel
          .updateMany(
            { notificationSent: { $ne: true } },
            { notificationSent: true }
          )
          .then(() => {
            this.logger.debug(
              `Notification sent for session ${emailContent.session}`
            );
          });
      }
    });
  }
}
