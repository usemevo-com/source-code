import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import {
  Organization,
  OrganizationSchema,
} from "../organizations/entities/organization.schema";
import { NotificationManagerService } from "./notification-manager.service";
import { Bot, BotSchema } from "src/bots/entities/bot.schema";
import { Message, MessageSchema } from "src/bots/entities/message.schema";
import { User, UserSchema } from "src/users/entities/user.schema";
import { HttpModule } from "@nestjs/axios";
import {
  NotificationReceiver,
  NotificationReceiverSchema,
} from "src/bots/entities/notification-receiver.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Organization.name, schema: OrganizationSchema },
      { name: Bot.name, schema: BotSchema },
      { name: Message.name, schema: MessageSchema },
      { name: User.name, schema: UserSchema },
      { name: NotificationReceiver.name, schema: NotificationReceiverSchema },
    ]),
    HttpModule,
  ],
  providers: [NotificationManagerService],
})
export class NotificationManagerModule {}
